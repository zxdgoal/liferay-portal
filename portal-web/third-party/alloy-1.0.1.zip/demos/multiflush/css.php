<?php
sleep(2);

header("Content-Type: text/css");

$n = $_REQUEST["n"];
?>

#portlet<?= $n ?> {
	border: 10px solid #ccc;
	font-size: 16px;
}