# AUI Timer

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master/src/aui-timer).

## @VERSION@

No registries yet.

## [2.5.0](https://github.com/liferay/alloy-ui/releases/tag/2.5.0)

No changes.