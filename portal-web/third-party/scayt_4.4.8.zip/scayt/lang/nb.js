﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'nb', {
	btn_about: 'Om SCAYT',
	btn_dictionaries: 'Ordbøker',
	btn_disable: 'Slå av SCAYT',
	btn_enable: 'Slå på SCAYT',
	btn_langs:'Språk',
	btn_options: 'Valg',
	text_title:  'Stavekontroll mens du skriver'
});
