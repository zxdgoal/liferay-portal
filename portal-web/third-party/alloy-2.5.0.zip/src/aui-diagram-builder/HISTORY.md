aui-diagram-builder
========

@VERSION@
------
	* #AUI-1158 - AUI Diagram Builder connections jump if diagram area is scrollable