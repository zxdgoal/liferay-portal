aui-button
========

@VERSION@
------

	* #AUI-1161 - Aui-search-button should follow input on window resize and when moved in DOM