AUI.add('tooltip', function(A) {

var L = A.Lang,
	isString = L.isString,

	TOOLTIP = 'tooltip';

function Tooltip(config) {
 	Tooltip.superclass.constructor.apply(this, arguments);
}

A.mix(Tooltip, {
	NAME: TOOLTIP,

	ATTRS: {

	}
});

A.extend(Tooltip, A.ContextOverlay, {

});

A.Tooltip = Tooltip;

}, '0.1a', { requires: [ 'context-overlay' ] });