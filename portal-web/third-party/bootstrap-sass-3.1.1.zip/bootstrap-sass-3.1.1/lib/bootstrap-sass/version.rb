module Bootstrap
  VERSION = '3.1.1.0'
  BOOTSTRAP_SHA = '385fb6898128bbfdc3def581bb92e01818fa0525'
end
