﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'hr', {
	btn_about: 'O SCAYT',
	btn_dictionaries: 'Rječnici',
	btn_disable: 'Onemogući SCAYT',
	btn_enable: 'Omogući SCAYT',
	btn_langs:'Jezici',
	btn_options: 'Opcije',
	text_title:  'Provjeri pravopis tijekom tipkanja (SCAYT)'
});
