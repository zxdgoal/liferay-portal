﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'eo', {
	btnIgnore: 'Ignori',
	btnIgnoreAll: 'Ignori Ĉion',
	btnReplace: 'Anstataŭigi',
	btnReplaceAll: 'Anstataŭigi Ĉion',
	btnUndo: 'Malfari',
	changeTo: 'Ŝanĝi al',
	errorLoading: 'Eraro en la servoelŝuto el la gastiga komputiko: %s.',
	ieSpellDownload: 'Ortografikontrolilo ne instalita. Ĉu vi volas elŝuti ĝin nun?',
	manyChanges: 'Ortografikontrolado finita: %1 vortoj korektitaj',
	noChanges: 'Ortografikontrolado finita: neniu vorto korektita',
	noMispell: 'Ortografikontrolado finita: neniu eraro trovita',
	noSuggestions: '- Neniu propono -',
	notAvailable: 'Bedaŭrinde la servo ne funkcias nuntempe.',
	notInDic: 'Ne trovita en la vortaro',
	oneChange: 'Ortografikontrolado finita: unu vorto korektita',
	progress: 'La ortografio estas kontrolata...',
	title: 'Kontroli la ortografion',
	toolbar: 'Kontroli la ortografion'
});
