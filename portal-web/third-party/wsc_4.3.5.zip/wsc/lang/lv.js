﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'lv', {
	btnIgnore: 'Ignorēt',
	btnIgnoreAll: 'Ignorēt visu',
	btnReplace: 'Aizvietot',
	btnReplaceAll: 'Aizvietot visu',
	btnUndo: 'Atcelt',
	changeTo: 'Nomainīt uz',
	errorLoading: 'Kļūda ielādējot aplikācijas servisa adresi: %s.',
	ieSpellDownload: 'Pareizrakstības pārbaudītājs nav pievienots. Vai vēlaties to lejupielādēt tagad?',
	manyChanges: 'Pareizrakstības pārbaude pabeigta: %1 vārdi tika mainīti',
	noChanges: 'Pareizrakstības pārbaude pabeigta: nekas netika labots',
	noMispell: 'Pareizrakstības pārbaude pabeigta: kļūdas netika atrastas',
	noSuggestions: '- Nav ieteikumu -',
	notAvailable: 'Atvainojiet, bet serviss šobrīd nav pieejams.',
	notInDic: 'Netika atrasts vārdnīcā',
	oneChange: 'Pareizrakstības pārbaude pabeigta: 1 vārds izmainīts',
	progress: 'Notiek pareizrakstības pārbaude...',
	title: 'Pārbaudīt gramatiku',
	toolbar: 'Pareizrakstības pārbaude'
});
