﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'mn', {
	btnIgnore: 'Зөвшөөрөх',
	btnIgnoreAll: 'Бүгдийг зөвшөөрөх',
	btnReplace: 'Солих',
	btnReplaceAll: 'Бүгдийг Дарж бичих',
	btnUndo: 'Буцаах',
	changeTo: 'Өөрчлөх',
	errorLoading: 'Error loading application service host: %s.',
	ieSpellDownload: 'Дүрэм шалгагч суугаагүй байна. Татаж авахыг хүсч байна уу?',
	manyChanges: 'Дүрэм шалгаад дууссан: %1 үг өөрчлөгдсөн',
	noChanges: 'Дүрэм шалгаад дууссан: үг өөрчлөгдөөгүй',
	noMispell: 'Дүрэм шалгаад дууссан: Алдаа олдсонгүй',
	noSuggestions: '- Тайлбаргүй -',
	notAvailable: 'Sorry, but service is unavailable now.',
	notInDic: 'Толь бичиггүй',
	oneChange: 'Дүрэм шалгаад дууссан: 1 үг өөрчлөгдсөн',
	progress: 'Дүрэм шалгаж байгаа үйл явц...',
	title: 'Spell Checker',
	toolbar: 'Үгийн дүрэх шалгах'
});
