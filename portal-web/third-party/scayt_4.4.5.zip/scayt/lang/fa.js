﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'fa', {
	btn_about: 'درباره SCAYT',
	btn_dictionaries: 'دیکشنریها',
	btn_disable: 'غیرفعالسازی SCAYT',
	btn_enable: 'فعالسازی SCAYT',
	btn_langs:'زبانها',
	btn_options: 'گزینهها',
	text_title: ''
});
