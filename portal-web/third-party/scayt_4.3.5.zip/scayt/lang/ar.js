﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'ar', {
	about: 'عن SCAYT',
	aboutTab: 'عن',
	addWord: 'إضافة كلمة',
	allCaps: 'Ignore All-Caps Words', // MISSING
	dic_create: 'Create', // MISSING
	dic_delete: 'Delete', // MISSING
	dic_field_name: 'Dictionary name', // MISSING
	dic_info: 'Initially the User Dictionary is stored in a Cookie. However, Cookies are limited in size. When the User Dictionary grows to a point where it cannot be stored in a Cookie, then the dictionary may be stored on our server. To store your personal dictionary on our server you should specify a name for your dictionary. If you already have a stored dictionary, please type its name and click the Restore button.', // MISSING
	dic_rename: 'Rename', // MISSING
	dic_restore: 'Restore', // MISSING
	dictionariesTab: 'قواميس',
	disable: 'تعطيل SCAYT',
	emptyDic: 'اسم القاموس يجب ألا يكون فارغاً.',
	enable: 'تفعيل SCAYT',
	ignore: 'تجاهل',
	ignoreAll: 'تجاهل الكل',
	ignoreDomainNames: 'Ignore Domain Names', // MISSING
	langs: 'لغات',
	languagesTab: 'لغات',
	mixedCase: 'Ignore Words with Mixed Case', // MISSING
	mixedWithDigits: 'Ignore Words with Numbers', // MISSING
	moreSuggestions: 'المزيد من المقترحات',
	opera_title: 'Not supported by Opera', // MISSING
	options: 'خيارات',
	optionsTab: 'خيارات',
	title: 'تدقيق إملائي أثناء الكتابة',
	toggle: 'تثبيت SCAYT',
	noSuggestions: 'No suggestion'
});
