﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'uk', {
	btn_about: 'Про SCAYT',
	btn_dictionaries: 'Словники',
	btn_disable: 'Вимкнути SCAYT',
	btn_enable: 'Ввімкнути SCAYT',
	btn_langs:'Мови',
	btn_options: 'Опції',
	text_title: ''
});
