﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'ru', {
	btnIgnore: 'Пропустить',
	btnIgnoreAll: 'Пропустить всё',
	btnReplace: 'Заменить',
	btnReplaceAll: 'Заменить всё',
	btnUndo: 'Отменить',
	changeTo: 'Изменить на',
	errorLoading: 'Произошла ошибка при подключении к серверу проверки орфографии: %s.',
	ieSpellDownload: 'Модуль проверки орфографии не установлен. Хотите скачать его?',
	manyChanges: 'Проверка орфографии завершена. Изменено слов: %1',
	noChanges: 'Проверка орфографии завершена. Не изменено ни одного слова',
	noMispell: 'Проверка орфографии завершена. Ошибок не найдено',
	noSuggestions: '- Варианты отсутствуют -',
	notAvailable: 'Извините, но в данный момент сервис недоступен.',
	notInDic: 'Отсутствует в словаре',
	oneChange: 'Проверка орфографии завершена. Изменено одно слово',
	progress: 'Орфография проверяется...',
	title: 'Проверка орфографии',
	toolbar: 'Проверить орфографию'
});
