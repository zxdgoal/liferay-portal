﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'hu', {
	copy: 'Copyright &copy; $1. Minden jog fenntartva.',
	dlgTitle: 'CKEditor névjegy',
	help: 'Itt találsz segítséget: $1',
	moreInfo: 'Licenszelési információkért kérjük látogassa meg weboldalunkat:',
	title: 'CKEditor névjegy',
	userGuide: 'CKEditor Felhasználói útmutató'
});
