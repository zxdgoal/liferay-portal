# AUI Palette

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master/src/aui-palette).

## @VERSION@

No registries yet.

## [2.5.0](https://github.com/liferay/alloy-ui/releases/tag/2.5.0)

* [AUI-1163](https://issues.liferay.com/browse/AUI-1163) Remove unnecessary constants
* [AUI-1033](https://issues.liferay.com/browse/AUI-1033) Palette does not accept objects as items