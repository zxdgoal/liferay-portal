﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'sk', {
	about: 'O KPPP (Kontrola pravopisu počas písania)',
	aboutTab: 'O',
	addWord: 'Pridať slovo',
	allCaps: 'Ignorovať slová písané veľkými písmenami',
	dic_create: 'Vytvoriť',
	dic_delete: 'Vymazať',
	dic_field_name: 'Názov slovníka',
	dic_info: 'Spočiatku je užívateľský slovník uložený v cookie. Cookie však majú obmedzenú veľkosť. Keď užívateľský slovník narastie do bodu, kedy nemôže byť uložený v cookie, potom musí byť slovník uložený na našom serveri. Pre uloženie vášho osobného slovníka na náš server by ste mali zadať názov pre váš slovník. Ak už máte uložený slovník, prosíme, napíšte jeho názov a kliknite tlačidlo Obnoviť.',
	dic_rename: 'Premenovať',
	dic_restore: 'Obnoviť',
	dictionariesTab: 'Slovníky',
	disable: 'Zakázať  KPPP (Kontrola pravopisu počas písania)',
	emptyDic: 'Názov slovníka by nemal byť prázdny.',
	enable: 'Povoliť KPPP (Kontrola pravopisu počas písania)',
	ignore: 'Ignorovať',
	ignoreAll: 'Ignorovať všetko',
	ignoreDomainNames: 'Iznorovať názvy domén',
	langs: 'Jazyky',
	languagesTab: 'Jazyky',
	mixedCase: 'Ignorovať slová so smiešanými veľkými a malými písmenami',
	mixedWithDigits: 'Ignorovať slová s číslami',
	moreSuggestions: 'Viac návrhov',
	opera_title: 'Nepodporované Operou',
	options: 'Možnosti',
	optionsTab: 'Možnosti',
	title: 'Kontrola pravopisu počas písania',
	toggle: 'Prepnúť KPPP (Kontrola pravopisu počas písania)',
	noSuggestions: 'No suggestion'// MISSING
});
