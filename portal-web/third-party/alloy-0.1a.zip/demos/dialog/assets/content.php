<?php

var_export($_REQUEST);

?>