AUI.add('date-picker-select', function(A) {

var L = A.Lang,
	isString = L.isString,
	isObject = L.isObject,
	isBoolean = L.isBoolean,
	isNumber = L.isNumber,
	isUndefined = L.isUndefined,

	BODY = 'body',
	BUTTON = 'button',
	CALENDAR = 'calendar',
	CLEARFIX = 'clearfix',
	DATEPICKER = 'datepicker',
	DAY_ELEMENT = 'dayElement',
	DEFAULT = 'default',
	DISPLAY = 'display',
	DISPLAY_BOUNDING_BOX = 'displayBoundingBox',
	DOT = '.',
	HELPER = 'helper',
	ICON = 'icon',
	MONTH_ELEMENT = 'monthElement',
	OPTION = 'option',
	SELECT = 'select',
	SELECTED = 'selected',
	STATE = 'state',
	TOOL = 'tool',
	TRIGGER = 'trigger',
	VALUE = 'value',
	WRAPPER = 'wrapper',
	YEAR_ELEMENT = 'yearElement',
	YEAR_RANGE = 'yearRange',
	BLANK = '',

	getCN = A.ClassNameManager.getClassName,

	CSS_DATEPICKER_BUTTON_WRAPPER = getCN(DATEPICKER, BUTTON, WRAPPER),
	CSS_DATEPICKER_DISPLAY = getCN(DATEPICKER, DISPLAY),
	CSS_DATEPICKER_DISPLAY_SELECT = getCN(DATEPICKER, DISPLAY, SELECT),
	CSS_DATEPICKER_SELECT_WRAPPER = getCN(DATEPICKER, SELECT, WRAPPER),
	CSS_HELPER_CLEARFIX = getCN(HELPER, CLEARFIX),
	CSS_ICON = getCN(ICON),
	CSS_ICON_CALENDAR = getCN(ICON, CALENDAR),
	CSS_STATE_DEFAULT = getCN(STATE, DEFAULT),
	CSS_TOOL = getCN(TOOL),

	SELECT_TPL = '<select></select>',
	SELECT_OPTION_TPL = '<option></option>',

	WRAPPER_BUTTON_TPL = '<div class="'+ CSS_DATEPICKER_BUTTON_WRAPPER +'"></div>',
	WRAPPER_SELECT_TPL = '<div class='+ CSS_DATEPICKER_SELECT_WRAPPER +'></div>';

function DatePickerSelect(config) {
	DatePickerSelect.superclass.constructor.apply(this, arguments);
}

A.mix(DatePickerSelect, {
	NAME: DATEPICKER,

	ATTRS: {
		displayBoundingBox: {
			value: null
		},

		yearElement: {
			value: A.Node.create(SELECT_TPL),
			setter: function(v) {
				return A.get(v);
			}
		},

		monthElement: {
			value: A.Node.create(SELECT_TPL),
			setter: function(v) {
				return A.get(v);
			}
		},

		dayElement: {
			value: A.Node.create(SELECT_TPL),
			setter: function(v) {
				return A.get(v);
			}
		},

		trigger: {
			value: A.Node.create(WRAPPER_BUTTON_TPL)
		},

		visible: {
			value: false
		},

		yearRange: {
			value: 10,
			validator: isNumber
		},

		setValue: {
			value: false
		}
	}
});

A.extend(DatePickerSelect, A.Calendar, {
	/*
	* Lifecycle
	*/
	renderUI: function() {
		var instance = this;

		DatePickerSelect.superclass.renderUI.apply(this, arguments);

		instance._renderElements();
		instance._renderButton();
	},

	bindUI: function() {
		var instance = this;

		DatePickerSelect.superclass.bindUI.apply(this, arguments);

		// instance.after('select', A.bind(instance._afterSelectDate, instance));
		instance.after('datesChange', A.bind(instance._afterSelectDate, instance));
	},

	syncUI: function() {
		var instance = this;

		DatePickerSelect.superclass.syncUI.apply(this, arguments);

		instance._syncSelects();
	},

	_syncSelects: function() {
		var instance = this;
		var currentDate = instance.getCurrentDate();
		var currentDay = currentDate.getDate();
		var currentMonth = currentDate.getMonth();
		var currentYear = currentDate.getFullYear();

		instance._populateDays(currentDay, currentMonth);
		instance._populateMonths(currentMonth);
		instance._populateYears(currentYear);
	},

	_renderElements: function() {
		var instance = this;
		var displayBoundingBox = instance.get(DISPLAY_BOUNDING_BOX);

		instance._buttonItem = new A.ToolItem(CALENDAR);
		instance._selectWrapper = A.Node.create(WRAPPER_SELECT_TPL);

		displayBoundingBox.addClass(CSS_DATEPICKER_DISPLAY);
		displayBoundingBox.addClass(CSS_HELPER_CLEARFIX);

		instance._selectWrapper.append( instance.get(MONTH_ELEMENT) );
		instance._selectWrapper.append( instance.get(DAY_ELEMENT) );
		instance._selectWrapper.append( instance.get(YEAR_ELEMENT) );

		displayBoundingBox.append( instance._selectWrapper );
	},

	_renderButton: function() {
		var instance = this;
		var trigger = instance.get(TRIGGER).item(0);
		var displayBoundingBox = instance.get(DISPLAY_BOUNDING_BOX);

		displayBoundingBox.append(trigger);

		if ( trigger.test(DOT+CSS_DATEPICKER_BUTTON_WRAPPER) ) {
			// use ToolItem if the user doesn't specify a trigger
			instance._buttonItem.render(trigger);
		}
	},

	/*
	* Methods
	*/
	_populateYears: function(year) {
		var instance = this;
		var yearRange = instance.get(YEAR_RANGE);
		var yearElement = instance.get(YEAR_ELEMENT);

		instance._populate(yearElement, (year - yearRange), (year + yearRange), year);
	},

	_populateMonths: function(month) {
		var instance = this;
		var monthElement = instance.get(MONTH_ELEMENT);
		var localeMap = instance._getLocaleMap();
		var monthLabels = localeMap.B;

		instance._populate(monthElement, 0, (monthLabels.length - 1), month, monthLabels);
	},

	_populateDays: function(day, month) {
		var instance = this;
		var dayElement = instance.get(DAY_ELEMENT);
		var daysInMonth = instance.getDaysInMonth(month);

		instance._populate(dayElement, 1, daysInMonth, day);
	},

	_populate: function(select, fromIndex, toIndex, selectedValue, labels, values) {
		var instance = this;
		var index = fromIndex;

		select.empty();

		while (index <= toIndex) {
			var value = index;
			var label = index;
			var option = A.Node.create(SELECT_OPTION_TPL);

			if (values) {
				value = values[index];
			}

			if (labels) {
				label = labels[index];
			}

			select.append(
				option.html(label).val(value)
			);

			index++;
		}

		instance.selectByValue(select, selectedValue);

	},

	selectByValue: function(select, value) {
		var instance = this;
		var options = select.all(OPTION);

		options.each(function(option, index) {
			var v = BLANK;

			if (option.val() == value) {
				v = SELECTED;
			}

			option.attr(SELECTED, v);
		});
	},

	/*
	* Listeners
	*/

	_afterSelectDate: function(event) {
		var instance = this;

		console.log(event);

		instance._syncSelects();
	},

	/*
	* Setters
	*/

	_setDates: function(v) {
		var instance = this;

		DatePickerSelect.superclass._setDates.apply(this, arguments);
console.log(v);
		instance._syncSelects();

		return v;
	},
});

A.DatePickerSelect = DatePickerSelect;

}, '0.1a', { requires: [ 'calendar', 'tool-item' ] });