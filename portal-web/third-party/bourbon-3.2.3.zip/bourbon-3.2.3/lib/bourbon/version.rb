module Bourbon
  VERSION = "3.2.3"
end
