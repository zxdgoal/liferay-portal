0.3.0
Issue #219 removes the event 'imageDrop' when user D&D image inside the editor. Instead, an event 'imageAdd' will be fired.