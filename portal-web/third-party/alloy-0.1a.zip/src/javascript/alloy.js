/*
 * Alloy JavaScript Library v0.1
 * http://alloyui.com/
 *
 * Copyright (c) 2009 Liferay Inc.
 * Licensed under the MIT license.
 * http://alloyui.com/License
 *
 * Date: @DATE
 * Revision: @REVISION
 */

;(function() {
	var PATH_BASE = YUI.config.base + '../../../';
	var PATH_JAVASCRIPT = PATH_BASE + 'src/javascript/';
	var PATH_THEME_ROOT = PATH_BASE + 'themes/base/css/';

	window.AUI = {
		defaults: {
			classNamePrefix: 'aui',

			//base: '',

			defaultModules: [ 'aui-base' ],

			filter: 'raw',

			modules: {

				/*
				* AUI Base modules
				*/
				'aui-base': {
					fullpath: PATH_JAVASCRIPT + 'base.js',
					requires: [ 'event', 'oop', 'widget', 'aui-node' ]
				},

				/*
				* AutoComplete
				*/
				'autocomplete': {
					fullpath: PATH_JAVASCRIPT + 'autocomplete.js',
					requires: [ 'aui-base', 'overlay', 'datasource', 'dataschema', 'tool-item', 'autocomplete-css' ]
				},
				'autocomplete-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'autocomplete.css',
					type: 'css'
				},

				/*
				* Editable
				*/
				'editable': {
					fullpath: PATH_JAVASCRIPT + 'editable.js',
					requires: [ 'aui-base', 'editable-css', 'tool-item' ]
				},
				'editable-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'editable.css',
					type: 'css'
				},

				/*
				* Rating
				*/
				'rating': {
					fullpath: PATH_JAVASCRIPT + 'rating.js',
					requires: [ 'aui-base', 'rating-css' ]
				},
				'rating-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'rating.css',
					type: 'css'
				},

				/*
				* Tool Item
				*/
				'tool-item': {
					fullpath: PATH_JAVASCRIPT + 'tool-item.js',
					requires: [ 'aui-base', 'state-interaction' ]
				},

				/*
				* ContextPanel
				*/
				'context-panel': {
					fullpath: PATH_JAVASCRIPT + 'context-panel.js',
					requires: [ 'context-overlay', 'context-panel-css' ]
				},
				'context-panel-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'context-panel.css',
					type: 'css'
				},

				/*
				* Tooltip
				*/
				'tooltip': {
					fullpath: PATH_JAVASCRIPT + 'tooltip.js',
					requires: [ 'context-overlay', 'tooltip-css' ]
				},
				'tooltip-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'tooltip.css',
					type: 'css'
				},

				/*
				* Dialog
				*/
				'dialog': {
					fullpath: PATH_JAVASCRIPT + 'dialog.js',
					requires: [ 'plugin', 'overlay', 'dd-constrain', 'aui-base', 'tool-item', 'overlay-manager', 'io-stdmod', 'dialog-css' ]
				},
				'dialog-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'dialog.css',
					type: 'css'
				},

				/*
				* Tabs
				*/
				'tabs': {
					fullpath: PATH_JAVASCRIPT + 'tabs.js',
					requires: ['widget', 'state-interaction', 'tabs-css']
				},
				'tabs-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'tabs.css',
					type: 'css'
				},

				/*
				* Resize
				*/
				'resize': {
					fullpath: PATH_JAVASCRIPT + 'resize.js',
					requires: [ 'aui-base', 'dd', 'resize-css' ]
				},
				'resize-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'resize.css',
					type: 'css'
				},
				'resize-plugin': {
					fullpath: PATH_JAVASCRIPT + 'resize.js',
					requires: [ 'resize' ]
				},

				/*
				* ContextOverlay
				*/
				'context-overlay': {
					fullpath: PATH_JAVASCRIPT + 'context-overlay.js',
					requires: [ 'aui-base', 'overlay', 'delayed-task' ]
				},

				/*
				* OverlayManager
				*/
				'overlay-manager': {
					fullpath: PATH_JAVASCRIPT + 'overlay-manager.js',
					requires: [ 'aui-base', 'overlay', 'plugin' ]
				},

				/*
				* OverlayMask
				*/
				'overlay-mask': {
					fullpath: PATH_JAVASCRIPT + 'overlay-mask.js',
					requires: [ 'aui-base', 'overlay', 'plugin' ]
				},

				/*
				* StdModIOPlugin
				*/
				'io-stdmod': {
					fullpath: PATH_JAVASCRIPT + 'io-stdmod.js',
					requires: [ 'aui-base', 'overlay', 'io', 'plugin' ]
				},

				/*
				* State Interaction plugin
				*/
				'state-interaction': {
					fullpath: PATH_JAVASCRIPT + 'state-interaction.js',
					requires: [ 'aui-base', 'plugin' ]
				}
			}
		}
	}
})();;(function() {

	// Based on jQuery.extend
	var extend = function() {
		// copy reference to target object
		var target = arguments[0] || {}, i = 1, length = arguments.length, deep = false, options, toString = Object.prototype.toString;

		var isFunction = function( obj ) {
			return toString.call(obj) === "[object Function]";
		};

		// Handle a deep copy situation
		if ( typeof target === "boolean" ) {
			deep = target;
			target = arguments[1] || {};
			// skip the boolean and the target
			i = 2;
		}

		// Handle case when target is a string or something (possible in deep copy)
		if ( typeof target !== "object" && !isFunction(target) ) {
			target = {};
		}

		// extend Object itself if only one argument is passed
		if ( length == i ) {
			target = this;
			--i;
		}

		for ( ; i < length; i++ ) {
			// Only deal with non-null/undefined values
			if ( (options = arguments[ i ]) != null ) {
				// Extend the base object
				for ( var name in options ) {
					var src = target[ name ], copy = options[ name ];

					// Prevent never-ending loop
					if ( target === copy ) {
						continue;
					}

					// Recurse if we're merging object values
					if ( deep && copy && typeof copy === "object" && !copy.nodeType ) {
						target[ name ] = extend( deep,
							// Never move original objects, clone them
							src || ( copy.length != null ? [ ] : { } )
						, copy );
					}
					// Don't bring in undefined values
					else if ( copy !== undefined ) {
						target[ name ] = copy;
					}

				}
			}
		}

		// Return the modified object
		return target;
	};

	var getBasePath = function () {
		var nodes = document.getElementsByTagName('script');
		var yuiRE = /^(.*)yui[\.-].*js(\?.*)?$/;
		var length = nodes.length;
		var node, match, base;

		while(length--) {
			node = nodes[length];
			match = node.src && node.src.match(yuiRE);
			base = match && match[1];

			if (base) {
				base = base.substring(0, base.length - 4);

				break;
			}
		}

		return base;
	};

	/*
	 * Alloy JavaScript Library v0.1a
	 * http://alloyui.com/
	 *
	 * Copyright (c) 2009 Liferay Inc.
	 * Licensed under the MIT license.
	 * http://alloyui.com/License
	 *
	 * Nate Cavanaugh (nate.cavanaugh@liferay.com)
	 * Eduardo Lundgren (eduardo.lundgren@liferay.com)
	 *
	 * Date: @DATE
	 * Revision: @REVISION
	 */

	window.AUI = window.AUI || {};

	var defaults = AUI.defaults || {};
	var defaultModules = defaults.defaultModules || [];

	// extending YUI prototype
	extend(YUI.prototype, {
		ready: function() {
			var instance = this;

			var slice = Array.prototype.slice;
			var args = slice.call(arguments, 0), index = args.length - 1;

			// user callback
			var fn = args[index];

			// array with YUI modules to be loaded
			var modules = slice.call(arguments, 0, index);

			if (!modules.length) {
				modules.push('event');
			}

			// adding AUI().use() callback
			modules.push(
				function(instance) {
					var args = arguments;
					instance.on('domready', function() {
					   fn.apply(this, args);
					});
				}
			);

			instance.use.apply(instance, modules);
		},

		toQueryString: function(obj) {
			var instance = this;

			var Lang = instance.Lang;
			var isArray = Lang.isArray;
			var isFunction = Lang.isFunction;

			var buffer = [];
			var isNodeList = false;

			if (isArray(obj) || (isNodeList = (instance.NodeList && (obj instanceof instance.NodeList)))) {
				if (isNodeList) {
					obj = instance.NodeList.getDOMNodes(obj);
				}

				var length = obj.length;

				for (var i=0; i < length; i++) {
					var el = obj[i];

					buffer.push(encodeURIComponent(el.name) + '=' + encodeURIComponent(el.value));
				}
			}
			else {
				for (var i in obj){
					var value = obj[i];

					if (isArray(value)) {
						var vlength = value.length;

						for (var j = 0; j < vlength; j++) {
							buffer.push(encodeURIComponent(i) + '=' + encodeURIComponent(value[j]));
						}
					}
					else {
						if (isFunction(value)) {
							value = value();
						}

						buffer.push(encodeURIComponent(i) + '=' + encodeURIComponent(value));
					}
				}
			}

			return buffer.join('&').replace(/%20/g, '+');
		}
	});

	var ALLOY = YUI( extend({}, defaults) );

	var originalConfig = ALLOY.config;

	// adding callback for .use()
	defaultModules.push(
		function(A, result) {
			if (!result.success) {
				throw result.msg;
			}
		}
	);

	// loading default modules
	ALLOY.use.apply(ALLOY, defaultModules);

	AUI = function(o) {
		var instance = this;

		ALLOY.config = ALLOY.merge(originalConfig, AUI.defaults);

		if (o || instance instanceof AUI) {
			// new AUI() creates a new YUI sandbox
			return YUI( ALLOY.merge(ALLOY.config, o) );
		}

		// returns the cached YUI sandbox
		return ALLOY;
	};

	extend(
		AUI,
		YUI,
		{
			__version: '0.1a',

			extend: extend,

			defaults: defaults
		}
	);

	/*
	* AUI support constants
	*/
	AUI.support = {
		scriptEval: false
	};

	var checkScriptEvalSupport = function() {
		var root = document.documentElement;
		var script = document.createElement("script");

		var TYPE = 'text/javascript',
			TPL_EVAL_SCRIPT_TRUE = 'AUI.support.scriptEval = true;';

		script.type = TYPE;

		try {
			script.appendChild(document.createTextNode(TPL_EVAL_SCRIPT_TRUE));
			root.insertBefore(script, root.firstChild);
			root.removeChild(script);
		}
		catch(e) {
		}
	};

	checkScriptEvalSupport();

	/*
		UA extensions
	*/

	var UA = ALLOY.UA;

	var p = navigator.platform;
	var u = navigator.userAgent;
	var b = /(Firefox|Opera|Safari|KDE|iCab|Flock|IE)/.exec(u);
	var os = /(Win|Mac|Linux|iPhone|Sun|Solaris)/.exec(p);
	var versionDefaults = [0,0];

	b = (!b || !b.length) ? (/(Mozilla)/.exec(u) || ['']) : b;
	os = (!os || !os.length) ? [''] : os;

	extend(
		UA,
		{
			gecko: /Gecko/.test(u) && !/like Gecko/.test(u),
			webkit: /WebKit/.test(u),

			aol: /America Online Browser/.test(u),
			camino: /Camino/.test(u),
			firefox: /Firefox/.test(u),
			flock: /Flock/.test(u),
			icab: /iCab/.test(u),
			konqueror: /KDE/.test(u),
			mozilla: /mozilla/.test(u),
			ie: /MSIE/.test(u),
			netscape: /Netscape/.test(u),
			opera: /Opera/.test(u),
			safari: /Safari/.test(u),
			browser: b[0].toLowerCase(),

			win: /Win/.test(p),
			mac: /Mac/.test(p),
			linux: /Linux/.test(p),
			iphone: /iPhone/.test(p),
			sun: /Solaris|SunOS/.test(p),
			os: os[0].toLowerCase(),

			platform: p,
			agent: u
		}
	);

	UA.version = {
		string: ''
	};

	if (UA.ie) {
		UA.version.string = (/MSIE ([^;]+)/.exec(u) || versionDefaults)[1];
	}
	else if (UA.firefox) {
		UA.version.string = (/Firefox\/(.+)/.exec(u) || versionDefaults)[1];
	}
	else if (UA.safari) {
		UA.version.string = (/Version\/([^\s]+)/.exec(u) || versionDefaults)[1];
	}
	else if (UA.opera) {
		UA.version.string = (/Opera\/([^\s]+)/.exec(u) || versionDefaults)[1];
	}

	UA.version.number = parseFloat(UA.version.string) || versionDefaults[0];
	UA.version.major = (/([^\.]+)/.exec(UA.version.string) || versionDefaults)[1];

	UA[UA.browser + UA.version.major] = true;

	UA.renderer = '';

	if (UA.ie) {
		UA.renderer = 'trident';
	}
	else if (UA.gecko) {
		UA.renderer = 'gecko';
	}
	else if (UA.webkit) {
		UA.renderer = 'webkit';
	}
	else if (UA.opera) {
		UA.renderer = 'presto';
	}

	/*
		Browser selectors
	*/

	var selectors = [
		UA.renderer,
		UA.browser,
		UA.browser + UA.version.major,
		UA.os,
		'js'
	];

	if (UA.os == 'macintosh') {
		selectors.push('mac');
	}
	else if (UA.os == 'windows') {
		selectors.push('win');
	}

	if (UA.mobile) {
		selectors.push('mobile');
	}

	if (UA.secure) {
		selectors.push('secure');
	}

	UA.selectors = selectors.join(' ');

	document.getElementsByTagName('html')[0].className += ' ' + UA.selectors;
})();AUI.add('autocomplete', function(A) {

var Lang = A.Lang,
	isArray = Lang.isArray,
	isString = Lang.isString,
	isNull = Lang.isNull,
	isFunction = Lang.isFunction,

	getClassName = A.ClassNameManager.getClassName,

	ALERT = 'alert',
	CIRCLE = 'circle',
	CONTENT = 'content',
	HELPER = 'helper',
	ICON = 'icon',
	INPUT = 'input',
	ITEM = 'item',
	LIST = 'list',
	LOADING = 'loading',
	NAME = 'autocomplete',
	NO = 'no',
	RESET = 'reset',
	RESULTS = 'results',
	S = 's',
	SELECTED = 'selected',
	TRIANGLE = 'triangle',
	TRIGGER = 'trigger',

	ICON_DEFAULT = 'circle-triangle-b',
	ICON_ERROR = ALERT,
	ICON_LOADING = LOADING,

	CSS_BUTTON_TRIGGER = getClassName(NAME, TRIGGER),
	CSS_HIGLIGHT = getClassName(NAME, SELECTED),
	CSS_ICON_BUTTON_TRIGGER = getClassName(NAME, TRIGGER, ICON),
	CSS_INPUT = getClassName(NAME, INPUT),
	CSS_LIST_ITEM = getClassName(NAME, LIST, ITEM),
	CSS_NO_RESULTS = getClassName(NAME, NO, RESULTS),
	CSS_RESULTS_LIST = getClassName(HELPER, RESET),
	CSS_RESULTS_OVERLAY = getClassName(NAME, RESULTS),
	CSS_RESULTS_OVERLAY_CONTENT = getClassName(NAME, RESULTS, CONTENT),

	KEY_BACKSPACE = 8,
	KEY_TAB = 9,
	KEY_ENTER = 13,
	KEY_SHIFT = 16,
	KEY_CTRL = 17,
	KEY_ALT = 18,
	KEY_CAPS_LOCK = 20,
	KEY_ESC = 27,
	KEY_PAGEUP = 33,
	KEY_END = 35,
	KEY_HOME = 36,
	KEY_UP = 38,
	KEY_DOWN = 40,
	KEY_RIGHT = 39,
	KEY_LEFT = 37,
	KEY_PRINT_SCREEN = 44,
	KEY_INSERT = 44,
	KEY_KOREAN_IME = 229,

	OVERLAY_ALIGN = {
		node: null,
		points: ['tl', 'bl']
	},

	TPL_INPUT = '<input type="text" />',
	TPL_INPUT_WRAPPER = '<span class="aui-ctrl-holder"></span>',

	BLANK = '',
	BOUNDING_BOX = 'boundingBox',
	CONTENT_BOX = 'contentBox';

	var AutoComplete = function() {
		AutoComplete.superclass.constructor.apply(this, arguments);
	};

	AutoComplete.NAME = NAME;

	AutoComplete.ATTRS = {

		allowBrowserAutocomplete: {
			value: true
		},

		alwaysShowContainer: {
			value: false
		},

		autoHighlight: {
			value: true
		},

		applyLocalFilter: {
			value: null
		},

		button: {
			value: true
		},

		dataSource: {
			value: null
		},

		dataSourceType: {
			value: null
		},

		delimChar: {
			value: null,
			setter: function(value) {
				if (isString(value) && (value.length > 0)) {
					value = [value];
				}
				else if (!isArray(value)) {
					value = A.Attribute.INVALID_VALUE;
				}

				return value;
			}
		},

		forceSelection: {
			value: false
		},

		input: {
			value: null
		},

		matchKey: {
			value: ''
		},

		maxResultsDisplayed: {
			value: 10
		},

		minQueryLength: {
			value: 1
		},

		queryDelay: {
			value: 0.2,
			getter: function(value) {
				return value * 1000;
			}
		},

		queryInterval: {
			value: 0.5,
			getter: function(value) {
				var instance = this;

				return value * 1000;
			}
		},

		queryMatchCase: {
			value: false
		},

		queryMatchContains: {
			value: false
		},

		queryQuestionMark: {
			value: true
		},

		resultTypeList: {
			value: true
		},

		schema: {
			value: null
		},

		schemaType: {
			value: '',
			validator: isString
		},

		suppressInputUpdate: {
			value: false
		},

		typeAhead: {
			value: false
		},

		typeAheadDelay: {
			value: 0.2,
			getter: function(value) {
				return value * 1000;
			}
		},

		uniqueName: {
			value: null
		}
	};

	A.extend(
		AutoComplete,
		A.Widget,
		{
			initializer: function(config) {
				var instance = this;

				instance._createDataSource();
			},

			renderUI: function() {
				var instance = this;

				instance._renderInput();
				instance._renderButton();

				instance._renderOverlay();
			},

			bindUI: function() {
				var instance = this;

				var button = instance.button;
				var inputNode = instance.inputNode;

				instance.dataSource.on('request', A.bind(button.set, button, ICON, ICON_LOADING));

				button.on('click', instance._onButtonMouseDown, instance);

				inputNode.on('blur', instance._onTextboxBlur, instance);
				inputNode.on('focus', instance._onTextboxFocus, instance);
				inputNode.on('keydown', instance._onTextboxKeyDown, instance);
				inputNode.on('keypress', instance._onTextboxKeyPress, instance);
				inputNode.on('keyup', instance._onTextboxKeyUp, instance);

				var overlayBoundingBox = instance.overlay.get(BOUNDING_BOX);

				overlayBoundingBox.on('click', instance._onContainerClick, instance);
				overlayBoundingBox.on('mouseout', instance._onContainerMouseout, instance);
				overlayBoundingBox.on('mouseover', instance._onContainerMouseover, instance);
				overlayBoundingBox.on('scroll', instance._onContainerScroll, instance);

				instance.publish('containerCollapse');
				instance.publish('containerExpand');
				instance.publish('containerPopulate');

				instance.publish('dataError');
				instance.publish('dataRequest');
				instance.publish('dataReturn');

				instance.publish('itemArrowFrom');
				instance.publish('itemArrowTo');
				instance.publish('itemMouseOut');
				instance.publish('itemMouseOver');
				instance.publish('itemSelect');

				instance.publish('selectionEnforce');

				instance.publish('textboxBlur');
				instance.publish('textboxChange');
				instance.publish('textboxFocus');
				instance.publish('textboxKey');

				instance.publish('typeAhead');

				instance.publish('unmatchedItemSelect');

				instance.overlay.on('visibleChange', instance._realignContainer);
			},

			syncUI: function() {
				var instance = this;

				instance.inputNode.setAttribute('autocomplete', 'off');
			},

			doBeforeExpandContainer: function() {
				return true;
			},

			doBeforeLoadData: function(event) {
				return true;
			},

			filterResults: function(event) {
				var instance = this;

				var callback = event.callback;
				var query = event.request;
				var response = event.response;

				if (callback && callback.argument && callback.argument.query) {
					query = callback.argument.query;
				}

				if (query) {
					var dataSource = instance.dataSource;
					var allResults = response.results;
					var filteredResults = [];
					var matchFound = false;
					var matchKey = instance.get('matchKey') || 0;
					var matchCase = instance.get('queryMatchCase');
					var matchContains = instance.get('queryMatchContains');
					var showAll = (query == '*');

					var fields = instance.get('schema.resultFields');

					for (var i = allResults.length - 1; i >= 0; i--){
						var result = allResults[i];

						var strResult = null;

						if (isString(result)) {
							strResult = result;
						}
						else if (isArray(result)) {
							strResult = result[0];
						}
						else if (fields) {
							strResult = result[matchKey || fields[0]];
						}

						if (isString(strResult)) {
							var keyIndex = -1;

							if (matchCase) {
								keyIndex = strResult.indexOf(decodeURIComponent(query));
							}
							else {
								keyIndex = strResult.toLowerCase().indexOf(decodeURIComponent(query).toLowerCase());
							}

							if (
								(showAll) ||
								(!matchContains && (keyIndex === 0)) ||
								(matchContains && (keyIndex > -1)
								)
							) {
								filteredResults.unshift(result);
							}
						}
					}

					response.results = filteredResults;
				}

				return response;
			},

			formatResult: function(result, request, resultMatch) {
				return resultMatch || '';
			},

			generateRequest: function(query) {
				return query;
			},

			handleResponse: function(event) {
				var instance = this;

				instance._populateList(event);

				var iconClass = ICON_DEFAULT;

				if (event.error) {
					iconClass = ICON_ERROR;
				}

				instance.button.set(ICON, iconClass);
			},

			preparseRawResponse: function(event) {
			},

			sendQuery: function(query) {
				var instance = this;

				instance.set('focused', null);

				var newQuery = query;

				if (instance.get('delimChar')) {
					query = instance.inputNode.get('value') + query;
				}

				instance._sendQuery(newQuery);
			},

			_clearInterval: function() {
				var instance = this;

				if (instance._queryIntervalId) {
					clearInterval(instance._queryIntervalId);

					instance._queryIntervalId = null;
				}
			},

			_clearSelection: function() {
				var instance = this;

				var delimChar = instance.get('delimChar');
				var extraction = {
					previous: '',
					query: instance.inputNode.get('value')
				};

				if (delimChar) {
					extraction = instance._extractQuery(instance.inputNode.get('value'));
				}

				instance.fire('selectionEnforce', extraction.query);
			},

			_createDataSource: function() {
				var instance = this;

				var dataSource = instance.get('dataSource');
				var data = dataSource;

				var dataSourceType = instance.get('dataSourceType');

				if (!(dataSource instanceof A.DataSource.Local)) {
					if (!dataSourceType) {
						dataSourceType = 'Local';

						if (isFunction(data)) {
							dataSourceType = 'Function'
						}
						else if (isString(data)) {
							dataSourceType = 'IO'
						}
					}

					dataSource = new A.DataSource[dataSourceType](
						{
							source: data
						}
					);
				}

				dataSource.on('error', instance.handleResponse, instance);
				dataSource.after('response', instance.handleResponse, instance);

				dataSourceType = dataSource.name;

				if (dataSourceType == 'dataSourceLocal') {
					instance.set('applyLocalFilter', true);
				}

				instance.set('dataSource', dataSource);
				instance.set('dataSource', dataSourceType);

				instance.dataSource = dataSource;

				var schema = instance.get('schema');

				if (schema) {
					if (schema.fn) {
						instance.dataSource.plug(schema);
					}
					else {
						var schemaType = instance.get('schemaType');

						var schemaTypes = {
							array: A.Plugin.DataSourceArraySchema,
							json: A.Plugin.DataSourceJSONSchema,
							text: A.Plugin.DataSourceTextSchema,
							xml: A.Plugin.DataSourceXMLSchema
						};

						schemaType = schemaType.toLowerCase() || 'array';

						instance.dataSource.plug(
							{
								fn: schemaTypes[schemaType],
								cfg: {
									schema: schema
								}
							}
						);
					}
				}

				instance.set('schema', schema);
			},

			_enableIntervalDetection: function() {
				var instance = this;

				var queryInterval = instance.get('queryInterval');

				if (!instance._queryIntervalId && queryInterval) {
					instance._queryInterval = setInterval(A.bind(instance._onInterval, instance), queryInterval);
				}
			},

			_extractQuery: function(query) {
				var instance = this;

				var delimChar = instance.get('delimChar');
				var delimIndex = -1;
				var i = delimChar.length - 1;

				var newIndex, queryStart, previous;

				for (; i >= 0; i--) {
					newIndex = query.lastIndexOf(delimChar[i]);

					if (newIndex > delimIndex) {
						delimIndex = newIndex;
					}
				}

				if (delimChar[i] == ' ') {
					for (var j = delimChar.length - 1; j >= 0; j--){
						if (query[delimIndex - 1] == delimChar[j]) {
							delimIndex--;

							break;
						}
					}
				}

				if (delimIndex > -1) {
					queryStart = delimIndex + 1;

					while (query.charAt(queryStart) == ' ') {
						queryStart += 1;
					}

					previous = query.substring(0, queryStart);

					query = query.substring(queryStart);
				}
				else {
					previous = '';
				}

				return {
					previous: previous,
					query: query
				};
			},

			_focus: function() {
				var instance = this;

				setTimeout(
					function() {
						instance.inputNode.focus();
					},
					0
				);
			},

			_isIgnoreKey: function(keyCode) {
				var instance = this;

				if (
					(keyCode == KEY_TAB) ||
					(keyCode == KEY_ENTER) ||
					(keyCode == KEY_SHIFT) ||
					(keyCode == KEY_CTRL) ||
					(keyCode >= KEY_ALT && keyCode <= KEY_CAPS_LOCK) ||
					(keyCode == KEY_ESC) ||
					(keyCode >= KEY_PAGEUP && keyCode <= KEY_END) ||
					(keyCode >= KEY_HOME && keyCode <= KEY_DOWN) ||
					(keyCode >= KEY_PRINT_SCREEN && keyCode <= KEY_INSERT) ||
					(keyCode == KEY_KOREAN_IME)
				) {
					return true;
				}

				return false;
			},

			_jumpSelection: function() {
				var instance = this;

				if (instance._elCurListItem) {
					instance._selectItem(instance._elCurListItem);
				}
				else {
					instance._toggleContainer(false);
				}
			},

			_moveSelection: function(keyCode) {
				var instance = this;

				if (instance.overlay.get('visible')) {
					var elCurListItem = instance._elCurListItem;
					var curItemIndex = -1;

					if (elCurListItem) {
						curItemIndex = Number(elCurListItem.getAttribute('data-listItemIndex'));
					}

					var newItemIndex = curItemIndex - 1;

					if (keyCode == KEY_DOWN) {
						newItemIndex = curItemIndex + 1;
					}

					if (newItemIndex == -1) {
						newItemIndex = instance._displayedItems - 1;
					}

					if (newItemIndex >= instance._displayedItems) {
						newItemIndex = 0;
					}

					if (newItemIndex < -2) {
						return;
					}

					if (elCurListItem) {
						instance._toggleHighlight(elCurListItem, 'from');

						instance.fire('itemArrowFrom', elCurListItem);
					}

					if (newItemIndex == -1) {
						if (instance.get('delimChar')) {
							instance.inputNode.set('value', instance._pastSelections + instance._currentQuery);
						}
						else {
							instance.inputNode.set('value', instance._currentQuery);
						}

						return;
					}

					if (newItemIndex == -2) {
						instance._toggleContainer(false);

						return;
					}

					var elNewListItem = instance.resultList.get('childNodes').item(newItemIndex);

					var elContent = instance.overlay.get(CONTENT_BOX);

					var contentOverflow = elContent.getStyle('overflow');
					var contentOverflowY = elContent.getStyle('overflowY');

					var scrollOn = (contentOverflow == 'auto') || (contentOverflow == 'scroll') || (contentOverflowY == 'auto') || (contentOverflowY == 'scroll');

					if (scrollOn &&
						(newItemIndex > -1) &&
						(newItemIndex < instance._displayedItems)) {

						var newScrollTop = -1;
						var liTop = elNewListItem.get('offsetTop');
						var liBottom = liTop + elNewListItem.get('offsetHeight');

						var contentHeight = elContent.get('offsetHeight');
						var contentScrollTop = elContent.get('scrollTop');
						var contentBottom = contentHeight + contentScrollTop;

						if (keyCode == KEY_DOWN) {
							if (liBottom > contentBottom) {
								newScrollTop = (liBottom - contentHeight);
							}
							else if (liBottom < contentScrollTop) {
								newScrollTop = liTop;
							}
						}
						else {
							if (liTop < contentHeight) {
								newScrollTop = liTop;
							}
							else if (liTop > contentBottom) {
								newScrollTop = (liBottom - contentHeight);
							}
						}

						if (newScrollTop > -1) {
							elContent.set('scrollTop', newScrollTop);
						}
					}

					instance._toggleHighlight(elNewListItem, 'to');

					instance.fire('itemArrowTo', elNewListItem);

					if (instance.get('typeAhead')) {
						instance._updateValue(elNewListItem);
					}
				}
			},

			_onButtonMouseDown: function(event) {
				var instance = this;

				event.halt();

				instance._focus();

				instance._sendQuery(instance.inputNode.get('value') + '*');

			},

			_onContainerClick: function(event) {
				var instance = this;

				var target = event.target;
				var tagName = target.get('nodeName').toLowerCase();

				event.halt();

				while (target && (tagName != 'table')) {
					switch (tagName) {
						case 'body':
						return;

						case 'li':
							instance._toggleHighlight(target, 'to');
							instance._selectItem(target);
						return;

						default:
						break;
					}

					target = target.get('parentNode');

					if (target) {
						tagName.get('nodeName').toLowerCase();
					}
				}
			},

			_onContainerMouseout: function(event) {
				var instance = this;

				var target = event.target;
				var tagName = target.get('nodeName').toLowerCase();

				while (target && (tagName != 'table')) {
					switch (tagName) {
						case 'body':
						return;

						case 'li':
							instance._toggleHighlight(target, 'from');
							instance.fire('itemMouseOut', target);
						break;

						case 'ul':
							instance._toggleHighlight(instance._elCurListItem, 'to');
						break;

						case 'div':
							if (target.hasClass(CSS_RESULTS_OVERLAY)) {
								instance._overContainer = false;

								return;
							}
						break;

						default:
						break;
					}

					target = target.get('parentNode');

					if (target) {
						tagName = target.get('nodeName').toLowerCase();
					}
				}
			},

			_onContainerMouseover: function(event) {
				var instance = this;

				var target = event.target;
				var tagName = target.get('nodeName').toLowerCase();

				while (target && (tagName != 'table')) {
					switch (tagName) {
						case 'body':
						return;

						case 'li':
							instance._toggleHighlight(target, 'to');
							instance.fire('itemMouseOut', target);
						break;

						case 'div':
							if (target.hasClass(CSS_RESULTS_OVERLAY)) {
								instance._overContainer = true;
								return;
							}
						break;

						default:
						break;
					}

					target = target.get('parentNode');

					if (target) {
						tagName = target.get('nodeName').toLowerCase();
					}
				}
			},

			_onContainerScroll: function(event) {
				var instance = this;

				instance._focus();
			},

			_onInterval: function() {
				var instance = this;

				var curValue = instance.inputNode.get('value');
				var lastValue = instance._lastValue;

				if (curValue != lastValue) {
					instance._lastValue = curValue;

					instance._sendQuery(curValue);
				}
			},

			_onTextboxBlur: function(event) {
				var instance = this;

				if (!instance._overContainer || (instance._keyCode == KEY_TAB)) {
					if (!instance._itemSelected) {
						var elMatchListItem = instance._textMatchesOption();

						var overlayVisible = instance.overlay.get('visible');

						if (!overlayVisible || (overlayVisible && isNull(elMatchListItem))) {
							if (instance.get('forceSelection')) {
								instance._clearSelection();
							}
							else {
								instance.fire('unmatchedItemSelect', instance._currentQuery);
							}
						}
						else {
							if (instance.get('forceSelection')) {
								instance._selectItem(elMatchListItem);
							}
						}
					}

					instance._clearInterval();

					instance.blur();

					if (instance._initInputValue !== instance.inputNode.get('value')) {
						instance.fire('textboxChange');
					}

					instance.fire('textboxBlur');

					instance._toggleContainer(false);
				}
				else {
					instance._focus();
				}
			},

			_onTextboxFocus: function(event) {
				var instance = this;

				if (!instance.get('focused')) {
					instance.inputNode.setAttribute('autocomplete', 'off');
					instance.focus();
					instance._initInputValue = instance.inputNode.get('value');

					instance.fire('textboxFocus');
				}
			},

			_onTextboxKeyDown: function(event) {
				var instance = this;

				var keyCode = event.keyCode;

				if (instance._typeAheadDelayId != -1) {
					clearTimeout(instance._typeAheadDelayId);
				}

				switch (keyCode) {
					case KEY_TAB:
						if (instance._elCurListItem) {
							if (instance.get('delimChar') && instance._keyCode != keyCode) {
								if (instance.overlay.get('visible')) {
									event.halt();
								}
							}

							instance._selectItem(instance._elCurListItem);
						}
						else {
							instance._toggleContainer(false);
						}
					break;

					case KEY_ENTER:
						if (instance._elCurListItem) {
							if (instance._keyCode != keyCode) {
								if (instance.overlay.get('visible')) {
									event.halt();
								}
							}

							instance._selectItem(instance._elCurListItem);
						}
						else {
							instance._toggleContainer(false);
						}
					break;

					case KEY_ESC:
						instance._toggleContainer(false);
					return;

					case KEY_UP:
						if (instance.overlay.get('visible')) {
							event.halt();

							instance._moveSelection(keyCode);
						}
					break;

					case KEY_RIGHT:
						instance._jumpSelection();
					break;

					case KEY_DOWN:
						if (instance.overlay.get('visible')) {
							event.halt();

							instance._moveSelection(keyCode);
						}
					break;

					default:
						instance._itemSelected = false;
						instance._toggleHighlight(instance._elCurListItem, 'from');

						instance.fire('textboxKey', keyCode);
					break;
				}

				if (keyCode == KEY_ALT) {
					instance._enableIntervalDetection();
				}

				instance._keyCode = keyCode;
			},

			_onTextboxKeyPress: function(event) {
				var instance = this;

				var keyCode = event.keyCode;

				switch (keyCode) {
					case KEY_TAB:
						if (instance.overlay.get('visible')) {
							if (instance.get('delimChar')) {
								event.halt();
							}

							if (instance._elCurListItem) {
								instance._selectItem(instance._elCurListItem);
							}
							else {
								instance._toggleContainer(false);
							}
						}
					break;

					case 13:
						if (instance.overlay.get('visible')) {
							event.halt();

							if (instance._elCurListItem) {
								instance._selectItem(instance._elCurListItem);
							}
							else {
								instance._toggleContainer(false);
							}
						}
					break;

					default:
					break;
				}

				if (keyCode == KEY_KOREAN_IME) {
					instance._enableIntervalDetection();
				}
			},

			_onTextboxKeyUp: function(event) {
				var instance = this;

				var input = instance.inputNode;

				var value = input.get('value');
				var keyCode = event.keyCode;

				if (instance._isIgnoreKey(keyCode)) {
					return;
				}

				if (instance._delayId != -1) {
					clearTimeout(instance._delayId);
				}

				instance._delayId = setTimeout(
					function() {
						instance._sendQuery(value);
					},
					instance.get('queryDelay')
				);
			},

			_populateList: function(event) {
				var instance = this;

				if (instance._typeAheadDelayId != -1) {
					clearTimeout(instance._typeAheadDelayId);
				}

				var query = event.request;
				var response = event.response;
				var callback = event.callback;
				var showAll = (query == '*');

				if (callback && callback.argument && callback.argument.query) {
					event.request = query = callback.argument.query;
				}

				var ok = instance.doBeforeLoadData(event);

				if (ok && !event.error) {
					instance.fire('dataReturn', event);

					var focused = instance.get('focused');

					if (showAll || focused || focused === null) {
						var currentQuery = decodeURIComponent(query);

						instance._currentQuery = currentQuery;
						instance._itemSelected = false;

						var allResults = event.response.results;
						var itemsToShow = Math.min(allResults.length, instance.get('maxResultsDisplayed'));
						var fields = instance.get('schema.resultFields');
						var matchKey = instance.get('matchKey');

						if (!matchKey && fields) {
							matchKey = fields[0];
						}
						else {
							matchKey = matchKey || 0;
						}

						if (itemsToShow > 0) {
							var allListItemEls = instance.resultList.get('childNodes');

							allListItemEls.each(
								function(node, i, nodeList) {
									if (i < itemsToShow) {
										var result = allResults[i];

										var resultMatch = '';

										if (isString(result)) {
											resultMatch = result;
										}
										else if (isArray(result)) {
											resultMatch = result[0]
										}
										else {
											resultMatch = result[matchKey];
										}

										node._resultMatch = resultMatch;

										node._resultData = result;
										node.html(instance.formatResult(result, currentQuery, resultMatch));

										node.removeClass('aui-helper-hidden');
									}
									else {
										node.addClass('aui-helper-hidden');
									}
								}
							);

							instance._displayedItems = itemsToShow;

							instance.fire('containerPopulate', query, allResults);

							if (query != '*' && instance.get('autoHighlight')) {
								var elFirstListItem = instance.resultList.get('firstChild');

								instance._toggleHighlight(elFirstListItem, 'to');
								instance.fire('itemArrowTo', elFirstListItem);

								instance._typeAhead(elFirstListItem, query);
							}
							else {
								instance._toggleHighlight(instance._elCurListItem, 'from');
							}

							ok = instance.doBeforeExpandContainer(query, allResults);

							instance._toggleContainer(ok);
						}
						else {
							instance._toggleContainer(false);
						}

						return;
					}

				}
				else {
					instance.fire('dataError', query);
				}
			},

			_renderButton: function() {
				var instance = this;

				var button = new A.ToolItem(ICON_DEFAULT);

				button.get('boundingBox').addClass(CSS_BUTTON_TRIGGER);
				button.get('node').addClass(CSS_ICON_BUTTON_TRIGGER);

				if (instance.get('button') !== false) {
					button.render(instance.inputWrapper);
				}

				instance.button = button;
			},

			_realignContainer: function(event) {
				var instance = this;

				instance._uiSetAlign(OVERLAY_ALIGN.node, OVERLAY_ALIGN.points);
			},

			_renderInput: function() {
				var instance = this;

				var contentBox = instance.get(CONTENT_BOX);
				var input = instance.get('input');

				if (input) {
					input = A.get(input);
				}
				else {
					input = A.Node.create(TPL_INPUT);

					input.addClass(CSS_INPUT);

					contentBox.appendChild(input);
				}

				var wrapper = A.Node.create(TPL_INPUT_WRAPPER);

				contentBox.insertBefore(wrapper, input);

				wrapper.appendChild(input);

				instance.set('uniqueName', A.stamp(input));

				instance.inputNode = input;
				instance.inputWrapper = wrapper;
			},

			_renderListElements: function() {
				var instance = this;

				var maxResultsDisplayed = instance.get('maxResultsDisplayed');

				var resultList = instance.resultList;

				var listItems = [];

				while (maxResultsDisplayed--) {
					listItems[maxResultsDisplayed] = '<li class="aui-helper-hidden ' + CSS_LIST_ITEM + '" data-listItemIndex="' + maxResultsDisplayed + '"></li>';
				}

				resultList.html(listItems.join(''));
			},

			_renderOverlay: function() {
				var instance = this;

				OVERLAY_ALIGN.node = instance.inputNode;

				var overlay = new A.Overlay(
					{
						align: OVERLAY_ALIGN,
						bodyContent: '<ul></ul>',
						visible: false,
						width: instance.inputNode.get('offsetWidth')
					}
				);

				var contentBox = overlay.get(CONTENT_BOX);

				overlay.get(BOUNDING_BOX).addClass(CSS_RESULTS_OVERLAY);

				contentBox.addClass(CSS_RESULTS_OVERLAY_CONTENT);

				overlay.render(document.body);

				overlay.addTarget(instance);

				instance.overlay = overlay;
				instance.resultList = contentBox.query('ul');

				instance.resultList.addClass(CSS_RESULTS_LIST);

				instance._renderListElements();
			},

			_selectItem: function(elListItem) {
				var instance = this;

				instance._itemSelected = true;

				instance._updateValue(elListItem);

				instance._pastSelections = instance.inputNode.get('value');

				instance._clearInterval();

				instance.fire('itemSelect', elListItem, elListItem._resultData);

				instance._toggleContainer(false);
			},

			_selectText: function(el, start, end) {
				var instance = this;

				var rawEl = A.Node.getDOMNode(el);
				var value = el.get('value');

				if (rawEl.setSelectionRange) {
					rawEl.setSelectionRange(start, end);
				}
				else if (rawEl.createTextRange) {
					var range = rawEl.createTextRange();

					range.moveStart('character', start);
					range.moveEnd('character', end - value.length);

					range.select();
				}
				else {
					rawEl.select();
				}
			},

			_sendQuery: function(query) {
				var instance = this;

				if (instance.get('disabled')) {
					instance._toggleContainer(false);

					return;
				}

				var delimChar = instance.get('delimChar');
				var minQueryLength = instance.get('minQueryLength');

				if (delimChar) {
					var extraction = instance._extractQuery(query);

					query = extraction.query;

					instance._pastSelections = extraction.previous;
				}

				if ((query && (query.length < minQueryLength)) || (!query && minQueryLength > 0)) {
					if (instance._delayId != -1) {
						clearTimeout(instance._delayId);
					}

					instance._toggleContainer(false);

					return;
				}

				query = encodeURIComponent(query);

				instance._delayId = -1;

				if (instance.get('applyLocalFilter')) {
					instance.dataSource.on('response', instance.filterResults, instance);
				}

				var request = instance.generateRequest(query);

				instance.fire('dataRequest', query, request);

				instance.dataSource.sendRequest(request);
			},

			_textMatchesOption: function() {
				var instance = this;

				var elMatch = null;
				var displayedItems = instance._displayedItems;
				var listItems = instance.resultList.get('childNodes');

				for (var i=0; i < displayedItems.length; i++) {
					var elListItem = listItems.item(i);

					var match = ('' + elListItem._resultMatch).toLowerCase();

					if (match == instance._currentQuery.toLowerCase()) {
						elMatch = elListItem;

						break;
					}
				}

				return elMatch;
			},

			_toggleContainer: function(show) {
				var instance = this;

				var overlay = instance.overlay;

				if (instance.get('alwaysShowContainer') && overlay.get('visible')) {
					return;
				}

				if (!show) {
					instance._toggleHighlight(instance._elCurListItem, 'from');

					instance._displayedItems = 0;
					instance._currentQuery = null;
				}

				if (show) {
					overlay.show();
					instance.fire('containerExpand');
				}
				else {
					overlay.hide();
					instance.fire('containerCollapse');
				}
			},

			_toggleHighlight: function(elNewListItem, action) {
				var instance = this;

				if (elNewListItem) {
					if (instance._elCurListItem) {
						instance._elCurListItem.removeClass(CSS_HIGLIGHT);
						instance._elCurListItem = null;
					}

					if (action == 'to') {
						elNewListItem.addClass(CSS_HIGLIGHT);

						instance._elCurListItem = elNewListItem;
					}
				}
			},

			_typeAhead: function(elListItem, query) {
				var instance = this;

				if (!instance.get('typeAhead') || instance._keyCode == KEY_BACKSPACE) {
					return;
				}

				var inputEl = A.Node.getDOMNode(instance.inputNode);

				if (inputEl.setSelectionRange || inputEl.createTextRange) {
					instance._typeAheadDelayId = setTimeout(
						function() {
							var value = inputEl.value;

							var start = value.length;

							instance._updateValue(elListItem);

							var end = inputEl.value.length;

							instance._selectText(instance.inputNode, start, end);

							var prefill = inputEl.value.substr(start, end);

							instance.fire('typeAhead', query, prefill);
						},
						instance.get('typeAheadDelay')
					);
				}
			},

			_updateValue: function(elListItem) {
				var instance = this;

				if (!instance.get('suppressInputUpdate')) {
					var input = instance.inputNode;
					var resultMatch = elListItem._resultMatch;

					var delimChar = instance.get('delimChar');

					delimChar = (delimChar && delimChar[0]) || delimChar;

					var newValue = '';

					if (delimChar) {
						newValue = instance._pastSelections;

						newValue += resultMatch + delimChar;

						if (delimChar != ' ') {
							newValue += ' ';
						}
					}
					else {
						newValue = resultMatch;
					}

					input.set('value', newValue);

					if (input.get('type') == 'textarea') {
						input.set('scrollTop', input.get('scrollHeight'));
					}

					var end = newValue.length;

					instance._selectText(input, end, end);

					instance._elCurListItem = elListItem;
				}
			},

			_currentQuery: null,
			_delayId: -1,
			_displayedItems: 0,
			_elCurListItem: null,
			_initInputValue: null,
			_itemSelected: false,
			_keyCode: null,
			_lastValue: null,
			_overContainer: false,
			_pastSelections: '',
			_typeAheadDelayId: -1
		}
	);

	A.AutoComplete = AutoComplete;

}, '0.1a' , { requires: [ 'datasource', 'dataschema', 'overlay', 'tool' ] });/*
* AUI Base
*/
AUI.add('aui-base', function(A) {

	A.mix(A.Array, {
		remove: function(a, from, to) {
		  var rest = a.slice((to || from) + 1 || a.length);
		  a.length = (from < 0) ? (a.length + from) : from;

		  return a.push.apply(a, rest);
		},

		removeItem: function(a, item) {
			var index = A.Array.indexOf(a, item);

		  	return A.Array.remove(a, index);
		}
	});

}, '0.1a', { requires: [ 'yui-base' ] });

/*
* AUI Delayed Task
*/

AUI.add('delayed-task', function(A) {

	var DelayedTask = function(fn, scope, args) {
		var instance = this;

		instance._args = args;
		instance._delay = 0;
		instance._fn = fn;
		instance._id = null;
		instance._scope = scope || instance;
		instance._time = 0;

		instance._base = function() {
			var now = instance._getTime();

			if (now - instance._time >= instance._delay) {
				clearInterval(instance._id);

				instance._id = null;

				instance._fn.apply(instance._scope, instance._args || []);
			}
		};
	};

	DelayedTask.prototype = {
		delay: function(delay, newFn, newScope, newArgs) {
			var instance = this;

			if (instance._id && instance._delay != delay) {
				instance.cancel();
			}

			instance._delay = delay || instance._delay;
			instance._time = instance._getTime();

			instance._fn = newFn || instance._fn;
			instance._scope = newScope || instance._scope;
			instance._args = newArgs || instance._args;

			if (!A.Lang.isArray(instance._args)) {
				instance._args = [instance._args];
			}

			if (!instance._id) {
				if (instance._delay > 0) {
					instance._id = setInterval(instance._base, instance._delay);
				}
				else {
					instance._base();
				}
			}
		},

		cancel: function() {
			var instance = this;

			if (instance._id) {
				clearInterval(instance._id);

				instance._id = null;
			}
		},

		_getTime: function() {
			var instance = this;

			return (+new Date());
		}
	};

	A.DelayedTask = DelayedTask;

}, '0.1a', { requires: [ 'yui-base' ] });

/*
* AUI Node
*/

AUI.add('aui-node', function(A) {

	var Lang = A.Lang,
		isString = Lang.isString,
		isUndefined = Lang.isUndefined,

		INNER_HTML = 'innerHTML';

	A.mix(A.Node.prototype, {
		after: function(content) {
			var instance = this;

			return instance.insertAfter(content);
		},

		appendTo: function(selector) {
			var instance = this;

			A.get(selector).append(instance);
		},

		attr: function(name, value) {
			var instance = this;

			if (!isUndefined(value)) {
				return instance.setAttribute(name, value);
			}
			else {
				return instance.getAttribute(name);
			}
		},

		before: function(content) {
			var instance = this;

			var parent = instance.get('parentNode');

			if (parent) {
				parent.insertBefore(content, instance);
			}

			return instance;
		},

		empty: function() {
			var instance = this;

			instance.queryAll('>*').remove();

			var el = A.Node.getDOMNode(instance);

			while (el.firstChild) {
				el.removeChild(el.firstChild);
			}

			return instance;
		},

		getDOM: function() {
			var instance = this;

			return A.Node.getDOMNode(instance);
		},

		html: function() {
			var args = arguments, length = args.length;

			if (length) {
				this.set(INNER_HTML, args[0]);
			}
			else {
				return this.get(INNER_HTML);
			}

			return this;
		},

		insertAfter: function(content) {
			var instance = this;

			var parent = instance.get('parentNode');

			if (parent) {
				parent.insertBefore(content, instance.get('nextSibling'));
			}

			return instance;
		},

		prependTo: function(selector) {
			var instance = this;

			A.get(selector).prepend(instance);
		},

		text: function(text) {
			var instance = this;

			if (!isUndefined(text)) {
				text = A.DOM._getDoc(A.Node.getDOMNode(instance)).createTextNode(text);

				return instance.empty().append(text);
			}

			var el = A.Node.getDOMNode(instance);

			return instance._getText(el.childNodes);
		},

		_getText: function(childNodes) {
			var instance = this;

			var length = childNodes.length;
			var childNode;

			var str = [];

			for (var i = 0; i < length; i++) {
				childNode = childNodes[i];

				if (childNode && childNode.nodeType != 8) {
					if (childNode.nodeType != 1) {
						str.push(childNode.nodeValue);
					}

					if (childNode.childNodes) {
						str.push(instance._getText(childNode.childNodes));
					}
				}
			}

			return str.join('');
		}
	}, true);

	A.mix(A.Node, {
		globalEval: function(data) {
			if ( data && /\S/.test(data) ) {
				var head = document.getElementsByTagName("head")[0] || document.documentElement;
				var script = document.createElement("script");

				script.type = "text/javascript";

				if (AUI.support.scriptEval) {
					script.appendChild(document.createTextNode(data));
				}
				else {
					script.text = data;
				}

				head.insertBefore(script, head.firstChild);
				head.removeChild(script);
			}
		},

		evalScript: function(elem) {
			if (elem.src) {
				A.io(elem.src, {
					async: false,
					on: {
						complete: function(i, o) {
							A.Node.globalEval(o.responseText);
						}
					}
				});
			}
			else {
				A.Node.globalEval(elem.text || elem.textContent || elem.innerHTML || "");
			}
		},

		clean: function(html) {
			var TPL_NODE = '<div></div>',
				IE_FIX_PADDING_NODE = '<div>_</div>',
				SCRIPT = 'script';

			// instead of fix all tags to "XHTML"-style, make the firstChild be a valid non-empty tag
			html = IE_FIX_PADDING_NODE + A.Lang.trim(html);

			delete A.DOM._cloneCache[html];

			// wrap in a nodeType == 1, nodeType 11 (document fragment) does not support getElementsByTagName
			var temp = A.Node.create(TPL_NODE).append(
				A.Node.create(html)
			);

			var scripts = temp.getElementsByTagName(SCRIPT);

			scripts.each(function(elem) {
				elem.remove();
			});

			temp.removeChild(A.Node.getDOMNode(temp).firstChild);

			var html = temp.html();

			// avoid IE6 memory leak
			temp = null;

			return [ html, scripts ];
		},

		domManip: function(html, callback) {
			var clean = A.Node.clean(html);
			var content = clean[0];
			var scripts = clean[1];

			if (callback) {
				callback.apply(this, [ content ]);
			}

			scripts.each(function(elem) {
				A.Node.evalScript( A.Node.getDOMNode(elem) );
			});
		}
	});

	A.Node.ATTRS.innerHTML = {
		setter: function(v) {
			var instance = this;

			var defaultSetter = function(value) {
				A.Node.DEFAULT_SETTER.apply(instance, [ INNER_HTML, value ]);
			};

			if (isString(v)) {
				// eval scripts
				v = A.Node.domManip(v, defaultSetter);
			}
			else {
				defaultSetter(v);
			}
		}
	};

	A.NodeList.importMethod(
		A.Node.prototype,
		[
			'after',

			'appendTo',

			'attr',

			'before',

			'empty',

			'html',

			'insertAfter',

			'prepend',

			'prependTo',

			'text'
		]
	);

	A.NodeList.prototype.getDOM = function() {
		return A.NodeList.getDOMNodes(this);
	};

}, '0.1a', { requires: [ 'node' ] });AUI.add('calendar', function(A) {

var L = A.Lang,
	isBoolean = L.isBoolean,
	isNumber = L.isNumber,
	isString = L.isString,

	isNodeList = function(v) {
		return (v instanceof A.NodeList);
	},

	isNode = function(v) {
		return (v instanceof A.Node);
	},

	ALLOY = 'alloy',
	ANCHOR = 'a',
	AUTO_RENDER = 'autoRender',
	ARROW = 'arrow',
	BLANK = '',
	BOUNDING_BOX = 'boundingBox',
	CAN_RESET = 'canReset',
	CLASS_NAME = 'className',
	CONTENT_BOX = 'contentBox',
	DAY = 'day',
	DAY_NAMES = 'dayNames',
	DAY_NAMES_SHORT = 'dayNamesShort',
	DATE = 'date',
	DATE_FORMAT = 'dateFormat',
	DEFAULT_SELECTED = 'defaultSelected',
	DESTROY = 'destroy',
	DISABLED = 'disabled',
	ELEMENT = 'element',
	ELEMENTS = 'elements',
	HOVER = 'hover',
	INNER_HTML = 'innerHTML',
	INPUT = 'input',
	INPUT_NAME = 'inputName',
	LABEL = 'label',
	LABEL_ELEMENT = 'labelElement',
	NAME = 'name',
	OFF = 'off',
	ON = 'on',
	CALENDAR = 'calendar',
	MONTH_NAMES = 'monthNames',
	MONTH_NAMES_SHORT = 'monthNamesShort',
	NAVIGATION = 'navigation'
	WRAPPER = 'wrapper',
	SELECTED_INDEX = 'selectedIndex',
	SHOW_TITLE = 'showTitle',
	SIZE = 'size',
	TITLE = 'title',
	VALUE = 'value',

	getCN = A.ClassNameManager.getClassName,

	CSS_CLEAR_FIX = 'aui-helper-clearfix',
	CSS_WIDGET_HEADER = 'aui-widget-hd',
	CSS_WIDGET_TITLEBAR = 'aui-widget-titlebar',
	CSS_STATE_ACTIVE = ' aui-state-active',
	CSS_STATE_DEFAULT = ' aui-state-default',
	CSS_ICON = 'aui-icon',
	CSS_ICON_LEFT = 'aui-icon-triangle-1-w',
	CSS_ICON_RIGHT = 'aui-icon-triangle-1-e',

	CSS_CALENDAR_LABEL_EL = getCN(CALENDAR, LABEL, ELEMENT),
	CSS_CALENDAR_DAY = getCN(CALENDAR, DAY),
	CSS_CALENDAR_DAY_LABEL = getCN(CALENDAR, DAY, LABEL),
	CSS_CALENDAR_DAY_BLANK = getCN(CALENDAR, DAY, 'blank'),
	CSS_CALENDAR_EL = getCN(CALENDAR, ELEMENT),
	CSS_CALENDAR_EL_HOVER  = getCN(CALENDAR, ELEMENT, HOVER),
	CSS_NAVIGATION_WRAPPER = getCN(CALENDAR, NAVIGATION, WRAPPER);

function Calendar() {
	Calendar.superclass.constructor.apply(this, arguments);
}

A.mix(Calendar, {
	NAME: 'Calendar',

	ATTRS: {
		autoRender: {
			value: true,
			validator: isBoolean
		},

		canReset: {
			value: true,
			validator: isBoolean
		},

		dayNamesShort: {
			value: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
		},

		dayNames: {
			value: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
		},

		date: {
			value: (new Date())
		},

		dateFormat: {
			value: 'mm/dd/yy'
		},

		monthNames: {
			value: ['January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December']
        },

        monthNamesShort: {
        	value: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    	},

		title: null,

		value: null
	}
});

A.extend(Calendar, A.Widget, {
	/*
	* Lifecycle
	*/
	initializer: function() {
		var instance = this;

		instance.date = instance.get(DATE);

		if (instance.get(AUTO_RENDER)) {
			instance.render();
		}
	},

	renderUI: function() {
		var instance = this;

		instance._renderElements();
		instance._renderDayValues();
		instance._renderDayNames();
	},

	bindUI: function() {
		var instance = this;

		A.each(instance.dayValues, function(dayValue, i) {
			dayValue.on({
				click: function() {
					instance.setDate(i + 1);

					instance.syncUI();
				}
			});
		});

		instance.leftArrowWrapper.on({
			click: function() {
				instance.setMonth(instance.date.getMonth() - 1);

				instance.syncUI();
			}
		});

		instance.rightArrowWrapper.on({
			click: function() {
				instance.setMonth(instance.date.getMonth() + 1);

				instance.syncUI();
			}
		});

		instance.get(CONTENT_BOX).on({
			focus: function() {
				instance.calendarWrapper.setStyle("display", 'block');
			},
			blur: function() {
				//instance.calendarWrapper.setStyle("display", 'none');
			}
		});

	},

	syncUI: function() {
		var instance = this;

		instance._syncDate();
		instance._syncDateLabel();
		instance._syncMonthValues();
	},

	destructor: function() {
		var instance = this;
		var	boundingBox = instance.get(BOUNDING_BOX);

		boundingBox.detachAll();
		boundingBox.remove();
	},

	/*
	* Methods
	*/
	_renderElements: function() {
		var instance = this;
		var	boundingBox = instance.get(BOUNDING_BOX);
		var contentBox = instance.get(CONTENT_BOX);

		instance.calendarWrapper = A.Node.create('<div></div>');
		instance.calendarWrapper.set(CLASS_NAME, getCN(CALENDAR, WRAPPER));

		instance.navigationWrapper = A.Node.create('<div></div>');
		instance.navigationWrapper.set(CLASS_NAME, [
			CSS_NAVIGATION_WRAPPER,
			CSS_STATE_DEFAULT,
			CSS_WIDGET_HEADER,
			CSS_CLEAR_FIX
		].join(' '));

		var getArrowWraper = function(arrowClass) {
			var wrapper = A.Node.create('<a href="javascript:void(0);"></a>');
			wrapper.set(CLASS_NAME, getCN(CALENDAR, ARROW));

			var arrow = A.Node.create('<div></div>');
			arrow.set(CLASS_NAME, arrowClass);

			wrapper.appendChild(arrow);

			return wrapper;
		};

		instance.dateLabel = A.Node.create('<label>March 2009</label>');
		instance.dateLabel.set(CLASS_NAME, getCN(CALENDAR, LABEL));

		instance.leftArrowWrapper = getArrowWraper([CSS_ICON, CSS_ICON_LEFT].join(' '));
		instance.rightArrowWrapper = getArrowWraper([CSS_ICON, CSS_ICON_RIGHT].join(' '));

		instance.dayNamesWrapper = A.Node.create('<div></div>');
		instance.dayNamesWrapper.set(CLASS_NAME, CSS_CLEAR_FIX);

		instance.dayValuesWrapper = A.Node.create('<div></div>');
		instance.dayValuesWrapper.set(CLASS_NAME, CSS_CLEAR_FIX);

		instance.navigationWrapper.appendChild(instance.leftArrowWrapper);
		instance.navigationWrapper.appendChild(instance.dateLabel);
		instance.navigationWrapper.appendChild(instance.rightArrowWrapper);

		instance.calendarWrapper.appendChild(instance.navigationWrapper);
		instance.calendarWrapper.appendChild(instance.dayNamesWrapper);
		instance.calendarWrapper.appendChild(instance.dayValuesWrapper);

		boundingBox.appendChild(instance.calendarWrapper);
	},

	_renderDayNames: function() {
		var instance = this;
		var names = instance.get(DAY_NAMES_SHORT);

		instance.dayNamesWrapper.set(INNER_HTML, BLANK);

		A.each(names, function(name, i) {
			var dayName = A.Node.create('<label></label>');
			dayName.set(CLASS_NAME, CSS_CALENDAR_DAY_LABEL);
			dayName.set(INNER_HTML, name);

			instance.dayNamesWrapper.appendChild(dayName);
		});

	},

	_renderDayValues: function() {
		var instance = this;

		instance.dayValues = [];
		instance.blankDays = [];
		instance.biggerDays = [];

		for (var i = 1; i < (instance._getDaysInMonth() + 7); i++) {
			(function(i) {
				var dayValue = A.Node.create('<a href="javascript:void(0);"></a>');
				var value = i - 6;

				dayValue.set(CLASS_NAME, CSS_CALENDAR_DAY);

				if (value < 1) {
					value = '&nbsp;';

					dayValue.addClass(CSS_CALENDAR_DAY_BLANK);

					instance.blankDays.push(dayValue);
				}
				else if (value > 28) {
					instance.biggerDays.push(dayValue);
				}

				if (value > 0) {
					instance.dayValues.push(dayValue);
				}

				dayValue.setAttribute('value', value);
				dayValue.set(INNER_HTML, value);

				instance.dayValuesWrapper.appendChild(dayValue);
			})(i);
		};

	},

	setDate: function(date) {
		var instance = this;

		instance.date.setDate(date);

		instance.get(CONTENT_BOX).setAttribute('value', instance._formatDate(instance.get(DATE_FORMAT), instance.date));

		instance.calendarWrapper.setStyle("display", 'none');
	},

	setMonth: function(month) {
		var instance = this;

		instance.date = instance._getValidDate(instance.date.getFullYear(), month);
	},

	_getDaysInMonth: function(year, month) {
		var instance = this;

		month = month || instance.date.getMonth();
        year = year || instance.date.getFullYear();

        return 32 - new Date(year, month, 32).getDate();
    },

    _getMonthValues: function() {
        var instance = this,
	        monthNames = instance.get(MONTH_NAMES);
	        months = [];

        for (var i = 0; i < 12; i++) {
            months.push({
                value: i,
                caption: monthNames[i]
            });
        }

        return months;
    },

    _getValidDate: function(year, month, day) {
        var instance = this,
        	daysInMonth = instance._getDaysInMonth(year, month);

        if (daysInMonth < instance.date.getDate()) {
            return (new Date(year, month, (day || daysInMonth)));
        }

        return (new Date(year, month, (day || instance.date.getDate())));
    },

    _syncDate: function() {
    	var instance = this,
    		now = instance.date.getDate();

    	A.each(instance.dayValues, function(dv, i) {
			dv.removeClass(CSS_STATE_ACTIVE);

			if ((i + 1) == now) {
				dv.addClass(CSS_STATE_ACTIVE);
			}
    	});

    },

    _syncMonthValues: function() {
    	var instance = this,
    		daysInMonth = instance._getDaysInMonth(),
			firstDay = (new Date(
        		instance.date.getFullYear(),
        		instance.date.getMonth(),
        	1)).getDay();

    	A.each(instance.blankDays, function(dayValue, i) {
    		var display;

    		if (firstDay <= i) {
    			display = 'none';
    		} else {
    			display = 'block';
    		}

    		dayValue.setStyle("display", display);
    	});

    	A.each(instance.biggerDays, function(dayValue, i) {
    		var display;

    		if (dayValue.getAttribute('value') > daysInMonth) {
    			display = 'none';
    		} else {
    			display = 'block';
    		}

    		dayValue.setStyle("display", display);
    	});

    },

    _syncDateLabel: function() {
    	var instance = this,
    		dateFormat = instance.get(DATE_FORMAT);

    	instance.dateLabel.set(INNER_HTML, instance._formatDate('MM yy', instance.date));
    },

    /*
     * jQuery Datepicker method
    */

    _formatDate: function(format, date) {
        var instance = this;

        if (!format) {
            return '';
        }

        if (!date) {
            return '';
        }

        var dayNamesShort = instance.get(DAY_NAMES_SHORT);
        var dayNames = instance.get(DAY_NAMES);
        var monthNamesShort = instance.get(MONTH_NAMES_SHORT);
        var monthNames = instance.get(MONTH_NAMES);

        // Check whether a format character is doubled
        var lookAhead = function(match) {
            var matches = (iFormat + 1 < format.length && format.charAt(iFormat + 1) == match);
            if (matches) {
                iFormat++;
            }
            return matches;
        };

        // Format a number, with leading zero if necessary
        var formatNumber = function(match, value, len) {
            var num = '' + value;
            if (lookAhead(match)) {
                while (num.length < len) {
                    num = '0' + num;
                }
            }
            return num;
        };
        // Format a name, short or long as requested
        var formatName = function(match, value, shortNames, longNames) {
            return (lookAhead(match) ? longNames[value] : shortNames[value]);
        };
        var output = '';
        var literal = false;
        if (date) {
            for (var iFormat = 0; iFormat < format.length; iFormat++) {
                if (literal) {
                    if (format.charAt(iFormat) == "'" && !lookAhead("'")) {
                        literal = false;
                    } else {
                        output += format.charAt(iFormat);
                    }
                } else {
                    switch (format.charAt(iFormat)) {
                    case 'd':
                        output += formatNumber('d', date.getDate(), 2);
                        break;
                    case 'D':
                        output += formatName('D', date.getDay(), dayNamesShort, dayNames);
                        break;
                    case 'o':
                        var doy = date.getDate();
                        for (var m = date.getMonth() - 1; m >= 0; m--)
                        doy += this._getDaysInMonth(date.getFullYear(), m);
                        output += formatNumber('o', doy, 3);
                        break;
                    case 'm':
                        output += formatNumber('m', date.getMonth() + 1, 2);
                        break;
                    case 'M':
                        output += formatName('M', date.getMonth(), monthNamesShort, monthNames);
                        break;
                    case 'y':
                        output += (lookAhead('y') ? date.getFullYear() :
                        (date.getYear() % 100 < 10 ? '0': '') + date.getYear() % 100);
                        break;
                    case '@':
                        output += date.getTime();
                        break;
                    case "'":
                        if (lookAhead("'"))
                        output += "'";
                        else
                        literal = true;
                        break;
                    default:
                        output += format.charAt(iFormat);
                    }
                }
            }
        }

        return output;
    },

	/*
	* Delegated events
	*/
	_delegateMethod: function(event) {
		var instance = this;
		var type = event.type;
		var disabled = instance.get(DISABLED);
		var	elements = instance.get(ELEMENTS);
		var selectedIndex = instance.get(SELECTED_INDEX);
		var index = elements.indexOf(event.target);

		var on = {
			click: function() {
				instance.select(index);
			},
			mouseover: function() {
				instance.fillTo(index, CSS_RATING_EL_HOVER);
			},
			mouseout: function() {
				instance.fillTo(selectedIndex);
			}
		};

		if (type) {
			if (!disabled) {
				on[type]();
			}
			// trigger user callback even when disabled
			instance.fire(type);
		}
	},

	/*
	* Attribute Listeners
	*/
	_afterSetLabel: function(event) {
		this.syncUI();
	}

});

A.Calendar = Calendar;

}, '0.1a' , { requires: [ 'overlay' ] });AUI.add('context-overlay', function(A) {

var L = A.Lang,
	isString = L.isString,
	isNumber = L.isNumber,
	isObject = L.isObject,

	ALIGN = 'align',
	BL = 'bl',
	CONTEXT_OVERLAY = 'contextoverlay',
	HIDE = 'hide',
	HIDE_DELAY = 'hideDelay',
	HIDE_ON = 'hideOn',
	SHOW = 'show',
	SHOW_DELAY = 'showDelay',
	SHOW_ON = 'showOn',
	TL = 'tl',
	TRIGGER = 'trigger',
	VISIBLE = 'visible';

function ContextOverlay(config) {
	var instance = this;

	instance._hideTask = new A.DelayedTask(instance._hide, instance);
	instance._showTask = new A.DelayedTask(instance._show, instance);

	instance._showCallback = null;
	instance._hideCallback = null;

 	ContextOverlay.superclass.constructor.apply(this, arguments);
}

A.mix(ContextOverlay, {
	NAME: CONTEXT_OVERLAY,

	ATTRS: {
		align: {
            value: { node: null, points: [ TL, BL ] }
        },

		delay: {
			value: null,
			validator: isObject
		},

		hideOn: {
			lazyAdd: false,
			value: 'mouseout',
			validator: isString,
			setter: function(v) {
				return this._setHideOn(v);
			}
		},

		hideDelay: {
			value: 0
		},

		intervals: {
			value: {}
		},

		showOn: {
			lazyAdd: false,
			value: 'mouseover',
			validator: isString,
			setter: function(v) {
				return this._setShowOn(v);
			}
		},

		showDelay: {
			value: 0,
			validator: isNumber
		},

		trigger: {
			lazyAdd: false,
			setter: function(v) {
				return A.all(v);
			}
		},

		visible: {
			value: false
		}
	}
});

A.extend(ContextOverlay, A.Overlay, {
	/*
	* Lifecycle
	*/
	bindUI: function(){
		var instance = this;

		instance.before('triggerChange', instance._beforeTriggerChange);
		instance.before('showOnChange', instance._beforeShowOnChange);
		instance.before('hideOnChange', instance._beforeHideOnChange);

		instance.after('triggerChange', instance._afterTriggerChange);
		instance.after('showOnChange', instance._afterShowOnChange);
		instance.after('hideOnChange', instance._afterHideOnChange);
	},

	/*
	* Methods
	*/
	hide: function() {
		this.clearIntervals();

		ContextOverlay.superclass.hide.apply(this, arguments);
	},

	show: function() {
		this.clearIntervals();

		ContextOverlay.superclass.show.apply(this, arguments);
	},

	toggle: function(event) {
		var instance = this;

		if (instance.get(VISIBLE)) {
			instance._hideTask.delay( instance.get(HIDE_DELAY), null, null, [event] );
		}
		else {
			instance._showTask.delay( instance.get(SHOW_DELAY), null, null, [event] );
		}
	},

	clearIntervals: function() {
		this._hideTask.cancel();
		this._showTask.cancel();
	},

	_hide: function(event) {
		var instance = this;

		instance.fire('hide');

		instance.hide();
	},

	_show: function(event) {
		var instance = this;
		var align = instance.get(ALIGN);
		var node = align.node || event.currentTarget;

		instance._uiSetAlign(node, align.points);

		instance.fire('show');

		instance.show();
	},

	_toggle: function(event) {
		var instance = this;
		var currentTarget = event.currentTarget;

		// check if the target is different and simulate a .hide() before toggle
		if (instance._lastTarget != currentTarget) {
			instance.hide();
		}

		instance.toggle(event);

		event.halt();

		instance._lastTarget = event.currentTarget;
	},

	/*
	* Attribute Listeners
	*/
	_afterShowOnChange: function(event) {
		var instance = this;
		var wasToggle = event.prevVal == instance.get(HIDE_ON);

		if (wasToggle) {
			var trigger = instance.get(TRIGGER);

			// if wasToggle remove the toggle callback
			trigger.detach(event.prevVal, instance._hideCallback);
			// and re attach the hide event
			instance._setHideOn( instance.get(HIDE_ON) );
		}
	},

	_afterHideOnChange: function(event) {
		var instance = this;
		var wasToggle = event.prevVal == instance.get(SHOW_ON);

		if (wasToggle) {
			var trigger = instance.get(TRIGGER);

			// if wasToggle remove the toggle callback
			trigger.detach(event.prevVal, instance._showCallback);
			// and re attach the show event
			instance._setShowOn( instance.get(SHOW_ON) );
		}
	},

	_afterTriggerChange: function(event) {
		var instance = this;

		instance._setShowOn( instance.get(SHOW_ON) );
		instance._setHideOn( instance.get(HIDE_ON) );
	},

	_beforeShowOnChange: function(event) {
		var instance = this;
		var trigger = instance.get(TRIGGER);

		// detach the old callback
		trigger.detach(event.prevVal, instance._showCallback);
	},

	_beforeHideOnChange: function(event) {
		var instance = this;
		var trigger = instance.get(TRIGGER);

		// detach the old callback
		trigger.detach(event.prevVal, instance._hideCallback);
	},

	_beforeTriggerChange: function(event) {
		var instance = this;
		var trigger = instance.get(TRIGGER);
		var showOn = instance.get(SHOW_ON);
		var hideOn = instance.get(HIDE_ON);

		trigger.detach(showOn, instance._showCallback);
		trigger.detach(hideOn, instance._hideCallback);
	},

	/*
	* Setters
	*/
	_setHideOn: function(eventType) {
		var instance = this;
		var trigger = instance.get(TRIGGER);
		var toggle = eventType == instance.get(SHOW_ON);

		if (toggle) {
			instance._hideCallback = A.bind(instance._toggle, instance);

			// only one attached event is enough for toggle
			trigger.detach(eventType, instance._showCallback);
		}
		else {
			var delay = instance.get(HIDE_DELAY);

			instance._hideCallback = function(event) {
				instance._hideTask.delay(delay, null, null, [event]);

				event.halt();
			};
		}

		trigger.on(eventType, instance._hideCallback);

		return eventType;
	},

	_setShowOn: function(eventType) {
		var instance = this;
		var trigger = instance.get(TRIGGER);
		var toggle = eventType == instance.get(HIDE_ON);

		if (toggle) {
			instance._showCallback = A.bind(instance._toggle, instance);

			// only one attached event is enough for toggle
			trigger.detach(eventType, instance._hideCallback);
		}
		else {
			var delay = instance.get(SHOW_DELAY);

			instance._showCallback = function(event) {
				instance._showTask.delay(delay, null, null, [event]);

				event.halt();
			};
		}

		trigger.on(eventType, instance._showCallback);

		return eventType;
	}
});

A.ContextOverlay = ContextOverlay;

}, '0.1a', { requires: [ 'aui-base', 'overlay', 'delayed-task' ] });AUI.add('context-panel', function(A) {

var L = A.Lang,
	isString = L.isString,

	CONTEXT_PANEL = 'contextpanel';

function ContextPanel(config) {
 	ContextPanel.superclass.constructor.apply(this, arguments);
}

A.mix(ContextPanel, {
	NAME: CONTEXT_PANEL,

	ATTRS: {

	}
});

A.extend(ContextPanel, A.ContextOverlay, {

});

A.ContextPanel = ContextPanel;

}, '0.1a', { requires: [ 'context-overlay' ] });AUI.add('dialog', function(A) {

var L = A.Lang,
	isBoolean = L.isBoolean,
	isNumber = L.isNumber,
	isString = L.isString,
	isArray = L.isArray,
	isObject = L.isObject,

	ADD_CLASS = 'addClass',
	ANCHOR = 'a',
	BD = 'bd',
	BLANK = '',
	BODY_CONTENT = 'bodyContent',
	BOUNDING_BOX = 'boundingBox',
	BUTTON = 'button',
	BUTTONS = 'buttons',
	CLOSE = 'close',
	CONSTRAIN_TO_VIEWPORT = 'constrain2view',
	CONTAINER = 'container',
	CONTENT_BOX = 'contentBox',
	DD = 'dd',
	DEFAULT = 'default',
	DESTROY_ON_CLOSE = 'destroyOnClose',
	DIALOG = 'dialog',
	DOT = '.',
	DRAGGABLE = 'draggable',
	DRAG_INSTANCE = 'dragInstance',
	FOOTER_CONTENT = 'footerContent',
	FT = 'ft',
	HD = 'hd',
	HEADER = 'header',
	HEADER_CONTENT = 'headerContent',
	HOVER = 'hover',
	ICON = 'icon',
	INNER_HTML = 'innerHTML',
	IO = 'io',
	LOADING = 'loading',
	POST = 'POST',
	REMOVE_CLASS = 'removeClass',
	SPACE = ' ',
	STACK = 'stack',
	STATE = 'state',
	TITLE = 'title',
	WIDGET = 'widget',

	getCN = A.ClassNameManager.getClassName,

	CSS_DIALOG_BUTTON = getCN(DIALOG, BUTTON),
	CSS_DIALOG_BUTTON_CONTAINER = getCN(DIALOG, BUTTON, CONTAINER),
	CSS_DIALOG_BUTTON_DEFAULT = getCN(DIALOG, BUTTON, DEFAULT),
	CSS_DIALOG_CLOSE = getCN(DIALOG, CLOSE),
	CSS_DIALOG_TITLE = getCN(DIALOG, TITLE),
	CSS_ICON = getCN(ICON),
	CSS_ICON_CLOSE = getCN(ICON, CLOSE),
	CSS_ICON_LOADING = getCN(ICON, LOADING),
	CSS_PREFIX = getCN(DD),
	CSS_STATE_DEFAULT = getCN(STATE, DEFAULT),
	CSS_STATE_HOVER = getCN(STATE, HOVER),
	CSS_WIDGET_HD = getCN(WIDGET, HD),
	CSS_DIALOG_HD = getCN(DIALOG, HD),
	CSS_DIALOG_BD = getCN(DIALOG, BD),
	CSS_DIALOG_FT = getCN(DIALOG, FT),

	TPL_LOADING = '<div class="' + CSS_ICON_LOADING + '"></div>';

function Dialog(config) {
	Dialog.superclass.constructor.apply(this, arguments);
}

A.mix(Dialog, {
	NAME: DIALOG,

	ATTRS: {
		bodyContent: {
			value: SPACE
		},

		buttons: {
			value: [],
			validator: isArray
		},

		constrain2view: {
			value: true,
			validator: isBoolean
		},

		destroyOnClose: {
			value: false,
			validator: isBoolean
		},

		draggable: {
			lazyAdd: true,
			value: true,
			setter: function(v) {
				return this._setDraggable(v);
			}
		},

		dragInstance: {
			value: null
		},

		headerContent: {
			writeOnce: true,
			getter: function() {
				return this.titleContainter;
			}
		},

		io: {
			lazyAdd: true,
			value: null,
			setter: function(v) {
				return this._setIO(v);
			}
		},

		stack: {
			lazyAdd: true,
			value: true,
			setter: function(v) {
				return this._setStack(v);
			},
			validator: isBoolean
		},

		title: {
			value: BLANK,
			validator: function(v) {
				return isString(v) || isBoolean(v);
			}
		}
	}
});

A.extend(Dialog, A.Overlay, {
	/*
	* Lifecycle
	*/
	renderUI: function () {
		var instance = this;

		instance._renderElements();
	},

	bindUI: function () {
		var instance = this;

		instance._bindElements();
	},

	renderer: function() {
		var instance = this;

		Dialog.superclass.renderer.apply(instance, arguments);

		instance._afterRenderer();
	},

	destructor: function() {
		var instance = this;

		if (instance.OverlayManager) {
			instance.OverlayManager.destroy();
		}

		instance.get(BOUNDING_BOX).remove();
	},

	/*
	* Methods
	*/
	close: function() {
		var instance = this;

		if (instance.get(DESTROY_ON_CLOSE)) {
			instance.destroy();
		}
		else {
			instance.hide();
		}

		instance.fire('close');
	},

	_bindElements: function () {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);

		instance.closeIcon.on(
			'click',
			function(event) {
				instance.close();
			}
		);

		boundingBox.on('mousedown', function() {
			if (instance.OverlayManager) {
				instance.OverlayManager.bringToTop();
			}

			instance.fire('focus');
		});

		instance.after('titleChange', this._afterSetTitle);
	},

	_renderElements: function() {
		var instance = this;

		instance.titleContainter = A.Node.create('<div></div>');

		var closeIcon = new A.ToolItem(CLOSE);

		closeIcon.get('node').addClass(CSS_DIALOG_CLOSE);

		instance.closeIcon = closeIcon;

		var title = instance.get(TITLE);

		if (title !== false) {
			var titleContainter = instance.titleContainter;

			titleContainter.addClass(CSS_DIALOG_TITLE);

			titleContainter.html(title);
		}
	},

	_afterRenderer: function() {
		var instance = this;
		var bodyNode = instance.bodyNode;
		var footerNode = instance.footerNode;
		var headerNode = instance.headerNode;

		var stack = instance.get(STACK);
		var title = instance.get(TITLE);

		headerNode.addClass(CSS_DIALOG_HD);
		headerNode.addClass(CSS_STATE_DEFAULT);

		if (bodyNode) {
			bodyNode.addClass(CSS_DIALOG_BD);
		}

		if (footerNode) {
			footerNode.addClass(CSS_DIALOG_FT);
		}

		if (title === false) {
			headerNode.removeClass(CSS_STATE_DEFAULT);
			headerNode.removeClass(CSS_WIDGET_HD);
			headerNode.removeClass(CSS_DIALOG_HD);
		}

		headerNode.append(instance.titleContainter);

		instance.closeIcon.render(headerNode);

		instance._initButtons();

		// forcing lazyAdd:true attrs call the setter
		instance.get(DRAGGABLE);
		instance.get(IO);
	},

	_initButtons: function() {
		var instance = this;
		var buttons = instance.get(BUTTONS);
		var container = A.Node.create('<div></div>');
		var nodeModel = A.Node.create('<button></button>');

		container.addClass(CSS_DIALOG_BUTTON_CONTAINER);
		nodeModel.addClass(CSS_DIALOG_BUTTON);

		A.each(buttons, function(button, i) {
			var node = nodeModel.cloneNode();

			if (button.isDefault) {
				node.addClass(CSS_DIALOG_BUTTON_DEFAULT);
			}

			if (button.handler) {
				node.on('click', A.bind(button.handler, instance));
			}

			node.html(button.text || BLANK);

			container.append(node);
		});

		if (buttons.length) {
			instance.set(FOOTER_CONTENT, container);

			instance.footerNode.addClass(CSS_DIALOG_FT);
		}
	},

	_setDraggable: function(value) {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);

		var destroyDraggable = function() {
			var dragInstance = instance.get(DRAG_INSTANCE);

			if (dragInstance) {
				// TODO - YUI3 has a bug when destroy and recreates
				dragInstance.destroy();
				dragInstance.unplug(A.Plugin.DDConstrained);
			}
		};

		A.DD.DDM.CSS_PREFIX = CSS_PREFIX;

		if (value) {
			var defaults = {
				node: boundingBox,
				handles: [ DOT + CSS_DIALOG_HD ]
			};
			var dragOptions = A.merge(defaults, instance.get(DRAGGABLE) || {});

			// change the drag scope callback to execute using the dialog scope
			if (dragOptions.on) {
				A.each(dragOptions.on, function(fn, eventName) {
					dragOptions.on[eventName] = A.bind(fn, instance);
				});
			}

			destroyDraggable();

			var dragInstance = new A.DD.Drag(dragOptions);

			dragInstance.plug(A.Plugin.DDConstrained, {
				constrain2view: instance.get(CONSTRAIN_TO_VIEWPORT)
			});

			instance.set(DRAG_INSTANCE, dragInstance);
		}
		else {
			destroyDraggable();
		}

		return value;
	},

	_setIO: function(value) {
		var instance = this;

		if (value && !instance.get(BODY_CONTENT)) {
			instance.set(BODY_CONTENT, TPL_LOADING);
		}

		if (value) {
			instance.unplug(A.Plugin.StdModIOPlugin);

			value.uri = value.uri || value.url;
			value.cfg = value.cfg || {};

			var data = value.cfg.data;

			if (isObject(data)) {
				value.cfg.data = A.toQueryString(data);
			}

			instance.plug(A.Plugin.StdModIOPlugin, value);

			var autoRefresh = ('autoRefresh' in value) ? value.autoRefresh : true;

			if (instance.io && autoRefresh) {
				instance.io.refresh();
			}
		}
		else {
			instance.unplug(A.Plugin.StdModIOPlugin);
		}

		return value;
	},

	_setStack: function(value) {
		var instance = this;

		if (value) {
			A.DialogManager.register(instance);
		}
		else {
			A.DialogManager.remove(instance);
		}

		return value;
	},

	/*
	* Attribute Listeners
	*/
	_afterSetTitle: function(event) {
		var instance = this;

		if (!isBoolean(event.newVal)) {
			var headerNode = instance.headerNode;

			headerNode.addClass(CSS_WIDGET_HD);
			headerNode.addClass(CSS_DIALOG_HD);
			headerNode.addClass(CSS_STATE_DEFAULT);

			instance.titleContainter.html(event.newVal);
		}
	}
});

A.Dialog = Dialog;

A.DialogManager = new A.OverlayManager({
	zIndexBase: 1000
});

A.mix(A.DialogManager, {
	findByChild: function(child) {
		return A.Widget.getByNode(child);
	},

	closeByChild: function(child) {
		return A.DialogManager.findByChild(child).close();
	},

	refreshByChild: function(child, io) {
		var dialog = A.DialogManager.findByChild(child);

		if (dialog && dialog.io) {
			if (io) {
				dialog.set(IO, io);
			}
			else {
				dialog.io.refresh();
			}
		}
	}
});

}, '0.1a', { requires: [ 'aui-base', 'overlay-manager', 'dd-constrain', 'io-stdmod', 'dialog-css' ] });AUI().add(
	'editable',
	function(A) {
		var Lang = A.Lang,
			isFunction = Lang.isFunction,

			getClassName = A.ClassNameManager.getClassName,

			CONTENT = 'content',
			CTRL = 'ctrl',
			HELPER = 'helper',
			HIDDEN = 'hidden',
			HOLDER = 'holder',
			HOVER = 'hover',
			INPUT = 'input',
			NAME = 'editable',
			STATE = 'state',
			WRAPPER = 'wrapper',

			CSS_CTRL_HOLDER = getClassName(CTRL, HOLDER),
			CSS_BUTTON_ROW = getClassName('button-row'),
			CSS_EDITING = getClassName(NAME, 'editing'),
			CSS_TRIGGER_ROW = getClassName(NAME, 'form-triggers'),
			CSS_HOVER = [ getClassName(NAME, HOVER), getClassName(CTRL, HOLDER) ].join(' '),
			CSS_CONTENT_WRAPPER = getClassName(NAME, CONTENT, WRAPPER),
			CSS_INPUT_WRAPPER = getClassName(NAME, CTRL, HOLDER),
			CSS_INPUT = getClassName(NAME, INPUT),

			TPL_INPUT = '<input class="' + CSS_INPUT + '" type="text" />',
			TPL_TEXTAREA = '<textarea class="' + CSS_INPUT + '"></textarea>',
			TPL_INPUT_WRAPPER = '<span class="' + [ CSS_CTRL_HOLDER, CSS_INPUT_WRAPPER ].join(' ') + '"></span>',
			TPL_BUTTON_ROW = '<span class="' + [ CSS_BUTTON_ROW, CSS_TRIGGER_ROW ].join(' ') + '"></span>',

			CONTENT_BOX = 'contentBox';

		var Editable = function() {
			Editable.superclass.constructor.apply(this, arguments);
		};

		Editable.NAME = 'editable';
		Editable.ATTRS = {
			contentText: {
				value: '',
				setter: function(value) {
					var instance = this;

					value = Lang.trim(value);

					instance._toText(value);

					return value;
				}
			},

			formatInput: {
				value: null,
				validator: isFunction
			},

			formatOutput: {
				value: null,
				validator: isFunction
			},

			node: {
				setter: function(value) {
					var node = A.get(value);

					if (!node) {
						A.error('AUI.Editable: Invalid Node Given: ' + value);
					}
					else {
						node = node.item(0);
					}

					return node;
				}
			},

			eventType: {
				value: 'click'
			},

			renderTo: {
				value: document.body,
				setter: function(value) {
					var instance = this;

					var node;

					if (value == 'node') {
						node = instance.get(value);
					}
					else {
						node = A.get(value);
					}

					if (!node) {
						A.error('AUI.Editable: Invalid renderTo Given: ' + value);
					}
					else {
						node = node.item(0);
					}

					return node;
				}
			},

			inputType: {
				value: 'text',
				setter: function(value) {
					var instance = this;

					if (value != 'text' && value != 'textarea') {
						value = Attribute.INVALID_ATTRIBUTE;
					}

					return value;
				}
			}
		};

		A.extend(
			Editable,
			A.Widget,
			{
				initializer: function() {
					var instance = this;

					instance._scopedSave = A.bind(instance.save, instance);

					var node = instance.get('node');
					var eventType = instance.get('eventType');

					node.on('mouseenter', instance._onMouseEnterEditable, instance);
					node.on('mouseleave', instance._onMouseLeaveEditable, instance);

					node.on(eventType, instance._startEditing, instance);

					instance._createEvents();
				},

				renderUI: function() {
					var instance = this;

					var contentBox = instance.get(CONTENT_BOX);
					var inputType = instance.get('inputType');

					var buttonRow = A.Node.create(TPL_BUTTON_ROW);
					var inputWrapper = A.Node.create(TPL_INPUT_WRAPPER);
					var inputNode = A.Node.create(inputType == 'text' ? TPL_INPUT : TPL_TEXTAREA);

					var cancelButton = new A.ToolItem('circle-close');

					var saveButton = new A.ToolItem('circle-check');

					inputWrapper.appendChild(inputNode);

					contentBox.appendChild(inputWrapper);
					contentBox.appendChild(buttonRow);

					cancelButton.render(buttonRow);
					saveButton.render(buttonRow);

					inputNode.addClass(CSS_INPUT);

					instance.inputWrapper = inputWrapper;
					instance.buttonRow = buttonRow;

					instance.cancelButton = cancelButton;
					instance.saveButton = saveButton;

					instance.inputNode = inputNode;
				},

				bindUI: function() {
					var instance = this;

					var contentBox = instance.get(CONTENT_BOX);
					var node = instance.get('node');

					var inputNode = instance.inputNode;

					inputNode.on('keypress', instance._onKeypressEditable, instance);

					instance.cancelButton.on('click', instance.cancel, instance);
					instance.saveButton.on('click', instance.save, instance);

					instance.after('contentTextChange', instance._syncContentText);

					instance.after('focusedChange', instance._afterFocusedChangeEditable);
				},

				syncUI: function() {
					var instance = this;

					var currentText = instance.get('node').get('innerHTML');

					currentText = currentText.replace(/\n|\r/gim, '');
					currentText = Lang.trim(currentText);

					currentText = instance._toText(currentText);

					instance._setInput(currentText);

					instance.set(
						'contentText',
						currentText,
						{
							initial: true
						}
					);
				},

				cancel: function() {
					var instance = this;

					instance.fire('cancel');
				},

				save: function(event) {
					var instance = this;

					instance.fire('save');
				},

				_afterFocusedChangeEditable: function(event) {
					var instance = this;

					if (event.newVal === false) {
						instance.fire('stopEditing', instance.get('visible'));
					}
				},

				_createEvents: function() {
					var instance = this;

					instance.publish(
						'startEditing',
						{
							bubbles: true,
							defaultFn: instance._defStartEditingFn,
							emitFacade: true,
							queable: false
						}
					);

					instance.publish(
						'stopEditing',
						{
							bubbles: true,
							defaultFn: instance._defStopEditingFn,
							emitFacade: true,
							queable: false
						}
					);

					instance.publish(
						'save',
						{
							bubbles: true,
							defaultFn: instance._defSaveFn,
							emitFacade: true,
							queable: false
						}
					);

					instance.publish(
						'cancel',
						{
							bubbles: true,
							defaultFn: instance._defCancelFn,
							emitFacade: true,
							queable: false
						}
					);
				},

				_defCancelFn: function(event) {
					var instance = this;

					instance.fire('stopEditing', false);
				},

				_defStartEditingFn: function(event) {
					var instance = this;

					var boundingBox = instance.get('boundingBox');
					var node = instance.get('node');

					var inputNode = instance.inputNode;

					var nodeHeight = node.get('offsetHeight');
					var nodeWidth = node.get('offsetWidth');

					instance.show();

					node.addClass(CSS_EDITING);

					var xy = node.getXY();

					boundingBox.setStyles(
						{
							height: nodeHeight + 'px',
							left: xy[0] + 'px',
							top: xy[1] + 'px',
							width: nodeWidth + 'px'
						}
					);

					inputNode.focus();
					inputNode.select();
				},

				_defStopEditingFn: function(event, save) {
					var instance = this;

					instance.hide();

					instance.get('node').removeClass(CSS_EDITING);

					if (save) {
						instance.set('contentText', instance.inputNode.get('value'));
					}
					else {
						instance._setInput(instance.get('contentText'));
					}
				},

				_defSaveFn: function(event) {
					var instance = this;

					instance.fire('stopEditing', true);
				},

				_onKeypressEditable: function(event) {
					var instance = this;

					var keyCode = event.keyCode;

					if (keyCode == 27) {
						event.preventDefault();

						instance.cancel();
					}
					else if (keyCode == 13 && (instance.get('inputType') == 'text')) {
						instance.save();
					}
				},

				_onMouseEnterEditable: function(event) {
					var instance = this;

					instance.get('node').addClass(CSS_HOVER);
				},

				_onMouseLeaveEditable: function(event) {
					var instance = this;

					instance.get('node').removeClass(CSS_HOVER);
				},

				_setInput: function(value) {
					var instance = this;

					var inputFormatter = instance.get('formatInput');

					if (inputFormatter) {
						value = inputFormatter.call(instance, value);
					}
					else {
						value = instance._toText(value);
					}

					instance.inputNode.set('value', value);
				},

				_setOutput: function(value) {
					var instance = this;

					var outputFormatter = instance.get('formatOutput');

					if (outputFormatter) {
						value = outputFormatter.call(instance, value);
					}
					else {
						value = instance._toHTML(value);
					}

					instance.get('node').set('innerHTML', value);
				},

				_startEditing: function(event) {
					var instance = this;

					if (!instance.get('rendered')) {
						instance.render(instance.get('renderTo'));
					}

					instance.fire('startEditing');

					event.halt();
				},

				_syncContentText: function(event) {
					var instance = this;

					if (!event.initial) {
						var contentText = event.newVal;

						instance._setInput(contentText);
						instance._setOutput(contentText);
					}
				},

				_toHTML: function(text) {
					var instance = this;

					return String(text).replace(/\n|\r/gim, '<br/>');
				},

				_toText: function(text) {
					var instance = this;

					var text = String(text);

					text = text.replace(/<br\s*\/?>/gim, '\n');

					text = text.replace(/(<\/?[^>]+>|\t)/gim, '');

					return text;
				}
			}
		);

		A.Editable = Editable;
	},
	'0.1a',
	{
		requires: ['widget', 'tool'],
		use: []
	}
);AUI.add('io-stdmod', function(A) {

var L = A.Lang,
	isString = L.isString,

	BLANK = '',
	CFG = 'cfg',
	FORMATTER = 'formatter',
	HOST = 'host',
	ICON = 'icon',
	LOADING = 'loading',
	POST = 'POST',
	SECTION = 'section',
	URI = 'uri',

	getCN = A.ClassNameManager.getClassName,

	CSS_ICON_LOADING = getCN(ICON, LOADING);

var StdMod = A.WidgetStdMod;

/* Standard Module IO Plugin Constructor */
function StdModIOPlugin(config) {
	StdModIOPlugin.superclass.constructor.apply(this, arguments);
}

A.mix(StdModIOPlugin, {
	NAME: 'stdModIOPlugin',

	NS: 'io',

	ATTRS: {
		uri: {
			value: null
		},

		cfg: {
			value: {}
		},

		/*
		* The default formatter to use when formatting response data. The default
		* implementation simply passes back the response data passed in.
		*/
		formatter: {
			valueFn: function() {
				return this._defFormatter;
			}
		},

		/*
		* The Standard Module section to which the io plugin instance is bound.
		* Response data will be used to populate this section, after passing through
		* the configured formatter.
		*/
		section: {
			value: StdMod.BODY,
			validator: function(val) {
				return (!val || val == StdMod.BODY || val == StdMod.HEADER || val == StdMod.FOOTER);
			}
		},

		loading: {
			value: '<div class="' + CSS_ICON_LOADING + '"></div>'
		}
	}
});

A.extend(StdModIOPlugin, A.Plugin.Base, {
	destructor: function() {
		if (this.isActive()) {
			A.io.abort(this._activeIO);
			this._activeIO = null;
		}
	},

	isActive: function() {
		return this._activeIO;
	},

	/*
	* IO Plugin specific method, use to initiate a new io request using the current
	* io configuration settings.
	*/
	refresh: function() {
		var instance = this;
		var section = this.get(SECTION);

		if (section && !this.isActive()) {
			var uri = this.get(URI);

			if (uri) {
				var cfg = A.mix(
					this.get(CFG),
					{
						method: POST,
						on: {}
					}
				);

				// binding correct scopes on callbacks
				cfg.on = A.merge(
					cfg.on,
					{
						start: A.bind(cfg.on.start || this._defStartHandler, this),
						complete: A.bind(cfg.on.complete || this._defCompleteHandler, this),
						success: A.bind(cfg.on.success || this._defSuccessHandler, this),
						failure: A.bind(cfg.on.failure || this._defFailureHandler, this)
					}
				);

				A.io(uri, cfg);
			}
		}
	},

	_defSuccessHandler: function(id, o) {
		var response = o.responseText || BLANK;
		var section = this.get(SECTION);
		var formatter = this.get(FORMATTER);

		this.get(HOST).setStdModContent(section, formatter(response));
	},

	_defFailureHandler: function(id, o) {
		this.get(HOST).setStdModContent(this.get(SECTION), 'Failed to retrieve content');
	},

	_defStartHandler: function(id, o) {
		this._activeIO = o;
		this.get(HOST).setStdModContent(this.get(SECTION), this.get(LOADING));
	},

	_defCompleteHandler: function(id, o) {
		this._activeIO = null;
	},

	_defFormatter: function(val) {
		return val;
	}
});

A.namespace('Plugin');
A.Plugin.StdModIOPlugin = StdModIOPlugin;

}, '0.1a', { requires: [ 'overlay', 'io', 'plugin' ] });AUI.add('overlay-manager', function(A) {

var Lang = A.Lang,
	isArray = Lang.isArray,
	isBoolean = Lang.isBoolean,
	isNumber = Lang.isNumber,
	isString = Lang.isString,

	BOUNDING_BOX = 'boundingBox',
	DEFAULT = 'default',
	HOST = 'host',
	OVERLAY_MANAGER = 'OverlayManager',
	GROUP = 'group',
	Z_INDEX = 'zIndex',
	Z_INDEX_BASE = 'zIndexBase';

	function OverlayManager(config) {
	 	OverlayManager.superclass.constructor.apply(this, arguments);
	}

	A.mix(
		OverlayManager,
		{
			NAME: OVERLAY_MANAGER.toLowerCase(),

			ATTRS: {
				zIndexBase: {
					value: 1000,
					validator: isNumber,
					setter: function(value) {
						return parseInt(value, 10);
					}
				}
			}
		}
	);

	A.extend(OverlayManager, A.Base, {
		initializer: function() {
			var instance = this;

			instance._overlays = [];
		},

		bringToTop: function(overlay) {
			var instance = this;

			var overlays = instance._overlays.sort(instance.sortByZIndexDesc);

			var highest = overlays[0];

			if (highest !== overlay) {
				var overlayZ = overlay.get(Z_INDEX);
				var highestZ = highest.get(Z_INDEX);

				overlay.set(Z_INDEX, highestZ + 1);

				overlay.focus();
			}
		},

		destroy: function() {
			var instance = this;

			instance.remove();
		},

		register: function (overlay) {
			var instance = this;

			var overlays = instance._overlays;

			if (isArray(overlay)) {
				A.Array.each(overlay, function(o) {
					instance.register(o);
				});
			}
			else {
				var zIndexBase = instance.get(Z_INDEX_BASE);
				var registered = instance._registered(overlay);

				if (!registered && overlay && (overlay instanceof A.Overlay)) {
					var boundingBox = overlay.get(BOUNDING_BOX);

					overlays.push(overlay);

					var zIndex = overlay.get(Z_INDEX) || 0;
					var newZIndex = overlays.length + zIndex + zIndexBase;

					overlay.set(Z_INDEX, newZIndex);

					overlay.on('focusedChange', instance._onFocusedChange, instance);
					boundingBox.on('mousedown', instance._onMouseDown, instance);
				}
			}

			return overlays;
		},

		remove: function (overlay) {
			var instance = this;

			var overlays = instance._overlays;

			return A.Array.removeItem(overlays, overlay);
		},

		each: function(fn) {
			var instance = this;

			var overlays = instance._overlays;

			A.Array.each(overlays, fn);
		},

		showAll: function() {
			this.each(
				function(overlay) {
					overlay.show();
				}
			);
		},

		hideAll: function() {
			this.each(
				function(overlay) {
					overlay.hide();
				}
			);
		},

		sortByZIndexDesc: function(a, b) {
			if (!a || !b || !a.hasImpl(A.WidgetStack) || !b.hasImpl(A.WidgetStack)) {
				return 0;
			}
			else {
				var aZ = a.get(Z_INDEX);
				var bZ = b.get(Z_INDEX);

				if (aZ > bZ) {
					return -1;
				} else if (aZ < bZ) {
					return 1;
				} else {
					return 0;
				}
			}
		},

		_registered: function(overlay) {
			var instance = this;

			return A.Array.indexOf(instance._overlays, overlay) != -1;
		},

		_onMouseDown: function(event) {
			var instance = this;
			var overlay = A.Widget.getByNode(event.currentTarget || event.target);
			var registered = instance._registered(overlay);

			if (overlay && registered) {
				instance.bringToTop(overlay);
			}
		},

		_onFocusedChange: function(event) {
			var instance = this;

			if (event.newVal) {
				var overlay = event.currentTarget || event.target;
				var registered = instance._registered(overlay);

				if (overlay && registered) {
					instance.bringToTop(overlay);
				}
			}
		}
	});

	A.OverlayManager = OverlayManager;

}, '0.1a', { requires: [ 'overlay', 'plugin' ] });AUI.add('overlay-mask', function(A) {

var L = A.Lang,
	isString = L.isString,

	OVERLAY_MASK = 'OverlayMask';

function OverlayMask(config) {
 	OverlayMask.superclass.constructor.apply(this, arguments);
}

A.mix(OverlayMask, {
	NAME: OVERLAY_MASK,

	NS: OVERLAY_MASK,

	ATTRS: {

	}
});

A.extend(OverlayMask, A.Plugin.Base, {

});

A.namespace('Plugin');
A.Plugin.OverlayMask = OverlayMask;

}, '0.1a', { requires: [ 'overlay' ] });AUI.add('rating', function(A) {

var L = A.Lang,
	isBoolean = L.isBoolean,
	isNumber = L.isNumber,
	isString = L.isString,

	isNodeList = function(v) {
		return (v instanceof A.NodeList);
	},

	isNode = function(v) {
		return (v instanceof A.Node);
	},

	ANCHOR = 'a',
	AUTO_RENDER = 'autoRender',
	BLANK = '',
	BOUNDING_BOX = 'boundingBox',
	CAN_RESET = 'canReset',
	CLEARFIX = 'clearfix',
	CONTENT_BOX = 'contentBox',
	DEFAULT_SELECTED = 'defaultSelected',
	DESTROY = 'destroy',
	DISABLED = 'disabled',
	ELEMENT = 'element',
	ELEMENTS = 'elements',
	HELPER = 'helper',
	HOVER = 'hover',
	INNER_HTML = 'innerHTML',
	INPUT = 'input',
	INPUT_NAME = 'inputName',
	LABEL = 'label',
	LABEL_ELEMENT = 'labelElement',
	NAME = 'name',
	OFF = 'off',
	ON = 'on',
	RATING = 'rating',
	SELECTED_INDEX = 'selectedIndex',
	SHOW_TITLE = 'showTitle',
	SIZE = 'size',
	TITLE = 'title',
	VALUE = 'value',

	getCN = A.ClassNameManager.getClassName,

	CSS_CLEAR_FIX = getCN(HELPER, CLEARFIX),
	CSS_RATING_LABEL_EL = getCN(RATING, LABEL, ELEMENT),
	CSS_RATING_EL = getCN(RATING, ELEMENT),
	CSS_RATING_EL_HOVER  = getCN(RATING, ELEMENT, HOVER),
	CSS_RATING_EL_OFF = getCN(RATING, ELEMENT, OFF),
	CSS_RATING_EL_ON = getCN(RATING, ELEMENT, ON);

function Rating() {
	Rating.superclass.constructor.apply(this, arguments);
}

A.mix(Rating, {
	NAME: 'Rating',

	ATTRS: {
		autoRender: {
			value: true,
			validator: isBoolean
		},

		canReset: {
			value: true,
			validator: isBoolean
		},

		defaultSelected: {
			value: 0,
			writeOnce: true,
			validator: isNumber
		},

		elements: {
			writeOnce: true,
			readOnly: true,
			validator: isNodeList
		},

		hiddenInput: {
			validator: isNode
		},

		labelElement: {
			validator: isNode
		},

		inputName: {
			value: BLANK,
			validator: isString
		},

		label: {
			value: BLANK,
			validator: isString
		},

		selectedIndex: {
			value: -1,
			validator: isNumber
		},

		showTitle: {
			value: true,
			validator: isBoolean
		},

		size: {
			value: 5,
			validator: function(v) {
				return isNumber(v) && (v > 0);
			}
		},

		title: null,

		value: null
	}
});

A.extend(Rating, A.Widget, {
	/*
	* Lifecycle
	*/
	initializer: function(){
		var instance = this;

		instance.inputElementsData = {};

		instance.after('labelChange', this._afterSetLabel);

		if (instance.get(AUTO_RENDER)) {
			instance.render();
		}
	},

	renderUI: function () {
		var instance = this;

		instance._parseInputElements();
		instance._renderElements();
	},

	bindUI: function () {
		var instance = this;

		instance._delegateElements();
	},

	syncUI: function(){
		var instance = this;

		instance._syncElements();
	},

	destructor: function(){
		var instance = this;
		var	boundingBox = instance.get(BOUNDING_BOX);

		boundingBox.detachAll();
		boundingBox.remove();
	},

	/*
	* Methods
	*/
	clearSelection: function() {
		var instance = this;

		instance.get(ELEMENTS).each(function(node) {
			node.removeClass(CSS_RATING_EL_ON);
			node.removeClass(CSS_RATING_EL_HOVER);
		});
	},

	select: function(index) {
		var instance = this;
		var oldIndex = instance.get(SELECTED_INDEX);
		var canReset = instance.get(CAN_RESET);

		// clear selection when the selected element is clicked
		if (canReset && (oldIndex == index)) {
			index = -1;
		}

		instance.set(SELECTED_INDEX, index);

		var selectedIndex = instance.get(SELECTED_INDEX);
		var	data = instance._getInputData(selectedIndex);

		var title = (TITLE in data) ? data.title : BLANK;
		var value = (VALUE in data) ? data.value : selectedIndex;

		instance.fillTo(selectedIndex);

		instance.set(TITLE, title);
		instance.set(VALUE, value);

		var hiddenInput = instance.get('hiddenInput');

		hiddenInput.setAttribute(TITLE, title);
		hiddenInput.setAttribute(VALUE, value);

		instance.fire('select');
	},

	fillTo: function(index, className) {
		var instance = this;

		instance.clearSelection();

		if (index >= 0) {
			instance.get(ELEMENTS).some(function(node, i) {
				node.addClass(className || CSS_RATING_EL_ON);

				return (index == i);
			});
		}
	},

	_parseInputElements: function() {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);
		var inputs = boundingBox.queryAll(INPUT);
		var size = inputs.size();
		var inputName = instance.get(INPUT_NAME);
		var hiddenInput = A.Node.create('<input type="hidden" />');

		if (size > 0) {
			inputName = inputName || inputs.item(0).getAttribute(NAME);

			instance.set(SIZE, size);

			inputs.each(function(node, index) {
				instance.inputElementsData[index] = {
					value: node.getAttribute(VALUE) || index,
					title: node.getAttribute(TITLE)
				};
			});

			inputs.remove();
		}

		hiddenInput.setAttribute(NAME, inputName);

		boundingBox.appendChild(hiddenInput);

		instance.set('hiddenInput', hiddenInput);
	},

	_renderElements: function() {
		var instance = this;
		var contentBox = instance.get(CONTENT_BOX);
		var ratingElement = A.Node.create('<a href="javascript:void(0);"></a>');
		var labelElement = A.Node.create('<div></div>');

		contentBox.addClass(CSS_CLEAR_FIX);
		ratingElement.addClass(CSS_RATING_EL);
		ratingElement.addClass(CSS_RATING_EL_OFF);
		labelElement.addClass(CSS_RATING_LABEL_EL);

		contentBox.append(labelElement);

		// creating rating elements
		for (var i = 0, size = this.get(SIZE); i < size; i++) {
			var	data = instance._getInputData(i);
			var title = data.title;
			var element = ratingElement.cloneNode();

			if (!title) {
				title = instance.get(TITLE);
			}

			if (instance.get(SHOW_TITLE) && title) {
				element.setAttribute(TITLE, title);
			}

			contentBox.appendChild(element);
		}

		instance.set(LABEL_ELEMENT, labelElement);
		instance.set(ELEMENTS, contentBox.queryAll(ANCHOR));
	},

	_syncElements: function(){
		var instance = this;
		var labelText = instance.get(LABEL);
		var selectedIndex = instance.get(DEFAULT_SELECTED) - 1;

		instance.set(SELECTED_INDEX, selectedIndex);

		instance.get(LABEL_ELEMENT).html(labelText);

		instance.select();
	},

	_delegateElements: function() {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);

		boundingBox.delegate('click', A.bind(instance._delegateMethod, this), ANCHOR);
		boundingBox.delegate('mouseover', A.bind(instance._delegateMethod, this), ANCHOR);
		boundingBox.delegate('mouseout', A.bind(instance._delegateMethod, this), ANCHOR);
	},

	_getInputData: function(index) {
		var instance = this;

		return instance.inputElementsData[index] || {};
	},

	/*
	* Delegated events
	*/
	_delegateMethod: function(event){
		var instance = this;
		var type = event.type;
		var disabled = instance.get(DISABLED);
		var	elements = instance.get(ELEMENTS);
		var selectedIndex = instance.get(SELECTED_INDEX);
		var index = elements.indexOf(event.target);

		var on = {
			click: function() {
				instance.select(index);
			},
			mouseover: function() {
				instance.fillTo(index, CSS_RATING_EL_HOVER);
			},
			mouseout: function() {
				instance.fillTo(selectedIndex);
			}
		};

		if (type) {
			if (!disabled) {
				on[type]();
			}
			// trigger user callback even when disabled
			instance.fire(type);
		}
	},

	/*
	* Attribute Listeners
	*/
	_afterSetLabel: function(event) {
		this.syncUI();
	}
});


/*
* ThumbRating
*/
var DOWN = 'down',
	THUMB = 'thumb',
	THUMB_RATING = 'ThumbRating',
	UP = 'up',

	CSS_RATING_THUMB_DOWN = getCN(RATING, THUMB, DOWN),
	CSS_RATING_THUMB_UP = getCN(RATING, THUMB, UP);

function ThumbRating(config) {
	ThumbRating.superclass.constructor.apply(this, arguments);
}

A.mix(ThumbRating, {
	NAME: THUMB_RATING,

	ATTRS: {
		size: {
			value: 2,
			readOnly: true
		}
	}
});

A.extend(ThumbRating, Rating, {
	renderUI: function() {
		ThumbRating.superclass.renderUI.apply(this, arguments);

		var elements = this.get(ELEMENTS);
		elements.item(0).addClass(CSS_RATING_THUMB_UP);
		elements.item(1).addClass(CSS_RATING_THUMB_DOWN);
	},

	fillTo: function(index, className) {
		this.clearSelection();

		if (index >= 0) {
			this.get(ELEMENTS).item(index).addClass(className || CSS_RATING_EL_ON);
		}
	},

	_syncElements: function(){
		var instance = this;
		var labelText = instance.get(LABEL);

		instance.get(LABEL_ELEMENT).html(labelText);
	}
});

A.Rating = Rating;
A.StarRating = Rating;
A.ThumbRating = ThumbRating;

}, '0.1a' , { requires: [ 'widget' ] });
AUI().add(
	'resize',
	function(A) {
		var Lang = A.Lang,
			isBoolean = Lang.isBoolean,
			isNumber = Lang.isNumber,
			isString = Lang.isString,
			isArray = Lang.isArray,

			UA = A.UA,
			IS_IE = UA.ie,

			getClassName = A.ClassNameManager.getClassName,

			NAME = 'resize',

			STR_BLANK = ' ',
			STR_HANDLE = 'handle',
			STR_ACTIVE = 'active',
			STR_INNER = 'inner',
			STR_T = 't',
			STR_R = 'r',
			STR_B = 'b',
			STR_L = 'l',
			STR_TR = 'tr',
			STR_TL = 'tl',
			STR_BR = 'br',
			STR_BL = 'bl',

			CSS_RESIZE = getClassName(NAME),
			CSS_TEXTAREA = getClassName(NAME, 'textarea'),
			CSS_DRAG = getClassName('dd'),
			CSS_HOVER = getClassName(NAME, 'hover'),
			CSS_PROXY = getClassName(NAME, 'proxy'),
			CSS_WRAP = getClassName(NAME, 'wrap'),
			CSS_KNOB = getClassName(NAME, 'knob'),
			CSS_HIDDEN = getClassName(NAME, 'hidden'),
			CSS_STATUS = getClassName(NAME, 'status'),
			CSS_GHOST = getClassName(NAME, 'ghost'),
			CSS_RESIZING = getClassName(NAME, 'resizing'),

			CSS_ICON = getClassName('icon'),
			CSS_GRIP_HORIZONTAL = getClassName('icon-grip-solid-horizontal'),
			CSS_GRIP_VERTICAL = getClassName('icon-grip-solid-vertical'),
			CSS_GRIP_DIAGONAL_TR = getClassName('icon-grip-diagonal-tr'),
			CSS_GRIP_DIAGONAL_TL = getClassName('icon-grip-diagonal-tl'),
			CSS_GRIP_DIAGONAL_BR = getClassName('icon-grip-diagonal-br'),
			CSS_GRIP_DIAGONAL_BL = getClassName('icon-grip-diagonal-bl'),

			CSS_HANDLE = getClassName(NAME, STR_HANDLE),
			CSS_HANDLE_ACTIVE = getClassName(NAME, STR_HANDLE, STR_ACTIVE),

			CSS_HANDLES_MAP = {
				t: getClassName(NAME, STR_HANDLE, STR_T),
				r: getClassName(NAME, STR_HANDLE, STR_R),
				b: getClassName(NAME, STR_HANDLE, STR_B),
				l: getClassName(NAME, STR_HANDLE, STR_L),
				tr: getClassName(NAME, STR_HANDLE, STR_TR),
				tl: getClassName(NAME, STR_HANDLE, STR_TL),
				br: getClassName(NAME, STR_HANDLE, STR_BR),
				bl: getClassName(NAME, STR_HANDLE, STR_BL)
			},

			CSS_HANDLES_INNER_MAP = {
				t: [getClassName(NAME, STR_INNER, STR_T), CSS_ICON, CSS_GRIP_HORIZONTAL].join(STR_BLANK),
				r: [getClassName(NAME, STR_INNER, STR_R), CSS_ICON, CSS_GRIP_VERTICAL].join(STR_BLANK),
				b: [getClassName(NAME, STR_INNER, STR_B), CSS_ICON, CSS_GRIP_HORIZONTAL].join(STR_BLANK),
				l: [getClassName(NAME, STR_INNER, STR_L), CSS_ICON, CSS_GRIP_VERTICAL].join(STR_BLANK),
				tr: [getClassName(NAME, STR_INNER, STR_TR), CSS_ICON, CSS_GRIP_DIAGONAL_TR].join(STR_BLANK),
				tl: [getClassName(NAME, STR_INNER, STR_TL), CSS_ICON, CSS_GRIP_DIAGONAL_TL].join(STR_BLANK),
				br: [getClassName(NAME, STR_INNER, STR_BR), CSS_ICON, CSS_GRIP_DIAGONAL_BR].join(STR_BLANK),
				bl: [getClassName(NAME, STR_INNER, STR_BL), CSS_ICON, CSS_GRIP_DIAGONAL_BL].join(STR_BLANK)
			},

			CSS_HANDLES_ACTIVE_MAP = {
				t: getClassName(NAME, STR_HANDLE, STR_T, STR_ACTIVE),
				r: getClassName(NAME, STR_HANDLE, STR_R, STR_ACTIVE),
				b: getClassName(NAME, STR_HANDLE, STR_B, STR_ACTIVE),
				l: getClassName(NAME, STR_HANDLE, STR_L, STR_ACTIVE),
				tr: getClassName(NAME, STR_HANDLE, STR_TR, STR_ACTIVE),
				tl: getClassName(NAME, STR_HANDLE, STR_TL, STR_ACTIVE),
				br: getClassName(NAME, STR_HANDLE, STR_BR, STR_ACTIVE),
				bl: getClassName(NAME, STR_HANDLE, STR_BL, STR_ACTIVE)
			};

		var Resize = function() {
			Resize.superclass.constructor.apply(this, arguments);
		};

		Resize.NAME = NAME;

		Resize.ATTRS = {
			active: {
				value: false
			},

			dd: {
				value: null
			},

			node: {
				setter: function(value) {
					var instance = this;

					var node = A.get(value);

					if (!node) {
						A.error('Resize: Invalid Node Given: ' + value);
					}
					else {
						node = node.item(0);
					}

					return node;
				}
			},

			lock: {
				value: false,
				setter: function(value) {
					var instance = this;

					var dd = instance.get('dd');

					if (dd) {
						dd.set('lock', value);
					}

					return value;
				},
				validator: isBoolean
			},

			positioned: {
				value: false
			},

			wrap: {
				value: null
			},
			useShim: {
				value: false
			},

			size: {
				value: true
			},

			setSize: {
				value: true,
				validator: isBoolean
			},

			handles: {
				value: ['r', 'b', 'br'],
				validator: function(value) {
					var instance = this;

					if (isString(value) && value.toLowerCase() == 'all') {
						value = ['t', 'b', 'r', 'l', 'bl', 'br', 'tl', 'tr'];
					}

					if (!isArray(value)) {
						value = value.replace(/, /g, ',');
						value = value.split(',');
					}

					return value;
				}
			},

			width: {
				value: 0,
				setter: function(value) {
					var instance = this;

					if (isNumber(value)) {
						if (value > 0) {
							var node = instance.get('node');

							if (instance.get('setSize')) {
								node.setStyle('width', value + 'px');
							}

							node.set('width', value);

							instance._cache.width = value;
						}
					}
					else {
						value = A.Attribute.INVALID_ATTRIBUTE;
					}

					return value;
				}
			},

			height: {
				value: 0,
				setter: function(value) {
					var instance = this;

					if (isNumber(value)) {
						if (value > 0) {
							var node = instance.get('node');

							if (instance.get('setSize')) {
								node.setStyle('height', value + 'px');
							}

							node.set('height', value);
							instance._cache.height = value;
						}
					}
					else {
						value = A.Attribute.INVALID_ATTRIBUTE;
					}

					return value;
				}
			},

			minHeight: {
				value: 15,
				validator: isNumber
			},

			minWidth: {
				value: 15,
				validator: isNumber
			},

			maxHeight: {
				value: 10000,
				validator: isNumber
			},

			maxWidth: {
				value: 10000,
				validator: isNumber
			},

			minY: {
				value: false
			},

			minX: {
				value: false
			},

			maxX: {
				value: false
			},

			maxY: {
				value: false
			},

			proxy: {
				value: false,
				validator: isBoolean
			},

			ratio: {
				value: false,
				validator: isBoolean
			},

			ghost: {
				value: false,
				validator: isBoolean
			},

			draggable: {
				value: false,
				validator: isBoolean,
				valueFn: function(dd) {
					var instance = this;

					if (dd && instance.get('wrap')) {
						instance._setupDragDrop();
					}
					else if (instance.get('dd')) {
						instance.get('wrap').removeClass(CSS_DRAG);

						instance.get('dd').unreg();
					}
				}
			},

			hover: {
				value: false,
				validator: isBoolean
			},

			hiddenHandles: {
				value: false,
				validator: isBoolean
			},

			knobHandles: {
				value: false,
				validator: isBoolean
			},

			xTicks: {
				value: false
			},

			yTicks: {
				value: false
			},

			status: {
				value: true,
				validator: isBoolean
			},

			autoRatio: {
				value: false,
				validator: isBoolean
			}
		};

		Resize._instances = {};

		Resize.getResizeById = function(id) {
			return Resize._instances[id] || false;
		};

		A.extend(
			Resize,
			A.Base,
			{
				initializer: function() {
					var instance = this;

					instance._createCache();
					instance._createWrap();
					instance._createProxy();
					instance._createHandles();
				},

				destructor: function() {
					var instance = this;

					var handles = instance._handles;

					for (var i in handles) {
						var handle = handles[i];

						A.Event.purgeElement(handle);
						handle.remove();
					}

					if (instance._proxy) {
						instance._proxy.remove();
					}

					if (instance._status) {
						instance._status.remove();
					}

					if (instance.dd) {
						instance.dd.destroy();

						instance._wrap.removeClass(CSS_DRAG);
					}

					var node = instance.get('node');

					if (!instance._wrap.compareTo(node)) {
						node.setStyles(
							{
								position: '',
								top: '',
								left: ''
							}
						);

						instance._wrap.get('parentNode').replaceChild(node, instance._wrap);
					}

					node.removeClass(CSS_RESIZE);

					delete Resize._instances[instance.get('id')];

					for (var i in instance) {
						instance[i] = null;

						delete instance[i];
					}
				},

				toString: function() {
					var instance = this;

					if (instance.get) {
						return 'Resize (#' + instance.get('id') + ')';
					}

					return 'Resize utility';
				},

				_createCache: function() {
					var instance = this;

					this._cache = {
						xy: [],
						height: 0,
						width: 0,
						top: 0,
						left: 0,
						offsetHeight: 0,
						offsetWidth: 0,
						start: {
							height: 0,
							width: 0,
							top: 0,
							left: 0
						}
					};
				},

				_createProxy: function() {
					var instance = this;

					if (instance.get('proxy')) {
						var proxy = A.Node.create('<div></div>');

						proxy.set('className', CSS_PROXY);

						var node = instance.get('node');
						var elHeight = node.get('clientHeight');
						var elWidth = node.get('clientWidth');

						proxy.setStyle('height', elHeight + 'px');
						proxy.setStyle('width', elWidth + 'px');

						instance._wrap.get('parentNode').appendChild(proxy);

						instance._proxy = proxy;
					}
				},

				_createWrap: function() {
					var instance = this;

					var node = instance.get('node');
					var tagName = node.get('tagName').toLowerCase();
					var wrap = node;

					if (instance.get('wrap') == false) {
						if (/img|textarea|input|iframe|select/.test(tagName)) {
							instance.set('wrap', true);
						}
					}

					if (instance.get('wrap') == true) {
						wrap = A.Node.create('<div></div>');

						wrap.set('id', node.get('id') + '_wrap');
						wrap.set('className', CSS_WRAP);

						if (tagName == 'textarea') {
							wrap.addClass(CSS_TEXTAREA);
						}

						wrap.setStyle('width', instance.get('width') + 'px');
						wrap.setStyle('height', instance.get('height') + 'px');
						wrap.setStyle('zIndex', node.getStyle('zIndex'));

						node.setStyle('zIndex', 0);

						var position = node.getStyle('position');
						var top = node.getStyle('top');
						var left = node.getStyle('left');

						wrap.setStyle('position', (position == 'static' ? 'relative' : position));
						wrap.setStyle('top', top);
						wrap.setStyle('left', left);

						if (position == 'absolute') {
							node.setStyle('position', 'relative');
							node.setStyle('top', 0);
							node.setStyle('left', 0);
						}

						var parentNode = node.get('parentNode');

						parentNode.replaceChild(wrap, node);

						wrap.appendChild(node);
					}
					else if (wrap.getStyle('position') == 'absolute') {
						instance.set('positioned', true);
					}

					if (instance.get('draggable')) {
						instance._setupDragDrop();
					}

					if (instance.get('hover')) {
						wrap.addClass(CSS_HOVER);
					}

					if (instance.get('knobHandles')) {
						wrap.addClass(CSS_KNOB);
					}

					if (instance.get('hiddenHandles')) {
						wrap.addClass(CSS_HIDDEN);
					}

					wrap.addClass(CSS_RESIZE);

					instance._wrap = wrap;
				},

				_setupDragDrop: function() {
					var instance = this;

					instance._wrap.addClass(CSS_DRAG);

					var dd = new A.DD.Drag(
						{
							node: instance._wrap
						}
					);

					dd.addTarget(instance);

					instance.set('dd', dd);
				},

				_createHandles: function() {
					var instance = this;

					var handlesCache = {};
					var ddsCache = {};

					var handles = instance.get('handles');
					var length = handles.length;

					var useShim = instance.get('useShim');

					for (var i = 0; i < length; i++) {
						var handle = handles[i];

						var handleNode = A.Node.create('<div></div>');

						var handleClassName = CSS_HANDLE + ' ' + CSS_HANDLES_MAP[handle];

						handleNode.set('id', A.guid());
						handleNode.addClass(handleClassName);

						var knobNode = A.Node.create('<div></div>');

						knobNode.addClass(CSS_HANDLES_INNER_MAP[handle]);

						handleNode.appendChild(knobNode);

						handleNode.on('mouseover', instance._handleMouseOver, instance);
						handleNode.on('mouseout', instance._handleMouseOut, instance);

						var dd = new A.DD.Drag(
							{
								node: handleNode,
								useShim: useShim,
								move: false
							}
						);

						dd.plug(
							A.Plugin.DDConstrained,
							{
								stickX: (handle == 'r' || handle == 'l'),
								stickY: (handle == 't' || handle == 'b')
							}
						);

						dd.on('drag:start', A.rbind(instance._handleStartDrag, instance, dd));
						dd.on('drag:mouseDown', A.rbind(instance._handleMouseDown, instance, dd));
						dd.on('drag:drag', A.rbind(instance['_handle_for_' + handle], instance, dd), instance);
						dd.on('drag:end', instance._handleMouseUp, instance);

						handlesCache[handle] = handleNode;
						ddsCache[handle] = dd;

						instance._wrap.appendChild(handleNode);
					}

					instance._status = A.Node.create('<span class="' + CSS_STATUS + '"></span>');

					A.get('body').appendChild(instance._status);

					instance._handles = handlesCache;
					instance._dds = ddsCache;
				},

				_ieSelectFix: function() {
					return false;
				},

				_setAutoRatio: function(dd) {
					var instance = this;

					if (instance.get('autoRatio')) {
						var event = dd && dd._ev_md;

						instance.set('ratio', (event && event.shiftKey));
					}
				},

				_handleMouseDown: function(event, dd) {
					var instance = this;

					if (instance.get('lock')) {
						return false;
					}

					if (instance._wrap.getStyle('position') == 'absolute') {
						instance.set('positioned', true);
					}

					instance._setAutoRatio(dd);

					if (IS_IE) {
						instance._ieSelectBack = document.body.onselectstart;
						document.body.onselectstart = instance._ieSelectFix;
					}
				},

				_handleMouseOver: function(event) {
					var instance = this;

					if (instance.get('lock')) {
						return false;
					}

					instance._wrap.removeClass(CSS_RESIZE);

					if (instance.get('hover')) {
						instance._wrap.removeClass(CSS_HOVER);
					}

					var target = event.target;

					if (!target.hasClass(CSS_HANDLE)) {
						target = target.get('parentNode');
					}

					if (target.hasClass(CSS_HANDLE) && !instance.get(STR_ACTIVE)) {
						target.addClass(CSS_HANDLE_ACTIVE);

						for (var i in instance._handles) {
							if (instance._handles[i].compareTo(target)) {
								target.addClass(CSS_HANDLES_ACTIVE_MAP[i]);

								break;
							}
						}
					}

					instance._wrap.addClass(CSS_RESIZE);
				},

				_handleMouseOut: function(event) {
					var instance = this;

					instance._wrap.removeClass(CSS_RESIZE);

					if (instance.get('hover') && !instance.get(STR_ACTIVE)) {
						instance._wrap.addClass(CSS_HOVER);
					}

					var target = event.target;

					if (!target.hasClass(CSS_HANDLE)) {
						target = target.get('parentNode');
					}

					if (target.hasClass(CSS_HANDLE) && !instance.get(STR_ACTIVE)) {
						target.removeClass(CSS_HANDLE_ACTIVE);

						for (var i in instance._handles) {
							if (instance._handles[i].compareTo(target)) {
								target.removeClass(CSS_HANDLES_ACTIVE_MAP[i]);

								break;
							}
						}
					}

					instance._wrap.addClass(CSS_RESIZE);
				},

				_handleStartDrag: function(event, dd) {
					var instance = this;

					var target = dd.get('dragNode');

					if (target.hasClass(CSS_HANDLE)) {
						if (instance._wrap.getStyle('position') == 'absolute') {
							instance.set('positioned', true);
						}

						var node = instance.get('node');

						instance.set(STR_ACTIVE, true);
						instance._currentDD = dd;

						if (instance._proxy) {
							instance._proxy.setStyles(
								{
									visibility: 'visible',
									zIndex: 1000,
									width: node.get('offsetWidth') + 'px',
									height: node.get('offsetHeight') + 'px'
								}
							);
						}

						for (var i in instance._handles) {
							if (instance._handles[i].compareTo(target)) {
								instance._currentHandle = i;

								var handle = '_handle_for_' + i;

								target.addClass(CSS_HANDLES_ACTIVE_MAP[i]);

								break;
							}
						}

						target.addClass(CSS_HANDLE_ACTIVE);

						if (instance.get('proxy')) {
							var xy = node.getXY();

							instance._proxy.setXY(xy);

							if (instance.get('ghost')) {
								node.addClass(CSS_GHOST);
							}
						}

						instance._wrap.addClass(CSS_RESIZING);

						instance._setCache();

						var cache = instance._cache;

						instance._updateStatus(cache.height, cache.width, cache.top, cache.left);

						instance.fire('startResize');
					}
				},

				_setCache: function() {
					var instance = this;

					var cache = instance._cache;
					var wrap = instance._wrap;
					var node = instance.get('node');

					cache.xy = wrap.getXY();

					wrap.setXY(cache.xy);

					cache.height = node.get('offsetHeight');
					cache.width = node.get('offsetWidth');

					cache.start.height = cache.height;
					cache.start.width = cache.width;
					cache.start.top = cache.xy[1];
					cache.start.left = cache.xy[0];

					instance.set('height', cache.height);
					instance.set('width', cache.width);
				},

				_handleMouseUp: function(event) {
					var instance = this;

					event.stopImmediatePropagation();

					instance.set(STR_ACTIVE, false);

					var handle = '_handle_for_' + instance._currentHandle;
					var cache = instance._cache;

					if (instance._proxy) {
						var proxy = instance._proxy;

						proxy.setStyles(
							{
								visibility: 'hidden',
								zIndex: '-1'
							}
						);

						if (instance.get('setSize')) {
							instance.resize(event, cache.height, cache.width, cache.top, cache.left, true);
						}
						else {
							instance.fire(
								'resize',
								{
									height: cache.height,
									width: cache.width,
									top: cache.top,
									left: cache.left
								}
							);
						}

						if (instance.get('ghost')) {
							instance.get('node').removeClass(CSS_GHOST);
						}
					}

					if (instance.get('hover')) {
						instance._wrap.addClass(CSS_HOVER);
					}

					if (instance._status) {
						instance._status.addClass('aui-helper-hidden');
					}

					if (IS_IE) {
						document.body.onselectstart = instance._ieSelectBack;

						instance._wrap.removeClass(CSS_RESIZE);
					}

					for (var i in instance._handles) {
						instance._handles[i].removeClass(CSS_HANDLES_ACTIVE_MAP[i]);
					}

					if (instance.get('hover') && !instance.get(STR_ACTIVE)) {
						instance._wrap.addClass(CSS_HOVER);
					}

					instance._wrap.removeClass(CSS_RESIZING);

					var currentHandle = instance._handles[instance._currentHandle];

					currentHandle.removeClass(CSS_HANDLE_ACTIVE);

					if (IS_IE) {
						instance._wrap.addClass(CSS_RESIZE);
					}

					instance._resizeEvent = null;
					instance._currentHandle = null;

					instance.fire(
						'endResize',
						{
							height: cache.height,
							width: cache.width,
							top: cache.top,
							left: cache.left
						}
					);
				},

				_setRatio: function(height, width, top, left) {
					var instance = this;

					var originalHeight = height;
					var originalWidth = width;

					if (instance.get('ratio')) {
						var newHeight = instance.get('height');
						var newWidth = instance.get('width');

						var maxHeight = instance.get('maxHeight');
						var maxWidth = instance.get('maxWidth');
						var minHeight = instance.get('minHeight');
						var minWidth = instance.get('minWidth');

						switch(instance._currentHandle) {
							case 'l':
								height = newHeight * (width / newWidth);
								height = Math.min(Math.max(minHeight, height), maxHeight);

								width = newWidth * (height / newHeight);

								top = (instance._cache.start.top - (-((newHeight - height) / 2)));
								left = (instance._cache.start.left - (-((newWidth - width))));

							break;

							case 'r':
								height = newHeight * (width / newWidth);
								height = Math.min(Math.max(minHeight, height), maxHeight);

								width = newWidth * (height / newHeight);

								top = (instance._cache.start.top - (-((newHeight - height) / 2)));
							break;

							case 't':
								height = newHeight * (width / newWidth);
								width = newWidth * (height / newHeight);

								top = (instance._cache.start.top - (-((newHeight - height))));
								left = (instance._cache.start.left - (-((newWidth - width) / 2)));
							break;

							case 'b':
								height = newHeight * (width / newWidth);
								width = newWidth * (height / newHeight);

								left = (instance._cache.start.left - (-((newWidth - width) / 2)));
							break;

							case 'bl':
								height = newHeight * (width / newWidth);
								width = newWidth * (height / newHeight);

								left = (instance._cache.start.left - (-((newWidth - width))));
							break;

							case 'br':
								height = newHeight * (width / newWidth);
								width = newWidth * (height / newHeight);
							break;

							case 'tl':
								height = newHeight * (width / newWidth);
								width = newWidth * (height / newHeight);

								top = (instance._cache.start.top - (-((newHeight - height))));
								left = (instance._cache.start.left - (-((newWidth - width))));
							break;

							case 'tr':
								height = newHeight * (width / newWidth);
								width = newWidth * (height / newHeight);

								top = (instance._cache.start.top - (-((newHeight - height))));
								left = (instance._cache.start.left);
							break;
						}

						var originalHeight = instance._checkHeight(height);
						var originalWidth = instance._checkWidth(width);

						if ((originalHeight != height) || (originalWidth != width)) {
							top = 0;
							left = 0;

							if (originalHeight != height) {
								originalWidth = instance._cache.width;
							}

							if (originalWidth != width) {
								originalHeight = instance._cache.height;
							}
						}
					}

					return [originalHeight, originalWidth, top, left];
				},

				_updateStatus: function(height, width, top, left) {
					var instance = this;

					if (instance._resizeEvent && !Lang.isString(instance._resizeEvent)) {
						height = (height === 0) ? instance._cache.start.height : height;
						width = (width === 0) ? instance._cache.start.width : width;

						var height1 = instance.get('height');
						var width1 = instance.get('width');

						if (isNaN(height1)) {
							height1 = height;
						}

						if (isNaN(width1)) {
							width1 = width;
						}

						var diffHeight = (height - height1);
						var diffWidth = (width - width1);

						instance._cache.offsetHeight = diffHeight;
						instance._cache.offsetWidth = diffWidth;

						if (instance.get('status')) {
							instance._status.removeClass('aui-helper-hidden');

							var statusSize = '<strong>' + parseInt(height, 10) + ' x ' + parseInt(width, 10) + '</strong>';
							var statusDelta = '<em>' + (diffHeight > 0 ? '+' : '') + diffHeight + ' x ' + (diffWidth > 0 ? '+' : '') + diffWidth + '</em>';

							instance._status.html(statusSize + statusDelta);

							instance._status.setXY(instance._resizeEvent.pageX + 12, instance._resizeEvent.pageY + 12);
						}
					}
				},

				reset: function() {
					var instance = this;

					var cacheStart = instance._cache.start;

					instance.resize(null, cacheStart.height, cacheStart.width, cacheStart.top, cacheStart.left, true);

					return instance;
				},

				resize: function(event, height, width, top, left, force, silent) {
					var instance = this;

					if (instance.get('lock')) {
						return false;
					}

					instance._resizeEvent = event;

					var el = instance._wrap;
					var set = true;

					var positioned = instance.get('positioned');

					if (instance._proxy && !force) {
						el = instance._proxy;
					}

					instance._setAutoRatio(instance._currentDD);

					if (positioned == true) {
						if (instance._proxy) {
							top = instance._cache.top - top;
							left = instance._cache.left - left;
						}
					}

					var ratio = instance._setRatio(height, width, top, left);

					height = parseInt(ratio[0], 10);
					width = parseInt(ratio[1], 10);
					top = parseInt(ratio[2], 10);
					left = parseInt(ratio[3], 10);

					if (top == 0) {
						top = el.getY();
					}

					if (left == 0) {
						left = el.getX();
					}

					if (positioned) {
						if (instance._proxy && force) {
							el.setStyles(
								{
									left: instance._proxy.getStyle('left'),
									top: instance._proxy.getStyle('top')
								}
							);
						}
						else {
							if (!instance.get('ratio') && !instance._proxy) {
								top = instance._cache.top + -(top);
								left = instance._cache.left + -(left);
							}

							if (top) {
								var minY = instance.get('minY');
								var maxY = instance.get('maxY');

								if (minY) {
									if (top < minY) {
										top = minY;
									}
								}

								if (maxY) {
									if (top > maxY) {
										top = maxY;
									}
								}
							}

							if (left) {
								var minX = instance.get('minX');
								var maxX = instance.get('maxX');

								if (minX) {
									if (left < minX) {
										left = minX;
									}
								}

								if (maxX) {
									if ((left + width) > maxX) {
										left = maxX - width;
									}
								}
							}
						}
					}

					instance._updateStatus(height, width, top, left);

					if (positioned) {
						if (!(instance._proxy && force)) {
							if (top) {
								el.setY(top);
								instance._cache.top = top;
							}

							if (left) {
								el.setX(left);
								instance._cache.left = left;
							}
						}
					}

					if (height) {
						set = true;

						if (instance._proxy && force) {
							if (!instance.get('setSize')) {
								set = false;
							}
						}

						if (set) {
							el.setStyle('height', height + 'px');
						}

						if ((instance._proxy && force) || !instance._proxy) {
							var node = instance.get('node');

							if (!instance._wrap.compareTo(node)) {
								node.setStyle('height', height + 'px');
							}
						}

						instance._cache.height = height;
					}

					if (width) {
						instance._cache.width = width;

						set = true;

						if (instance._proxy && force) {
							if (!instance.get('setSize')) {
								set = false;
							}
						}

						if (set) {
							el.setStyle('width', width + 'px');
						}

						if ((instance._proxy && force) || !instance._proxy) {
							var node = instance.get('node');

							if (!instance._wrap.compareTo(node)) {
								node.setStyle('width', width + 'px');
							}
						}
					}

					var eventData = {
						height: height,
						width: width,
						top: top,
						left: left
					};

					if (instance._proxy && !force) {
						instance.fire('proxyResize', eventData);
					}
					else {
						instance.fire('resize', eventData);
					}

					return instance;
				},

				_handle_for_br: function(event, dd) {
					var instance = this;

					var newHeight = instance._setHeight(event);
					var newWidth = instance._setWidth(event);

					instance.resize(event, newHeight, newWidth, 0, 0);
				},

				_handle_for_bl: function(event) {
					var instance = this;

					var newHeight = instance._setHeight(event);
					var newWidth = instance._setWidth(event, true);

					var left = (newWidth - instance._cache.width);

					instance.resize(event, newHeight, newWidth, 0, left);
				},

				_handle_for_tl: function(event) {
					var instance = this;

					var newHeight = instance._setHeight(event, true);
					var newWidth = instance._setWidth(event, true);

					var top = (newHeight - instance._cache.height);
					var left = (newWidth - instance._cache.width);

					instance.resize(event, newHeight, newWidth, top, left);
				},

				_handle_for_tr: function(event) {
					var instance = this;

					var newHeight = instance._setHeight(event, true);
					var newWidth = instance._setWidth(event);

					var top = (newHeight - instance._cache.height);

					instance.resize(event, newHeight, newWidth, top, 0);
				},

				_handle_for_r: function(event) {
					var instance = this;

					var newWidth = instance._setWidth(event);

					instance.resize(event, 0, newWidth, 0, 0);
				},

				_handle_for_l: function(event) {
					var instance = this;

					var newWidth = instance._setWidth(event, true);

					var left = (newWidth - instance._cache.width);

					instance.resize(event, 0, newWidth, 0, left);
				},

				_handle_for_b: function(event) {
					var instance = this;

					var newHeight = instance._setHeight(event);

					instance.resize(event, newHeight, 0, 0, 0);
				},

				_handle_for_t: function(event) {
					var instance = this;

					var newHeight = instance._setHeight(event, true);

					var top = (newHeight - instance._cache.height);

					instance.resize(event, newHeight, 0, top, 0);
				},

				_setWidth: function(event, flip) {
					var instance = this;

					var xy = instance._cache.xy[0];
					var width = instance._cache.width;
					var x = event.pageX;
					var newWidth = (x - xy);

					if (flip) {
						newWidth = (xy - x) + instance.get('width');
					}

					newWidth = instance._snapTick(newWidth, instance.get('xTicks'));
					newWidth = instance._checkWidth(newWidth);

					return newWidth;
				},

				_checkWidth: function(width) {
					var instance = this;

					var minWidth = instance.get('minWidth');
					var maxWidth = instance.get('maxWidth');

					if (minWidth) {
						if (width < minWidth) {
							width = minWidth;
						}
					}

					if (maxWidth) {
						if (width > maxWidth) {
							width = maxWidth;
						}
					}

					return width;
				},

				_checkHeight: function(height) {
					var instance = this;

					var minHeight = instance.get('minHeight');
					var maxHeight = instance.get('maxHeight');

					if (minHeight) {
						if (height < minHeight) {
							height = minHeight;
						}
					}

					if (maxHeight) {
						if (height > maxHeight) {
							height = maxHeight;
						}
					}

					return height;
				},

				_setHeight: function(event, flip) {
					var instance = this;

					var xy = instance._cache.xy[1];
					var height = instance._cache.height;
					var y = event.pageY;
					var newHeight = (y - xy);

					if (flip) {
						newHeight = (xy - y) + instance.get('height');
					}

					newHeight = instance._snapTick(newHeight, instance.get('yTicks'));
					newHeight = instance._checkWidth(newHeight);

					return newHeight;
				},

				_snapTick: function(size, pix) {
					var instance = this;

					if (!size || !pix) {
						return size;
					}

					var newSize = size;
					var newX = size % pix;

					if (newX > 0) {
						if (newX > (pix / 2)) {
							newSize = size + (pix - newX);
						}
						else {
							newSize = size - newX;
						}
					}

					return newSize;
				},

				_cache: {},
				_currentDD: null,
				_dds: null,
				_handles: null,
				_ieSelectBack: null,
				_proxy: null
			}
		);

		A.Resize = Resize;
	},
	'0.1a',
	{
		requires: ['dd'],
		skinnable: false
	}
);

AUI().add(
	'resize-plugin',
	function(A) {
		var ResizePlugin = function(config) {
			config.node = config.host;

			ResizePlugin.superclass.constructor.apply(this, arguments);
		};

		ResizePlugin.NAME = 'resizePlugin';
		ResizePlugin.NS = 'resize';

		A.extend(ResizePlugin, A.Resize);

		A.namespace('Plugin');

		A.Plugin.ResizePlugin = ResizePlugin;
	},
	'0.1a',
	{
		requires: ['resize'],
		skinnable: false
	}
);AUI().add(
	'state-interaction',
	function(A) {
		var Lang = A.Lang,
			isString = Lang.isString,

			getClassName = A.ClassNameManager.getClassName,

			STATE = 'state',

			CSS_STATE_DEFAULT = getClassName(STATE, 'default'),
			CSS_STATE_HOVER = getClassName(STATE, 'hover');
			CSS_STATE_ACTIVE = getClassName(STATE, 'active');

		var StateInteractionPlugin = function() {
			StateInteractionPlugin.superclass.constructor.apply(this, arguments);
		};

		StateInteractionPlugin.NAME = 'stateinteraction';
		StateInteractionPlugin.NS = 'StateInteraction';

		StateInteractionPlugin.ATTRS = {
			active: {
				value: false,
				setter: function(value) {
					var instance = this;

					var action = 'addClass';

					if (!value) {
						action = 'removeClass';
					}

					instance.get('host')[action](instance._CSS_STATE_ACTIVE);
				}
			},

			'default': {
				value: false,
				setter: function(value) {
					var instance = this;

					var action = 'addClass';

					if (!value) {
						action = 'removeClass';
					}

					instance.get('host')[action](instance._CSS_STATE_DEFAULT);
				}
			},

			hover: {
				value: false,
				setter: function(value) {
					var instance = this;

					var action = 'addClass';

					if (!value) {
						action = 'removeClass';
					}

					instance.get('host')[action](instance._CSS_STATE_HOVER);
				}
			},

			bubbleTarget: {
				value: null
			},

			classNames: {
				value: {}
			}
		};

		A.extend(
			StateInteractionPlugin,
			A.Plugin.Base,
			{
				initializer: function() {
					var instance = this;

					var activeClass = instance.get('classNames.active');
					var defaultClass = instance.get('classNames.default');
					var hoverClass = instance.get('classNames.hover');

					instance._CSS_STATE_ACTIVE = isString(activeClass) ? activeClass : CSS_STATE_ACTIVE;
					instance._CSS_STATE_DEFAULT = isString(defaultClass) ? defaultClass : CSS_STATE_DEFAULT;
					instance._CSS_STATE_HOVER = isString(hoverClass) ? hoverClass : CSS_STATE_HOVER;

					instance.get('host').addClass(instance._CSS_STATE_DEFAULT);

					instance._createEvents();

					instance._attachInteractionEvents();
				},

				_attachInteractionEvents: function() {
					var instance = this;

					var node = instance.get('host');

					node.on('click', instance._fireEvents, instance);

					node.on('mouseenter', A.rbind(instance._fireEvents, instance, 'mouseover'));
					node.on('mouseleave', A.rbind(instance._fireEvents, instance, 'mouseout'));
				},

				_fireEvents: function(event, officialType) {
					var instance = this;

					var bubbleTarget = instance.get('bubbleTarget');

					officialType = officialType || event.type;

					if (bubbleTarget) {
						bubbleTarget.fire(officialType);
					}

					return instance.fire(officialType);
				},

				_createEvents: function() {
					var instance = this;

					var bubbleTarget = instance.get('bubbleTarget');

					if (bubbleTarget) {
						instance.addTarget(bubbleTarget);
					}

					instance.publish(
						'click',
						{
							defaultFn: instance._defClickFn,
							emitFacade: true
						}
					);

					instance.publish(
						'mouseout',
						{
							defaultFn: instance._defMouseOutFn,
							emitFacade: true
						}
					);

					instance.publish(
						'mouseover',
						{
							defaultFn: instance._defMouseOverFn,
							emitFacade: true
						}
					);
				},

				_defClickFn: function(event) {
					var instance = this;

					instance.set('active', !instance.get('active'));
				},

				_defMouseOutFn: function() {
					var instance = this;

					instance.set('hover', false);
				},

				_defMouseOverFn: function() {
					var instance = this;

					instance.set('hover', true);
				}
			}
		);

		A.StateInteractionPlugin = StateInteractionPlugin;
	},
	'0.1a',
	{
		requires: ['aui-base', 'plugin']
	}
);AUI().add(
	'tabs',
	function(A) {
		var Lang = A.Lang,

			getClassName = A.ClassNameManager.getClassName,

			TAB = 'tab',
			TABVIEW = 'tabview',

			BOUNDING_BOX = 'boundingBox',
			CONTENT_BOX = 'contentBox',
			CONTENT_NODE = 'contentNode',

			CSS_TAB = getClassName(TAB),
			CSS_TAB_LABEL = getClassName(TAB, 'label'),
			CSS_TAB_DISABLED = getClassName(TAB, 'disabled'),
			CSS_TAB_ACTIVE = getClassName(TAB, 'active'),

			CSS_TABVIEW_LIST = [getClassName(TABVIEW, 'list'), getClassName('widget', 'hd')].join(' '),
			CSS_TABVIEW_CONTENT = [getClassName(TABVIEW, 'content'), getClassName('widget', 'bd')].join(' '),

			CSS_HIDDEN = getClassName('helper-hidden'),

			TPL_DIV = '<div></div>',
			TPL_SPAN = '<span></span>',
			TPL_UL = '<ul></ul>',

			TPL_LABEL = TPL_SPAN,
			TPL_TAB_CONTAINER = TPL_UL,
			TPL_CONTENT_ITEM = TPL_DIV,
			TPL_CONTENT_CONTAINER = TPL_DIV;

		var Tab = function() {
			Tab.superclass.constructor.apply(this, arguments);
		};

		Tab.NAME = TAB;

		Tab.ATTRS = {
			label: {
				lazyAdd: false,
				valueFn: function() {
					var instance = this;

					var boundingBox = instance.get(BOUNDING_BOX);

					var label = boundingBox.one('.' + CSS_TAB_LABEL);

					var value;

					if (label) {
						value = label.html();

						instance.set('labelNode', label);
					}
					else {
						value = boundingBox.html();
						boundingBox.html('');
					}

					return value;
				},

				setter: function(value) {
					var instance = this;

					var labelNode = instance.get('labelNode');

					labelNode.html(value);

					return value;
				}
			},

			labelNode: {
				valueFn: function() {
					var instance = this;

					var labelNode = instance.get(BOUNDING_BOX).one('.' + CSS_TAB_LABEL);

					if (!labelNode) {
						labelNode = instance._createDefaultLabel();
					}

					instance.get(CONTENT_BOX).appendChild(labelNode);

					return labelNode;
				},
				setter: function(value) {
					var instance = this;

					var node = A.Node.get(value);

					if (!node) {
						node = instance._createDefaultLabel();

						instance.get(CONTENT_BOX).appendChild(node);
					}

					node.addClass(CSS_TAB_LABEL);

					return node;
				}
			},

			contentNode: {
				value: null,
				setter: function(value) {
					var instance = this;

					var node = A.Node.get(value);

					if (!node) {
						node = instance._createDefaultContentEl();

						instance.get(CONTENT_BOX).prepend(node);
					}

					node.addClass(CSS_TABVIEW_CONTENT);

					var current = instance.get(CONTENT_NODE);

					if (current) {
						if (!instance.get('active')) {
							node.addClass(CSS_HIDDEN);
						}

						var currentHTML = node.html();

						instance.set('content', currentHTML);
					}

					return node;
				}
			},

			content: {
				lazyAdd: false,
				valueFn: function() {
					var instance = this;

					var value = '';
					var contentNode = instance.get(CONTENT_NODE);

					if (contentNode) {
						value = contentNode.html();
					}

					return value;
				},
				setter: function(value) {
					var instance = this;

					var node = instance.get(CONTENT_NODE);

					var currentHTML = node.html();

					if (currentHTML != value) {
						node.html(value);
					}

					return value;
				}
			},

			active: {
				valueFn: function() {
					var instance = this;

					return instance.get(BOUNDING_BOX).hasClass(CSS_TAB_ACTIVE);
				},
				validator: function(value) {
					var instance = this;

					return Lang.isBoolean(value) && !instance.get('disabled');
				},
				setter: function(value) {
					var instance = this;

					var action = 'addClass';
					var boundingBox = instance.get(BOUNDING_BOX);

					if (value === false) {
						action = 'removeClass';
					}

					instance.StateInteraction.set('active', value);

					boundingBox[action](CSS_TAB_ACTIVE);

					instance.set('contentVisible', value);

					return value;
				}
			},

			disabled: {
				valueFn: function() {
					var instance = this;

					return instance.get(BOUNDING_BOX).hasClass(CSS_TAB_DISABLED);
				},
				setter: function(value) {
					var instance = this;

					var action = 'addClass';
					var boundingBox = instance.get(BOUNDING_BOX);

					if (value === false) {
						action = 'removeClass';
					}

					boundingBox[action](CSS_TAB_DISABLED);

					return value;
				}
			},

			contentVisible: {
				value: false,
				setter: function(value) {
					var instance = this;

					var action = 'addClass';
					var contentNode = instance.get(CONTENT_NODE);

					if (value === true) {
						action = 'removeClass';
					}

					contentNode[action](CSS_HIDDEN);

					return value;
				}
			},

			tabView: {
				value: null
			}
		};

		A.extend(
			Tab,
			A.Widget,
			{
				BOUNDING_TEMPLATE: '<li></li>',
				CONTENT_TEMPLATE: '<span></span>',
				bindUI: function() {
					var instance = this;

					var boundingBox = instance.get(BOUNDING_BOX);

					boundingBox.plug(
						A.StateInteractionPlugin,
						{
							bubbleTarget: instance
						}
					);

					boundingBox.StateInteraction.on('click', instance._onActivateTab, instance);

					instance.StateInteraction = boundingBox.StateInteraction;

					instance.get('labelNode').on('click', instance._onLabelClick, instance);
				},

				destructor: function() {
					var instance = this;

					var boundingBox = instance.get(BOUNDING_BOX);
					var contentNode = instance.get(CONTENT_NODE);

					A.Event.purgeElement(boundingBox, true);
					A.Event.purgeElement(contentNode, true);

					boundingBox.remove();
					contentNode.remove();
				},

				_createDefaultLabel: function() {
					var instance = this;

					return A.Node.create(TPL_LABEL);
				},

				_createDefaultContentEl: function() {
					var instance = this;

					return A.Node.create(TPL_CONTENT_ITEM);
				},

				_onActivateTab: function(event) {
					var instance = this;

					event.halt();

					var tabView = instance.get('tabView');

					tabView.set('activeTab', instance);
				},

				_onLabelClick: function(event) {
					event.preventDefault();
				}
			}
		);

		A.Tab = Tab;

		var TabView = function() {
			TabView.superclass.constructor.apply(this, arguments);
		};

		TabView.NAME = TABVIEW;

		TabView.ATTRS = {
			listNode: {
				value: null,
				setter: function(value) {
					var instance = this;

					var node = A.Node.get(value);

					if (!node) {
						node = instance._createDefaultList();
					}

					instance.get(CONTENT_BOX).prepend(node);

					node.addClass(CSS_TABVIEW_LIST);

					return node;
				}
			},

			contentNode: {
				value: null,
				setter: function(value) {
					var instance = this;

					var node = A.Node.get(value);

					if (!node) {
						node = instance._createDefaultContentContainer();
					}

					instance.get(CONTENT_BOX).appendChild(node);

					node.addClass(CSS_TABVIEW_CONTENT);

					return node;
				}
			},

			items: {
				value: []
			},

			activeTab: {
				value: null,
				setter: function(value) {
					var instance = this;

					var activeTab = instance.get('activeTab');

					if (activeTab && activeTab != value) {
						activeTab.set('active', false);
					}

					return value;
				},
				validator: function(value) {
					return Lang.isNull(value) || (value && !value.get('disabled'));
				}
			}
		};

		A.extend(
			TabView,
			A.Widget,
			{
				renderUI: function() {
					var instance = this;

					instance.after('activeTabChange', instance._onActiveTabChange);

					instance._renderContentSections();
					instance._renderTabs();
				},

				addTab: function(tab, index) {
					var instance = this;

					var before = instance.getTab(index);

					var items = instance.get('items');

					if (Lang.isUndefined(index)) {
						index = A.Array.indexOf(items, tab);
					}

					var inArray = index > -1;

					if (!inArray) {
						index = items.length;

						items.splice(index, 0, tab);
					}

					if (!instance.get('rendered') && !inArray) {
						return;
					}

					if (!(tab instanceof Tab)) {
						tab = new Tab(tab);

						items.splice(index, 1, tab);
					}

					var listNode = instance.get('listNode');

					tab.render(listNode);

					if (before) {
						listNode.insert(tab.get(BOUNDING_BOX), before.get(BOUNDING_BOX));
					}
					else {
						listNode.appendChild(tab.get(BOUNDING_BOX));
					}

					var tabContentNode = tab.get(CONTENT_NODE);

					var tabViewContentNode = instance.get(CONTENT_NODE);

					if (!tabViewContentNode.contains(tabContentNode)) {
						tabViewContentNode.appendChild(tabContentNode);
					}

					if (tab.get('active')) {
						instance.set('activeTab', tab);
					}

					tab.set('tabView', instance);
				},

				deselectTab: function(index){
					var instance = this;

					if (instance.getTab(index) === instance.get('activeTab')) {
						instance.set('activeTab', null);
					}
				},

				disableTab: function(index){
					var instance = this;

					var tab;

					if (Lang.isNumber(index)) {
						tab = instance.getTab(index);
					}
					else {
						tab = index;
					}

					if (tab) {
						tab.set('disabled', true);
					}
				},

				enableTab: function(index){
					var instance = this;

					var tab;

					if (Lang.isNumber(index)) {
						tab = instance.getTab(index);
					}
					else {
						tab = index;
					}

					if (tab) {
						tab.set('disabled', false);
					}
				},

				getTab: function(index){
					var instance = this;

					return instance.get('items')[index];
				},

				getTabIndex: function(tab){
					var instance = this;

					var items = instance.get('items');

					return A.Array.indexOf(items, tab);
				},

				removeTab: function(index){
					var instance = this;

					var tab;

					if (Lang.isNumber(index)) {
						tab = instance.getTab(index);
					}
					else {
						tab = index;
					}

					if (tab) {
						var items = instance.get('items');

						var tabCount = items.length;

						if (tab === instance.get('activeTab')) {
							if (tabCount > 1) {
								if (index + 1 === tabCount) {
									instance.selectTab(index - 1);
								}
								else {
									instance.selectTab(index + 1);
								}
							}
							else {
								instance.set('activeTab', null);
							}
						}

						tab.destroy();

						items.splice(index, 1);
					}
				},

				selectTab: function(index){
					var instance = this;

					var selectedTab = instance.getTab(index);

					instance.set('activeTab', selectedTab);
				},

				_createDefaultList: function() {
					var instance = this;

					return A.Node.create(TPL_TAB_CONTAINER);
				},

				_createDefaultContentContainer: function() {
					var instance = this;

					return A.Node.create(TPL_CONTENT_CONTAINER);
				},

				_onActiveTabChange: function(event) {
					var instance = this;

					var oldTab = event.prevVal;
					var newTab = event.newVal;

					if (newTab) {
						newTab.set('active', true);
					}

					if (oldTab) {
						oldTab.set('active', false);
					}
				},

				_renderContentSections: function() {
					var instance = this;

					instance._renderSection('list');
					instance._renderSection('content');
				},

				_renderSection: function(section) {
					var instance = this;

					instance.get(section + 'Node');
				},

				_renderTabs: function() {
					var instance = this;

					var contentNode = instance.get(CONTENT_NODE);
					var listNode = instance.get('listNode');

					var tabs = listNode.get('children');
					var tabContent = contentNode.get('children');

					var items = instance.get('items');

					tabs.each(
						function(node, i, nodeList) {
							var config = {
								boundingBox: node,
								contentNode: tabContent.item(i)
							};

							items.splice(i, 0, config);
						}
					);

					var length = items.length;

					for (var i = 0; i < items.length; i++) {
						instance.addTab(items[i]);
					}

					if (!instance.get('activeTab')) {
						instance.selectTab(0);
					}
				}
			}
		);

		A.TabView = TabView;
	},
	'0.1a',
	{
		requires: ['widget', 'state-interaction'],
		use: []
	}
);AUI().add(
	'tool-item',
	function(A) {
		var Lang = A.Lang,
			isString = Lang.isString,

			getClassName = A.ClassNameManager.getClassName,

			TOOL = 'tool',
			ICON = 'icon',
			STATE = 'state',

			CSS_TOOL = getClassName(TOOL),
			CSS_ICON = getClassName(ICON),

			TPL_GENERIC = '<span></span>',
			TPL_ICON = TPL_GENERIC,
			TPL_TOOL = TPL_GENERIC;

		var ToolItem = function(config) {
			if (isString(config)) {
				config = {
					icon: config
				};
			}

			ToolItem.superclass.constructor.apply(this, arguments);
		};

		ToolItem.NAME = 'tool-item';

		ToolItem.ATTRS = {
			classNames: {
				value: {
					active: ''
				}
			},

			icon: {
				setter: function(value) {
					var instance = this;

					var iconNode = instance.get('iconNode');

					if (iconNode) {
						iconNode.addClass(getClassName(ICON, value))
					}

					return value;
				}
			},

			iconNode: {
				value: null,
				setter: function(value) {
					var instance = this;

					var icon = A.get(value);

					if (!icon) {
						icon = instance._createDefaultIconNodeToolItem();
					}
					else {
						icon = icon.item(0);
					}

					icon.addClass(CSS_ICON);
					icon.addClass(getClassName(ICON, instance.get(ICON)));

					return icon;
				}
			},

			node: {
				value: null,
				setter: function(value) {
					var instance = this;

					var node = A.get(value);

					if (!node) {
						node = instance._createDefaultNodeToolItem();
					}
					else {
						node = node.item(0);
					}

					node.addClass(CSS_TOOL);

					node.plug(
						A.StateInteractionPlugin,
						{
							classNames: instance.get('classNames'),
							bubbleTarget: instance
						}
					);

					return node;
				}
			},

			renderTo: {
				value: null
			}
		};

		A.extend(
			ToolItem,
			A.Widget,
			{
				BOUNDING_TEMPLATE: TPL_GENERIC,
				CONTENT_TEMPLATE: TPL_GENERIC,

				initializer: function() {
					var instance = this;

					var renderTo = instance.get('renderTo');

					if (renderTo) {
						instance.render(renderTo);
					}
				},

				renderUI: function() {
					var instance = this;

					var node = instance.get('node');
					var icon = instance.get('iconNode');

					node.appendChild(icon);

					instance.get('contentBox').appendChild(node);
				},

				bindUI: function() {
					var instance = this;

					instance.after('iconChange', instance._afterIconChange);
				},

				_afterIconChange: function(event) {
					var instance = this;

					var prevVal = event.prevVal;
					var iconNode = instance.get('iconNode');

					iconNode.removeClass(getClassName(ICON, prevVal));
				},

				_createDefaultNodeToolItem: function() {
					return A.Node.create(TPL_TOOL);
				},

				_createDefaultIconNodeToolItem: function() {
					return A.Node.create(TPL_ICON);
				}
			}
		);

		A.ToolItem = ToolItem;
	},
	'0.1a',
	{
		requires: ['aui-base', 'state-interaction'],
		use: []
	}
);
AUI.add('tooltip', function(A) {

var L = A.Lang,
	isString = L.isString,

	TOOLTIP = 'tooltip';

function Tooltip(config) {
 	Tooltip.superclass.constructor.apply(this, arguments);
}

A.mix(Tooltip, {
	NAME: TOOLTIP,

	ATTRS: {

	}
});

A.extend(Tooltip, A.ContextOverlay, {

});

A.Tooltip = Tooltip;

}, '0.1a', { requires: [ 'context-overlay' ] });