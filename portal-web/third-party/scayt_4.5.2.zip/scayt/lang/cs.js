﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'cs', {
	btn_about: 'O aplikaci SCAYT',
	btn_dictionaries: 'Slovníky',
	btn_disable: 'Vypnout SCAYT',
	btn_enable: 'Zapnout SCAYT',
	btn_langs:'Jazyky',
	btn_options: 'Nastavení',
	text_title:  'Kontrola pravopisu během psaní (SCAYT)'
});
