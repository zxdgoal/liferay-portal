document.getElementById('log').innerHTML += 'external.js Declaring variable window.a<br/>';

window.a = 'Value of window.a: Declared on external.js<br/>';