﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'sl', {
	btn_about: 'O storitvi SCAYT',
	btn_dictionaries: 'Slovarji',
	btn_disable: 'Onemogoči SCAYT',
	btn_enable: 'Omogoči SCAYT',
	btn_langs:'Jeziki',
	btn_options: 'Možnosti',
	text_title:  'Črkovanje med tipkanjem'
});
