﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'lt', {
	border: 'Rodyti rėmelį',
	noUrl: 'Nurodykite iframe nuorodą',
	scrolling: 'Įjungti slankiklius',
	title: 'IFrame nustatymai',
	toolbar: 'IFrame'
});
