<?
include("content.php");
?>
<!DOCTYPE html>

<html>
<head>
</head>

<body>

	<?= $content1 ?>
	
	<br/><br/>
	
	<?= $content2 ?>
	
	<br/><br/>
	
	<?= $content3 ?>

</body>
</html>