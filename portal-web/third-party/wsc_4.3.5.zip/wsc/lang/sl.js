﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'sl', {
	btnIgnore: 'Prezri',
	btnIgnoreAll: 'Prezri vse',
	btnReplace: 'Zamenjaj',
	btnReplaceAll: 'Zamenjaj vse',
	btnUndo: 'Razveljavi',
	changeTo: 'Spremeni v',
	errorLoading: 'Napaka pri nalaganju storitve programa na naslovu %s.',
	ieSpellDownload: 'Črkovalnik ni nameščen. Ali ga želite prenesti sedaj?',
	manyChanges: 'Črkovanje je končano: Spremenjenih je bilo %1 besed',
	noChanges: 'Črkovanje je končano: Nobena beseda ni bila spremenjena',
	noMispell: 'Črkovanje je končano: Brez napak',
	noSuggestions: '- Ni predlogov -',
	notAvailable: 'Oprostite, storitev trenutno ni dosegljiva.',
	notInDic: 'Ni v slovarju',
	oneChange: 'Črkovanje je končano: Spremenjena je bila ena beseda',
	progress: 'Preverjanje črkovanja se izvaja...',
	title: 'Črkovalnik',
	toolbar: 'Preveri črkovanje'
});
