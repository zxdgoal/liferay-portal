AUI.add('tests', function(A) {

/*
* Test
*/
var	L = A.Lang,
	isString = L.isString,

	TEST = 'test',

	getCN = A.ClassNameManager.getClassName,

	CSS_TEST = getCN(TEST);

function Test(config) {
	Test.superclass.constructor.apply(this, arguments);
}

A.mix(Test, {
	NAME: TEST,

	ATTRS: {
		name: {
			value: 'TestName',
			setter: function(v) {
				// I have a private setter for the "name" attribute
				return this._setName(v);
			}
		},

		age: {
			value: 24,
			setter: function(v) {
				// string casting
				return (v + '');
			}
		}
	}
});

A.extend(Test, A.Widget, {
	/*
	* Lifecycle
	*/
	initializer: function() {
		var instance = this;

		console.log('initializer');

		var name = instance.get('name');
		var age = instance.get('age');

		console.log(name);
		console.log( 'isString: ', isString(age) );
	},

	renderUI: function() {
		var instance = this;

		console.log('renderUI');
	},

	bindUI: function() {
		var instance = this;

		console.log( 'parent get age: ', instance.get('age') );

		console.log('bindUI parent');
	},

	syncUI: function() {
		var instance = this;

		console.log('syncUI');
	},

	/*
	* Setters
	*/
	_setName: function(v) {
		var instance = this;

		return 'Test _setName: ' + v;
	}
});

A.Test = Test;



/*
* Child
*/
function TestChild(config) {
	TestChild.superclass.constructor.apply(this, arguments);
	console.log('sdfsd: ', TestChild.superclass.constructor.ATTRS);
}

TestChild.HTML_PARSER = {
	testing: 'div'
};

A.mix(TestChild, {
	NAME: TEST,

	ATTRS: {
		testing: {

		},

		name: {
			setter: function(v) {
				// I can invoke the parent _setName private method
				return TestChild.superclass._setName(v);
			}
		},
		age: {
			// lazyAdd: false,
			setter: function(v) {
				// but, how to invoke the parent class setter when it doesn't have the private _set method defined ??
				// SUGGESTION: TestChild.superclass.SETTERS.age(v);
				// same for getters: TestChild.superclass.GETTERS.age(v);
				return v;
			}
		}
	}
});

A.extend(TestChild, A.Test, {
	/*
	* Lifecycle
	*/
	initializer: function() {
		var instance = this;
instance.after('ageChange', A.bind(instance._afterSetAge, instance));
		console.log('initializer');
	},

	renderUI: function() {
		var instance = this;

		console.log('renderUI');
	},

	bindUI: function() {
		var instance = this;

		TestChild.superclass.bindUI.apply(this, arguments);

		console.log(
			instance.get('testing')
		);



		console.log('bindUI child');
	},

	syncUI: function() {
		var instance = this;

		console.log('syncUI');
	},

	/*
	* Methods
	*/
	_afterSetAge: function(event) {
		var instance = this;

		console.log('_afterSetAge', event);
	},
});

A.TestChild = TestChild;


}, '0.1a', { requires: [ 'aui-base' ] });