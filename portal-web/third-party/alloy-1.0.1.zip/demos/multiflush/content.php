<?

$c = 0;

$content1 = '<div id="portlet1">
	<div id="portlet1log"></div>
	<link rel="stylesheet" href="css.php?n=1&'.$c++.'" type="text/css" />
	<link rel="stylesheet" href="css.php?n=1&'.$c++.'" type="text/css" />
	<style type="text/css">#portlet2 { color: #ccc; }</style>
	<script src="js.php?n=1&m=JS_EXECUTION top" type="text/javascript" charset="utf-8"></script>
	<h1>Portlet 1</h1>
	<script type="text/javascript">
	document.getElementById("portlet1log").style.border = "2px solid black";
	</script>
	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	<script src="js.php?n=1&m=JS_EXECUTION bottom" type="text/javascript" charset="utf-8"></script>
</div>';



$content2 = '<div id="portlet2">
	<div id="portlet2log"></div>
	<link rel="stylesheet" href="css.php?n=2&'.$c++.'" type="text/css" />
	<link rel="stylesheet" href="css.php?n=2&'.$c++.'" type="text/css" />
	<script src="js.php?n=2&m=JS_EXECUTION top" type="text/javascript" charset="utf-8"></script>
	<h1>Portlet 2</h1>
	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	<script src="js.php?n=2&m=JS_EXECUTION bottom" type="text/javascript" charset="utf-8"></script>
</div>';

$content3 = '<div id="portlet3">
	<div id="portlet3log"></div>
	<link rel="stylesheet" href="css.php?n=3&'.$c++.'" type="text/css" />
	<link rel="stylesheet" href="css.php?n=3&'.$c++.'" type="text/css" />
	<script src="js.php?n=3&m=JS_EXECUTION top" type="text/javascript" charset="utf-8"></script>
	<h1>Portlet 3</h1>
	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	<script src="js.php?n=3&m=JS_EXECUTION bottom" type="text/javascript" charset="utf-8"></script>
</div>';

?>