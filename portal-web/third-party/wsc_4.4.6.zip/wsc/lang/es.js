﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'es', {
	btnIgnore: 'Ignorar',
	btnIgnoreAll: 'Ignorar Todo',
	btnReplace: 'Reemplazar',
	btnReplaceAll: 'Reemplazar Todo',
	btnUndo: 'Deshacer',
	changeTo: 'Cambiar a',
	errorLoading: 'Error cargando la aplicación del servidor: %s.',
	ieSpellDownload: 'Módulo de Control de Ortografía no instalado.\r\n¿Desea descargarlo ahora?',
	manyChanges: 'Control finalizado: se ha cambiado %1 palabras',
	noChanges: 'Control finalizado: no se ha cambiado ninguna palabra',
	noMispell: 'Control finalizado: no se encontraron errores',
	noSuggestions: '- No hay sugerencias -',
	notAvailable: 'Lo sentimos pero el servicio no está disponible.',
	notInDic: 'No se encuentra en el Diccionario',
	oneChange: 'Control finalizado: se ha cambiado una palabra',
	progress: 'Control de Ortografía en progreso...',
	title: 'Comprobar ortografía',
	toolbar: 'Ortografía'
});
