﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'sr', {
	btnIgnore: 'Игнориши',
	btnIgnoreAll: 'Игнориши све',
	btnReplace: 'Замени',
	btnReplaceAll: 'Замени све',
	btnUndo: 'Врати акцију',
	changeTo: 'Измени',
	errorLoading: 'Error loading application service host: %s.',
	ieSpellDownload: 'Провера спеловања није инсталирана. Да ли желите да је скинете са Интернета?',
	manyChanges: 'Провера спеловања завршена:  %1 реч(и) је измењено',
	noChanges: 'Провера спеловања завршена: Није измењена ниједна реч',
	noMispell: 'Провера спеловања завршена: грешке нису пронађене',
	noSuggestions: '- Без сугестија -',
	notAvailable: 'Sorry, but service is unavailable now.',
	notInDic: 'Није у речнику',
	oneChange: 'Провера спеловања завршена: Измењена је једна реч',
	progress: 'Провера спеловања у току...',
	title: 'Spell Checker',
	toolbar: 'Провери спеловање'
});
