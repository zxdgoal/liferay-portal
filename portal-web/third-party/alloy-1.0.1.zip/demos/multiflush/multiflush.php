<?
include("content.php");
?>
<!DOCTYPE html>

<html>
<head>
	<script src="/alloy/trunk/lib/yui-combo/combo.php?./../../build/aui/aui-min.js&./../../build/oop/oop-min.js&./../../build/event-custom/event-custom-min.js&./../../build/async-queue/async-queue.js&./../../build/dom/dom-base-min.js&./../../build/dom/selector-native-min.js&./../../build/dom/selector-css2-min.js&./../../build/event/event-base-min.js&./../../build/node/node-base-min.js&./../../build/attribute/attribute-base-min.js&./../../build/base/base-base-min.js&./../../build/base/base-build-min.js&./../../build/collection/arraylist-min.js&./../../build/collection/arraylist-add-min.js" charset="utf-8" type="text/javascript"></script>

	<script src="multi-flush.js" type="text/javascript"></script>

	<script type="text/javascript">
	var multiFlush;

	AUI().use('aui-multi-flush', function(A) {
		multiFlush = new A.MultiFlush({});
	});
	</script>
</head>

<body>

	<h1>MultiFlush</h1>

	<div id="pContainer1"></div>
	<br/><br/>
	<div id="pContainer2"></div>
	<br/><br/>
	<div id="pContainer3"></div>

	<script type="text/javascript">
	multiFlush.render({
		id: 'pContainer1',
		timeout: 0,
		fetchCSS: true,
		fetchJS: true,
		content: <?= json_encode($content1) ?>
	});
	</script>

	<script type="text/javascript">
	multiFlush.render({
		id: 'pContainer2',
		timeout: 0,
		fetchCSS: true,
		fetchJS: true,
		content: <?= json_encode($content2) ?>
	});
	</script>

	<script type="text/javascript">
	multiFlush.render({
		id: 'pContainer3',
		timeout: 0,
		fetchCSS: true,
		fetchJS: true,
		content: <?= json_encode($content3) ?>
	});
	</script>

	<br/><br/>

</body>
</html>