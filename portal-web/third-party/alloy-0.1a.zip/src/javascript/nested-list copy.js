AUI.add('nested-list', function(A) {

var L = A.Lang,
	isString = L.isString,

	BLOCK = 'block',
	BODY = 'body',
	CLEARFIX = 'clearfix',
	CONTENT = 'content',
	DD = 'dd',
	DISPLAY = 'display',
	DOWN = 'down',
	DRAG = 'drag',
	DRAG_NODE = 'dragNode',
	HELPER = 'helper',
	ICON = 'icon',
	LABEL = 'label',
	LEFT = 'left',
	NESTED_LIST = 'nested-list',
	NODES = 'nodes',
	NONE = 'none',
	RIGHT = 'right',
	SPACE = ' ',
	UP = 'up',
	PLACEHOLDER = 'placeholder',
	NODE = 'node',
	OFFSET_HEIGHT = 'offsetHeight',
	APPEND = 'append',

	DDM = A.DD.DDM,

	isNodeList = function(v) {
		return (v instanceof A.NodeList);
	},

	getCN = A.ClassNameManager.getClassName,

	CSS_ICON = getCN(ICON),
	CSS_HELPER_CLEARFIX = getCN(HELPER, CLEARFIX),
	CSS_NESTED_LIST = getCN(NESTED_LIST),
	CSS_NESTED_LIST_DRAG_HELPER = getCN(NESTED_LIST, DRAG, HELPER),
	CSS_NESTED_LIST_DRAG_HELPER_CONTENT = getCN(NESTED_LIST, DRAG, HELPER, CONTENT),
	CSS_NESTED_LIST_DRAG_HELPER_LABEL = getCN(NESTED_LIST, DRAG, HELPER, LABEL);

function NestedList(config) {
	NestedList.superclass.constructor.apply(this, arguments);
}

A.mix(NestedList, {
	NAME: NESTED_LIST,

	ATTRS: {
		dd: {
			value: null
		},

		helper: {
			value: null
		},

		nodes: {
			setter: function(v) {
				return this._setNodes(v);
			}
		},

		placeholder: {
			value: null
		}
	}
});

A.extend(NestedList, A.Base, {
	/*
	* Lifecycle
	*/
	initializer: function() {
		var instance = this;
		var nodes = instance.get(NODES);

		// drag & drop listeners
		instance.on('drag:align', instance._onDragAlign);
		instance.on('drag:start', instance._onDragStart);
		instance.on('drop:enter', instance._onDropEnter);
		instance.on('drop:exit', instance._onDropExit);
		// instance.on('drop:hit', instance._onDropHit);
		instance.on('drop:over', instance._onDropOver);

		instance._createHelper();

		instance.addAll(nodes);
	},

	/*
	* Methods
	*/
	add: function(node) {
		var instance = this;

		instance._createDrag(node);
	},

	addAll: function(nodes) {
		var instance = this;

		nodes.each(function(node) {
			instance.add(node);
		});
	},

	_createDrag: function(node) {
		var instance = this;
		var helper = instance.get(HELPER);

		if (!DDM.getDrag(node)) {
			var dragOptions = {
				node: node,
				bubbles: instance,
				target: true
			};

			var proxyOptions = {
				moveOnEnd: false,
				positionProxy: false
			};

			if (helper) {
				proxyOptions.borderStyle = null;
			}

			// creating delayed drag instance
			var dd = new A.DD.Drag(
				A.mix(dragOptions, instance.get(DD))
			)
			.plug(A.Plugin.DDProxy, proxyOptions);
		}
	},

	_createHelper: function() {
		var instance = this;
		var helper = instance.get(HELPER);

		if (helper) {
			// append helper to the body
			A.get(BODY).append( helper.hide() );

			instance.set(HELPER, helper);
		}
	},

	_updateDropState: function(event) {
		var instance = this;
		var drag = event.drag;
		var drop = event.drop;
		var dropNode = drop.get(NODE);
		var dragNode = drag.get(NODE);

		var hasDropNode = dropNode.one('> ul');

// 		instance.dropState = instance.YDirection;
//
// 		if (hasDropNode) {
// 			instance.dropState = APPEND;
// 		}
// console.log(instance.drop);
// return;

		// cannot drop the dragged element into any of its children
		// using DOM contains method for performance reason
		if ( !dragNode.contains(dropNode) ) {
			// nArea splits the height in 3 areas top/center/bottom
			// these areas are responsible for defining the state when the mouse is over any of them
			var nArea = dropNode.get(OFFSET_HEIGHT) / 3;
			var yTop = dropNode.getY();
			var yCenter = yTop + nArea*1;
			var yBottom = yTop + nArea*2;
			var mouseY = drag.mouseXY[1];

			// UP: mouse on the top area of the node
			if ((mouseY > yTop) && (mouseY < yCenter)) {
				instance.dropState = UP;
			}
			// DOWN: mouse on the bottom area of the node
			else if (mouseY > yBottom) {
				instance.dropState = DOWN;
			}
			// APPEND: mouse on the center area of the node
			else if ((mouseY > yCenter) && (mouseY < yBottom)) {
				if (hasDropNode) {
					instance.dropState = APPEND;
				}
				// if it's a leaf we need to set the ABOVE or BELOW state instead of append
				else {
					if (instance.YDirection == UP) {
						instance.dropState = UP;
					}
					else {
						instance.dropState = DOWN;
					}
				}
			}
		}

		instance.dropNode = dropNode;
	},

	_updatePlaceholder: function(event) {
		var instance = this;
		var drag = event.drag;
		var drop = event.drop;
		var dropState = instance.dropState;
		var dropNode = drop.get(NODE);
		var dragNode = drag.get(NODE);
		var children = dropNode.one('> ul > li');
		var dropContainer = dropNode.one('> ul');

// console.log(dropState, instance.XDirection);

		if (instance.lockAppend || (dropState == APPEND)) {
			if (dropContainer) {
				dropContainer.append(dragNode);

				if (!instance.lockAppend && !children) {
					instance.lockAppend = true;
				}

			}
		}
		else if (dropState == DOWN) {
			// if (instance.YDirection == UP) {
				dropNode.placeAfter(dragNode);
			// }
		}
		else {
			// if (instance.YDirection == DOWN) {
				dropNode.placeBefore(dragNode);
			// }
		}
	},

	/*
	* Listeners
	*/
	_onDragAlign: function(event) {
		var instance = this;
		var lastX = instance.lastX;
		var lastY = instance.lastY;
		var xy = event.target.lastXY;

		var x = xy[0];
		var y = xy[1];

		// if the y change
		if (y != lastY) {
			// set the drag vertical direction
			instance.YDirection = (y < lastY) ? UP : DOWN;
		}

		// if the x change
		if (x != lastX) {
			// set the drag horizontal direction
			instance.XDirection = (x < lastX) ? LEFT : RIGHT;
		}

		instance.lastX = x;
		instance.lastY = y;
	},

	_onDragStart: function(event) {
 		var instance = this;
		var drag = event.target;
		var helper = instance.get(HELPER);

		if (helper) {
			// show helper, we need display block here, yui dd hide it with display none
			helper.setStyle(DISPLAY, BLOCK).show();

			// update the DRAG_NODE with the new helper
			drag.set(DRAG_NODE, helper);
		}
 	},

	_onDropOver: function(event) {
		var instance = this;

		var drag = event.drag;
		var drop = event.drop;

		if (instance.activeDrop == drop) {
			instance._updateDropState(event);

			instance._updatePlaceholder(event);
		}
	},

	_onDropEnter: function(event) {
		var instance = this;

		instance.activeDrop = event.drop;
	},

	_onDropExit: function(event) {
		var instance = this;

		instance.lockAppend = false;
		instance.activeDrop = null;
	},

	/*
	* Setters
	*/
	_setNodes: function(v) {
		var instance = this;

		if (isNodeList(v)) {
			return v;
		}
		else if (isString(v)) {
			return A.all(v);
		}

		return new A.NodeList([v]);
	}
});

A.NestedList = NestedList;

}, '0.1a', { requires: [ 'aui-base', 'dd' ] });