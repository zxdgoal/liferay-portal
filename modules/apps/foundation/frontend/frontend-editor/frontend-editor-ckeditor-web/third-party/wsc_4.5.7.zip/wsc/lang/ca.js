﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'ca', {
	btnIgnore: 'Ignora',
	btnIgnoreAll: 'Ignora-les totes',
	btnReplace: 'Canvia',
	btnReplaceAll: 'Canvia-les totes',
	btnUndo: 'Desfés',
	changeTo: 'Reemplaça amb',
	errorLoading: 'Error carregant el servidor: %s.',
	ieSpellDownload: 'Verificació ortogràfica no instal·lada. Voleu descarregar-ho ara?',
	manyChanges: 'Verificació ortogràfica: s\'han canviat %1 paraules',
	noChanges: 'Verificació ortogràfica: no s\'ha canviat cap paraula',
	noMispell: 'Verificació ortogràfica acabada: no hi ha cap paraula mal escrita',
	noSuggestions: 'Cap suggeriment',
	notAvailable: 'El servei no es troba disponible ara.',
	notInDic: 'No és al diccionari',
	oneChange: 'Verificació ortogràfica: s\'ha canviat una paraula',
	progress: 'Verificació ortogràfica en curs...',
	title: 'Comprova l\'ortografia',
	toolbar: 'Revisa l\'ortografia'
});
