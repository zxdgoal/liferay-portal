﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'ug', {
	btnIgnore: 'پەرۋا قىلما',
	btnIgnoreAll: 'ھەممىگە پەرۋا قىلما',
	btnReplace: 'ئالماشتۇر',
	btnReplaceAll: 'ھەممىنى ئالماشتۇر',
	btnUndo: 'يېنىۋال',
	changeTo: 'ئۆزگەرت',
	errorLoading: 'لازىملىق مۇلازىمېتىرنى يۈكلىگەندە خاتالىق كۆرۈلدى: %s.',
	ieSpellDownload: 'ئىملا تەكشۈرۈش قىستۇرمىسى تېخى ئورنىتىلمىغان، ھازىرلا چۈشۈرەمسىز؟',
	manyChanges: 'ئىملا تەكشۈرۈش تامام: %1  سۆزنى ئۆزگەرتتى',
	noChanges: 'ئىملا تەكشۈرۈش تامام: ھېچقانداق سۆزنى ئۆزگەرتمىدى',
	noMispell: 'ئىملا تەكشۈرۈش تامام: ئىملا خاتالىقى بايقالمىدى',
	noSuggestions: '-تەكلىپ يوق-',
	notAvailable: 'كەچۈرۈڭ، مۇلازىمېتىرنى ۋاقتىنچە ئىشلەتكىلى بولمايدۇ',
	notInDic: 'لۇغەتتە يوق',
	oneChange: 'ئىملا تەكشۈرۈش تامام: بىر سۆزنى ئۆزگەرتتى',
	progress: 'ئىملا تەكشۈرۈۋاتىدۇ…',
	title: 'ئىملا تەكشۈر',
	toolbar: 'ئىملا تەكشۈر'
});
