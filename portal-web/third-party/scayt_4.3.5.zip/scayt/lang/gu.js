﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'gu', {
	about: 'SCAYT વિષે',
	aboutTab: 'વિષે',
	addWord: 'શબ્દ ઉમેરવો',
	allCaps: 'ઓલ-કેપ્સ વર્ડ છોડી દો.',
	dic_create: 'બનાવવું',
	dic_delete: 'કાઢી નાખવું',
	dic_field_name: 'શબ્દકોશ નામ',
	dic_info: 'પેહલા User Dictionary, Cookie તરીકે સ્ટોર થાય છે. પણ Cookie ની સમતા ઓછી છે. જયારે User Dictionary, Cookie તરીકે સ્ટોર ના કરી શકાય, ત્યારે તે અમારા સર્વર પર સ્ટોર થાય છે. તમારી વ્યતિગત ડીકસ્નરી ને સર્વર પર સ્ટોર કરવા માટે તમારે તેનું નામ આપવું પડશે. જો તમે તમારી ડીકસ્નરી નું નામ આપેલું હોય તો તમે રિસ્ટોર બટન ક્લીક કરી શકો.',
	dic_rename: 'નવું નામ આપવું',
	dic_restore: 'પાછું ',
	dictionariesTab: 'શબ્દકોશ',
	disable: 'SCAYT ડિસેબલ કરવું',
	emptyDic: 'ડિક્સનરીનું નામ ખાલી ના હોય.',
	enable: 'SCAYT એનેબલ કરવું',
	ignore: 'ઇગ્નોર',
	ignoreAll: 'બધા ઇગ્નોર ',
	ignoreDomainNames: 'ડોમેન નામ છોડી દો.',
	langs: 'ભાષાઓ',
	languagesTab: 'ભાષા',
	mixedCase: 'મિક્સ કેસ વર્ડ છોડી દો.',
	mixedWithDigits: 'આંકડા વાળા શબ્દ છોડી દો.',
	moreSuggestions: 'વધારે વિકલ્પો',
	opera_title: 'ઓપેરામાં સપોર્ટ નથી',
	options: 'વિકલ્પો',
	optionsTab: 'વિકલ્પો',
	title: 'ટાઈપ કરતા સ્પેલ તપાસો',
	toggle: 'SCAYT ટોગલ',
	noSuggestions: 'No suggestion'
});
