AUI.add('context-panel', function(A) {

var L = A.Lang,
	isString = L.isString,

	CONTEXT_PANEL = 'contextpanel';

function ContextPanel(config) {
 	ContextPanel.superclass.constructor.apply(this, arguments);
}

A.mix(ContextPanel, {
	NAME: CONTEXT_PANEL,

	ATTRS: {

	}
});

A.extend(ContextPanel, A.ContextOverlay, {

});

A.ContextPanel = ContextPanel;

}, '0.1a', { requires: [ 'context-overlay' ] });