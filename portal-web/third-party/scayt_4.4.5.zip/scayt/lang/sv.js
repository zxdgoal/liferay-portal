﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'sv', {
	btn_about: 'Om SCAYT',
	btn_dictionaries: 'Ordlistor',
	btn_disable: 'Inaktivera SCAYT',
	btn_enable: 'Aktivera SCAYT',
	btn_langs:'Språk',
	btn_options: 'Inställningar',
	text_title: ''
});