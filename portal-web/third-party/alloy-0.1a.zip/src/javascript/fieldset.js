AUI().add(
	'fieldset',
	function(A) {
		A.Fieldset = A.Base.build('fieldset', A.Panel, []);
	},
	'0.1a',
	{
		requires: ['panel'],
		use: []
	}
);