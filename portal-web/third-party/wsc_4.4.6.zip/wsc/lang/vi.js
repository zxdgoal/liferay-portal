﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'vi', {
	btnIgnore: 'Bỏ qua',
	btnIgnoreAll: 'Bỏ qua tất cả',
	btnReplace: 'Thay thế',
	btnReplaceAll: 'Thay thế tất cả',
	btnUndo: 'Phục hồi lại',
	changeTo: 'Chuyển thành',
	errorLoading: 'Lỗi khi đang nạp dịch vụ ứng dụng: %s.',
	ieSpellDownload: 'Chức năng kiểm tra chính tả chưa được cài đặt. Bạn có muốn tải về ngay bây giờ?',
	manyChanges: 'Hoàn tất kiểm tra chính tả: %1 từ đã được thay đổi',
	noChanges: 'Hoàn tất kiểm tra chính tả: Không có từ nào được thay đổi',
	noMispell: 'Hoàn tất kiểm tra chính tả: Không có lỗi chính tả',
	noSuggestions: '- Không đưa ra gợi ý về từ -',
	notAvailable: 'Xin lỗi, dịch vụ này hiện tại không có.',
	notInDic: 'Không có trong từ điển',
	oneChange: 'Hoàn tất kiểm tra chính tả: Một từ đã được thay đổi',
	progress: 'Đang tiến hành kiểm tra chính tả...',
	title: 'Kiểm tra chính tả',
	toolbar: 'Kiểm tra chính tả'
});
