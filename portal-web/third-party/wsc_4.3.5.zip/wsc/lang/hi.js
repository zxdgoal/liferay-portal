﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'hi', {
	btnIgnore: 'इग्नोर',
	btnIgnoreAll: 'सभी इग्नोर करें',
	btnReplace: 'रिप्लेस',
	btnReplaceAll: 'सभी रिप्लेस करें',
	btnUndo: 'अन्डू',
	changeTo: 'इसमें बदलें',
	errorLoading: 'Error loading application service host: %s.',
	ieSpellDownload: 'स्पॅल-चॅकर इन्स्टाल नहीं किया गया है। क्या आप इसे डाउनलोड करना चाहेंगे?',
	manyChanges: 'वर्तनी की जाँच : %1 शब्द बदले गये',
	noChanges: 'वर्तनी की जाँच :कोई शब्द नहीं बदला गया',
	noMispell: 'वर्तनी की जाँच : कोई गलत वर्तनी (स्पॅलिंग) नहीं पाई गई',
	noSuggestions: '- कोई सुझाव नहीं -',
	notAvailable: 'Sorry, but service is unavailable now.',
	notInDic: 'शब्दकोश में नहीं',
	oneChange: 'वर्तनी की जाँच : एक शब्द बदला गया',
	progress: 'वर्तनी की जाँच (स्पॅल-चॅक) जारी है...',
	title: 'Spell Check',
	toolbar: 'वर्तनी (स्पेलिंग) जाँच'
});
