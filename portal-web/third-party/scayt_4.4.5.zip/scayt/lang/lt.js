﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'lt', {
	btn_about: 'Apie SCAYT',
	btn_dictionaries: 'Žodynai',
	btn_disable: 'Išjungti SCAYT',
	btn_enable: 'Įjungti SCAYT',
	btn_langs:'Kalbos',
	btn_options: 'Parametrai',
	text_title: ''
});
