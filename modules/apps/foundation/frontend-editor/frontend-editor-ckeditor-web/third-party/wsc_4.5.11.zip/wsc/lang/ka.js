﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'ka', {
	btnIgnore: 'უგულებელყოფა',
	btnIgnoreAll: 'ყველას უგულებელყოფა',
	btnReplace: 'შეცვლა',
	btnReplaceAll: 'ყველას შეცვლა',
	btnUndo: 'გაუქმება',
	changeTo: 'შეცვლელი',
	errorLoading: 'სერვისის გამოძახების შეცდომა: %s.',
	ieSpellDownload: 'მართლწერის შემოწმება არაა დაინსტალირებული. ჩამოვქაჩოთ ინტერნეტიდან?',
	manyChanges: 'მართლწერის შემოწმება: %1 სიტყვა შეიცვალა',
	noChanges: 'მართლწერის შემოწმება: არაფერი შეცვლილა',
	noMispell: 'მართლწერის შემოწმება: შეცდომა არ მოიძებნა',
	noSuggestions: '- არაა შემოთავაზება -',
	notAvailable: 'უკაცრავად, ეს სერვისი ამჟამად მიუწვდომელია.',
	notInDic: 'არაა ლექსიკონში',
	oneChange: 'მართლწერის შემოწმება: ერთი სიტყვა შეიცვალა',
	progress: 'მიმდინარეობს მართლწერის შემოწმება...',
	title: 'მართლწერა',
	toolbar: 'მართლწერა'
});
