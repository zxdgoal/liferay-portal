﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'pt', {
	options: 'Special Character Options', // MISSING
	title: 'Seleccione um caracter especial',
	toolbar: 'Inserir Caracter Especial'
});
