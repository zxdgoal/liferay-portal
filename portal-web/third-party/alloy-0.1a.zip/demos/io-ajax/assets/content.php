<?php
sleep(5);
echo 'POST parameters: ';
echo '<pre>' . print_r($_POST, true) . '</pre>';

echo 'GET parameters: ';
echo '<pre>' . print_r($_GET, true) . '</pre>';
?>