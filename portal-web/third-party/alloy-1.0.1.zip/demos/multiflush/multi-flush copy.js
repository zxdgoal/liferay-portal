AUI.add('aui-multi-flush', function(A) {

/*
1. Instruction fetch
2. Instruction decode and register fetch
3. Execute
4. Memory access
5. Register write back
*/

var L = A.Lang,
	isBoolean = L.isBoolean,
	isNumber = L.isNumber,
	isString = L.isString,

	UA = A.UA,
	DOC = A.one(A.config.doc),

	DASH = '-',
	CSS_SELECTORS = 'style,link[type=text/css]',
	EMPTY_STR = '',
	HASH = '#',

	COMPLETE = 'complete',
	CONTENT = 'content',
	CSS = 'css',
	CSS_POOL = 'cssPool',
	CSS_QUEUE = 'cssQueue',
	DOCUMENT_ELEMENT = 'documentElement',
	FETCH_CSS = 'fetchCSS',
	FETCH_JS = 'fetchJS',
	FIRST_CHILD = 'firstChild',
	FRAGMENT = 'fragment',
	HEAD = 'head',
	HOST = 'host',
	HREF = 'href',
	ID = 'id',
	JS = 'js',
	JS_QUEUE = 'jsQueue',
	OWNER_DOCUMENT = 'ownerDocument',
	PORTLETS = 'portlets',
	PURGE = 'purge',
	SCRIPT = 'script',
	SRC = 'src',
	TIMEOUT = 'timeout',

	EV_ALL_CSS_QUEUE_COMPLETE = 'multiFlush:allCssQueueComplete',

	isMultiFlush = function(val) {
		return (val instanceof A.MultiFlush);
	},

	isMultiFlushDispatcher = function(val) {
		return (val instanceof A.MultiFlushDispatcher);
	},

	_getDocHead = function(node) {
		var ownerDocument = node.get(OWNER_DOCUMENT) || node;

		return (ownerDocument.one(HEAD) || ownerDocument.get(DOCUMENT_ELEMENT));
	};

function MultiFlush() {}

MultiFlush.ATTRS = {
	cssPool: {
		readOnly: true,
		valueFn: function() {
			return new A.ArrayList();
		}
	},

	portlets: {
		readOnly: true,
		valueFn: function() {
			return new A.ArrayList();
		}
	}
};

MultiFlush.prototype = {
	initializer: function() {
		var instance = this;

		instance._createEvents();
	},

	render: function(portlet) {
		var instance = this;
		var portlets = instance.get(PORTLETS);

		if (!isMultiFlushDispatcher(portlet)) {
			portlet = new A.MultiFlushDispatcher(portlet);
		}

		portlet.set(HOST, instance);
		portlets.add(portlet);
		portlet.dispatch();
	},

	_createEvents: function() {
		var instance = this;

		var publish = function(name, fn) {
			instance.publish(name, {
				defaultFn: fn,
				queuable: false,
				emitFacade: true,
				bubbles: true
			});
		};

		publish(EV_ALL_CSS_QUEUE_COMPLETE, instance._defAllCSSQueueCompleteFn);
	},

	_defAllCSSQueueCompleteFn: function(event) {
		var instance = this;
		var portlets = instance.get(PORTLETS);

		// when load all the CSS and render the visible elements start downloading JS for the portlets
		portlets.each(function(portlet) {
			portlet.dispatchJS(portlet);
		});
	},

	_handleAllCSSQueueComplete: function(event) {
		this.fire(EV_ALL_CSS_QUEUE_COMPLETE);
	}
};

A.MultiFlush = A.Base.create('multiFlush', A.Base, [ MultiFlush ]);


function MultiFlushDispatcher() {
}

MultiFlushDispatcher.ATTRS = {
	content: {
		value: EMPTY_STR,
		validator: isString,
		writeOnce: true
	},

	css: {
		readOnly: true,
		valueFn: '_valueCSS'
	},

	cssQueue: {
		readOnly: true,
		valueFn: '_valueCSSQueue'
	},

	fetchCSS: {
		value: true,
		validator: isBoolean,
		writeOnce: true
	},

	fetchJS: {
		value: true,
		validator: isBoolean,
		writeOnce: true
	},

	fragment: {
		readOnly: true,
		valueFn: function() {
			// Note that IE has issues creating fragments which the firstChild of the firstChild is script, style or link elements.
			// appending '-' to the beginning of the content to prevent run into that particularity.
			var fragment = A.Node.create('<div></div>');
			fragment.setContent(DASH + this.get(CONTENT));
			fragment.get(FIRST_CHILD).remove();

			return fragment;
		}
	},

	host: {
		validator: isMultiFlush
	},

	id: {
		validator: isString
	},

	js: {
		readOnly: true,
		valueFn: '_valueJS'
	},

	jsQueue: {
		readOnly: true,
		valueFn: '_valueJSQueue'
	},

	purge: {
		value: true,
		validator: isBoolean
	},

	timeout: {
		value: 0,
		validator: isNumber
	}
};

MultiFlushDispatcher.prototype = {
	dispatch: function() {
		var instance = this;

		if (instance.get(FETCH_CSS)) {
			instance.dispatchCSS();
		}
		else {
			instance._handleCSSQueue();
		}
	},

	dispatchCSS: function() {
		var instance = this;
		var host = instance.get(HOST);
		var cssPool = host.get(CSS_POOL);
		var cssQueue = instance.get(CSS_QUEUE);

		instance.get(CSS).each(function(cssNode) {
			var qCallback = {
				autoContinue: false,
				context: instance,
				fn: function() {
					// instance.loadCSS(cssNode, A.bind(instance._handleCSSQueue, instance, cssQueue));
					console.log('sss', cssNode.get(HREF));
				},
				timeout: instance.get(TIMEOUT)
			};

			cssQueue.add(qCallback);

			instance.loadCSS(cssNode, A.bind(instance._handleCSSQueue, instance, qCallback, cssNode));
		});

		cssPool.add(cssQueue);
		cssQueue.run();
	},

	dispatchJS: function() {
		var instance = this;
		var jsQueue = instance.get(JS_QUEUE);

		instance.get(JS).each(function(jsNode) {
			jsQueue.add({
				autoContinue: false,
				context: instance,
				fn: function() {
					instance.loadJS(jsNode, A.bind(instance._handleJSQueue, instance));
				},
				timeout: instance.get(TIMEOUT)
			});
		});

		jsQueue.run();
	},

	globalEval: function(data) {
		// NOTE: A.Node.create('<script></script>') doesn't work correctly on Opera
		var newScript = document.createElement(SCRIPT);

		newScript.type = 'text/javascript';

		if (data) {
			// NOTE: newScript.set(TEXT, data) breaks on IE, YUI BUG.
			newScript.text = L.trim(data);
		}

		_getDocHead(DOC).appendChild(newScript).remove(); //removes the script node immediately after executing it
	},

	loadCSS: function(cssNode, fn) {
		var instance = this;
		var href = cssNode.get(HREF);

		var callback = function() {
			if (fn) {
				fn.call(instance);
			}
		};

		if (href) {
			// Note that Firefox and Safari at present do not support the load event on link nodes
			if (UA.webkit || UA.gecko) {
				var link = A.Node.create('<link rel="stylesheet" type="text/css" media="all" href="' + href + '"></link>');

				// pool work-around to wait until the link cssRules becomes ready
				(function(){
					try {
						link._node.sheet.cssRules;
					}
					catch(e) {
						setTimeout(arguments.callee, 20);
						return;
					}

					callback();
				})();

				_getDocHead(DOC).appendChild(link);
				console.log(cssNode);
			}
			else {
				A.Get.css(href, { onEnd: callback });
			}
		}
		else {
			_getDocHead(cssNode).appendChild(cssNode);

			callback();
		}
	},

	loadJS: function(jsNode, fn) {
		var instance = this;
		var src = jsNode.get(SRC);

		var callback = function() {
			if (fn) {
				fn.call(instance);
			}
		};

		if (src) {
			// console.log(jsNode);
			A.Get.script(src, {
				onEnd: function(o) {
					callback();

					if (instance.get(PURGE)) {
						o.purge();
					}
				}
			});
		}
		else {
			var dom = jsNode._node;

			instance.globalEval(
				dom.text || dom.textContent || dom.innerHTML || EMPTY_STR
			);

			callback();
		}
	},

	render: function() {
		var instance = this;
		var fragment = instance.get(FRAGMENT);
		var node = A.one(HASH+instance.get(ID));

		if (node) {
			node.setContent(fragment);
		}
	},

	_afterCSSQueueComplete: function(event) {
		var instance = this;
		var host = instance.get(HOST);
		var cssPool = host.get(CSS_POOL);
		var queue = event.currentTarget;
console.log('_afterCSSQueueComplete');
		cssPool.remove(queue);

		if (cssPool.size() === 0) {
			host._handleAllCSSQueueComplete();
		}

		instance.render();
	},

	_extractNodes: function(nodes) {
		var instance = this;
		var fragment = instance.get(FRAGMENT);

		return fragment.all(nodes).each(function(node) {
			node.remove();
		});
	},

	_handleJSQueue: function() {
		var instance = this;
		var jsQueue = instance.get(JS_QUEUE);

		A.later(0, instance, function() { jsQueue.run(); });
	},

	_handleCSSQueue: function(qCallback, cssNode) {
		var instance = this;
		var cssQueue = instance.get(CSS_QUEUE);
console.log('_handleCSSQueue', arguments);
		A.later(0, instance, function() { cssQueue.promote(qCallback); cssQueue.run(); });
	},

	_valueCSS: function() {
		var instance = this, nodes = A.all([]);

		if (instance.get(FETCH_CSS)) {
			nodes = instance._extractNodes(CSS_SELECTORS);
		}

		return nodes;
	},

	_valueCSSQueue: function(fn) {
		var instance = this;
		var queue = new A.AsyncQueue();

		queue.after(COMPLETE, function(event) {
			// Due to the async behavior of the complete event, make _afterCSSQueueComplete to be also async.
			A.later(0, instance, A.bind(instance._afterCSSQueueComplete, instance, event));
		});

		return queue;
	},

	_valueJSQueue: function() {
		return new A.AsyncQueue();
	},

	_valueJS: function() {
		var instance = this, nodes = A.all([]);

		if (instance.get(FETCH_JS)) {
			nodes = instance._extractNodes(SCRIPT);
		}

		return nodes;
	}
};

A.MultiFlushDispatcher = A.Base.create('multiFlushDispatcher', A.Base, [ MultiFlushDispatcher ]);

}, '@VERSION@' ,{skinnable:false, requires:['arraylist-add', 'async-queue', 'node-base', 'base-base', 'base-build']});
