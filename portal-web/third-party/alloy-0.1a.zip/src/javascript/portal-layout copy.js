AUI.add('portal-layout', function(A) {

/*
* PortalLayout
*/
var L = A.Lang,
	isObject = L.isObject,

	DDM = A.DD.DDM,

	BORDER_STYLE = 'borderStyle',
	CONTAINER = 'container',
	DD = 'dd',
	DD_DELEGATE = 'ddDelegate',
	DOWN = 'down',
	DRAG_NODE = 'dragNode',
	DRAG_NODES = 'dragNodes',
	DROP_NODES = 'dropNodes',
	GROUPS = 'groups',
	LEFT = 'left',
	NODE = 'node',
	OFFSET_HEIGHT = 'offsetHeight',
	OFFSET_WIDTH = 'offsetWidth',
	PLACEHOLDER = 'placeholder',
	PORTAL_LAYOUT = 'portal-layout',
	PROXY = 'proxy',
	PROXY_NODE = 'proxyNode',
	RIGHT = 'right',
	UP = 'up',

	EV_QUADRANT_ALIGN = 'quadrantAlign',
	EV_QUADRANT_ENTER = 'quadrantEnter',
	EV_QUADRANT_EXIT = 'quadrantExit',

	getCN = A.ClassNameManager.getClassName;

function PortalLayout(config) {
	PortalLayout.superclass.constructor.apply(this, arguments);
}

A.mix(PortalLayout, {
	NAME: PORTAL_LAYOUT,

	ATTRS: {
		container: {

		},

		dd: {
			value: null,
			setter: function(val) {
				var instance = this;

				var defaults = {
					// bubbleTarget: instance,
					cont: instance.get(CONTAINER),
					dragConfig: {
						// useShim: false,
						groups: [instance.get(GROUPS)],
						target: true
					},
					nodes: instance.get(DRAG_NODES),
					target: true
				};

				return A.merge(defaults, val);
			},
			validator: isObject
		},

		ddDelegate: {
			valueFn: function() {
				var instance = this;
				var proxy = instance.get(PROXY);

				var ddDelegate = new A.DD.Delegate(
					instance.get(DD)
				);

				ddDelegate.dd.plug(A.Plugin.DDProxy, proxy);

				return ddDelegate;
			}
		},

		proxyNode: {
			setter: function(val) {
				return A.Node.create(val);
			}
		},

		dragNodes: {

		},

		dropNodes: {
			value: false,
			setter: function(val) {
				return A.all(val);
			}
		},

		groups: {
			value: [PORTAL_LAYOUT]
		},

		placeholder: {
			setter: function(val) {
				var placeholder = A.Node.create(val);

				if (!placeholder.inDoc()) {
					A.getBody().append(
						placeholder.hide()
					);
				}

				return placeholder;
			}
		},

		proxy: {
			value: null,
			setter: function(val) {
				var instance = this;

				var defaults = {
					moveOnEnd: false,
					positionProxy: false
				};

				// if proxyNode is set remove the border from the default proxy
				if (instance.get(PROXY_NODE)) {
					defaults.borderStyle = null;
				}

				return A.merge(defaults, val || {});
			}
		}
	}
});

A.extend(PortalLayout, A.Base, {
	/*
	* Lifecycle
	*/
	initializer: function() {
		var instance = this;

		instance.bindUI();
	},

	bindUI: function() {
		var instance = this;

		// publishing events
		instance.publish(EV_QUADRANT_ENTER);
		instance.publish(EV_QUADRANT_EXIT);
		instance.publish(EV_QUADRANT_ALIGN);

		instance._bindDDEvents();
		instance._bindDropZones();
	},

	/*
	* Methods
	*/
	addDropTarget: function(drop) {
		var instance = this;

		drop.addToGroup(
			instance.get(GROUPS)
		);
	},

	addDropNode: function(node, config) {
		var instance = this;

		node = A.one(node);

		if (!DDM.getDrop(node)) {
			var defaults = {
				// bubbles: instance,
				node: node
			};

			instance.addDropTarget(
				new A.DD.Drop(
					A.merge(defaults, config)
				)
			);
		}
	},

	calculateDirections: function(drag) {
		var instance = this;
		var lastY = instance.lastY;
		var lastX = instance.lastX;

		var x = drag.lastXY[0];
		var y = drag.lastXY[1];

		// if the x change
		if (x != lastX) {
			// set the drag direction
			instance.XDirection = (x < lastX) ? LEFT : RIGHT;
		}

		// if the y change
		if (y != lastY) {
			// set the drag direction
			instance.YDirection = (y < lastY) ? UP : DOWN;
		}

		instance.lastX = x;
		instance.lastY = y;
	},

	calculateQuadrant: function(drag, drop) {
		var instance = this;
		var quadrant = 1;
		var region = drop.region;
		var mouseXY = drag.mouseXY;
		var mouseX = mouseXY[0];
		var mouseY = mouseXY[1];

		var top = region.top;
		var left = region.left;

		// (region.bottom - top) finds the height of the region
		var vCenter = top + (region.bottom - top)/2;
		// (region.right - left) finds the width of the region
		var hCenter = left + (region.right - left)/2;

		if (mouseY < vCenter) {
			if (mouseX > hCenter) {
				quadrant = 1;
			}
			else {
				quadrant = 2;
			}
		}
		else {
			if (mouseX < hCenter) {
				quadrant = 3;
			}
			else {
				quadrant = 4;
			}
		}

		instance.quadrant = quadrant;

		return quadrant;
	},

	position: function(drop) {
		var instance = this;
		var node = drop.get('node');

		var placeholder = instance.get(PLACEHOLDER);
		// clearTimeout(timer);

		if (placeholder) {
			placeholder.show();
			placeholder.setXY(node.getXY());
			placeholder.set('offsetWidth', node.get('offsetWidth'));
		}

		// timer = setTimeout(function() {

		// }, 1);
	},

	removeDropTarget: function(drop) {
		var instance = this;

		drop.removeFromGroup(
			instance.get(GROUPS)
		);
	},

	_bindDDEvents: function() {
		var instance = this;
		var ddDelegate = instance.get(DD_DELEGATE);

		ddDelegate.on('drag:over', A.bind(instance._onDragAlign, instance));
		ddDelegate.on('drag:end', A.bind(instance._onDragEnd, instance));
		ddDelegate.on('drag:enter', A.bind(instance._onDragEnter, instance));
		ddDelegate.on('drag:exit', A.bind(instance._onDragExit, instance));
		ddDelegate.on('drag:start', A.bind(instance._onDragStart, instance));

		instance.on(EV_QUADRANT_ENTER, instance._onQuadrantEnter);
		instance.on(EV_QUADRANT_EXIT, instance._onQuadrantExit);
	},

	_bindDropZones: function() {
		var instance = this;

		instance.get(DROP_NODES).each(function(node, i) {
			instance.addDropNode(node);
		});
	},

	_evOutput: function() {
		var instance = this;

		return {
			drag: DDM.activeDrag,
			drop: DDM.activeDrop,
			quadrant: instance.quadrant,
			XDirection: instance.XDirection,
			YDirection: instance.YDirection
		};
	},

	_fireQuadrantEvents: function() {
		var instance = this;
		var evOutput = instance._evOutput();
		var lastQuadrant = instance.lastQuadrant;
		var quadrant = instance.quadrant;

		if (quadrant != lastQuadrant) {
			// only trigger exit if it has previously entered in any quadrant
			if (lastQuadrant) {
				// merging event with the "last" information
				instance.fire(
					EV_QUADRANT_EXIT,
					A.merge(
						{
							lastDrag: instance.lastDrag,
							lastDrop: instance.lastDrop,
							lastQuadrant: instance.lastQuadrant,
							lastXDirection: instance.lastXDirection,
							lastYDirection: instance.lastYDirection
						},
						evOutput
					)
				);
			}

			// firing EV_QUADRANT_ENTER event
			instance.fire(EV_QUADRANT_ENTER, evOutput);
		}

		// firing EV_QUADRANT_ALIGN, align event fires like the drag over without bubbling for performance reasons
		instance.fire(EV_QUADRANT_ALIGN, evOutput);

		// updating "last" information
		instance.lastDrag = DDM.activeDrag;
		instance.lastDrop = DDM.activeDrop;
		instance.lastQuadrant = quadrant;
		instance.lastXDirection = instance.XDirection;
		instance.lastYDirection = instance.YDirection;
	},

	_syncProxyNodeUI: function(event) {
		var instance = this;
		var drag = event.target;
		var dragNode = drag.get(DRAG_NODE);
		var proxyNode = instance.get(PROXY_NODE);

		if (proxyNode && !proxyNode.compareTo(dragNode)) {
			dragNode.append(proxyNode);

			proxyNode.set(
				OFFSET_HEIGHT,
				dragNode.get(OFFSET_HEIGHT)
			);

			proxyNode.set(
				OFFSET_WIDTH,
				dragNode.get(OFFSET_WIDTH)
			);
		}
	},

	/*
	* Listeners
	*/
	_onDragEnd: function(event) {
		var instance = this;
		var placeholder = instance.get(PLACEHOLDER);
		var proxyNode = instance.get(PROXY_NODE);

		if (proxyNode) {
			proxyNode.remove();
		}

		if (placeholder) {
			placeholder.hide();
		}

		// reset the last information
		instance.lastQuadrant = null;
		instance.lastXDirection = null;
		instance.lastYDirection = null;
	},

	_onDragEnter: function(event) {
		var instance = this;
		var drop = event.drop;
// console.log(event,event.drop.get(NODE), DDM.activeDrop, DDM.activeDrag);
// console.dir(event.drag.region);
	// console.log(DDM, DDM.getDelegate( DDM.activeDrop.get(NODE) ) );

// console.log(DDM.activeDrag.region, DDM.activeDrag.get(NODE).getDOM());
		// instance.position(DDM.activeDrop);

		// console.log('_onDragEnter: ', text(drop));
	},

	_onDragExit: function(event) {
		var instance = this;

		// instance.position(DDM.activeDrop);
	},

	_onDragAlign: function(event) {
		var instance = this;
		var drag = event.drag;

		instance.calculateDirections(drag);
// console.dir(event.currentTarget.dd.target.region);
// console.dir(drag.region);
		// instance.calculateQuadrant(drag, DDM.activeDrop);

		instance._fireQuadrantEvents();
	},

	_onDragStart: function(event) {
		var instance = this;

		if (instance.get(PROXY)) {
			instance._syncProxyNodeUI(event);
		}
	},

	_onQuadrantEnter: function(event) {
		var instance = this;

		console.log('_onQuadrantEnter', event, event.drop.get(NODE).getDOM(), DDM.activeDrop.get(NODE).getDOM());

		instance.position(DDM.activeDrop);
	},

	_onQuadrantExit: function(event) {
		var instance = this;
		console.log('_onQuadrantExit', event, event.drop.get(NODE).getDOM(), DDM.activeDrop.get(NODE).getDOM());
		instance.position(DDM.activeDrop);
	}
});

A.PortalLayout = PortalLayout;

}, '0.1a', { requires: [ 'aui-base', 'dd' ] });