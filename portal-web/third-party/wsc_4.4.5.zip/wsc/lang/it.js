﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'it', {
	btnIgnore: 'Ignora',
	btnIgnoreAll: 'Ignora tutto',
	btnReplace: 'Cambia',
	btnReplaceAll: 'Cambia tutto',
	btnUndo: 'Annulla',
	changeTo: 'Cambia in',
	errorLoading: 'Errore nel caricamento dell\'host col servizio applicativo: %s.',
	ieSpellDownload: 'Contollo ortografico non installato. Lo vuoi scaricare ora?',
	manyChanges: 'Controllo ortografico completato: %1 parole cambiate',
	noChanges: 'Controllo ortografico completato: nessuna parola cambiata',
	noMispell: 'Controllo ortografico completato: nessun errore trovato',
	noSuggestions: '- Nessun suggerimento -',
	notAvailable: 'Il servizio non è momentaneamente disponibile.',
	notInDic: 'Non nel dizionario',
	oneChange: 'Controllo ortografico completato: 1 parola cambiata',
	progress: 'Controllo ortografico in corso',
	title: 'Controllo ortografico',
	toolbar: 'Correttore ortografico'
});
