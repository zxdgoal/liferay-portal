AUI().ready(
	'oop',
	function(A) {
		console.dir(A);
	}
);