﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'ar', {
	btnIgnore: 'تجاهل',
	btnIgnoreAll: 'تجاهل الكل',
	btnReplace: 'تغيير',
	btnReplaceAll: 'تغيير الكل',
	btnUndo: 'تراجع',
	changeTo: 'التغيير إلى',
	errorLoading: 'خطأ في تحميل تطبيق خدمة الاستضافة: %s.',
	ieSpellDownload: 'المدقق الإملائي (الإنجليزي) غير مثبّت. هل تود تحميله الآن؟',
	manyChanges: 'تم إكمال التدقيق الإملائي: تم تغيير %1 من كلمات',
	noChanges: 'تم التدقيق الإملائي: لم يتم تغيير أي كلمة',
	noMispell: 'تم التدقيق الإملائي: لم يتم العثور على أي أخطاء إملائية',
	noSuggestions: '- لا توجد إقتراحات -',
	notAvailable: 'عفواً، ولكن هذه الخدمة غير متاحة الان',
	notInDic: 'ليست في القاموس',
	oneChange: 'تم التدقيق الإملائي: تم تغيير كلمة واحدة فقط',
	progress: 'جاري التدقيق الاملائى',
	title: 'التدقيق الإملائي',
	toolbar: 'تدقيق إملائي'
});
