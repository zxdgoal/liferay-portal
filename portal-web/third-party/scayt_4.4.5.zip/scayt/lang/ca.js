﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'ca', {
	btn_about: 'Quant a l\'SCAYT',
	btn_dictionaries: 'Diccionaris',
	btn_disable: 'Deshabilita SCAYT',
	btn_enable: 'Habilitat l\'SCAYT',
	btn_langs:'Idiomes',
	btn_options: 'Opcions',
	text_title: ''
});
