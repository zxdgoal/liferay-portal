aui-classnamemanager
========
