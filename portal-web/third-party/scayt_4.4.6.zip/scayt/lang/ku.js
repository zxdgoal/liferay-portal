﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'ku', {
	btn_about: 'دهربارهی SCAYT',
	btn_dictionaries: 'فهرههنگهکان',
	btn_disable: 'ناچالاککردنی SCAYT',
	btn_enable: 'چالاککردنی SCAYT',
	btn_langs:'زمانهکان',
	btn_options: 'ههڵبژارده',
	text_title:  'پشکنینی نووسه لهکاتی نووسین'
});
