﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'gu', {
	btn_about: 'SCAYT વિષે',
	btn_dictionaries: 'શબ્દકોશ',
	btn_disable: 'SCAYT ડિસેબલ કરવું',
	btn_enable: 'SCAYT એનેબલ કરવું',
	btn_langs:'ભાષાઓ',
	btn_options: 'વિકલ્પો',
	text_title:  'ટાઈપ કરતા સ્પેલ તપાસો'
});
