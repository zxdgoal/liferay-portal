﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'nl', {
	btn_about: 'Over SCAYT',
	btn_dictionaries: 'Woordenboeken',
	btn_disable: 'SCAYT uitschakelen',
	btn_enable: 'SCAYT inschakelen',
	btn_langs:'Talen',
	btn_options: 'Opties',
	text_title: 'Controleer de spelling tijdens het typen'
});