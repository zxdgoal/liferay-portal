/*
 * Alloy JavaScript Library v0.1
 * http://alloyui.com/
 *
 * Copyright (c) 2009 Liferay Inc.
 * Licensed under the MIT license.
 * http://alloyui.com/License
 *
 * Date: @DATE
 * Revision: @REVISION
 */

;(function() {
	var PATH_BASE = YUI.config.base + '../../../';
	var PATH_JAVASCRIPT = PATH_BASE + 'src/javascript/';
	var PATH_THEME_ROOT = PATH_BASE + 'themes/base/css/';
	var PATH_THEME_IMAGES = PATH_THEME_ROOT + '../images/';

	window.AUI = {
		defaults: {
			classNamePrefix: 'aui',

			//base: '',

			defaultModules: [ 'aui-base' ],

			filter: 'raw',

			modules: {

				/*
				* AUI Base modules
				*/
				'aui-base': {
					fullpath: PATH_JAVASCRIPT + 'base.js',
					requires: [ 'event', 'oop', 'component', 'aui-node', 'collection' ]
				},

				/*
				* Data Set
				*/
				'data-set': {
					fullpath: PATH_JAVASCRIPT + 'data-set.js',
					requires: [ 'oop', 'collection', 'base' ]
				},

				/*
				* AutoComplete
				*/
				'autocomplete': {
					fullpath: PATH_JAVASCRIPT + 'autocomplete.js',
					requires: [ 'aui-base', 'component-overlay', 'datasource', 'dataschema', 'combobox', 'autocomplete-css' ]
				},
				'autocomplete-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'autocomplete.css',
					type: 'css'
				},

				/*
				* Parse Content
				*/
				'parse-content': {
					fullpath: PATH_JAVASCRIPT + 'parse-content.js',
					requires: [ 'async-queue', 'io', 'plugin' ]
				},

				/*
				* Editable
				*/
				'editable': {
					fullpath: PATH_JAVASCRIPT + 'editable.js',
					requires: [ 'aui-base', 'combobox', 'textarea', 'editable-css' ]
				},
				'editable-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'editable.css',
					type: 'css'
				},

				/*
				* Paginator
				*/
				'paginator': {
					fullpath: PATH_JAVASCRIPT + 'paginator.js',
					requires: [ 'aui-base', 'substitute', 'paginator-css' ]
				},
				'paginator-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'paginator.css',
					type: 'css'
				},

				/*
				* Rating
				*/
				'rating': {
					fullpath: PATH_JAVASCRIPT + 'rating.js',
					requires: [ 'aui-base', 'rating-css' ]
				},
				'rating-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'rating.css',
					type: 'css'
				},

				/*
				* Tool Item
				*/
				'tool-item': {
					fullpath: PATH_JAVASCRIPT + 'tool-item.js',
					requires: [ 'aui-base', 'state-interaction', 'tool-item-css' ]
				},
				'tool-item-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'tool-item.css',
					type: 'css'
				},

				/*
				* Tool Set
				*/
				'tool-set': {
					fullpath: PATH_JAVASCRIPT + 'tool-set.js',
					requires: [ 'data-set', 'tool-item', 'tool-set-css' ]
				},
				'tool-set-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'tool-set.css',
					type: 'css'
				},

				/*
				* Calendar
				*/
				'calendar': {
					fullpath: PATH_JAVASCRIPT + 'calendar.js',
					requires: [ 'aui-base', 'context-overlay', 'overlay-manager', 'datatype-date', 'calendar-css' ]
				},
				'calendar-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'calendar.css',
					type: 'css'
				},

				/*
				* Calendar
				*/
				'char-counter': {
					fullpath: PATH_JAVASCRIPT + 'char-counter.js',
					requires: [ 'aui-base', 'input-handler' ]
				},

				/*
				* DatePickerSelect
				*/
				'date-picker-select': {
					fullpath: PATH_JAVASCRIPT + 'date-picker-select.js',
					requires: [ 'calendar', 'tool-item', 'date-picker-select-css' ]
				},
				'date-picker-select-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'date-picker-select.css',
					type: 'css'
				},

				/*
				* ContextPanel
				*/
				'context-panel': {
					fullpath: PATH_JAVASCRIPT + 'context-panel.js',
					requires: [ 'context-overlay', 'anim', 'context-panel-css' ]
				},
				'context-panel-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'context-panel.css',
					type: 'css'
				},

				/*
				* ColorPicker
				*/
				'color-picker': {
					fullpath: PATH_JAVASCRIPT + 'color-picker.js',
					requires: [ 'context-overlay', 'dd', 'slider', 'substitute', 'tool-item', 'form', 'panel', 'color-picker-css' ]
				},
				'color-picker-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'color-picker.css',
					type: 'css'
				},

				/*
				* Tooltip
				*/
				'tooltip': {
					fullpath: PATH_JAVASCRIPT + 'tooltip.js',
					requires: [ 'context-panel', 'tooltip-css' ]
				},
				'tooltip-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'tooltip.css',
					type: 'css'
				},

				/*
				* TreeData
				*/
				'tree-data': {
					fullpath: PATH_JAVASCRIPT + 'tree-data.js',
					requires: [ 'aui-base' ]
				},

				/*
				* TreeNode
				*/
				'tree-node': {
					fullpath: PATH_JAVASCRIPT + 'tree-node.js',
					requires: [ 'tree-data', 'io', 'json', 'tree-css' ]
				},

				/*
				* TreeView
				*/
				'tree-view': {
					fullpath: PATH_JAVASCRIPT + 'tree-view.js',
					requires: [ 'tree-node', 'dd', 'tree-css' ]
				},

				'tree-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'tree.css',
					type: 'css'
				},

				/*
				* TextboxList
				*/
				'textboxlist': {
					fullpath: PATH_JAVASCRIPT + 'textboxlist.js',
					requires: [ 'anim-node-plugin', 'aui-base', 'autocomplete', 'node-focusmanager', 'textboxlist-css' ]
				},

				'textboxlist-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'textboxlist.css',
					type: 'css'
				},

				/*
				* Dialog
				*/
				'dialog': {
					fullpath: PATH_JAVASCRIPT + 'dialog.js',
					requires: [ 'plugin', 'panel', 'dd-constrain', 'aui-base', 'tool-item', 'overlay-manager', 'overlay-mask', 'io-stdmod', 'dialog-css' ]
				},
				'dialog-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'dialog.css',
					type: 'css'
				},

				/*
				* Component Overlay
				*/
				'component-overlay': {
					fullpath: PATH_JAVASCRIPT + 'component-overlay.js',
					requires: [ 'component', 'widget-position', 'widget-stack', 'widget-position-ext', 'widget-stdmod' ]
				},

				/*
				* Tabs
				*/
				'tabs': {
					fullpath: PATH_JAVASCRIPT + 'tabs.js',
					requires: ['component', 'state-interaction', 'tabs-css']
				},
				'tabs-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'tabs.css',
					type: 'css'
				},

				/*
				* Resize
				*/
				'resize': {
					fullpath: PATH_JAVASCRIPT + 'resize.js',
					requires: [ 'aui-base', 'dd', 'resize-css' ]
				},
				'resize-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'resize.css',
					type: 'css'
				},
				'resize-plugin': {
					fullpath: PATH_JAVASCRIPT + 'resize.js',
					requires: [ 'resize' ]
				},

				/*
				* Sortable
				*/
				'sortable': {
					fullpath: PATH_JAVASCRIPT + 'sortable.js',
					requires: [ 'aui-base', 'dd', 'sortable-css' ]
				},
				'sortable-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'sortable.css',
					type: 'css'
				},

				/*
				* LiveSearch
				*/
				'live-search': {
					fullpath: PATH_JAVASCRIPT + 'live-search.js',
					requires: [ 'aui-base' ]
				},

				/*
				* Nested list
				*/
				'nested-list': {
					fullpath: PATH_JAVASCRIPT + 'nested-list.js',
					requires: [ 'aui-base', 'dd' ]
				},

				/*
				* ContextOverlay
				*/
				'context-overlay': {
					fullpath: PATH_JAVASCRIPT + 'context-overlay.js',
					requires: [ 'aui-base', 'component-overlay', 'overlay-manager', 'delayed-task' ]
				},

				/*
				* OverlayManager
				*/
				'overlay-manager': {
					fullpath: PATH_JAVASCRIPT + 'overlay-manager.js',
					requires: [ 'aui-base', 'component', 'component-overlay', 'overlay', 'plugin' ]
				},

				/*
				* OverlayMask
				*/
				'overlay-mask': {
					fullpath: PATH_JAVASCRIPT + 'overlay-mask.js',
					requires: [ 'aui-base', 'component-overlay', 'event-resize' ]
				},

				/*
				* Module
				*/
				'panel': {
					fullpath: PATH_JAVASCRIPT + 'panel.js',
					requires: [ 'component', 'widget-stdmod', 'tool-set', 'panel-css' ]
				},
				'panel-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'panel.css',
					type: 'css'
				},

				/*
				* Form
				*/
				'form': {
					fullpath: PATH_JAVASCRIPT + 'form.js',
					requires: [ 'aui-base', 'data-set', 'io-form', 'field' ]
				},

				/*
				* Fieldset
				*/
				'fieldset': {
					fullpath: PATH_JAVASCRIPT + 'fieldset.js',
					requires: [ 'panel' ]
				},

				/*
				* Field
				*/
				'field': {
					fullpath: PATH_JAVASCRIPT + 'field.js',
					requires: [ 'substitute' ]
				},

				/*
				* Textfield
				*/
				'textfield': {
					fullpath: PATH_JAVASCRIPT + 'textfield.js',
					requires: [ 'field' ]
				},

				/*
				* Textarea
				*/
				'textarea': {
					fullpath: PATH_JAVASCRIPT + 'textarea.js',
					requires: [ 'textfield', 'textarea-css' ]
				},
				'textarea-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'textarea.css',
					type: 'css'
				},

				/*
				* Combobox
				*/
				'combobox': {
					fullpath: PATH_JAVASCRIPT + 'combobox.js',
					requires: [ 'textarea', 'tool-set', 'combobox-css' ]
				},
				'combobox-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'combobox.css',
					type: 'css'
				},

				/*
				* Component
				*/
				'component': {
					fullpath: PATH_JAVASCRIPT + 'component.js',
					requires: [ 'widget' ]
				},

				/*
				* StdModIOPlugin
				*/
				'io-stdmod': {
					fullpath: PATH_JAVASCRIPT + 'io-stdmod.js',
					requires: [ 'aui-base', 'component-overlay', 'parse-content', 'io', 'plugin' ]
				},

				/*
				* Input Event Handler
				*/
				'input-handler': {
					fullpath: PATH_JAVASCRIPT + 'input-handler.js'
				},

				/*
				* Image Viewer
				*/
				'image-viewer': {
					fullpath: PATH_JAVASCRIPT + 'image-viewer.js',
					requires: [ 'aui-base', 'anim', 'overlay-mask', 'substitute', 'image-viewer-css' ]
				},

				'image-viewer-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'image-viewer.css',
					type: 'css'
				},

				/*
				* ImageGallery
				*/
				'image-gallery': {
					fullpath: PATH_JAVASCRIPT + 'image-gallery.js',
					requires: [ 'image-viewer', 'paginator', 'tool-set', 'image-gallery-css' ]
				},

				'image-gallery-css': {
					ext: false,
					fullpath: PATH_THEME_ROOT + 'image-gallery.css',
					type: 'css'
				},

				/*
				* State Interaction plugin
				*/
				'state-interaction': {
					fullpath: PATH_JAVASCRIPT + 'state-interaction.js',
					requires: [ 'aui-base', 'plugin' ]
				}
			},

			paths: {
				images: PATH_THEME_IMAGES,
				javascript: PATH_JAVASCRIPT,
				theme: PATH_THEME_ROOT
			}
		}
	}
})();;(function() {

	var toString = Object.prototype.toString;

	var isFunction = function(obj) {
		return toString.call(obj) === "[object Function]";
	};

	// Based on jQuery.extend
	var apply = function() {
		var target = arguments[0] || {},
			i = 1,
			length = arguments.length,
			deep = false,
			options;

		if (typeof target === 'boolean') {
			deep = target;
			target = arguments[1] || {};
			i = 2;
		}

		if (typeof target !== 'object' && !isFunction(target)) {
			target = {};
		}

		if (length == i) {
			target = this;
			--i;
		}

		for (; i < length; i++) {
			if ((options = arguments[i]) != null) {
				for (var name in options) {
					var src = target[name],
						copy = options[name];

					if (target === copy) {
						continue;
					}

					if (deep && copy && typeof copy === 'object' && !copy.nodeType) {
						target[name] = apply(
							deep,
							src || (copy.length != null ? [] : {}),
							copy
						);
					}

					else if (copy !== undefined) {
						target[name] = copy;
					}

				}
			}
		}

		return target;
	};

	/*
	 * Alloy JavaScript Library v0.1a
	 * http://alloyui.com/
	 *
	 * Copyright (c) 2009 Liferay Inc.
	 * Licensed under the MIT license.
	 * http://alloyui.com/License
	 *
	 * Nate Cavanaugh (nate.cavanaugh@liferay.com)
	 * Eduardo Lundgren (eduardo.lundgren@liferay.com)
	 *
	 * Date: @DATE
	 * Revision: @REVISION
	 */

	window.AUI = window.AUI || {};

	var defaults = AUI.defaults || {};
	var defaultModules = defaults.defaultModules || [];

	apply(
		YUI.prototype,
		{
			apply: apply,
			ready: function() {
				var instance = this;

				var slice = Array.prototype.slice;
				var args = slice.call(arguments, 0), index = args.length - 1;

				var fn = args[index];

				var modules = slice.call(arguments, 0, index);

				modules.push('event');

				modules.push(
					function(instance) {
						var args = arguments;

						instance.on(
							'domready',
							function() {
								fn.apply(this, args);
							}
						);
					}
				);

				instance.use.apply(instance, modules);
			},

			fromQueryString: function(str, allowMultipleValues) {
				var instance = this;

				var obj = {};
				var params = str.split('&');
				var name, value, param;

				var length = params.length;

				for (var i = 0; i < length; i++) {
					param = params[i];

					param = param.split('=');

					name = decodeURIComponent(param[0]);
					value = decodeURIComponent(param[1]);

					if (allowMultipleValues) {
						obj[name] = [].concat(obj[name]).concat(value);
					}
					else {
						obj[name] = value;
					}
				}

				return obj;
			},

			toQueryString: function(obj) {
				var instance = this;

				var Lang = instance.Lang;
				var isArray = Lang.isArray;
				var isFunction = Lang.isFunction;

				var buffer = [];
				var isNodeList = false;

				if (isArray(obj) || (isNodeList = (instance.NodeList && (obj instanceof instance.NodeList)))) {
					if (isNodeList) {
						obj = instance.NodeList.getDOMNodes(obj);
					}

					var length = obj.length;

					for (var i=0; i < length; i++) {
						var el = obj[i];

						buffer.push(encodeURIComponent(el.name) + '=' + encodeURIComponent(el.value));
					}
				}
				else {
					for (var i in obj){
						var value = obj[i];

						if (isArray(value)) {
							var vlength = value.length;

							for (var j = 0; j < vlength; j++) {
								buffer.push(encodeURIComponent(i) + '=' + encodeURIComponent(value[j]));
							}
						}
						else {
							if (isFunction(value)) {
								value = value();
							}

							buffer.push(encodeURIComponent(i) + '=' + encodeURIComponent(value));
						}
					}
				}

				return buffer.join('&').replace(/%20/g, '+');
			}
		}
	);

	var ALLOY = YUI(apply({}, defaults));

	ALLOY.Env._guidp = ['aui', ALLOY.version, ALLOY.Env._yidx, new Date().getTime()].join('-').replace(/\./g, '-');

	var originalConfig = ALLOY.config;

	defaultModules.push(
		function(A, result) {
			if (!result.success) {
				throw result.msg;
			}
		}
	);

	ALLOY.use.apply(ALLOY, defaultModules);

	ALLOY.config = ALLOY.merge(originalConfig, AUI.defaults);

	AUI = function(o) {
		var instance = this;

		if (o || instance instanceof AUI) {
			return YUI(ALLOY.merge(ALLOY.config, o));
		}

		return ALLOY;
	};

	apply(
		AUI,
		YUI,
		{
			__version: '0.1a',

			apply: apply,

			defaults: defaults,

			setDefaults: function(defaults) {
				var instance = this;

				ALLOY.config = ALLOY.merge(AUI.defaults, defaults);
			}
		}
	);

	/*
	* AUI support constants
	*/
	AUI.support = {
		scriptEval: false
	};

	var checkScriptEvalSupport = function() {
		var root = document.documentElement;
		var script = document.createElement("script");

		var TYPE = 'text/javascript',
			TPL_EVAL_SCRIPT_TRUE = 'AUI.support.scriptEval = true;';

		script.type = TYPE;

		try {
			script.appendChild(document.createTextNode(TPL_EVAL_SCRIPT_TRUE));
			root.insertBefore(script, root.firstChild);
			root.removeChild(script);
		}
		catch(e) {
		}
	};

	checkScriptEvalSupport();

	/*
		UA extensions
	*/

	var UA = ALLOY.UA;

	var p = navigator.platform;
	var u = navigator.userAgent;
	var b = /(Firefox|Opera|Safari|KDE|iCab|Flock|IE)/.exec(u);
	var os = /(Win|Mac|Linux|iPhone|Sun|Solaris)/.exec(p);
	var versionDefaults = [0,0];

	b = (!b || !b.length) ? (/(Mozilla)/.exec(u) || ['']) : b;
	os = (!os || !os.length) ? [''] : os;

	apply(
		UA,
		{
			gecko: /Gecko/.test(u) && !/like Gecko/.test(u),
			webkit: /WebKit/.test(u),

			aol: /America Online Browser/.test(u),
			camino: /Camino/.test(u),
			firefox: /Firefox/.test(u),
			flock: /Flock/.test(u),
			icab: /iCab/.test(u),
			konqueror: /KDE/.test(u),
			mozilla: /mozilla/.test(u),
			ie: /MSIE/.test(u),
			netscape: /Netscape/.test(u),
			opera: /Opera/.test(u),
			safari: /Safari/.test(u),
			browser: b[0].toLowerCase(),

			win: /Win/.test(p),
			mac: /Mac/.test(p),
			linux: /Linux/.test(p),
			iphone: /iPhone/.test(p),
			sun: /Solaris|SunOS/.test(p),
			os: os[0].toLowerCase(),

			platform: p,
			agent: u
		}
	);

	UA.version = {
		string: ''
	};

	if (UA.ie) {
		UA.version.string = (/MSIE ([^;]+)/.exec(u) || versionDefaults)[1];
	}
	else if (UA.firefox) {
		UA.version.string = (/Firefox\/(.+)/.exec(u) || versionDefaults)[1];
	}
	else if (UA.safari) {
		UA.version.string = (/Version\/([^\s]+)/.exec(u) || versionDefaults)[1];
	}
	else if (UA.opera) {
		UA.version.string = (/Opera\/([^\s]+)/.exec(u) || versionDefaults)[1];
	}

	UA.version.number = parseFloat(UA.version.string) || versionDefaults[0];
	UA.version.major = (/([^\.]+)/.exec(UA.version.string) || versionDefaults)[1];

	UA[UA.browser + UA.version.major] = true;

	UA.renderer = '';

	if (UA.ie) {
		UA.renderer = 'trident';
	}
	else if (UA.gecko) {
		UA.renderer = 'gecko';
	}
	else if (UA.webkit) {
		UA.renderer = 'webkit';
	}
	else if (UA.opera) {
		UA.renderer = 'presto';
	}

	/*
		Browser selectors
	*/

	var selectors = [
		UA.renderer,
		UA.browser,
		UA.browser + UA.version.major,
		UA.os,
		'js'
	];

	if (UA.os == 'macintosh') {
		selectors.push('mac');
	}
	else if (UA.os == 'windows') {
		selectors.push('win');
	}

	if (UA.mobile) {
		selectors.push('mobile');
	}

	if (UA.secure) {
		selectors.push('secure');
	}

	UA.selectors = selectors.join(' ');

	document.getElementsByTagName('html')[0].className += ' ' + UA.selectors;
})();AUI.add('autocomplete', function(A) {

var Lang = A.Lang,
	isArray = Lang.isArray,
	isString = Lang.isString,
	isNull = Lang.isNull,
	isFunction = Lang.isFunction,

	getClassName = A.ClassNameManager.getClassName,

	ALERT = 'alert',
	CIRCLE = 'circle',
	CONTENT = 'content',
	HELPER = 'helper',
	ICON = 'icon',
	ITEM = 'item',
	LIST = 'list',
	LOADING = 'loading',
	NAME = 'autocomplete',
	NO = 'no',
	RESET = 'reset',
	RESULTS = 'results',
	S = 's',
	SELECTED = 'selected',

	ICON_DEFAULT = 'circle-triangle-b',
	ICON_ERROR = ALERT,
	ICON_LOADING = LOADING,

	CSS_HIGLIGHT = getClassName(NAME, SELECTED),
	CSS_LIST_ITEM = getClassName(NAME, LIST, ITEM),
	CSS_NO_RESULTS = getClassName(NAME, NO, RESULTS),
	CSS_RESULTS_LIST = getClassName(HELPER, RESET),
	CSS_RESULTS_OVERLAY = getClassName(NAME, RESULTS),
	CSS_RESULTS_OVERLAY_CONTENT = getClassName(NAME, RESULTS, CONTENT),

	KEY_BACKSPACE = 8,
	KEY_TAB = 9,
	KEY_ENTER = 13,
	KEY_SHIFT = 16,
	KEY_CTRL = 17,
	KEY_ALT = 18,
	KEY_CAPS_LOCK = 20,
	KEY_ESC = 27,
	KEY_PAGEUP = 33,
	KEY_END = 35,
	KEY_HOME = 36,
	KEY_UP = 38,
	KEY_DOWN = 40,
	KEY_RIGHT = 39,
	KEY_LEFT = 37,
	KEY_PRINT_SCREEN = 44,
	KEY_INSERT = 44,
	KEY_KOREAN_IME = 229,

	OVERLAY_ALIGN = {
		node: null,
		points: ['tl', 'bl']
	},

	BOUNDING_BOX = 'boundingBox',
	CONTENT_BOX = 'contentBox';

	var AutoComplete = function() {
		AutoComplete.superclass.constructor.apply(this, arguments);
	};

	AutoComplete.NAME = NAME;

	AutoComplete.ATTRS = {

		allowBrowserAutocomplete: {
			value: true
		},

		alwaysShowContainer: {
			value: false
		},

		autoHighlight: {
			value: true
		},

		applyLocalFilter: {
			value: null
		},

		button: {
			value: true
		},

		dataSource: {
			value: null
		},

		dataSourceType: {
			value: null
		},

		delimChar: {
			value: null,
			setter: function(value) {
				if (isString(value) && (value.length > 0)) {
					value = [value];
				}
				else if (!isArray(value)) {
					value = A.Attribute.INVALID_VALUE;
				}

				return value;
			}
		},

		forceSelection: {
			value: false
		},

		input: {
			value: null
		},

		matchKey: {
			value: 0
		},

		maxResultsDisplayed: {
			value: 10
		},

		minQueryLength: {
			value: 1
		},

		queryDelay: {
			value: 0.2,
			getter: function(value) {
				return value * 1000;
			}
		},

		queryInterval: {
			value: 0.5,
			getter: function(value) {
				var instance = this;

				return value * 1000;
			}
		},

		queryMatchCase: {
			value: false
		},

		queryMatchContains: {
			value: false
		},

		queryQuestionMark: {
			value: true
		},

		resultTypeList: {
			value: true
		},

		schema: {
			value: null
		},

		schemaType: {
			value: '',
			validator: isString
		},

		suppressInputUpdate: {
			value: false
		},

		typeAhead: {
			value: false
		},

		typeAheadDelay: {
			value: 0.2,
			getter: function(value) {
				return value * 1000;
			}
		},

		uniqueName: {
			value: null
		}
	};

	A.extend(
		AutoComplete,
		A.Component,
		{
			initializer: function(config) {
				var instance = this;

				instance._overlayAlign = A.mix({}, OVERLAY_ALIGN);

				instance._createDataSource();
			},

			renderUI: function() {
				var instance = this;

				instance._renderInput();
				instance._renderOverlay();
			},

			bindUI: function() {
				var instance = this;

				var button = instance.button;
				var inputNode = instance.inputNode;

				instance.dataSource.on('request', A.bind(button.set, button, ICON, ICON_LOADING));

				inputNode.on('blur', instance._onTextboxBlur, instance);
				inputNode.on('focus', instance._onTextboxFocus, instance);
				inputNode.on('keydown', instance._onTextboxKeyDown, instance);
				inputNode.on('keypress', instance._onTextboxKeyPress, instance);
				inputNode.on('keyup', instance._onTextboxKeyUp, instance);

				var overlayBoundingBox = instance.overlay.get(BOUNDING_BOX);

				overlayBoundingBox.on('click', instance._onContainerClick, instance);
				overlayBoundingBox.on('mouseout', instance._onContainerMouseout, instance);
				overlayBoundingBox.on('mouseover', instance._onContainerMouseover, instance);
				overlayBoundingBox.on('scroll', instance._onContainerScroll, instance);

				instance.publish('containerCollapse');
				instance.publish('containerExpand');
				instance.publish('containerPopulate');

				instance.publish('dataError');
				instance.publish('dataRequest');
				instance.publish('dataReturn');

				instance.publish('itemArrowFrom');
				instance.publish('itemArrowTo');
				instance.publish('itemMouseOut');
				instance.publish('itemMouseOver');
				instance.publish('itemSelect');

				instance.publish('selectionEnforce');

				instance.publish('textboxBlur');
				instance.publish('textboxChange');
				instance.publish('textboxFocus');
				instance.publish('textboxKey');

				instance.publish('typeAhead');

				instance.publish('unmatchedItemSelect');

				instance.overlay.on('visibleChange', instance._realignContainer, instance);
			},

			syncUI: function() {
				var instance = this;

				instance.inputNode.setAttribute('autocomplete', 'off');
			},

			doBeforeExpandContainer: function() {
				return true;
			},

			doBeforeLoadData: function(event) {
				return true;
			},

			filterResults: function(event) {
				var instance = this;

				var callback = event.callback;
				var query = event.request;
				var response = event.response;

				if (callback && callback.argument && callback.argument.query) {
					query = callback.argument.query;
				}

				if (query) {
					var dataSource = instance.dataSource;
					var allResults = response.results;
					var filteredResults = [];
					var matchFound = false;
					var matchKey = instance.get('matchKey');
					var matchCase = instance.get('queryMatchCase');
					var matchContains = instance.get('queryMatchContains');
					var showAll = (query == '*');

					var fields = instance.get('schema.resultFields');

					for (var i = allResults.length - 1; i >= 0; i--){
						var result = allResults[i];

						var strResult = null;

						if (isString(result)) {
							strResult = result;
						}
						else if (isArray(result)) {
							strResult = result[0];
						}
						else if (fields) {
							strResult = result[matchKey || fields[0]];
						}

						if (isString(strResult)) {
							var keyIndex = -1;

							if (matchCase) {
								keyIndex = strResult.indexOf(decodeURIComponent(query));
							}
							else {
								keyIndex = strResult.toLowerCase().indexOf(decodeURIComponent(query).toLowerCase());
							}

							if (
								(showAll) ||
								(!matchContains && (keyIndex === 0)) ||
								(matchContains && (keyIndex > -1)
								)
							) {
								filteredResults.unshift(result);
							}
						}
					}

					response.results = filteredResults;
				}

				return response;
			},

			formatResult: function(result, request, resultMatch) {
				return resultMatch || '';
			},

			generateRequest: function(query) {
				return query;
			},

			handleResponse: function(event) {
				var instance = this;

				instance._populateList(event);

				var iconClass = ICON_DEFAULT;

				if (event.error) {
					iconClass = ICON_ERROR;
				}

				instance.button.set(ICON, iconClass);
			},

			preparseRawResponse: function(event) {
			},

			sendQuery: function(query) {
				var instance = this;

				instance.set('focused', null);

				var newQuery = query;

				if (instance.get('delimChar')) {
					query = instance.inputNode.get('value') + query;
				}

				instance._sendQuery(newQuery);
			},

			_clearInterval: function() {
				var instance = this;

				if (instance._queryIntervalId) {
					clearInterval(instance._queryIntervalId);

					instance._queryIntervalId = null;
				}
			},

			_clearSelection: function() {
				var instance = this;

				var delimChar = instance.get('delimChar');
				var extraction = {
					previous: '',
					query: instance.inputNode.get('value')
				};

				if (delimChar) {
					extraction = instance._extractQuery(instance.inputNode.get('value'));
				}

				instance.fire('selectionEnforce', extraction.query);
			},

			_createDataSource: function() {
				var instance = this;

				var dataSource = instance.get('dataSource');
				var data = dataSource;

				var dataSourceType = instance.get('dataSourceType');

				if (!(dataSource instanceof A.DataSource.Local)) {
					if (!dataSourceType) {
						dataSourceType = 'Local';

						if (isFunction(data)) {
							dataSourceType = 'Function'
						}
						else if (isString(data)) {
							dataSourceType = 'IO'
						}
					}

					dataSource = new A.DataSource[dataSourceType](
						{
							source: data
						}
					);
				}

				dataSource.on('error', instance.handleResponse, instance);
				dataSource.after('response', instance.handleResponse, instance);

				dataSourceType = dataSource.name;

				if (dataSourceType == 'dataSourceLocal') {
					instance.set('applyLocalFilter', true);
				}

				instance.set('dataSource', dataSource);
				instance.set('dataSource', dataSourceType);

				instance.dataSource = dataSource;

				var schema = instance.get('schema');

				if (schema) {
					if (schema.fn) {
						instance.dataSource.plug(schema);
					}
					else {
						var schemaType = instance.get('schemaType');

						var schemaTypes = {
							array: A.Plugin.DataSourceArraySchema,
							json: A.Plugin.DataSourceJSONSchema,
							text: A.Plugin.DataSourceTextSchema,
							xml: A.Plugin.DataSourceXMLSchema
						};

						schemaType = schemaType.toLowerCase() || 'array';

						instance.dataSource.plug(
							{
								fn: schemaTypes[schemaType],
								cfg: {
									schema: schema
								}
							}
						);
					}
				}

				instance.set('schema', schema);
			},

			_enableIntervalDetection: function() {
				var instance = this;

				var queryInterval = instance.get('queryInterval');

				if (!instance._queryIntervalId && queryInterval) {
					instance._queryInterval = setInterval(A.bind(instance._onInterval, instance), queryInterval);
				}
			},

			_extractQuery: function(query) {
				var instance = this;

				var delimChar = instance.get('delimChar');
				var delimIndex = -1;
				var i = delimChar.length - 1;

				var newIndex, queryStart, previous;

				for (; i >= 0; i--) {
					newIndex = query.lastIndexOf(delimChar[i]);

					if (newIndex > delimIndex) {
						delimIndex = newIndex;
					}
				}

				if (delimChar[i] == ' ') {
					for (var j = delimChar.length - 1; j >= 0; j--){
						if (query[delimIndex - 1] == delimChar[j]) {
							delimIndex--;

							break;
						}
					}
				}

				if (delimIndex > -1) {
					queryStart = delimIndex + 1;

					while (query.charAt(queryStart) == ' ') {
						queryStart += 1;
					}

					previous = query.substring(0, queryStart);

					query = query.substring(queryStart);
				}
				else {
					previous = '';
				}

				return {
					previous: previous,
					query: query
				};
			},

			_focus: function() {
				var instance = this;

				setTimeout(
					function() {
						instance.inputNode.focus();
					},
					0
				);
			},

			_isIgnoreKey: function(keyCode) {
				var instance = this;

				if (
					(keyCode == KEY_TAB) ||
					(keyCode == KEY_ENTER) ||
					(keyCode == KEY_SHIFT) ||
					(keyCode == KEY_CTRL) ||
					(keyCode >= KEY_ALT && keyCode <= KEY_CAPS_LOCK) ||
					(keyCode == KEY_ESC) ||
					(keyCode >= KEY_PAGEUP && keyCode <= KEY_END) ||
					(keyCode >= KEY_HOME && keyCode <= KEY_DOWN) ||
					(keyCode >= KEY_PRINT_SCREEN && keyCode <= KEY_INSERT) ||
					(keyCode == KEY_KOREAN_IME)
				) {
					return true;
				}

				return false;
			},

			_jumpSelection: function() {
				var instance = this;

				if (instance._elCurListItem) {
					instance._selectItem(instance._elCurListItem);
				}
				else {
					instance._toggleContainer(false);
				}
			},

			_moveSelection: function(keyCode) {
				var instance = this;

				if (instance.overlay.get('visible')) {
					var elCurListItem = instance._elCurListItem;
					var curItemIndex = -1;

					if (elCurListItem) {
						curItemIndex = Number(elCurListItem.getAttribute('data-listItemIndex'));
					}

					var newItemIndex = curItemIndex - 1;

					if (keyCode == KEY_DOWN) {
						newItemIndex = curItemIndex + 1;
					}

					if (newItemIndex == -1) {
						newItemIndex = instance._displayedItems - 1;
					}

					if (newItemIndex >= instance._displayedItems) {
						newItemIndex = 0;
					}

					if (newItemIndex < -2) {
						return;
					}

					if (elCurListItem) {
						instance._toggleHighlight(elCurListItem, 'from');

						instance.fire('itemArrowFrom', elCurListItem);
					}

					if (newItemIndex == -1) {
						if (instance.get('delimChar')) {
							instance.inputNode.set('value', instance._pastSelections + instance._currentQuery);
						}
						else {
							instance.inputNode.set('value', instance._currentQuery);
						}

						return;
					}

					if (newItemIndex == -2) {
						instance._toggleContainer(false);

						return;
					}

					var elNewListItem = instance.resultList.get('childNodes').item(newItemIndex);

					var elContent = instance.overlay.get(CONTENT_BOX);

					var contentOverflow = elContent.getStyle('overflow');
					var contentOverflowY = elContent.getStyle('overflowY');

					var scrollOn = (contentOverflow == 'auto') || (contentOverflow == 'scroll') || (contentOverflowY == 'auto') || (contentOverflowY == 'scroll');

					if (scrollOn &&
						(newItemIndex > -1) &&
						(newItemIndex < instance._displayedItems)) {

						var newScrollTop = -1;
						var liTop = elNewListItem.get('offsetTop');
						var liBottom = liTop + elNewListItem.get('offsetHeight');

						var contentHeight = elContent.get('offsetHeight');
						var contentScrollTop = elContent.get('scrollTop');
						var contentBottom = contentHeight + contentScrollTop;

						if (keyCode == KEY_DOWN) {
							if (liBottom > contentBottom) {
								newScrollTop = (liBottom - contentHeight);
							}
							else if (liBottom < contentScrollTop) {
								newScrollTop = liTop;
							}
						}
						else {
							if (liTop < contentHeight) {
								newScrollTop = liTop;
							}
							else if (liTop > contentBottom) {
								newScrollTop = (liBottom - contentHeight);
							}
						}

						if (newScrollTop > -1) {
							elContent.set('scrollTop', newScrollTop);
						}
					}

					instance._toggleHighlight(elNewListItem, 'to');

					instance.fire('itemArrowTo', elNewListItem);

					if (instance.get('typeAhead')) {
						instance._updateValue(elNewListItem);
					}
				}
			},

			_onButtonMouseDown: function(event) {
				var instance = this;

				event.halt();

				instance._focus();

				instance._sendQuery(instance.inputNode.get('value') + '*');

			},

			_onContainerClick: function(event) {
				var instance = this;

				var target = event.target;
				var tagName = target.get('nodeName').toLowerCase();

				event.halt();

				while (target && (tagName != 'table')) {
					switch (tagName) {
						case 'body':
						return;

						case 'li':
							instance._toggleHighlight(target, 'to');
							instance._selectItem(target);
						return;

						default:
						break;
					}

					target = target.get('parentNode');

					if (target) {
						tagName.get('nodeName').toLowerCase();
					}
				}
			},

			_onContainerMouseout: function(event) {
				var instance = this;

				var target = event.target;
				var tagName = target.get('nodeName').toLowerCase();

				while (target && (tagName != 'table')) {
					switch (tagName) {
						case 'body':
						return;

						case 'li':
							instance._toggleHighlight(target, 'from');
							instance.fire('itemMouseOut', target);
						break;

						case 'ul':
							instance._toggleHighlight(instance._elCurListItem, 'to');
						break;

						case 'div':
							if (target.hasClass(CSS_RESULTS_OVERLAY)) {
								instance._overContainer = false;

								return;
							}
						break;

						default:
						break;
					}

					target = target.get('parentNode');

					if (target) {
						tagName = target.get('nodeName').toLowerCase();
					}
				}
			},

			_onContainerMouseover: function(event) {
				var instance = this;

				var target = event.target;
				var tagName = target.get('nodeName').toLowerCase();

				while (target && (tagName != 'table')) {
					switch (tagName) {
						case 'body':
						return;

						case 'li':
							instance._toggleHighlight(target, 'to');
							instance.fire('itemMouseOut', target);
						break;

						case 'div':
							if (target.hasClass(CSS_RESULTS_OVERLAY)) {
								instance._overContainer = true;
								return;
							}
						break;

						default:
						break;
					}

					target = target.get('parentNode');

					if (target) {
						tagName = target.get('nodeName').toLowerCase();
					}
				}
			},

			_onContainerScroll: function(event) {
				var instance = this;

				instance._focus();
			},

			_onInterval: function() {
				var instance = this;

				var curValue = instance.inputNode.get('value');
				var lastValue = instance._lastValue;

				if (curValue != lastValue) {
					instance._lastValue = curValue;

					instance._sendQuery(curValue);
				}
			},

			_onTextboxBlur: function(event) {
				var instance = this;

				if (!instance._overContainer || (instance._keyCode == KEY_TAB)) {
					if (!instance._itemSelected) {
						var elMatchListItem = instance._textMatchesOption();

						var overlayVisible = instance.overlay.get('visible');

						if (!overlayVisible || (overlayVisible && isNull(elMatchListItem))) {
							if (instance.get('forceSelection')) {
								instance._clearSelection();
							}
							else {
								instance.fire('unmatchedItemSelect', instance._currentQuery);
							}
						}
						else {
							if (instance.get('forceSelection')) {
								instance._selectItem(elMatchListItem);
							}
						}
					}

					instance._clearInterval();

					instance.blur();

					if (instance._initInputValue !== instance.inputNode.get('value')) {
						instance.fire('textboxChange');
					}

					instance.fire('textboxBlur');

					instance._toggleContainer(false);
				}
				else {
					instance._focus();
				}
			},

			_onTextboxFocus: function(event) {
				var instance = this;

				if (!instance.get('focused')) {
					instance.inputNode.setAttribute('autocomplete', 'off');
					instance.focus();
					instance._initInputValue = instance.inputNode.get('value');

					instance.fire('textboxFocus');
				}
			},

			_onTextboxKeyDown: function(event) {
				var instance = this;

				var keyCode = event.keyCode;

				if (instance._typeAheadDelayId != -1) {
					clearTimeout(instance._typeAheadDelayId);
				}

				switch (keyCode) {
					case KEY_TAB:
						if (instance._elCurListItem) {
							if (instance.get('delimChar') && instance._keyCode != keyCode) {
								if (instance.overlay.get('visible')) {
									event.halt();
								}
							}

							instance._selectItem(instance._elCurListItem);
						}
						else {
							instance._toggleContainer(false);
						}
					break;

					case KEY_ENTER:
						if (instance._elCurListItem) {
							if (instance._keyCode != keyCode) {
								if (instance.overlay.get('visible')) {
									event.halt();
								}
							}

							instance._selectItem(instance._elCurListItem);
						}
						else {
							instance._toggleContainer(false);
						}
					break;

					case KEY_ESC:
						instance._toggleContainer(false);
					return;

					case KEY_UP:
						if (instance.overlay.get('visible')) {
							event.halt();

							instance._moveSelection(keyCode);
						}
					break;

					case KEY_RIGHT:
						instance._jumpSelection();
					break;

					case KEY_DOWN:
						if (instance.overlay.get('visible')) {
							event.halt();

							instance._moveSelection(keyCode);
						}
					break;

					default:
						instance._itemSelected = false;
						instance._toggleHighlight(instance._elCurListItem, 'from');

						instance.fire('textboxKey', keyCode);
					break;
				}

				if (keyCode == KEY_ALT) {
					instance._enableIntervalDetection();
				}

				instance._keyCode = keyCode;
			},

			_onTextboxKeyPress: function(event) {
				var instance = this;

				var keyCode = event.keyCode;

				switch (keyCode) {
					case KEY_TAB:
						if (instance.overlay.get('visible')) {
							if (instance.get('delimChar')) {
								event.halt();
							}

							if (instance._elCurListItem) {
								instance._selectItem(instance._elCurListItem);
							}
							else {
								instance._toggleContainer(false);
							}
						}
					break;

					case 13:
						if (instance.overlay.get('visible')) {
							event.halt();

							if (instance._elCurListItem) {
								instance._selectItem(instance._elCurListItem);
							}
							else {
								instance._toggleContainer(false);
							}
						}
					break;

					default:
					break;
				}

				if (keyCode == KEY_KOREAN_IME) {
					instance._enableIntervalDetection();
				}
			},

			_onTextboxKeyUp: function(event) {
				var instance = this;

				var input = instance.inputNode;

				var value = input.get('value');
				var keyCode = event.keyCode;

				if (instance._isIgnoreKey(keyCode)) {
					return;
				}

				if (instance._delayId != -1) {
					clearTimeout(instance._delayId);
				}

				instance._delayId = setTimeout(
					function() {
						instance._sendQuery(value);
					},
					instance.get('queryDelay')
				);
			},

			_populateList: function(event) {
				var instance = this;

				if (instance._typeAheadDelayId != -1) {
					clearTimeout(instance._typeAheadDelayId);
				}

				var query = event.request;
				var response = event.response;
				var callback = event.callback;
				var showAll = (query == '*');

				if (callback && callback.argument && callback.argument.query) {
					event.request = query = callback.argument.query;
				}

				var ok = instance.doBeforeLoadData(event);

				if (ok && !event.error) {
					instance.fire('dataReturn', event);

					var focused = instance.get('focused');

					if (showAll || focused || focused === null) {
						var currentQuery = decodeURIComponent(query);

						instance._currentQuery = currentQuery;
						instance._itemSelected = false;

						var allResults = event.response.results;
						var itemsToShow = Math.min(allResults.length, instance.get('maxResultsDisplayed'));
						var fields = instance.get('schema.resultFields');
						var matchKey = instance.get('matchKey');

						if (!matchKey && fields) {
							matchKey = fields[0];
						}
						else {
							matchKey = matchKey || 0;
						}

						if (itemsToShow > 0) {
							var allListItemEls = instance.resultList.get('childNodes');

							allListItemEls.each(
								function(node, i, nodeList) {
									if (i < itemsToShow) {
										var result = allResults[i];

										var resultMatch = '';

										if (isString(result)) {
											resultMatch = result;
										}
										else if (isArray(result)) {
											resultMatch = result[0]
										}
										else {
											resultMatch = result[matchKey];
										}

										node._resultMatch = resultMatch;

										node._resultData = result;
										node.html(instance.formatResult(result, currentQuery, resultMatch));

										node.removeClass('aui-helper-hidden');
									}
									else {
										node.addClass('aui-helper-hidden');
									}
								}
							);

							instance._displayedItems = itemsToShow;

							instance.fire('containerPopulate', query, allResults);

							if (query != '*' && instance.get('autoHighlight')) {
								var elFirstListItem = instance.resultList.get('firstChild');

								instance._toggleHighlight(elFirstListItem, 'to');
								instance.fire('itemArrowTo', elFirstListItem);

								instance._typeAhead(elFirstListItem, query);
							}
							else {
								instance._toggleHighlight(instance._elCurListItem, 'from');
							}

							ok = instance.doBeforeExpandContainer(query, allResults);

							instance._toggleContainer(ok);
						}
						else {
							instance._toggleContainer(false);
						}

						return;
					}

				}
				else {
					instance.fire('dataError', query);
				}
			},

			_realignContainer: function(event) {
				var instance = this;

				var overlayAlign = instance._overlayAlign;

				instance.overlay._uiSetAlign(overlayAlign.node, overlayAlign.points);
			},

			_renderInput: function() {
				var instance = this;

				var contentBox = instance.get(CONTENT_BOX);
				var input = instance.get('input');

				var comboConfig = {
					field: {
						labelText: false
					},
					tools: [
						{
							icon: 'circle-triangle-b',
							id: 'trigger',
							handler: {
								fn: instance._onButtonMouseDown,
								context: instance
							}
						}
					]
				};

				var inputReference = null;
				var inputParent = null;

				if (input) {
					input = A.get(input);

					comboConfig.field.node = input;

					inputReference = input.next();
					inputParent = input.get('parentNode');
				}

				var comboBox = new A.Combobox(comboConfig).render(contentBox);

				if (inputParent) {
					var comboBoundingBox = comboBox.get('boundingBox');

					inputParent.insertBefore(comboBoundingBox, inputReference);
				}

				instance.inputNode = comboBox.get('node');
				instance.button = comboBox.toolset.tools.item('trigger');

				instance.set('uniqueName', A.stamp(instance.inputNode));
			},

			_renderListElements: function() {
				var instance = this;

				var maxResultsDisplayed = instance.get('maxResultsDisplayed');

				var resultList = instance.resultList;

				var listItems = [];

				while (maxResultsDisplayed--) {
					listItems[maxResultsDisplayed] = '<li class="aui-helper-hidden ' + CSS_LIST_ITEM + '" data-listItemIndex="' + maxResultsDisplayed + '"></li>';
				}

				resultList.html(listItems.join(''));
			},

			_renderOverlay: function() {
				var instance = this;

				var overlayAlign = instance._overlayAlign;

				overlayAlign.node = instance.inputNode;

				var overlay = new A.ComponentOverlay(
					{
						align: overlayAlign,
						bodyContent: '<ul></ul>',
						visible: false,
						width: instance.inputNode.get('offsetWidth')
					}
				);

				var contentBox = overlay.get(CONTENT_BOX);

				overlay.get(BOUNDING_BOX).addClass(CSS_RESULTS_OVERLAY);

				contentBox.addClass(CSS_RESULTS_OVERLAY_CONTENT);

				overlay.render(document.body);

				overlay.addTarget(instance);

				instance.overlay = overlay;
				instance.resultList = contentBox.query('ul');

				instance.resultList.addClass(CSS_RESULTS_LIST);

				instance._renderListElements();
			},

			_selectItem: function(elListItem) {
				var instance = this;

				instance._itemSelected = true;

				instance._updateValue(elListItem);

				instance._pastSelections = instance.inputNode.get('value');

				instance._clearInterval();

				instance.fire('itemSelect', elListItem, elListItem._resultData);

				instance._toggleContainer(false);
			},

			_selectText: function(el, start, end) {
				var instance = this;

				var rawEl = A.Node.getDOMNode(el);
				var value = el.get('value');

				if (rawEl.setSelectionRange) {
					rawEl.setSelectionRange(start, end);
				}
				else if (rawEl.createTextRange) {
					var range = rawEl.createTextRange();

					range.moveStart('character', start);
					range.moveEnd('character', end - value.length);

					range.select();
				}
				else {
					rawEl.select();
				}
			},

			_sendQuery: function(query) {
				var instance = this;

				if (instance.get('disabled')) {
					instance._toggleContainer(false);

					return;
				}

				var delimChar = instance.get('delimChar');
				var minQueryLength = instance.get('minQueryLength');

				if (delimChar) {
					var extraction = instance._extractQuery(query);

					query = extraction.query;

					instance._pastSelections = extraction.previous;
				}

				if ((query && (query.length < minQueryLength)) || (!query && minQueryLength > 0)) {
					if (instance._delayId != -1) {
						clearTimeout(instance._delayId);
					}

					instance._toggleContainer(false);

					return;
				}

				query = encodeURIComponent(query);

				instance._delayId = -1;

				if (instance.get('applyLocalFilter')) {
					instance.dataSource.on('response', instance.filterResults, instance);
				}

				var request = instance.generateRequest(query);

				instance.fire('dataRequest', query, request);

				instance.dataSource.sendRequest(request);
			},

			_textMatchesOption: function() {
				var instance = this;

				var elMatch = null;
				var displayedItems = instance._displayedItems;
				var listItems = instance.resultList.get('childNodes');

				for (var i=0; i < displayedItems.length; i++) {
					var elListItem = listItems.item(i);

					var match = ('' + elListItem._resultMatch).toLowerCase();

					if (match == instance._currentQuery.toLowerCase()) {
						elMatch = elListItem;

						break;
					}
				}

				return elMatch;
			},

			_toggleContainer: function(show) {
				var instance = this;

				var overlay = instance.overlay;

				if (instance.get('alwaysShowContainer') && overlay.get('visible')) {
					return;
				}

				if (!show) {
					instance._toggleHighlight(instance._elCurListItem, 'from');

					instance._displayedItems = 0;
					instance._currentQuery = null;
				}

				if (show) {
					overlay.show();
					instance.fire('containerExpand');
				}
				else {
					overlay.hide();
					instance.fire('containerCollapse');
				}
			},

			_toggleHighlight: function(elNewListItem, action) {
				var instance = this;

				if (elNewListItem) {
					if (instance._elCurListItem) {
						instance._elCurListItem.removeClass(CSS_HIGLIGHT);
						instance._elCurListItem = null;
					}

					if (action == 'to') {
						elNewListItem.addClass(CSS_HIGLIGHT);

						instance._elCurListItem = elNewListItem;
					}
				}
			},

			_typeAhead: function(elListItem, query) {
				var instance = this;

				if (!instance.get('typeAhead') || instance._keyCode == KEY_BACKSPACE) {
					return;
				}

				var inputEl = A.Node.getDOMNode(instance.inputNode);

				if (inputEl.setSelectionRange || inputEl.createTextRange) {
					instance._typeAheadDelayId = setTimeout(
						function() {
							var value = inputEl.value;

							var start = value.length;

							instance._updateValue(elListItem);

							var end = inputEl.value.length;

							instance._selectText(instance.inputNode, start, end);

							var prefill = inputEl.value.substr(start, end);

							instance.fire('typeAhead', query, prefill);
						},
						instance.get('typeAheadDelay')
					);
				}
			},

			_updateValue: function(elListItem) {
				var instance = this;

				if (!instance.get('suppressInputUpdate')) {
					var input = instance.inputNode;
					var resultMatch = elListItem._resultMatch;

					var delimChar = instance.get('delimChar');

					delimChar = (delimChar && delimChar[0]) || delimChar;

					var newValue = '';

					if (delimChar) {
						newValue = instance._pastSelections;

						newValue += resultMatch + delimChar;

						if (delimChar != ' ') {
							newValue += ' ';
						}
					}
					else {
						newValue = resultMatch;
					}

					input.set('value', newValue);

					if (input.get('type') == 'textarea') {
						input.set('scrollTop', input.get('scrollHeight'));
					}

					var end = newValue.length;

					instance._selectText(input, end, end);

					instance._elCurListItem = elListItem;
				}
			},

			_currentQuery: null,
			_delayId: -1,
			_displayedItems: 0,
			_elCurListItem: null,
			_initInputValue: null,
			_itemSelected: false,
			_keyCode: null,
			_lastValue: null,
			_overContainer: false,
			_pastSelections: '',
			_typeAheadDelayId: -1
		}
	);

	A.AutoComplete = AutoComplete;

}, '0.1a' , { requires: [ 'datasource', 'dataschema', 'overlay', 'tool' ] });/*
* AUI Base
*/
AUI.add('aui-base', function(A) {

	A.mix(A.Array, {
		remove: function(a, from, to) {
		  var rest = a.slice((to || from) + 1 || a.length);
		  a.length = (from < 0) ? (a.length + from) : from;

		  return a.push.apply(a, rest);
		},

		removeItem: function(a, item) {
			var index = A.Array.indexOf(a, item);

			return A.Array.remove(a, index);
		}
	});

	// Courtesy of: http://simonwillison.net/2006/Jan/20/escape/
	A.Lang.escapeRegEx = function(str) {
		return str.replace(/([.*+?^$(){}|[\]\/\\])/g, '\\$1');
	};

}, '0.1a', { requires: [ 'yui-base', 'base' ] });

/*
* AUI Delayed Task
*/

AUI.add('delayed-task', function(A) {

	var DelayedTask = function(fn, scope, args) {
		var instance = this;

		instance._args = args;
		instance._delay = 0;
		instance._fn = fn;
		instance._id = null;
		instance._scope = scope || instance;
		instance._time = 0;

		instance._base = function() {
			var now = instance._getTime();

			if (now - instance._time >= instance._delay) {
				clearInterval(instance._id);

				instance._id = null;

				instance._fn.apply(instance._scope, instance._args || []);
			}
		};
	};

	DelayedTask.prototype = {
		delay: function(delay, newFn, newScope, newArgs) {
			var instance = this;

			if (instance._id && instance._delay != delay) {
				instance.cancel();
			}

			instance._delay = delay || instance._delay;
			instance._time = instance._getTime();

			instance._fn = newFn || instance._fn;
			instance._scope = newScope || instance._scope;
			instance._args = newArgs || instance._args;

			if (!A.Lang.isArray(instance._args)) {
				instance._args = [instance._args];
			}

			if (!instance._id) {
				if (instance._delay > 0) {
					instance._id = setInterval(instance._base, instance._delay);
				}
				else {
					instance._base();
				}
			}
		},

		cancel: function() {
			var instance = this;

			if (instance._id) {
				clearInterval(instance._id);

				instance._id = null;
			}
		},

		_getTime: function() {
			var instance = this;

			return (+new Date());
		}
	};

	A.DelayedTask = DelayedTask;

}, '0.1a', { requires: [ 'yui-base' ] });

/*
* AUI Node
*/

AUI.add('aui-node', function(A) {

	var Lang = A.Lang,
		isArray = Lang.isArray,
		isString = Lang.isString,
		isUndefined = Lang.isUndefined,

		INNER_HTML = 'innerHTML',
		NEXT_SIBLING = 'nextSibling',
		NONE = 'none',
		PARENT_NODE = 'parentNode',
		SCRIPT = 'script',
		VALUE = 'value';

	A.mix(A.Node.prototype, {
		appendTo: function(selector) {
			var instance = this;

			A.get(selector).append(instance);

			return instance;
		},

		attr: function(name, value) {
			var instance = this;

			if (!isUndefined(value)) {
				return instance.set(name, value);
			}
			else {
				return instance.get(name) || instance.getAttribute(name);
			}
		},

		empty: function() {
			var instance = this;

			instance.queryAll('>*').remove();

			var el = A.Node.getDOMNode(instance);

			while (el.firstChild) {
				el.removeChild(el.firstChild);
			}

			return instance;
		},

		getDOM: function() {
			var instance = this;

			return A.Node.getDOMNode(instance);
		},

		guid: function(prefix) {
			var instance = this;
			var currentId = instance.get('id');

			if (!currentId) {
				currentId = A.stamp(instance);

				instance.set('id', currentId);
			}

			return currentId;
		},

		hide: function(cssClass) {
			var instance = this;

			instance.addClass(cssClass || instance._hideClass || 'aui-helper-hidden');

			return instance;
		},

		html: function() {
			var args = arguments, length = args.length;

			if (length) {
				this.set(INNER_HTML, args[0]);
			}
			else {
				return this.get(INNER_HTML);
			}

			return this;
		},

		outerHTML: function() {
			var instance = this;
			var domEl = instance.getDOM();

			// IE, Opera and WebKit all have outerHTML.
			if ('outerHTML' in domEl) {
				return domEl.outerHTML;
			}

			var temp = A.Node.create('<div></div>').append(
				this.cloneNode(true)
			);

			try {
				return temp.html();
			}
			catch(e) {}
			finally {
				temp = null;
			}
		},

		placeAfter: function(content) {
			var instance = this;

			var parent = instance.get(PARENT_NODE);

			if (parent) {
				parent.insertBefore(content, instance.get(NEXT_SIBLING));
			}
		},

		placeBefore: function(content) {
			var instance = this;

			var parent = instance.get(PARENT_NODE);

			if (parent) {
				parent.insertBefore(content, instance);
			}
		},

		prependTo: function(selector) {
			var instance = this;

			A.get(selector).prepend(instance);
		},

		radioClass: function(cssClass) {
			var instance = this;

			instance.siblings().removeClass(cssClass);

			instance.addClass(cssClass);
		},

		resetId: function(prefix) {
			var instance = this;

			instance.attr('id', A.guid(prefix));

			return instance;
		},

		selectable: function() {
			var instance = this;

			instance.getDOM().unselectable = 'off';
			instance.detach('selectstart');

			instance.setStyles(
				{
					'MozUserSelect': '',
					'KhtmlUserSelect': ''
				}
			);

			instance.removeClass('aui-helper-unselectable');

			return instance;
		},

		show: function(cssClass) {
			var instance = this;

			instance.removeClass(cssClass || instance._hideClass || 'aui-helper-hidden')

			return instance;
		},

		siblings: function() {
			var instance = this;

			var all = instance.get('parentNode.children');
			var currentNode = instance._node;

			var siblings = A.Array.filter(
				all._nodes,
				function(item, index, collection) {
					return item != currentNode;
				}
			);

			return A.all(siblings);
		},

		swallowEvent: function(eventName, preventDefault) {
			var instance = this;

			var fn = function(event) {
				event.stopPropagation();

				if (preventDefault) {
					event.preventDefault();

					event.halt();
				}

				return false;
			};

			if(isArray(eventName)) {
				A.Array.each(
					eventName,
					function(name) {
						instance.on(name, fn);
					}
				);

				return this;
			}
			else {
				instance.on(eventName, fn);
			}

			return instance;
		},

		text: function(text) {
			var instance = this;
			var el = instance.getDOM();

			if (!isUndefined(text)) {
				text = A.DOM._getDoc(el).createTextNode(text);

				return instance.empty().append(text);
			}

			return instance._getText(el.childNodes);
		},

		toggle: function(cssClass) {
			var instance = this;

			var action = 'hide';
			var hideClass = cssClass || instance._hideClass || 'aui-helper-hidden';

			if (instance.hasClass(hideClass)) {
				action = 'show';
			}

			instance[action](hideClass);
		},

		unselectable: function() {
			var instance = this;

			instance.getDOM().unselectable = 'on';

			instance.swallowEvent('selectstart', true);

			instance.setStyles(
				{
					'MozUserSelect': NONE,
					'KhtmlUserSelect': NONE
				}
			);

			instance.addClass('aui-helper-unselectable');

			return instance;
		},

		val: function(value) {
			var instance = this;

			if (isUndefined(value)) {
				return instance.get(VALUE);
			}
			else {
				return instance.set(VALUE, value);
			}
		},

		_getText: function(childNodes) {
			var instance = this;

			var length = childNodes.length;
			var childNode;

			var str = [];

			for (var i = 0; i < length; i++) {
				childNode = childNodes[i];

				if (childNode && childNode.nodeType != 8) {
					if (childNode.nodeType != 1) {
						str.push(childNode.nodeValue);
					}

					if (childNode.childNodes) {
						str.push(instance._getText(childNode.childNodes));
					}
				}
			}

			return str.join('');
		}
	}, true);

	A.NodeList.importMethod(
		A.Node.prototype,
		[
			'after',

			'appendTo',

			'attr',

			'before',

			'empty',

			'hide',

			'html',

			'outerHTML',

			'prepend',

			'prependTo',

			'selectable',

			'show',

			'text',

			'toggle',

			'unselectable',

			'val'
		]
	);

	A.mix(
		A.NodeList.prototype,
		{
			all: function(selector) {
				var instance = this;

				var newNodeList = [];
				var nodes = instance._nodes;
				var length = nodes.length;

				var subList;

				for (var i = 0; i < length; i++) {
					subList = A.Selector.query(selector, nodes[i]);

					if (subList && subList.length) {
						newNodeList.push.apply(newNodeList, subList);
					}
				}

				newNodeList = A.Array.unique(newNodeList);

				return A.all(newNodeList);
			},

			getDOM: function() {
				var instance = this;

				return A.NodeList.getDOMNodes(this);
			},

			one: function(selector) {
				var instance = this;

				var newNode = null;

				var nodes = instance._nodes;
				var length = nodes.length;

				for (var i = 0; i < length; i++) {
					newNode = A.Selector.query(selector, nodes[i], true);

					if (newNode) {
						newNode = A.one(newNode);

						break;
					}
				}

				return newNode;
			}
		}
	);

	A.mix(
		A,
		{
			getBody: function() {
				var instance = this;

				if (!instance._bodyNode) {
					instance._bodyNode = A.get(document.body);
				}

				return instance._bodyNode;
			},

			getDoc: function() {
				var instance = this;

				if (!instance._documentNode) {
					instance._documentNode = A.get(document);
				}

				return instance._documentNode;
			},

			getWin: function() {
				var instance = this;

				if (!instance._windowNode) {
					instance._windowNode = A.get(window);
				}

				return instance._windowNode;
			}
		}
	);

}, '0.1a', { requires: [ 'collection', 'node' ] });AUI.add('calendar', function(A) {

var L = A.Lang,
	isString = L.isString,
	isArray = L.isArray,
	isBoolean = L.isBoolean,
	isUndefined = L.isUndefined,
	isNumber = L.isNumber,

	WidgetStdMod = A.WidgetStdMod,

	ACTIVE = 'active',
	BLANK = 'blank',
	BODY_CONTENT = 'bodyContent',
	BOUNDING_BOX = 'boundingBox',
	CALENDAR = 'calendar',
	CIRCLE = 'circle',
	CLEARFIX = 'clearfix',
	CURRENT_DAY = 'currentDay',
	CURRENT_MONTH = 'currentMonth',
	CURRENT_NODE = 'currentNode',
	CURRENT_YEAR = 'currentYear',
	DATES = 'dates',
	DATE_FORMAT = 'dateFormat',
	DAY = 'day',
	DEFAULT = 'default',
	DISABLED = 'disabled',
	DOT = '.',
	FIRST_DAY_OF_WEEK = 'firstDayOfWeek',
	HEADER = 'hd',
	HEADER_CONTENT = 'headerContent',
	HELPER = 'helper',
	HIDDEN = 'hidden',
	HOVER = 'hover',
	ICON = 'icon',
	LOCALE = 'locale',
	MAX_DATE = 'maxDate',
	MIN_DATE = 'minDate',
	MONTH = 'month',
	MONTHDAYS = 'monthdays',
	NEXT = 'next',
	PREV = 'prev',
	SELECT_MULTIPLE_DATES = 'selectMultipleDates',
	SET_VALUE = 'setValue',
	STATE = 'state',
	TITLE = 'title',
	TRIANGLE = 'triangle',
	WEEK = 'week',
	WEEKDAYS = 'weekdays',

	getCN = A.ClassNameManager.getClassName,

	CSS_CALENDAR = getCN(CALENDAR),
	CSS_CALENDAR_DISABLED = getCN(CALENDAR, DISABLED),
	CSS_DAY = getCN(CALENDAR, DAY),
	CSS_DAY_BLANK = getCN(CALENDAR, DAY, BLANK),
	CSS_DAY_HIDDEN = getCN(CALENDAR, DAY, HIDDEN),
	CSS_HEADER = getCN(CALENDAR, HEADER),
	CSS_HELPER_CLEARFIX = getCN(HELPER, CLEARFIX),
	CSS_ICON = getCN(ICON),
	CSS_ICON_CIRCLE_TRIANGLE_L = getCN(ICON, CIRCLE, TRIANGLE, 'l'),
	CSS_ICON_CIRCLE_TRIANGLE_R = getCN(ICON, CIRCLE, TRIANGLE, 'r'),
	CSS_MONTHDAYS = getCN(CALENDAR, MONTHDAYS),
	CSS_NEXT = getCN(CALENDAR, NEXT),
	CSS_PREV = getCN(CALENDAR, PREV),
	CSS_STATE_ACTIVE = getCN(STATE, ACTIVE),
	CSS_STATE_DEFAULT = getCN(STATE, DEFAULT),
	CSS_STATE_HOVER = getCN(STATE, HOVER),
	CSS_TITLE = getCN(CALENDAR, TITLE),
	CSS_WEEK = getCN(CALENDAR, WEEK),
	CSS_WEEKDAYS = getCN(CALENDAR, WEEKDAYS),

	TPL_CALENDAR_HEADER = '<div class="'+[ CSS_HEADER, CSS_STATE_DEFAULT, CSS_HELPER_CLEARFIX ].join(' ')+'">' +
							'<a href="" class="'+[ CSS_ICON, CSS_ICON_CIRCLE_TRIANGLE_L, CSS_PREV ].join(' ')+'">Back</a>'+
							'<a href="" class="'+[ CSS_ICON, CSS_ICON_CIRCLE_TRIANGLE_R, CSS_NEXT ].join(' ')+'">Prev</a>'+
						'</div>',

	TPL_CALENDAR_DAY_BLANK = '<div class="'+[ CSS_DAY_BLANK, CSS_DAY_HIDDEN ].join(' ')+'"></div>',

	TPL_CALENDAR_DAY = '<a href="#" class="'+[ CSS_DAY, CSS_STATE_DEFAULT ].join(' ')+'"></a>',

	TPL_CALENDAR_HEADER_TITLE = '<div class="'+CSS_TITLE+'"></div>',

	TPL_CALENDAR_MONTHDAYS = '<div class="'+[ CSS_MONTHDAYS, CSS_HELPER_CLEARFIX ].join(' ')+'"></div>',

	TPL_CALENDAR_WEEK = '<div class="'+CSS_WEEK+'"></div>',

	TPL_CALENDAR_WEEKDAYS = '<div class="'+[ CSS_WEEKDAYS, CSS_HELPER_CLEARFIX ].join(' ')+'"></div>';

function Calendar(config) {
	Calendar.superclass.constructor.apply(this, arguments);
}

A.mix(Calendar, {
	NAME: CALENDAR,

	ATTRS: {
		currentDay: {
			value: (new Date()).getDate()
		},

		currentMonth: {
			value: (new Date()).getMonth()
		},

		currentYear: {
			value: (new Date()).getFullYear()
		},

		dates: {
			value: [ new Date() ],
			validator: isArray,
			setter: function(v) {
				return this._setDates(v);
			}
		},

		dateFormat: {
			value: '%m/%d/%Y',
			validator: isString
		},

		firstDayOfWeek: {
			value: 0,
			validator: isNumber
		},

		minDate: {
			value: null,
			setter: function(v) {
				return this._setMinMaxDate(v);
			}
		},

		maxDate: {
			value: null,
			setter: function(v) {
				return this._setMinMaxDate(v);
			}
		},

		showOn: {
			value: 'mousedown'
		},

		hideOn: {
			value: 'mousedown'
		},

		selectMultipleDates: {
			value: false
		},

		setValue: {
			value: true,
			validator: isBoolean
		},

		stack: {
			lazyAdd: false,
			value: true,
			setter: function(v) {
				return this._setStack(v);
			},
			validator: isBoolean
		}
	}
});

A.extend(Calendar, A.ContextOverlay, {
	/*
	* Lifecycle
	*/
	initializer: function() {
		var instance = this;

		instance.selectedDates = [];
	},

	renderUI: function() {
		var instance = this;

		Calendar.superclass.renderUI.apply(this, arguments);

		instance._renderCalendar();
		instance._renderWeekDays();
		instance._renderBlankDays();
		instance._renderMonthDays();
	},

	bindUI: function() {
		var instance = this;

		Calendar.superclass.bindUI.apply(this, arguments);

		instance._bindDOMEvents();
		instance._bindDelegateMonthDays();

		instance.after('datesChange', A.bind(instance._afterSetDates, instance));
		// instance.after('currentDayChange', A.bind(instance._syncView, instance));
		instance.after('currentMonthChange', A.bind(instance._syncView, instance));
		instance.after('currentYearChange', A.bind(instance._syncView, instance));
	},

	syncUI: function() {
		var instance = this;

		Calendar.superclass.syncUI.apply(this, arguments);

		instance._syncView();
	},

	_syncView: function() {
		var instance = this;
		var currentDay = instance.get(CURRENT_DAY);
		var currentMonth = instance.get(CURRENT_MONTH);
		var currentYear = instance.get(CURRENT_YEAR);

		instance._syncDays()
		instance._syncHeader();
		instance._syncSelectedDays();
	},

	_syncHeader: function() {
		var instance = this;
		var currentMonth = instance.get(CURRENT_MONTH);
		var currentYear = instance.get(CURRENT_YEAR);

		var title = [ instance._getMonthName(currentMonth), currentYear ].join(' ');

		instance.headerTitleNode.html(title);
	},

	_syncDays: function() {
		var instance = this;
		var daysInMonth = instance.getDaysInMonth();
		var firstWeekDay = instance.getFirstDayOfWeek();
		var currentDate = instance.getCurrentDate();

		instance.monthDays.each(function(monthDayNode, day) {
			if (day >= daysInMonth) {
				// displaying the correct number of days in the current month
				monthDayNode.addClass(CSS_DAY_HIDDEN);
			}
			else {
				monthDayNode.removeClass(CSS_DAY_HIDDEN);
			}

			// restricting date
			currentDate.setDate(day + 1);

			instance._restrictDate(currentDate, monthDayNode);
		});

		instance.blankDays.each(function(blankDayNode, day) {
			var blankDays = (firstWeekDay - instance.get(FIRST_DAY_OF_WEEK) + 7) % 7;

			if (day < blankDays) {
				// show padding days to position the firstWeekDay correctly
				blankDayNode.removeClass(CSS_DAY_HIDDEN);
			}
			else {
				blankDayNode.addClass(CSS_DAY_HIDDEN);
			}
		});
	},

	_syncSelectedDays: function(dates) {
		var instance = this;
		var currentMonth = instance.get(CURRENT_MONTH);
		var currentYear = instance.get(CURRENT_YEAR);

		instance.monthDays.replaceClass(CSS_STATE_ACTIVE, CSS_STATE_DEFAULT);
		instance.monthDays.replaceClass(CSS_STATE_HOVER, CSS_STATE_DEFAULT);

		instance._eachSelectedDate(function(date, index) {
			var canSelectDays = (currentMonth == date.getMonth()) && (currentYear == date.getFullYear());

			if (canSelectDays) {
				var dayNode = instance.monthDays.item( date.getDate() - 1 );

				dayNode.addClass(CSS_STATE_ACTIVE);

				try {
					// focus the last selected date
					// IE doesn't support focus on hidden elements
					dayNode.focus();
				}
				catch (err) {}
			}
		}, dates);
	},

	_renderCalendar: function() {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);

		instance.weekDaysNode = A.Node.create(TPL_CALENDAR_WEEKDAYS);
		instance.monthDaysNode = A.Node.create(TPL_CALENDAR_MONTHDAYS);
		instance.headerTitleNode = A.Node.create(TPL_CALENDAR_HEADER_TITLE);
		instance.headerContentNode = A.Node.create(TPL_CALENDAR_HEADER).append(instance.headerTitleNode);

		var bodyContent = A.Node.create('<div></div>');
		bodyContent.append(this.weekDaysNode);
		bodyContent.append(this.monthDaysNode);

		instance.setStdModContent(WidgetStdMod.HEADER, instance.headerContentNode);
		instance.setStdModContent(WidgetStdMod.BODY, bodyContent);

		boundingBox.addClass(CSS_CALENDAR);
	},

	_renderWeekDays: function() {
		var day = 0;
		var instance = this;
		var weekDay = A.Node.create(TPL_CALENDAR_WEEK);
		var firstWeekDay = instance.get(FIRST_DAY_OF_WEEK);

		while(day < 7) {
			var fixedDay = (day + firstWeekDay) % 7;
			var dayName = instance._getDayNameMin(fixedDay);

			instance.weekDaysNode.append(
				weekDay.cloneNode().html(dayName)
			);

			day++;
		}
	},

	// blank days are used to align with the week day column
	_renderBlankDays: function() {
		var day = 0;
		var instance = this;
		var blankDay = A.Node.create(TPL_CALENDAR_DAY_BLANK);

		while (day++ < 7) {
			instance.monthDaysNode.append(
				blankDay.cloneNode()
			);
		}

		instance.blankDays = instance.monthDaysNode.all(DOT+CSS_DAY_BLANK);
	},

	_renderMonthDays: function() {
		var day = 0;
		var instance = this;
		var monthDay = A.Node.create(TPL_CALENDAR_DAY);

		while (day++ < 31) {
			instance.monthDaysNode.append(
				monthDay.cloneNode().html(day)
			);
		}

		instance.monthDays = instance.monthDaysNode.all(DOT+CSS_DAY);
	},

	_bindDOMEvents: function() {
		var instance = this;
		var headerContentNode = instance.headerContentNode;
		var boundingBox = instance.get(BOUNDING_BOX);

		var nextIcon = headerContentNode.query(DOT+CSS_ICON_CIRCLE_TRIANGLE_R)
		var prevIcon = headerContentNode.query(DOT+CSS_ICON_CIRCLE_TRIANGLE_L)

		var eventHalt = function(event) {
			event.halt();
		};

		boundingBox.on('click', eventHalt);
		boundingBox.on('mousedown', eventHalt);

		nextIcon.on('mousedown', A.bind(instance._selectNextMonth, instance));
		prevIcon.on('mousedown', A.bind(instance._selectPrevMonth, instance));
	},

	_bindDelegateMonthDays: function() {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);

		boundingBox.delegate('click', A.bind(instance._onClickDays, instance), DOT+CSS_DAY);
		boundingBox.delegate('mouseenter', A.bind(instance._onMouseEnterDays, instance), DOT+CSS_DAY);
		boundingBox.delegate('mouseleave', A.bind(instance._onMouseLeaveDays, instance), DOT+CSS_DAY);
	},

	/*
	* Methods
	*/
	alreadySelected: function(date) {
		var instance = this;
		var alreadySelected = false;

		instance._eachSelectedDate(function(d, index) {
			if (instance._compareDates(d, date)) {
				alreadySelected = true;
			}
		});

		return alreadySelected;
	},

	getSelectedDates: function() {
		var instance = this;

		return instance.get(DATES);
	},

	getFormattedSelectedDates: function() {
		var instance = this;
		var dates = [];

		instance._eachSelectedDate(function(date) {
			dates.push( instance.formatDate( date, instance.get(DATE_FORMAT) ) );
		});

		return dates;
	},

	getDetailedSelectedDates: function() {
		var instance = this;
		var dates = [];

		instance._eachSelectedDate(function(date) {
			dates.push({
				year: date.getFullYear(),
				month: date.getMonth(),
				day: date.getDate()
			});
		});

		return dates;
	},

	_getLocaleMap: function() {
		var instance = this;

		return A.DataType.Date.Locale[ instance.get(LOCALE) ];
	},

	_restrictDate: function(currentDate, monthDayNode) {
		var instance = this;
		var maxDate = instance.get(MAX_DATE);
		var minDate = instance.get(MIN_DATE);

		var disablePrev = minDate && (currentDate < minDate);
		var disableNext = maxDate && (currentDate > maxDate);

		if (disablePrev || disableNext) {
			monthDayNode.addClass(CSS_CALENDAR_DISABLED);
		}
		else {
			monthDayNode.removeClass(CSS_CALENDAR_DISABLED);
		}
	},

	_selectDate: function() {
		var instance = this;
		var dates = instance.get(DATES);
		var currentDate = instance.getCurrentDate();

		// if is single selection reset the selected dates
		if (!instance.get(SELECT_MULTIPLE_DATES)) {
			dates = [];
		}

		if (!instance.alreadySelected(currentDate)) {
			dates.push(currentDate);
			instance.set(DATES, dates);
		}
	},

	_removeDate: function(date) {
		var instance = this;
		var dates = instance.get(DATES);

		instance._eachSelectedDate(function(d, index) {
			if (instance._compareDates(d, date)) {
				A.Array.remove(dates, index);
			}
		});

		instance.set(DATES, dates);
	},

	_eachSelectedDate: function(fn, dates) {
		var instance = this;

		if (!dates) {
			dates = instance.get(DATES);
		}

		A.Array.each(dates, function() {
			fn.apply(this, arguments);
		});
	},

	_compareDates: function(d1, d2) {
		return ( d1.getTime() == d2.getTime() );
	},

	_selectNextMonth: function(event) {
		var instance = this;

		instance._navigateMonth(+1);

		event.preventDefault();
	},

	_selectPrevMonth: function(event) {
		var instance = this;

		instance._navigateMonth(-1);

		event.preventDefault();
	},

	_navigateMonth: function(offset) {
		var instance = this;
		var currentMonth = instance.get(CURRENT_MONTH);
		var currentYear = instance.get(CURRENT_YEAR);

		var date = new Date(currentYear, currentMonth + offset);

		// when navigate by month update the year also
		instance.set(CURRENT_MONTH, date.getMonth());
		instance.set(CURRENT_YEAR, date.getFullYear());
	},

	/*
	* Listeners
	*/
	_afterSetDates: function(event) {
		var instance = this;
		var normal = instance.getSelectedDates();
		var formatted = instance.getFormattedSelectedDates();
		var detailed = instance.getDetailedSelectedDates();
		var hasSelected = event.newVal.length;

		instance._syncSelectedDays();

		if (hasSelected) {
			instance.fire('select', {
				date: {
					detailed: detailed,
					formatted: formatted,
					normal: normal
				}
			});

			if (!instance.get(SELECT_MULTIPLE_DATES)) {
				instance.hide();
			}
		}

		if (instance.get(SET_VALUE)) {
			instance.get(CURRENT_NODE).val( formatted.join(',') );
		}
	},

	_onClickDays: function(event) {
		var instance = this;
		var target  = event.currentTarget || event.target;
		var day = instance.monthDays.indexOf(target)+1;
		var disabled = target.test(DOT+CSS_CALENDAR_DISABLED);

		if (!disabled) {
			instance.set(CURRENT_DAY, day);

			var currentDate = instance.getCurrentDate();
			var alreadySelected = instance.alreadySelected(currentDate);

			if (alreadySelected) {
				instance._removeDate(currentDate);
			}
			else {
				instance._selectDate();
			}
		}

		event.preventDefault();
	},

	_onMouseEnterDays: function(event) {
		var instance = this;
		var target  = event.currentTarget || event.target;

		target.replaceClass(CSS_STATE_DEFAULT, CSS_STATE_HOVER);
	},

	_onMouseLeaveDays: function(event) {
		var instance = this;
		var target  = event.currentTarget || event.target;

		target.replaceClass(CSS_STATE_HOVER, CSS_STATE_DEFAULT);
	},

	/*
	* Setters
	*/
	_setDates: function(value) {
		var instance = this;

		A.Array.each(value, function(date, index) {
			if (isString(date)) {
				value[index] = instance.parseDate( date );
			}
		});

		var lastSelectedDate = value[value.length - 1];

		if (lastSelectedDate) {
			// update the current values to the last selected date
			instance.set(CURRENT_DAY, lastSelectedDate.getDate());
			instance.set(CURRENT_MONTH, lastSelectedDate.getMonth());
			instance.set(CURRENT_YEAR, lastSelectedDate.getFullYear());

			instance._syncSelectedDays(value);
		}

		return value;
	},

	_setMinMaxDate: function(value) {
		var instance = this;

		if (isString(value)) {
			value = instance.parseDate( value );
		}

		return value;
	},

	_setStack: function(value) {
		var instance = this;

		if (value) {
			A.CalendarManager.register(instance);
		}
		else {
			A.CalendarManager.remove(instance);
		}

		return value;
	},

	/*
	* Date util methods
	*/
	getCurrentDate: function() {
		var instance = this;
		var date = instance._normalizeYearMonth();

		return ( new Date(date.year, date.month, date.day) );
	},

	getDaysInMonth: function(year, month) {
		var instance = this;
		var date = instance._normalizeYearMonth(year, month);

        return ( 32 - new Date(date.year, date.month, 32).getDate() );
    },

	getFirstDate: function(year, month) {
		var instance = this;
		var date = instance._normalizeYearMonth(year, month);

		return ( new Date(date.year, date.month, 1) );
	},

	getLastDate: function(year, month) {
		var instance = this;
		var date = instance._normalizeYearMonth(year, month);
		var daysInMonth = instance.getDaysInMonth(date.month);

		return ( new Date(date.year, date.month, daysInMonth) );
	},

	getFirstDayOfWeek: function(year, month) {
		var instance = this;

		return instance.getFirstDate(year, month).getDay();
	},

	_normalizeYearMonth: function(year, month, day) {
		var instance = this;
		var currentDay = instance.get(CURRENT_DAY);
		var currentMonth = instance.get(CURRENT_MONTH);
		var currentYear = instance.get(CURRENT_YEAR);

		if (isUndefined(day)) {
			day = currentDay;
		}

		if (isUndefined(month)) {
			month = currentMonth;
		}

		if (isUndefined(year)) {
			year = currentYear;
		}

		return { year: year, month: month, day: day };
	},

	_getDayName: function(weekDay) {
		var instance = this;
		var localeMap = instance._getLocaleMap();

		return localeMap.A[weekDay];
	},

	_getDayNameShort: function(weekDay) {
		var instance = this;
		var localeMap = instance._getLocaleMap();

		return localeMap.a[weekDay];
	},

	_getDayNameMin: function(weekDay) {
		var instance = this;
		var name = instance._getDayNameShort(weekDay);

		return name.slice(0, name.length-1);
	},

	_getMonthName: function(month) {
		var instance = this;
		var localeMap = instance._getLocaleMap();

		return localeMap.B[month];
	},

	_getMonthNameShort: function(month) {
		var instance = this;
		var localeMap = instance._getLocaleMap();

		return localeMap.b[month];
	},

	parseDate: function(dateString) {
		var instance = this;

		return ( dateString ? new Date(dateString) : new Date );
	},

	formatDate: function (date, mask) {
		var instance = this;
		var locale = instance.get(LOCALE);

		return A.DataType.Date.format(date, { format: mask, locale: locale });
	}
});

A.Calendar = Calendar;

A.CalendarManager = new A.OverlayManager({
	zIndexBase: 1000
});

}, '0.1a', { requires: [ 'aui-base', 'context-overlay', 'overlay-manager', 'datatype-date' ] });AUI.add('char-counter', function(A) {

/*
* CharCounter
*/
var L = A.Lang,
	isNumber = L.isNumber,

	CHAR_COUNTER = 'char-counter',
	COUNTER = 'counter',
	INPUT = 'input',
	MAX_LENGTH = 'maxLength',
	SCROLL_LEFT = 'scrollLeft',
	SCROLL_TOP = 'scrollTop';

function CharCounter(config) {
	CharCounter.superclass.constructor.apply(this, arguments);
}

A.mix(CharCounter, {
	NAME: CHAR_COUNTER,

	ATTRS: {
		counter: {
			setter: function(v) {
				return A.one(v);
			}
		},

		maxLength: {
			lazyAdd: false,
			setter: function(v) {
				return this._setMaxLength(v);
			},
			value: Infinity,
			validator: isNumber
		},

		input: {
			setter: function(v) {
				return A.one(v);
			}
		}
	}
});

A.extend(CharCounter, A.Base, {
	handler: null,

	/*
	* Lifecycle
	*/
	initializer: function() {
		var instance = this;

		instance.bindUI();

		instance.checkLength();
	},

	/*
	* Methods
	*/
	bindUI: function() {
		var instance = this;
		var input = instance.get(INPUT);

		instance.publish('maxLength');

		instance.after('maxLengthChange', instance.checkLength);

		if (input) {
			// use cross browser input-handler event
			instance.handler = input.on(INPUT, A.bind(instance._onInputChange, instance));
		}
	},

	syncUI: function() {
		var instance = this;
		var counter = instance.get(COUNTER);

		if (counter) {
			var value = instance.get(INPUT).val();

			counter.html(
				instance.get(MAX_LENGTH) - value.length
			);
		}
	},

	destroy: function() {
		var instance = this;

		if (instance.handler) {
			instance.handler.detach();
		}
	},

	checkLength: function() {
		var instance = this;
		var input = instance.get(INPUT);
		var maxLength = instance.get(MAX_LENGTH);

		if (!input) {
			return false; // NOTE: return
		}

		var value = input.val();
		var scrollTop = input.get(SCROLL_TOP);
		var scrollLeft = input.get(SCROLL_LEFT);

		if (value.length > maxLength) {
			input.val(
				value.substring(0, maxLength)
			);
		}

		if (value.length == maxLength) {
			instance.fire('maxLength');
		}

		input.set(SCROLL_TOP, scrollTop);
		input.set(SCROLL_LEFT, scrollLeft);

		instance.syncUI();
	},

	/*
	* Listeners
	*/
	_onInputChange: function(event) {
		var instance = this;

		instance.checkLength();
	},

	/*
	* Setters
	*/
	_setMaxLength: function(v) {
		var instance = this;
		var input = instance.get(INPUT);

		if (input && (v < Infinity)) {
			input.set(MAX_LENGTH, v);
		}

		return v;
	}
});

A.CharCounter = CharCounter;

}, '0.1a', { requires: [ 'aui-base', 'input-handler' ] });AUI().add(
	'color-picker',
	function(A) {
		var Lang = A.Lang,
			isArray = Lang.isArray,
			isObject = Lang.isObject,

			NAME = 'colorpicker',

			getClassName = A.ClassNameManager.getClassName,

			WidgetStdMod = A.WidgetStdMod,

			CSS_CANVAS = getClassName(NAME, 'canvas'),
			CSS_HUE_CANVAS = getClassName(NAME, 'hue-canvas'),
			CSS_CONTAINER = getClassName(NAME, 'container'),
			CSS_CONTROLS_CONTAINER = getClassName(NAME, 'controls'),

			CSS_SWATCH_CONTAINER = getClassName(NAME, 'swatch'),
			CSS_SWATCH_CURRENT = getClassName(NAME, 'swatch-current'),
			CSS_SWATCH_ORIGINAL = getClassName(NAME, 'swatch-original'),
			CSS_THUMB_CANVAS = getClassName(NAME, 'thumb'),
			CSS_THUMB_CANVAS_IMAGE = getClassName(NAME, 'thumb-image'),
			CSS_HUE_THUMB = getClassName(NAME, 'hue-thumb'),
			CSS_HUE_THUMB_IMAGE = getClassName(NAME, 'hue-thumb-image'),
			CSS_TRIGGER= getClassName(NAME, 'trigger'),
			CSS_TRIGGER_IMAGE = getClassName(NAME, 'trigger-image'),

			TPL_CANVAS = '<div class="' + CSS_CANVAS + '"></div>',
			TPL_HUE_CANVAS = '<div class="' + CSS_HUE_CANVAS + '"></div>',
			TPL_SWATCH_CONTAINER = '<div class="' + CSS_SWATCH_CONTAINER + '"></div>',
			TPL_SWATCH_CURRENT = '<div class="' + CSS_SWATCH_CURRENT + '"></div>',
			TPL_SWATCH_ORIGINAL = '<div class="' + CSS_SWATCH_ORIGINAL + '"></div>',
			TPL_THUMB_CANVAS = '<div class="' + CSS_THUMB_CANVAS + '"><img class="' + CSS_THUMB_CANVAS_IMAGE + '" src="{thumbImage}" /></div>',
			TPL_THUMB_HUE = '<div class="' + CSS_HUE_THUMB + '"><img class="' + CSS_HUE_THUMB_IMAGE + '" src="{thumbImage}" /></div>';

		var Color = {
			real2dec: function(number) {
				var instance = this;

				return Math.min(255, Math.round(number * 256));
			},

			hsv2rgb: function(hue, saturation, value) {
				var instance = this;

				if (isArray(hue)) {
					return instance.hsv2rgb.apply(instance, hue);
				}
				else if (isObject(hue)) {
					saturation = hue.saturation;
					value = hue.value;
					hue = hue.hue;
				}

				hue = instance.constrainTo(hue, 0, 360, 0);
				value = instance.constrainTo(value, 0, 1, 0);
				saturation = instance.constrainTo(saturation, 0, 1, 0);

				var red,
					green,
					blue,
					i = Math.floor((hue / 60) % 6),
					f = (hue / 60) - i,
					p = value * (1 - saturation),
					q = value * (1 - f * saturation),
					t = value * (1 - (1 - f) * saturation);

				switch (i) {
					case 0:
						red = value;
						green = t;
						blue = p;
					break;
					case 1:
						red = q;
						green = value;
						blue = p;
					break;
					case 2:
						red = p;
						green = value;
						blue = t;
					break;
					case 3:
						red = p;
						green = q;
						blue = value;
					break;
					case 4:
						red = t;
						green = p;
						blue = value;
					break;
					case 5:
						red = value;
						green = p;
						blue = q;
					break;
				}

				var real2dec = instance.real2dec;

				return {
					red: real2dec(red),
					green: real2dec(green),
					blue: real2dec(blue)
				};
			},

			rgb2hex: function(red, green, blue) {
				var instance = this;

				if (isArray(red)) {
					return instance.rgb2hex.apply(instance, red);
				}
				else if (isObject(red)) {
					green = red.green;
					blue = red.blue;
					red = red.red;
				}

				var dec2hex = instance.dec2hex;

				return dec2hex(red) + dec2hex(green) + dec2hex(blue);
			},

			dec2hex: function(number) {
				var instance = this;

				number = parseInt(number, 10)|0;
				number = Color.constrainTo(number, 0, 255, 0);

				return ('0' + number.toString(16)).slice(-2).toUpperCase();
			},

			hex2dec: function(string) {
				var instance = this;

				return parseInt(string, 16);
			},

			hex2rgb: function(string) {
				var instance = this;

				var hex2dec = instance.hex2dec;

				var red = string.slice(0, 2);
				var green = string.slice(2, 4);
				var blue = string.slice(4, 6);

				return {
					red: hex2dec(red),
					green: hex2dec(green),
					blue: hex2dec(blue)
				};
			},

			rgb2hsv: function(red, blue, green) {
				var instance = this;

				if (isArray(red)) {
					return instance.rgb2hsv.apply(instance, red);
				}
				else if (isObject(red)) {
					green = red.green;
					blue = red.blue;
					red = red.red;
				}

				red /= 255;
				green /= 255;
				blue /= 255;

				var hue,
					saturation,
					min = Math.min(Math.min(red, green), blue),
					max = Math.max(Math.max(red, green), blue),
					delta = max - min;

				switch (max) {
					case min:
						hue = 0;
					break;
					case red:
						hue = 60 * (green - blue) / delta;
						if (green < blue) {
							hue += 360;
						}
					break;
					case green:
						hue = (60 * (blue - red) / delta) + 120;
					break;
					case blue:
						hue = (60 * (red - green) / delta) + 240;
					break;
				}

				saturation = (max === 0) ? 0 : 1- (min / max);

				return {
					hue: Math.round(hue),
					saturation: saturation,
					value: max
				};
			},

			constrainTo: function(number, start, end, defaultNumber) {
				var instance = this;

				if (number < start || number > end) {
					number = defaultNumber;
				}

				return number;
			}
		};

		var ColorPicker = function(config) {
			ColorPicker.superclass.constructor.apply(this, arguments);
		};

		ColorPicker.NAME = 'colorpicker';

		ColorPicker.ATTRS = {
			colors: {
				value: {},
				getter: function() {
					var instance = this;

					var rgb = instance.get('rgb');
					var hex = instance.get('hex');

					var colors = {};

					A.mix(colors, rgb);

					colors.hex = hex;

					return colors;
				}
			},
			hex: {
				value: 'FFFFFF',
				getter: function() {
					var instance = this;

					var rgb = instance.get('rgb');

					return Color.rgb2hex(rgb);
				},
				setter: function(value) {
					var instance = this;

					var length = value.length;

					if (length == 3) {
						var chars = value.split('');

						for (var i = 0; i < chars.length; i++) {
							chars[i] += chars[i];
						}

						value = chars.join('');
					}

					if ((/[A-Fa-f0-9]{6}/).test(value)) {
						var rgb = Color.hex2rgb(value);

						instance.set('rgb', rgb);
					}
					else {
						value = A.Attribute.INVALID_VALUE;
					}

					return value;
				}
			},

			hideOn: {
				value: 'click'
			},

			hsv: {
				getter: function(value) {
					var instance = this;

					var rgb = instance.get('rgb');

					return Color.rgb2hsv(rgb);
				},
				setter: function(value) {
					var instance = this;

					if (isArray(value)) {
						var current = instance.get('hsv');

						var rgb = Color.hsv2rgb(value);

						instance.set('rgb', rgb);

						current = {
							hue: value[0],
							saturation: value[1],
							value: [2]
						};
					}
					else if (!isObject(value)) {
						value = A.Attribute.INVALID_VALUE;
					}

					return value;
				},
				value: {
					hue: 0,
					saturation: 0,
					value: 0
				}
			},

			images: {
				value: {
					HUE_THUMB: AUI.defaults.paths.images + 'color_picker/color_indic.png',
					PICKER_THUMB: AUI.defaults.paths.images + 'color_picker/select.png'
				}
			},

			showOn: {
				value: 'click'
			},

			pickersize: {
				value: 180
			},

			rgb: {
				value: {
					blue: 255,
					green: 255,
					red: 255
				},

				setter: function(value) {
					var instance = this;

					if (isArray(value)) {
						var current = instance.get('rgb');

						current = {
							blue: value[2],
							green: value[1],
							red: [0]
						};

						value = current;
					}
					else if (!isObject(value)) {
						value = A.Attribute.INVALID_VALUE;
					}

					value.red = Color.constrainTo(value.red, 0, 255, 255);
					value.green = Color.constrainTo(value.green, 0, 255, 255);
					value.blue = Color.constrainTo(value.blue, 0, 255, 255);

					return value;
				}
			},

			strings: {
				value: {
					R: 'R',
					G: 'G',
					B: 'B',
					H: 'H',
					S: 'S',
					V: 'V',
					HEX: '#',
					DEG: '\u00B0',
					PERCENT: '%'
				}
			},

			trigger: {
				lazyAdd: true,
				getter: function(value) {
					var instance = this;

					if (!value) {
						instance._toolItemTrigger = new A.ToolItem(
							{
								icon: 'pencil'
							}
						);

						value = instance._toolItemTrigger.get('boundingBox');

						instance.set('trigger', value);
					}

					return value;
				}
			}
		};

		A.extend(
			ColorPicker,
			A.ContextOverlay,
			{
				renderUI: function() {
					var instance = this;

					var toolTrigger = instance._toolItemTrigger;

					if (toolTrigger && !toolTrigger.get('rendered')) {
						toolTrigger.render(instance.get('boundingBox').get('parentNode'));
					}

					instance._renderContainer();
					instance._renderSliders();
					instance._renderControls();
				},

				bindUI: function() {
					var instance = this;

					ColorPicker.superclass.bindUI.apply(this, arguments);

					instance._createEvents();

					instance._colorCanvas.on('mousedown', instance._onCanvasMouseDown, instance);

					instance._colorPicker.on('drag:start', instance._onThumbDragStart, instance);

					instance._colorPicker.after('drag:drag', instance._afterThumbDrag, instance);
					instance._hueSlider.after('valueChange', instance._afterValueChange, instance);

					var formNode = instance._colorForm.get('contentBox');

					formNode.delegate('change', A.bind(instance._onFormChange, instance), 'input');

					instance.after('hexChange', instance._updateRGB);
					instance.after('rgbChange', instance._updateRGB);

					instance._colorSwatchOriginal.on('click', instance._restoreRGB, instance);

					instance.after('visibleChange', instance._afterVisibleChangeCP);
				},

				syncUI: function() {
					var instance = this;

					instance._updatePickerOffset();

					var rgb = instance.get('rgb');

					instance._updateControls();

					instance._updateOriginalRGB();
				},

				_afterThumbDrag: function(event) {
					var instance = this;

					var value = instance._translateOffset(event.pageX, event.pageY);

					if (!instance._preventDragEvent) {
						instance.fire(
							'colorChange',
							{
								ddEvent: event
							}
						);
					}

					instance._canvasThumbXY = value;
				},

				_afterValueChange: function(event) {
					var instance = this;

					if (event.src != 'controls') {
						instance.fire(
							'colorChange',
							{
								slideEvent: event
							}
						);
					}
				},

				_afterVisibleChangeCP: function(event) {
					var instance = this;

					if (event.newVal) {
						instance._hueSlider.syncUI();
					}

					instance._updateOriginalRGB();
				},

				_convertOffsetToValue: function(x, y) {
					var instance = this;

					if (isArray(x)) {
						return instance._convertOffsetToValue.apply(instance, x);
					}

					var size = instance.get('pickersize');

					x = Math.round(((x * size / 100)));
					y = Math.round((size - (y * size / 100)));

					return [x, y];
				},

				_convertValueToOffset: function(x, y) {
					var instance = this;

					if (isArray(x)) {
						return instance._convertValueToOffset.apply(instance, x);
					}

					x = Math.round(x + instance._offsetXY[0]);
					y = Math.round(y + instance._offsetXY[1]);

					return [x, y];
				},

				_createEvents: function() {
					var instance = this;

					instance.publish(
						'colorChange',
						{
							defaultFn: instance._onColorChange
						}
					);
				},

				_getHuePicker: function() {
					var instance = this;

					var size = instance._getPickerSize();
					var hue = (size - instance._hueSlider.get('value')) / size;

					hue = Math.round(hue * 360);

					return (hue === 360) ? 0 : hue;
				},

				_getPickerSize: function() {
					var instance = this;

					if (!instance._pickerSize) {
						var colorCanvas = instance._colorCanvas;
						var pickerSize = colorCanvas.get('offsetWidth');

						if (!pickerSize) {
							pickerSize = colorCanvas.getComputedStyle('width');
						}

						pickerSize = parseInt(pickerSize, 10);

						var width = instance._pickerThumb.get('offsetWidth');

						pickerSize -= width;

						instance._pickerSize = pickerSize;
					}

					return instance._pickerSize;
				},

				_getSaturationPicker: function() {
					var instance = this;

					return instance._canvasThumbXY[0] / instance._getPickerSize();
				},

				_getThumbOffset: function() {
					var instance = this;

					if (!instance._thumbOffset) {
						var pickerThumb = instance._pickerThumb;

						var height = pickerThumb.get('offsetHeight');
						var width = pickerThumb.get('offsetWidth');

						instance._thumbOffset = [Math.floor(width / 2), Math.floor(height / 2)];
					}

					return instance._thumbOffset;
				},

				_getValuePicker: function() {
					var instance = this;

					var size = instance._getPickerSize();

					return ((size - instance._canvasThumbXY[1])) / size;
				},

				_onCanvasMouseDown: function(event) {
					var instance = this;

					instance._setDragStart(event.pageX, event.pageY);

					event.halt();

					instance.fire(
						'colorChange',
						{
							ddEvent: event
						}
					);
				},

				_onColorChange: function(event) {
					var instance = this;

					var hue = instance._getHuePicker();

					var saturation = instance._getSaturationPicker();
					var value = instance._getValuePicker();

					var rgb = Color.hsv2rgb(hue, saturation, value);

					if (event.src != 'controls') {
						instance.set('rgb', rgb);
					}

					instance._updateControls();

					if (!event.ddEvent) {
						if (!event.slideEvent) {
							instance._updateHue();
							instance._updatePickerThumb();

							hue = instance._getHuePicker();
						}

						var canvasRGB = Color.hsv2rgb(hue, 1, 1);

						instance._updateCanvas(canvasRGB);
					}

					instance._updateColorSwatch();
				},

				_onFormChange: function(event) {
					var instance = this;

					var input = event.currentTarget;

					var colorKey = input.get('id');

					if (colorKey != 'hex') {
						colorKey = 'rgb.' + colorKey;
					}

					instance.set(colorKey, input.val());
				},

				_onThumbDragStart: function(event) {
					var instance = this;

					instance._updatePickerOffset();
				},

				_renderContainer: function() {
					var instance = this;

					if (!instance._pickerContainer) {
						var container = new A.Panel(
							{
								tools: [
									{
										icon: 'close',
										id: 'close',
										handler: {
											fn: instance.hide,
											context: instance
										}
									}
								]
							}
						)
						.render(instance.get('contentBox'));

						var bodyNode = container.bodyNode;

						bodyNode.addClass(CSS_CONTAINER);

						instance._pickerContainer = bodyNode;
					}
				},

				_renderControls: function() {
					var instance = this;

					instance._colorSwatch = A.Node.create(TPL_SWATCH_CONTAINER);
					instance._colorSwatchCurrent = A.Node.create(TPL_SWATCH_CURRENT);
					instance._colorSwatchOriginal = A.Node.create(TPL_SWATCH_ORIGINAL);

					instance._colorSwatch.appendChild(instance._colorSwatchCurrent);
					instance._colorSwatch.appendChild(instance._colorSwatchOriginal);

					instance._pickerContainer.appendChild(instance._colorSwatch);

					var strings = instance.get('strings');

					var form = new A.Form(
						{
							labelAlign: 'left'
						}
					).render(instance._pickerContainer);

					form.add(
						[
							{
								id: 'red',
								labelText: strings.R,
								size: 3
							},
							{
								id: 'green',
								labelText: strings.G,
								size: 3
							},
							{
								id: 'blue',
								labelText: strings.B,
								size: 3
							},
							{
								id: 'hex',
								labelText: strings.HEX,
								size: 6
							}
						],
						true
					);

					form.get('boundingBox').addClass(CSS_CONTROLS_CONTAINER);

					instance._colorForm = form;
				},

				_renderSliders: function() {
					var instance = this;

					var thumbCanvas = A.substitute(
						TPL_THUMB_CANVAS,
						{
							thumbImage: instance.get('images.PICKER_THUMB')
						}
					);

					var thumbHue = A.substitute(
						TPL_THUMB_HUE,
						{
							thumbImage: instance.get('images.HUE_THUMB')
						}
					);

					instance._colorCanvas = A.Node.create(TPL_CANVAS);
					instance._pickerThumb = A.Node.create(thumbCanvas);

					instance._hueCanvas = A.Node.create(TPL_HUE_CANVAS);
					instance._hueThumb = A.Node.create(thumbHue);

					var hueThumbImage = instance._hueThumb.get('firstChild');

					instance._colorCanvas.appendChild(instance._pickerThumb);
					instance._hueCanvas.appendChild(instance._hueThumb);

					instance._pickerContainer.appendChild(instance._colorCanvas);

					var size = instance.get('pickersize');

					instance._colorPicker = new A.DD.Drag(
						{
							node: instance._pickerThumb
						}
					)
					.plug(
						A.Plugin.DDConstrained,
						{
							constrain2node: instance._colorCanvas
						}
					);

					instance._hueSlider = new A.Slider(
						{
							railSize: instance._hueCanvas.getComputedStyle('height'),
							axis: 'y',
							rail: instance._hueCanvas,
							min: 0,
							max: size,
							thumb: instance._hueThumb,
							thumbImage: hueThumbImage
						}
					);

					instance._hueSlider.render(instance._pickerContainer);
				},

				_restoreRGB: function(event) {
					var instance = this;

					instance.set('rgb', instance._oldRGB);
					instance._updateHue();
					instance._updatePickerThumb();
					instance._updateColorSwatch();

					instance.fire('colorChange');
				},

				_setDragStart: function(x, y) {
					var instance = this;

					if (isArray(x)) {
						return instance._setDragStart.apply(instance, x);
					}

					var dd = instance._colorPicker;

					dd._dragThreshMet = true;
					dd._fixIEMouseDown();

					A.DD.DDM.activeDrag = dd;

					var xy = dd.get('dragNode').getXY();

					var thumbOffset = instance._getThumbOffset();

					xy[0] += thumbOffset[0];
					xy[1] += thumbOffset[1];

					dd._setStartPosition(xy);
					dd.set('activeHandle', dd.get('dragNode'));

					dd.start();
					dd._alignNode([x, y]);
				},

				_translateOffset: function(x, y) {
					var instance = this;

					var offsetXY = instance._offsetXY;
					var offset = [];

					offset[0] = Math.round(x - offsetXY[0]);
					offset[1] = Math.round(y - offsetXY[1]);

					return offset;
				},

				_updateCanvas: function(rgb) {
					var instance = this;

					rgb = rgb || instance.get('rgb');

					instance._colorCanvas.setStyle('backgroundColor', 'rgb(' + [rgb.red, rgb.green, rgb.blue].join(',') + ')');
				},

				_updateColorSwatch: function(rgb) {
					var instance = this;

					rgb = rgb || instance.get('rgb');

					instance._colorSwatchCurrent.setStyle('backgroundColor', 'rgb(' + [rgb.red, rgb.green, rgb.blue].join(',') + ')');
				},

				_updateControls: function() {
					var instance = this;

					var colors = instance.get('colors');

					instance._colorForm.set('values', colors);
				},

				_updateHue: function() {
					var instance = this;

					var size = instance._getPickerSize();
					var hue = instance.get('hsv.hue');

					hue = size - Math.round(hue / 360 * size);

					if (hue === size) {
						hue = 0;
					}

					instance._hueSlider.set(
						'value',
						 hue,
						{
							src: 'controls'
						}
					);
				},

				_updateOriginalColorSwatch: function(rgb) {
					var instance = this;

					rgb = rgb || instance.get('rgb');

					instance._colorSwatchOriginal.setStyle('backgroundColor', 'rgb(' + [rgb.red, rgb.green, rgb.blue].join(',') + ')');
				},

				_updateOriginalRGB: function() {
					var instance = this;

					instance._oldRGB = instance.get('rgb');
					instance._updateOriginalColorSwatch(instance._oldRGB);
				},

				_updatePickerOffset: function() {
					var instance = this;

					instance._offsetXY = instance._colorCanvas.getXY();
				},

				_updatePickerThumb: function() {
					var instance = this;

					instance._updatePickerOffset();

					var hsv = instance.get('hsv');

					var size = instance.get('pickersize');

					var saturation = hsv.saturation = Math.round(hsv.saturation * 100);
					var value = hsv.value = Math.round(hsv.value * 100);

					var xy = instance._convertOffsetToValue(saturation, value);

					xy = instance._convertValueToOffset(xy);

					instance._canvasThumbXY = xy;

					var dd = instance._colorPicker;

					instance._preventDragEvent = true;

					dd._setStartPosition(dd.get('dragNode').getXY());
		            dd._alignNode(xy, true);

					instance._preventDragEvent = false;
				},

				_updateRGB: function(event) {
					var instance = this;

					if (event.subAttrName || event.attrName == 'hex') {
						instance.fire(
							'colorChange',
							{
								src: 'controls'
							}
						);
					}
				},

				_canvasThumbXY: [0, 0],
				_offsetXY: [0, 0]
			}
		);

		A.ColorPicker = ColorPicker;
	},
	'0.1a',
	{
		requires: ['context-overlay','dd', 'panel', 'slider', 'substitute', 'tool-item'],
		use: []
	}
);AUI().add(
	'combobox',
	function(A) {
		var Lang = A.Lang,

			getClassName = A.ClassNameManager.getClassName,

			NAME = 'combobox',

			CSS_COMBOBOX = getClassName(NAME);

		var Combobox = function() {
			Combobox.superclass.constructor.apply(this, arguments);
		};

		Combobox.NAME = NAME;

		Combobox.ATTRS = {
			field: {
			},

			fieldWidget: {
				value: A.Textfield
			},

			node: {
				getter: function() {
					var instance = this;

					if (instance._field) {
						return instance._field.get('node');
					}
				}
			},

			tools: {
				value: ['circle-triangle-b'],
				validator: Lang.isArray
			}
		};

		A.extend(
			Combobox,
			A.Component,
			{
				renderUI: function() {
					var instance = this;

					Combobox.superclass.renderUI.call(instance);

					instance._renderField();
					instance._renderTools();
				},

				_renderField: function() {
					var instance = this;

					var contentBox = instance.get('contentBox');

					var field = instance.get('field');
					var fieldWidget = instance.get('fieldWidget');

					instance._field = new fieldWidget(field).render();

					contentBox.appendChild(instance._field.get('boundingBox'))
				},

				_renderTools: function() {
					var instance = this;

					var tools = instance.get('tools');

					if (tools.length) {
						var toolSet = new A.ToolSet(
							{
								tools: tools
							}
						)
						.render(instance.get('contentBox'));

						instance.toolset = toolSet;
					}
				}
			}
		);

		A.Combobox = Combobox;
	},
	'0.1a',
	{
		requires: ['textfield', 'tool-set'],
		use: []
	}
);AUI().add(
	'component-overlay',
	function(A) {
		A.ComponentOverlay = A.Base.build('overlay', A.Component, [A.WidgetPosition, A.WidgetStack, A.WidgetPositionExt, A.WidgetStdMod]);
	},
	'0.1a',
	{
		requires: ['component', 'widget-position', 'widget-stack', 'widget-position-ext', 'widget-stdmod'],
		use: []
	}
);AUI().add(
	'component',
	function(A) {
		var Lang = A.Lang,

			getClassName = A.ClassNameManager.getClassName,

			NAME = 'component',

			CSS_COMPONENT = getClassName(NAME),

			CSS_HELPER_HIDDEN = getClassName('helper', 'hidden');

		var Component = function(config) {
			var instance = this;

			instance._originalConfig = config;

			Component.superclass.constructor.apply(this, arguments);

			var render = instance.get('render');

			if (render) {
				if (render === true) {
					render = null;
				}

				instance.render(render);
			}
		};

		Component.NAME = 'component';

		Component.ATTRS = {
			cssClass: {
				lazyAdd: false,
				value: null
			},
			hideClass: {
				value: CSS_HELPER_HIDDEN
			},
			owner: {
				validator: function(value) {
					var instance = this;

					return value instanceof A.Widget || value === null;
				}
			},
			relayEvents: {
				value: true
			},
			render: {
				value: false,
				writeOnce: true
			}
		};

		A.extend(
			Component,
			A.Widget,
			{
				initializer: function(config) {
					var instance = this;

					if (config) {
						instance._uiSetCssClass(config.cssClass);
					}

					instance._setOwnerComponent(instance.get('ownerComponent'));
					instance._setRelayEvents(instance.get('relayEvents'));

					instance._setComponentClassNames();

					instance.after('cssClassChange', instance._afterCssClassChange);
					instance.after('destroy', instance._afterComponentDestroy);
					instance.after('ownerChange', instance._afterComponentOwnerChange);
					instance.after('relayEventsChange', instance._afterComponentRelayEventsChange);
					instance.after('visibleChange', instance._afterComponentVisibleChange);
				},

				clone: function(config) {
					var instance = this;

					config = config || {};

					config.id = config.id || A.guid();

					A.mix(config, instance._originalConfig);

					return new instance.constructor(config);
				},

				toggle: function() {
					var instance = this;

					return instance.set('visible', !instance.get('visible'));
				},

				_afterComponentDestroy: function(event) {
					var instance = this;

					try {
						instance.get('boundingBox').remove();
					}
					catch (e) {}
				},

				_afterComponentOwnerChange: function(event) {
					var instance = this;

					instance._setOwnerComponent(event.newVal);
				},

				_afterComponentRelayEventsChange: function(event) {
					var instance = this;

					instance._setRelayEvents(event.newVal);
				},

				_afterComponentVisibleChange: function(event) {
					var instance = this;

					var hideClass = instance.get('hideClass');

					if (hideClass !== false) {
						var boundingBox = instance.get('boundingBox');

						var action = 'addClass';

						if (event.newVal) {
							action = 'removeClass';
						}

						boundingBox[action](hideClass || CSS_HELPER_HIDDEN);
					}
				},

				_afterCssClassChange: function(event) {
					var instance = this;

					instance._uiSetCssClass(event.newVal, event.prevVal);
				},

				_relayEvents: function() {
					var instance = this;

					Component.superclass.fire.apply(instance, arguments);

					var ownerComponent = instance._ownerComponent;

					if (ownerComponent) {
						ownerComponent.fire.apply(ownerComponent, arguments);
					}
				},

				_setComponentClassNames: function() {
					var instance = this;

					var classes = instance._getClasses();
					var name;
					var buffer = [];

					for (var i = classes.length - 4; i >= 0; i--) {
						var name = classes[i].NAME.toLowerCase();

						buffer.push(getClassName(name, 'content'));
					}

					instance.get('contentBox').addClass(buffer.join(' '));
				},

				_setRelayEvents: function(relayEvents) {
					var instance = this;

					if (relayEvents) {
						instance.fire = instance._relayEvents;
					}
					else {
						instance.fire = Component.superclass.fire;
					}
				},

				_setOwnerComponent: function(ownerComponent) {
					var instance = this;

					instance._ownerComponent = ownerComponent;
				},

				_uiSetCssClass: function(newVal, prevVal) {
					var instance = this;

					var prevValContent = prevVal + '-content';

					var newValContent = newVal + '-content';

					var boundingBox = instance.get('boundingBox');
					var contentBox = instance.get('contentBox');

					boundingBox.replaceClass(prevVal, newVal);
					contentBox.replaceClass(prevValContent, newValContent);
				}
			}
		);

		A.Component = Component;
	},
	'0.1a',
	{
		requires: ['widget'],
		use: []
	}
);AUI.add('context-overlay', function(A) {

var L = A.Lang,
	isString = L.isString,
	isNumber = L.isNumber,
	isObject = L.isObject,
	isBoolean = L.isBoolean,

	isNodeList = function(v) {
		return (v instanceof A.NodeList);
	},

	ALIGN = 'align',
	BL = 'bl',
	BOUNDING_BOX = 'boundingBox',
	CANCELLABLE_HIDE = 'cancellableHide',
	CONTEXT_OVERLAY = 'contextoverlay',
	CURRENT_NODE = 'currentNode',
	FOCUSED = 'focused',
	HIDE = 'hide',
	HIDE_DELAY = 'hideDelay',
	HIDE_ON = 'hideOn',
	HIDE_ON_DOCUMENT_CLICK = 'hideOnDocumentClick',
	MOUSEDOWN = 'mousedown',
	SHOW = 'show',
	SHOW_DELAY = 'showDelay',
	SHOW_ON = 'showOn',
	TL = 'tl',
	TRIGGER = 'trigger',
	VISIBLE = 'visible';

function ContextOverlay(config) {
	var instance = this;

	instance._hideTask = new A.DelayedTask(instance.hide, instance);
	instance._showTask = new A.DelayedTask(instance.show, instance);

	instance._showCallback = null;
	instance._hideCallback = null;

 	ContextOverlay.superclass.constructor.apply(this, arguments);
}

A.mix(ContextOverlay, {
	NAME: CONTEXT_OVERLAY,

	ATTRS: {
		align: {
            value: { node: null, points: [ TL, BL ] }
        },

		cancellableHide: {
			value: true,
			validador: isBoolean
		},

		currentNode: {
			valueFn: function() {
				// define default currentNode as the first item from trigger
				return this.get(TRIGGER).item(0);
			}
		},

		delay: {
			value: null,
			validator: isObject
		},

		hideOn: {
			lazyAdd: false,
			value: 'mouseout',
			validator: isString,
			setter: function(v) {
				return this._setHideOn(v);
			}
		},

		hideOnDocumentClick: {
			lazyAdd: false,
			setter: function(v) {
				return this._setHideOnDocumentClick(v);
			},
			value: true,
			validador: isBoolean
		},

		hideDelay: {
			value: 0
		},

		showOn: {
			lazyAdd: false,
			value: 'mouseover',
			validator: isString,
			setter: function(v) {
				return this._setShowOn(v);
			}
		},

		showDelay: {
			value: 0,
			validator: isNumber
		},

		trigger: {
			lazyAdd: false,
			setter: function(v) {
				if (isNodeList(v)) {
					return v;
				}
				else if (isString(v)) {
					return A.all(v);
				}

				return new A.NodeList([v]);
			}
		},

		visible: {
			value: false
		}
	}
});

A.extend(ContextOverlay, A.ComponentOverlay, {
	/*
	* Lifecycle
	*/
	bindUI: function(){
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);

		boundingBox.on(MOUSEDOWN, instance._stopTriggerEventPropagation);

		instance.before('triggerChange', instance._beforeTriggerChange);
		instance.before('showOnChange', instance._beforeShowOnChange);
		instance.before('hideOnChange', instance._beforeHideOnChange);

		instance.after('triggerChange', instance._afterTriggerChange);
		instance.after('showOnChange', instance._afterShowOnChange);
		instance.after('hideOnChange', instance._afterHideOnChange);

		boundingBox.on('click', A.bind(instance._cancelAutoHide, instance));
		boundingBox.on('mouseenter', A.bind(instance._cancelAutoHide, instance));
		boundingBox.on('mouseleave', A.bind(instance._invokeHideTaskOnInteraction, instance));
		instance.after('focusedChange', A.bind(instance._invokeHideTaskOnInteraction, instance));
	},

	destructor: function() {
		var instance = this;

		instance.get(BOUNDING_BOX).remove();
	},

	/*
	* Methods
	*/
	hide: function() {
		var instance = this;

		instance.clearIntervals();

		instance.fire('hide');

		ContextOverlay.superclass.hide.apply(instance, arguments);
	},

	show: function(event) {
		var instance = this;

		instance.clearIntervals();

		instance.updateCurrentNode(event);

		instance.refreshAlign();

		instance.fire('show');

		ContextOverlay.superclass.show.apply(instance, arguments);
	},

	toggle: function(event) {
		var instance = this;

		if (instance.get(VISIBLE)) {
			instance._hideTask.delay( instance.get(HIDE_DELAY), null, null, [event] );
		}
		else {
			instance._showTask.delay( instance.get(SHOW_DELAY), null, null, [event] );
		}
	},

	clearIntervals: function() {
		this._hideTask.cancel();
		this._showTask.cancel();
	},

	refreshAlign: function() {
		var instance = this;
		var align = instance.get(ALIGN);
		var currentNode = instance.get(CURRENT_NODE);

		if (currentNode) {
			instance._uiSetAlign(currentNode, align.points);
		}
	},

	updateCurrentNode: function(event) {
		var instance = this;
		var align = instance.get(ALIGN);
		var trigger = instance.get(TRIGGER);
		var currentTarget = null;

		if (event) {
			currentTarget = event.currentTarget;
		}

		var node = align.node || currentTarget || trigger.item(0);

		if (node) {
			instance.set(CURRENT_NODE, node);
		}
	},

	_toggle: function(event) {
		var instance = this;
		var currentTarget = event.currentTarget;

		// check if the target is different and simulate a .hide() before toggle
		if (instance._lastTarget != currentTarget) {
			instance.hide();
		}

		instance.toggle(event);

		event.stopPropagation();

		instance._lastTarget = currentTarget;
	},

	/*
	* Attribute Listeners
	*/
	_afterShowOnChange: function(event) {
		var instance = this;
		var wasToggle = event.prevVal == instance.get(HIDE_ON);

		if (wasToggle) {
			var trigger = instance.get(TRIGGER);

			// if wasToggle remove the toggle callback
			trigger.detach(event.prevVal, instance._hideCallback);
			// and re attach the hide event
			instance._setHideOn( instance.get(HIDE_ON) );
		}
	},

	_afterHideOnChange: function(event) {
		var instance = this;
		var wasToggle = event.prevVal == instance.get(SHOW_ON);

		if (wasToggle) {
			var trigger = instance.get(TRIGGER);

			// if wasToggle remove the toggle callback
			trigger.detach(event.prevVal, instance._showCallback);
			// and re attach the show event
			instance._setShowOn( instance.get(SHOW_ON) );
		}
	},

	_afterTriggerChange: function(event) {
		var instance = this;

		instance._setShowOn( instance.get(SHOW_ON) );
		instance._setHideOn( instance.get(HIDE_ON) );
	},

	_beforeShowOnChange: function(event) {
		var instance = this;
		var trigger = instance.get(TRIGGER);

		// detach the old callback
		trigger.detach(event.prevVal, instance._showCallback);
	},

	_beforeHideOnChange: function(event) {
		var instance = this;
		var trigger = instance.get(TRIGGER);

		// detach the old callback
		trigger.detach(event.prevVal, instance._hideCallback);
	},

	_beforeTriggerChange: function(event) {
		var instance = this;
		var trigger = instance.get(TRIGGER);
		var showOn = instance.get(SHOW_ON);
		var hideOn = instance.get(HIDE_ON);

		trigger.detach(showOn, instance._showCallback);
		trigger.detach(hideOn, instance._hideCallback);
		trigger.detach(MOUSEDOWN, instance._stopTriggerEventPropagation);
	},

	// cancel hide if the user does some interaction with the tooltip
	// interaction = focus, click, mouseover
	_cancelAutoHide: function(event) {
		var instance = this;

		if (instance.get(CANCELLABLE_HIDE)) {
			instance.clearIntervals();
		}

		event.stopPropagation();
	},

	_invokeHideTaskOnInteraction: function(event) {
		var instance = this;
		var cancellableHide = instance.get(CANCELLABLE_HIDE);
		var focused = instance.get(FOCUSED);

		if (!focused && !cancellableHide) {
			instance._hideTask.delay( instance.get(HIDE_DELAY) );
		}
	},

	_stopTriggerEventPropagation: function(event) {
		event.stopPropagation();
	},

	/*
	* Setters
	*/
	_setHideOn: function(eventType) {
		var instance = this;
		var trigger = instance.get(TRIGGER);
		var toggle = eventType == instance.get(SHOW_ON);

		if (toggle) {
			instance._hideCallback = A.bind(instance._toggle, instance);

			// only one attached event is enough for toggle
			trigger.detach(eventType, instance._showCallback);
		}
		else {
			var delay = instance.get(HIDE_DELAY);

			instance._hideCallback = function(event) {
				instance._hideTask.delay(delay, null, null, [event]);

				event.stopPropagation();
			};
		}

		trigger.on(eventType, instance._hideCallback);

		return eventType;
	},

	_setHideOnDocumentClick: function(value) {
		var instance = this;

		if (value) {
			A.ContextOverlayManager.register(instance);
		}
		else {
			A.ContextOverlayManager.remove(instance);
		}

		return value;
	},

	_setShowOn: function(eventType) {
		var instance = this;
		var trigger = instance.get(TRIGGER);
		var toggle = eventType == instance.get(HIDE_ON);

		if (toggle) {
			instance._showCallback = A.bind(instance._toggle, instance);

			// only one attached event is enough for toggle
			trigger.detach(eventType, instance._hideCallback);
		}
		else {
			var delay = instance.get(SHOW_DELAY);

			instance._showCallback = function(event) {
				instance._showTask.delay(delay, null, null, [event]);

				event.stopPropagation();
			};
		}

		if (eventType != MOUSEDOWN) {
			trigger.on(MOUSEDOWN, instance._stopTriggerEventPropagation);
		}
		else {
			trigger.detach(MOUSEDOWN, instance._stopTriggerEventPropagation);
		}

		trigger.on(eventType, instance._showCallback);

		return eventType;
	}
});

A.ContextOverlay = ContextOverlay;

A.ContextOverlayManager = new A.OverlayManager({});

A.on(MOUSEDOWN, function() { A.ContextOverlayManager.hideAll(); }, A.getDoc());

}, '0.1a', { requires: [ 'aui-base', 'overlay', 'overlay-manager', 'delayed-task' ] });AUI.add('context-panel', function(A) {

var L = A.Lang,
	isBoolean = L.isBoolean,
	isString = L.isString,
	isObject = L.isObject,

	ALIGN = 'align',
	ANIM = 'anim',
	ARROW = 'arrow',
	BACKGROUND_COLOR = 'backgroundColor',
	BLANK = '',
	BOUNDING_BOX = 'boundingBox',
	CLICK = 'click',
	CONTENT_BOX = 'contentBox',
	CONTEXTPANEL = 'contextpanel',
	DEFAULT = 'default',
	DOT = '.',
	END = 'end',
	HIDDEN = 'hidden',
	INNER = 'inner',
	OPACITY = 'opacity',
	POINTER = 'pointer',
	SHOW_ARROW = 'showArrow',
	STATE = 'state',
	STYLE = 'style',
	VISIBLE = 'visible',

	BC = 'bc',
	BL = 'bl',
	BR = 'br',
	CC = 'cc',
	LB = 'lb',
	LC = 'lc',
	LT = 'lt',
	RB = 'rb',
	RC = 'rc',
	RL = 'rl',

	getCN = A.ClassNameManager.getClassName,

	CSS_CONTEXTPANEL = getCN(CONTEXTPANEL),
	CSS_CONTEXTPANEL_ARROW = getCN(CONTEXTPANEL, ARROW, BLANK),
	CSS_CONTEXTPANEL_HIDDEN = getCN(CONTEXTPANEL, HIDDEN),
	CSS_CONTEXTPANEL_POINTER = getCN(CONTEXTPANEL, POINTER),
	CSS_CONTEXTPANEL_POINTER_INNER = getCN(CONTEXTPANEL, POINTER, INNER),
	CSS_STATE_DEFAULT = getCN(STATE, DEFAULT),

	TPL_POINTER = '<div class="' + [ CSS_STATE_DEFAULT, CSS_CONTEXTPANEL_POINTER ].join(' ') + '"></div>',
	TPL_POINTER_INNER = '<div class="' + CSS_CONTEXTPANEL_POINTER_INNER + '"></div>';

function ContextPanel(config) {
 	ContextPanel.superclass.constructor.apply(this, arguments);
}

A.mix(ContextPanel, {
	NAME: CONTEXTPANEL,

	ATTRS: {
		anim: {
			lazyAdd: false,
			value: {
				show: false
			},
			setter: function(v) {
				return this._setAnim(v);
			}
		},

		arrow: {
			value: null,
			validator: isString
		},

		hideOn: {
			value: CLICK
		},

		showOn: {
			value: CLICK
		},

		showArrow: {
			lazyAdd: false,
			value: true,
			validator: isBoolean
		},

		stack: {
			lazyAdd: false,
			value: true,
			setter: function(v) {
				return this._setStack(v);
			},
			validator: isBoolean
		}
	}
});

A.extend(ContextPanel, A.ContextOverlay, {
	/*
	* Lifecycle
	*/
	bindUI: function() {
		var instance = this;

		instance.after('showArrowChange', instance._afterShowArrowChange);

		instance.before('show', instance._beforeShow);

		ContextPanel.superclass.bindUI.apply(instance, arguments);
	},

	renderUI: function() {
		var instance = this;

		instance._renderElements();
	},

	syncUI: function() {
		var instance = this;

		instance._syncElements();
	},

	/*
	* Methods
	*/
	align: function (node, points) {
		var instance = this;

		ContextPanel.superclass.align.apply(this, arguments);

		instance._syncElements();
	},

	fixPointerColor: function() {
		var instance = this;
		var contentBox = instance.get(CONTENT_BOX);
		var pointer = contentBox.query(DOT+CSS_CONTEXTPANEL_POINTER_INNER);

		pointer.removeAttribute(STYLE);

		var bColor = contentBox.getStyle(BACKGROUND_COLOR);
		var border = 'borderBottomColor';

		var right = [
			DOT+CSS_CONTEXTPANEL_ARROW+RB,
				DOT+CSS_CONTEXTPANEL_ARROW+RC,
					DOT+CSS_CONTEXTPANEL_ARROW+RL
		]
		.join(',');

		var bottom = [
			DOT+CSS_CONTEXTPANEL_ARROW+BR,
				DOT+CSS_CONTEXTPANEL_ARROW+BC,
					DOT+CSS_CONTEXTPANEL_ARROW+BL
		]
		.join(',');

		var left = [
			DOT+CSS_CONTEXTPANEL_ARROW+LB,
				DOT+CSS_CONTEXTPANEL_ARROW+LC,
					DOT+CSS_CONTEXTPANEL_ARROW+LT
		]
		.join(',');

		if (contentBox.test(right)) {
			border = 'borderLeftColor';
		}
		else if (contentBox.test(bottom)) {
			border = 'borderTopColor';
		}
		else if (contentBox.test(left)) {
			border = 'borderRightColor';
		}

		pointer.setStyle(border, bColor);
	},

	getAlignPoint: function() {
		var instance = this;
		var overlayPoint = instance.get(ALIGN).points[0];

		if (overlayPoint == CC) {
			// CC is not a valid position for the arrow
			overlayPoint = BC;
		}

		return instance.get(ARROW) || overlayPoint;
	},

	hide: function(event) {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);

		if(instance._hideAnim) {
			var visible = instance.get(VISIBLE);

			if (visible) {
				instance._hideAnim.run();

				instance._hideAnim.on(END, function() {
					ContextPanel.superclass.hide.apply(instance, arguments);
				});
			}
		}
		else {
			ContextPanel.superclass.hide.apply(instance, arguments);
		}
	},

	_renderElements: function() {
		var instance = this;
		var contentBox = instance.get(CONTENT_BOX);
		var align = instance.get(ALIGN);
		var overlayPoint = align.points[0];

		contentBox.addClass(CSS_STATE_DEFAULT);

		instance._pointerNode = A.Node.create(TPL_POINTER).append(TPL_POINTER_INNER);

		contentBox.append(
			instance._pointerNode
		);
	},

	_syncElements: function() {
		var instance = this;
		var contentBox = instance.get(CONTENT_BOX);
		var pointerNode = instance._pointerNode;
		var overlayPoint = instance.getAlignPoint();

		if (instance.get(SHOW_ARROW)) {
			pointerNode.removeClass(CSS_CONTEXTPANEL_HIDDEN);
			contentBox.removeClass(CSS_CONTEXTPANEL_ARROW + instance._lastOverlayPoint);
			contentBox.addClass(CSS_CONTEXTPANEL_ARROW + overlayPoint);

			instance.fixPointerColor();
		}
		else {
			pointerNode.addClass(CSS_CONTEXTPANEL_HIDDEN);
		}

		instance._lastOverlayPoint = overlayPoint;
	},

	/*
	* Setters
	*/
	_setStack: function(value) {
		var instance = this;

		if (value) {
			A.ContextPanelManager.register(instance);
		}
		else {
			A.ContextPanelManager.remove(instance);
		}

		return value;
	},

	_setAnim: function(value) {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);

		if (value) {
			var defaults = {
				node: boundingBox,
				duration: 0.1
			};

			var showOptions = A.merge(defaults, {
	    		from: { opacity: 0 },
	    		to: { opacity: 1 }
			});

			var hideOptions = A.merge(defaults, {
				from: { opacity: 1 },
	    		to: { opacity: 0 }
			});

			if (isObject(value)) {
				// loading user settings for animation
				showOptions = A.merge(showOptions, value.show);
				hideOptions = A.merge(hideOptions, value.hide);
			}

			instance._showAnim = new A.Anim(showOptions);
			instance._hideAnim = new A.Anim(hideOptions);

			// if anim.show or anim.hide === false, cancel respective animation
			if (isObject(value)) {
				if (value.show === false) {
					instance._showAnim = null;
				}

				if (value.hide === false) {
					instance._hideAnim = null;
				}
			}
		}

		return value;
	},

	/*
	* Listeners
	*/
	_beforeShow: function(event) {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);
		var visible = instance.get(VISIBLE);

		if(!visible && instance._showAnim) {
			boundingBox.setStyle(OPACITY, 0);

			instance._showAnim.run();
		}
		else {
			boundingBox.setStyle(OPACITY, 1);
		}
	},

	_afterShowArrowChange: function() {
		var instance = this;

		instance._syncElements();
	}
});

A.ContextPanel = ContextPanel;

A.ContextPanelManager = new A.OverlayManager({
	zIndexBase: 1000
});

}, '0.1a', { requires: [ 'context-overlay', 'context-panel-css' ] });AUI().add(
	'data-set',
	function(A) {
		var Lang = A.Lang;

		var DataSet = function() {
			DataSet.superclass.constructor.apply(this, arguments);
		};

		DataSet.NAME = 'dataset';

		DataSet.ATTRS = {
			keys: {
				getter: function(value) {
					var instance = this;

					return instance.keys;
				}
			},

			first: {
				getter: function() {
					var instance = this;

					var values = instance.values;

					return values[0];
				}
			},

			includeFunctions: {
				value: false
			},

			items: {
				value: null,
				getter: function() {
					var instance = this;

					return instance.collection || {};
				}
			},

			last: {
				getter: function() {
					var instance = this;

					var values = instance.values;

					return values[values.length - 1];
				}
			},

			getKey: {
				lazyAdd: false,
				value: null,
				getter: function(value) {
					var instance = this;

					return value || instance.getKey;
				},
				setter: function(value) {
					var instance = this;

					if (Lang.isFunction(value)) {
						instance.getKey = value;
					}

					return instance.getKey;
				}
			},

			values: {
				getter: function(value) {
					var instance = this;

					return instance.values;
				},
				readOnly: true
			}
		};

		A.extend(
			DataSet,
			A.Base,
			{
				initializer: function() {
					var instance = this;

					instance.collection = {};
					instance.keys = [];
					instance.values = [];

					instance.length = 0;
				},

				add: function(key, obj) {
					var instance = this;

					if (arguments.length == 1) {
						obj = key;
						key = instance.getKey(obj);
					}

					var includeFunctions = instance.get('includeFunctions');

					if (!Lang.isNull(key) && !Lang.isUndefined(key)) {
						var prevVal = instance.collection[key];

						if (!Lang.isUndefined(prevVal)) {
							return instance.replace(key, obj);
						}

						if (includeFunctions || !Lang.isFunction(obj)) {
							instance.collection[key] = obj;
						}
					}

					instance.keys.push(key);
					instance.values.push(obj);

					var length = (++instance.length);

					instance.fire(
						'add',
						{
							index: length - 1,
							attrName: key,
							item: obj,
							newVal: obj
						}
					);
				},

				addAll: function(obj) {
					var instance = this;

					var args = arguments;
					var length = args.length;

					if (length == 1) {
						args = obj;
					}

					if (length > 1 || Lang.isArray(obj)) {
						length = args.length;

						for (var i = 0; i < length; i++) {
							instance.add(args[i]);
						}
					}
					else {
						for (var i in obj) {
							var item = obj[i];

							instance.add(i, item);
						}
					}
				},

				clear: function() {
					var instance = this;

					instance.collection = {};
					instance.keys = [];
					instance.values = [];
					instance.length = 0;

					instance.fire('clear');
				},

				clone: function() {
					var instance = this;

					var clone = new DataSet();

					var keys = instance.keys;
					var values = instance.values;

					var length = values.length;

					for (var i = 0; i < length; i++) {
						clone.add(keys[i], values[i]);
					}

					clone.set('getKey', instance.get('getKey'));

					return clone;
				},

				contains: function(obj) {
					var instance = this;

					return instance.indexOf(obj) > -1;
				},

				containsKey: function(key) {
					var instance = this;

					return !(Lang.isUndefined(instance.collection[key]))
				},

				each: function(fn, context) {
					var instance = this;

					return instance._each(instance.values, fn, context);
				},

				eachKey: function(fn, context) {
					var instance = this;

					var keys = instance.keys;

					return instance._each(keys, fn, context);
				},

				filter: function(fn, context) {
					var instance = this;

					var filtered = new DataSet();

					filtered.set('getKey', instance.get('getKey'));

					var collection = instance.collection;
					var keys = instance.keys;
					var values = instance.values;

					context = context || instance;

					var filteredDataSet = filtered.collection;
					var filteredValues = filtered.values;

					var length = values.length;
					var item;

					for (var i = 0; i < length; i++) {
						item = values[i];

						if (fn.call(context, item, i, collection)) {
							filtered.add(keys[i], item);
						}
					}

					filtered.length = filteredValues.length;

					return filtered;
				},

				filterBy: function(key, value, startsWith, caseSensitive) {
					var instance = this;

					if (Lang.isUndefined(value) ||
					 	Lang.isNull(value) ||
						((Lang.isArray(value) ||
							Lang.isString(value)) && !value.length)) {

						return instance.clone();
					}

					value = instance._generateRegEx(value, startsWith, caseSensitive);

					var keyFilter = A.bind(instance._keyFilter, instance, key, value);

					return instance.filter(keyFilter);
				},

				find: function(fn, context) {
					var instance = this;

					return A.Array.find(instance.values, fn, context);
				},

				findIndex: function(fn, context, start) {
					var instance = this;

					var collection = instance.collection;
					var values = instance.values;
					var length = instance.length;

					start = start || 0;

					for (var i = start; i < length; i++) {
						if (fn.call(context, values[i], i, collection)) {
							return i;
						}
					}

					return -1;
				},

				findIndexBy: function(key, value, start, startsWith, caseSensitive) {
					var instance = this;

					if (Lang.isUndefined(value) ||
					 	Lang.isNull(value) ||
						((Lang.isArray(value) ||
							Lang.isString(value)) && !value.length)) {

						return -1;
					}

					value = instance._generateRegEx(value, startsWith, caseSensitive);

					var keyFilter = A.bind(instance._keyFilter, instance, key, value);

					return instance.findIndex(keyFilter, null, start);
				},

				getKey: function(obj) {
					var instance = this;

					return (obj.get && obj.get('id')) || obj.id;
				},

				indexOf: function(obj) {
					var instance = this;

					return A.Array.indexOf(instance.values, obj);
				},

				indexOfKey: function(key) {
					var instance = this;

					return A.Array.indexOf(instance.keys, key);
				},

				insert: function(index, key, obj) {
					var instance = this;

					if (arguments.length == 2) {
						obj = arguments[1];
						key = instance.getKey(obj);
					}

					if (instance.containsKey(key)) {
						instance.removeKey(key);
					}

					if (index >= instance.length) {
						return instance.add(key, obj);
					}

					instance.keys.splice(index, 0, key);
					instance.values.splice(index, 0, obj);

					instance.length++;

					if (!Lang.isUndefined(key) && !Lang.isNull(key)) {
						instance.collection[key] = obj;
					}

					instance.fire(
						'add',
						{
							index: index,
							attrName: key,
							item: obj,
							newVal: obj
						}
					);
				},

				invoke: function(method, args) {
					var instance = this;

					var values = instance.values;
					var length = values.length;

					if (!args) {
						args = [];
					}
					else {
						args = [].concat(args);
					}

					for (var i = 0; i < length; i++) {
						var item = values[i];
						var itemMethod = item && item[method];

						if (Lang.isFunction(itemMethod)) {
							itemMethod.apply(item, args);
						}
					}

					return instance;
				},

				item: function(key) {
					var instance = this;

					var item;

					if (Lang.isNumber(key)) {
						var values = instance.values;

						item = values[key];
					}
					else {
						item = instance.collection[key];
					}

					return item;
				},

				keySort: function(direction, fn) {
					var instance = this;

					instance._sortBy('key', direction, fn || instance._keySorter);
				},

				remove: function(obj) {
					var instance = this;

					var index = instance.indexOf(obj);

					return instance.removeAt(index);
				},

				removeAt: function(index) {
					var instance = this;

					if (index < instance.length && index >= 0) {
						var collection = instance.collection;
						var keys = instance.keys;
						var values = instance.values;

						var obj = values[index];

						values.splice(index, 1);

						var key = keys[index];

						if (!Lang.isUndefined(key)) {
							delete collection[key];
						}

						keys.splice(index, 1);

						instance.length--;

						instance.fire(
							'remove',
							{
								index: index,
								attrName: key,
								item: obj,
								prevVal: obj
							}
						);
					}
				},

				removeKey: function(key) {
					var instance = this;

					var index = instance.indexOfKey(key);

					return instance.removeAt(index);
				},

				replace: function(key, obj) {
					var instance = this;

					if (arguments.length == 1) {
						obj = key;
						key = instance.getKey(obj);
					}

					var prevVal = instance.collection[key];

					if (Lang.isUndefined(key) || Lang.isNull(key) || Lang.isUndefined(prevVal)) {
						return instance.add(key, obj);
					}

					var index = instance.indexOfKey(key);

					instance.collection[key] = obj;

					instance.fire(
						'replace',
						{
							attrName: key,
							index: index,
							item: obj,
							prevVal: prevVal,
							newVal: obj
						}
					);
				},

				size: function() {
					var instance = this;

					return instance.length;
				},

				slice: function(start, end) {
					var instance = this;

					var values = instance.values;

					return values.slice.apply(values, arguments);
				},

				sort: function(direction, fn) {
					var instance = this;

					instance._sortBy('value', direction, fn);
				},

				_each: function(arr, fn, context) {
					var instance = this;

					var values = arr.slice(0);
					var length = values.length;

					context = context || instance;

					for (var i = 0; i < length; i++) {
						if (fn.call(context, values[i], i, values) === false) {
							return false;
						}
					}

					return true;
				},

				_generateRegEx: function(value, startsWith, caseSensitive) {
					var instance = this;

					if (!(value instanceof RegExp)) {
						value = String(value);

						var regExBuffer = [];

						if (startsWith !== false) {
							regExBuffer.push('^');
						}

						regExBuffer.push(value);

						var options;

						if (!caseSensitive) {
							options = 'i';
						}

						value = new RegExp(regExBuffer.join(''), options);
					}

					return value;
				},

				_keyFilter: function(key, value, item, index, collection) {
					var instance = this;

					return item && value.test(item[key]);
				},

				_keySorter: function(a, b) {
					var instance = this;

					var keyA = String(a).toLowerCase();
					var keyB = String(b).toLowerCase();

					var returnValue = 0;

					if (keyA > keyB) {
						returnValue = 1;
					}
					else if (keyA < keyB) {
						returnValue = -1;
					}

					return returnValue;
				},

				_sortBy: function(property, direction, fn) {
					var instance = this;

					var asc = 1;
					var tempValues = [];
					var keys = instance.keys;
					var values = instance.values;

					var length = values.length;

					fn = fn || A.Array.numericSort;

					if (String(direction).toLowerCase() == 'desc') {
						asc = -1;
					}

					for (var i = 0; i < length; i++) {
						tempValues.push(
							{
								key: keys[i],
								value: values[i],
								index: i
							}
						);
					}

					tempValues.sort(
						function(a, b) {
							var value = fn(a[property], b[property]) * asc;

							if (value === 0) {
								value = 1;

								if (a.index < b.index) {
									value = -1;
								}
							}

							return value;
						}
					);

					length = tempValues.length;

					var collection = {};

					for (var i = 0; i < length; i++) {
						var item = tempValues[i];
						var key = item.key;
						var value = item.value;

						collection[key] = value;
						keys[i] = key;
						values[i] = value;
					}

					instance.collection = collection;

					instance.fire('sort');
				}
			}
		);

		A.DataSet = DataSet;
	},
	'0.1a',
	{
		requires: ['oop', 'collection', 'base'],
		use: []
	}
);AUI.add('date-picker-select', function(A) {

var L = A.Lang,
	isArray = L.isArray,

	nodeSetter = function(v) {
		return A.get(v);
	},

	createSelect = function() {
		return A.Node.create(SELECT_TPL);
	},

	APPEND_ORDER = 'appendOrder',
	BASE_NAME = 'baseName',
	BLANK = '',
	BODY = 'body',
	BUTTON = 'button',
	CALENDAR = 'calendar',
	CLEARFIX = 'clearfix',
	CURRENT_DAY = 'currentDay',
	CURRENT_MONTH = 'currentMonth',
	CURRENT_YEAR = 'currentYear',
	DATEPICKER = 'datepicker',
	DATE_FORMAT = 'dateFormat',
	DAY = 'day',
	DAY_FIELD = 'dayField',
	DAY_FIELD_NAME = 'dayFieldName',
	DISPLAY = 'display',
	DISPLAY_BOUNDING_BOX = 'displayBoundingBox',
	DOT = '.',
	HELPER = 'helper',
	MAX_DATE = 'maxDate',
	MIN_DATE = 'minDate',
	MONTH = 'month',
	MONTH_FIELD = 'monthField',
	MONTH_FIELD_NAME = 'monthFieldName',
	NAME = 'name',
	OPTION = 'option',
	POPULATE_DAY = 'populateDay',
	POPULATE_MONTH = 'populateMonth',
	POPULATE_YEAR = 'populateYear',
	SELECT = 'select',
	SELECTED = 'selected',
	TRIGGER = 'trigger',
	WRAPPER = 'wrapper',
	YEAR = 'year',
	YEAR_FIELD = 'yearField',
	YEAR_FIELD_NAME = 'yearFieldName',
	YEAR_RANGE = 'yearRange',

	getCN = A.ClassNameManager.getClassName,

	CSS_DATEPICKER = getCN(DATEPICKER),
	CSS_DATEPICKER_BUTTON_WRAPPER = getCN(DATEPICKER, BUTTON, WRAPPER),
	CSS_DATEPICKER_DAY = getCN(DATEPICKER, DAY),
	CSS_DATEPICKER_DISPLAY = getCN(DATEPICKER, DISPLAY),
	CSS_DATEPICKER_MONTH = getCN(DATEPICKER, MONTH),
	CSS_DATEPICKER_SELECT_WRAPPER = getCN(DATEPICKER, SELECT, WRAPPER),
	CSS_DATEPICKER_YEAR = getCN(DATEPICKER, YEAR),
	CSS_HELPER_CLEARFIX = getCN(HELPER, CLEARFIX),

	SELECT_TPL = '<select></select>',
	SELECT_OPTION_TPL = '<option></option>',
	DISPLAY_BOUNDING_BOX_TPL = '<div></div>',
	WRAPPER_BUTTON_TPL = '<div class="'+ CSS_DATEPICKER_BUTTON_WRAPPER +'"></div>',
	WRAPPER_SELECT_TPL = '<div class='+ CSS_DATEPICKER_SELECT_WRAPPER +'></div>';

function DatePickerSelect(config) {
	DatePickerSelect.superclass.constructor.apply(this, arguments);
}

A.mix(DatePickerSelect, {
	NAME: DATEPICKER,

	ATTRS: {
		appendOrder: {
			value: [ 'm', 'd', 'y' ],
			validator: isArray
		},

		baseName: {
			value: DATEPICKER
		},

		// displayBoundingBox is the boundingBox to the selects/button
		// the default boundingBox attribute refer to the Calendar Overlay
		displayBoundingBox: {
			value: null,
			setter: nodeSetter
		},

		dayField: {
			setter: nodeSetter,
			valueFn: createSelect
		},

		monthField: {
			setter: nodeSetter,
			valueFn: createSelect
		},

		yearField: {
			setter: nodeSetter,
			valueFn: createSelect
		},

		dayFieldName: {
			value: DAY
		},

		monthFieldName: {
			value: MONTH
		},

		yearFieldName: {
			value: YEAR
		},

		trigger: {
			valueFn: function() {
				return A.Node.create(WRAPPER_BUTTON_TPL).cloneNode();
			}
		},

		visible: {
			value: false
		},

		yearRange: {
			valueFn: function() {
				var year = new Date().getFullYear();

				return [ year - 10, year + 10 ]
			},
			validator: isArray
		},

		setValue: {
			value: false
		},

		populateDay: {
			value: true
		},

		populateMonth: {
			value: true
		},

		populateYear: {
			value: true
		}
	}
});

A.extend(DatePickerSelect, A.Calendar, {
	/*
	* Lifecycle
	*/
	renderUI: function() {
		var instance = this;

		DatePickerSelect.superclass.renderUI.apply(this, arguments);

		instance._renderElements();
		instance._renderTriggerButton();
	},

	bindUI: function() {
		var instance = this;

		DatePickerSelect.superclass.bindUI.apply(this, arguments);

		instance.after('datesChange', A.bind(instance._selectCurrentValues, instance));
		instance.after('currentMonthChange', A.bind(instance._afterSetCurrentMonth, instance));

		instance._bindSelectEvents();
	},

	syncUI: function() {
		var instance = this;

		DatePickerSelect.superclass.syncUI.apply(this, arguments);

		instance._pupulateSelects();
		instance._selectCurrentValues();
	},

	/*
	* Methods
	*/
	_getAppendOrder: function() {
		var instance = this;
		var appendOrder = instance.get(APPEND_ORDER);

		var mapping = {
			d: instance.get(DAY_FIELD),
			m: instance.get(MONTH_FIELD),
			y: instance.get(YEAR_FIELD)
		};

		var firstField = mapping[ appendOrder[0] ];
		var secondField = mapping[ appendOrder[1] ];
		var thirdField = mapping[ appendOrder[2] ];

		return [ firstField, secondField, thirdField ]
	},

	_renderElements: function() {
		var instance = this;
		var displayBoundingBox = instance.get(DISPLAY_BOUNDING_BOX);

		if (!displayBoundingBox) {
			displayBoundingBox = A.Node.create(DISPLAY_BOUNDING_BOX_TPL);

			instance.set(DISPLAY_BOUNDING_BOX, displayBoundingBox);

			A.get(BODY).append(displayBoundingBox);
		}

		var dayField = instance.get(DAY_FIELD);
		var monthField = instance.get(MONTH_FIELD);
		var yearField = instance.get(YEAR_FIELD);

		dayField.addClass(CSS_DATEPICKER_DAY);
		monthField.addClass(CSS_DATEPICKER_MONTH);
		yearField.addClass(CSS_DATEPICKER_YEAR);

		displayBoundingBox.addClass(CSS_DATEPICKER);
		displayBoundingBox.addClass(CSS_DATEPICKER_DISPLAY);
		displayBoundingBox.addClass(CSS_HELPER_CLEARFIX);

		instance._selectWrapper = A.Node.create(WRAPPER_SELECT_TPL);

		// setting name of the fields
		monthField.set(NAME, instance.get(MONTH_FIELD_NAME));
		yearField.set(NAME, instance.get(YEAR_FIELD_NAME));
		dayField.set(NAME, instance.get(DAY_FIELD_NAME));

		// append elements
		var orderedFields = instance._getAppendOrder();

		instance._selectWrapper.append(orderedFields[0]);
		instance._selectWrapper.append(orderedFields[1]);
		instance._selectWrapper.append(orderedFields[2]);

		displayBoundingBox.append( instance._selectWrapper );
	},

	_renderTriggerButton: function() {
		var instance = this;
		var trigger = instance.get(TRIGGER).item(0);
		var displayBoundingBox = instance.get(DISPLAY_BOUNDING_BOX);

		instance._buttonItem = new A.ToolItem(CALENDAR);

		displayBoundingBox.append(trigger);

		if ( trigger.test(DOT+CSS_DATEPICKER_BUTTON_WRAPPER) ) {
			// use ToolItem if the user doesn't specify a trigger
			instance._buttonItem.render(trigger);
		}
	},

	_bindSelectEvents: function() {
		var instance = this;
		var selects = instance._selectWrapper.all(SELECT);

		selects.on('change', A.bind(instance._onSelectChange, instance));
		selects.on('keypress', A.bind(instance._onSelectChange, instance));
	},

	_selectCurrentValues: function() {
		var instance = this;

		instance._selectCurrentDay();
		instance._selectCurrentMonth();
		instance._selectCurrentYear();
	},

	_selectCurrentDay: function() {
		var instance = this;
		var currentDate = instance.getCurrentDate();

		instance.get(DAY_FIELD).val( currentDate.getDate() );
	},

	_selectCurrentMonth: function() {
		var instance = this;
		var currentDate = instance.getCurrentDate();

		instance.get(MONTH_FIELD).val( currentDate.getMonth() );
	},

	_selectCurrentYear: function() {
		var instance = this;
		var currentDate = instance.getCurrentDate();

		instance.get(YEAR_FIELD).val( currentDate.getFullYear() );
	},

	_pupulateSelects: function() {
		var instance = this;

		instance._populateDays();
		instance._populateMonths();
		instance._populateYears();

		// restricting dates based on the selects values
		var monthOptions = instance.get(MONTH_FIELD).all(OPTION);
		var yearOptions = instance.get(YEAR_FIELD).all(OPTION);

		var mLength = monthOptions.size() - 1;
		var yLength = yearOptions.size() - 1;

		var firstMonth = monthOptions.item(0).val();
		var firstYear = yearOptions.item(0).val();
		var lastMonth = monthOptions.item(mLength).val();
		var lastYear = yearOptions.item(yLength).val();

		var maxMonthDays = instance.getDaysInMonth(lastYear, lastMonth);

		var minDate = new Date(firstYear, firstMonth, 1);
		var maxDate = new Date(lastYear, lastMonth, maxMonthDays);

		instance.set(MAX_DATE, maxDate);
		instance.set(MIN_DATE, minDate);
	},

	_populateYears: function() {
		var instance = this;
		var yearRange = instance.get(YEAR_RANGE);
		var yearField = instance.get(YEAR_FIELD);

		if (instance.get(POPULATE_YEAR)) {
			instance._populateSelect(yearField, yearRange[0], yearRange[1]);
		}
	},

	_populateMonths: function() {
		var instance = this;
		var monthField = instance.get(MONTH_FIELD);
		var localeMap = instance._getLocaleMap();
		var monthLabels = localeMap.B;

		if (instance.get(POPULATE_MONTH)) {
			instance._populateSelect(monthField, 0, (monthLabels.length - 1), monthLabels);
		}
	},

	_populateDays: function() {
		var instance = this;
		var dayField = instance.get(DAY_FIELD);
		var daysInMonth = instance.getDaysInMonth();

		if (instance.get(POPULATE_DAY)) {
			instance._populateSelect(dayField, 1, daysInMonth);
		}
	},

	_populateSelect: function(select, fromIndex, toIndex, labels, values) {
		var i = 0;
		var index = fromIndex;
		var instance = this;

		select.empty();
		labels = labels || [];
		values = values || [];

		while (index <= toIndex) {
			var value = values[index] || index;
			var label = labels[index] || index;

			A.Node.getDOMNode(select).options[i] = new Option(label, index);

			i++;
			index++;
		}
	},

	/*
	* Listeners
	*/
	_onSelectChange: function(event) {
		var instance = this;
		var target = event.currentTarget || event.target;
		var monthChanged = target.test(DOT+CSS_DATEPICKER_MONTH);

		var currentDay = instance.get(DAY_FIELD).val();
		var currentMonth = instance.get(MONTH_FIELD).val();
		var currentYear = instance.get(YEAR_FIELD).val();

		instance.set(CURRENT_DAY, currentDay);
		instance.set(CURRENT_MONTH, currentMonth);
		instance.set(CURRENT_YEAR, currentYear);

		if (monthChanged) {
			instance._afterSetCurrentMonth();
		}

		instance._selectDate();
	},

	_afterSetCurrentMonth: function(event) {
		var instance = this;

		instance._populateDays();
		instance._selectCurrentDay();
	}
});

A.DatePickerSelect = DatePickerSelect;

}, '0.1a', { requires: [ 'calendar', 'tool-item' ] });AUI.add('dialog', function(A) {

var L = A.Lang,
	isBoolean = L.isBoolean,
	isArray = L.isArray,
	isObject = L.isObject,

	BLANK = '',
	BODY_CONTENT = 'bodyContent',
	BOUNDING_BOX = 'boundingBox',
	BUTTON = 'button',
	BUTTONS = 'buttons',
	CLOSE = 'close',
	CONSTRAIN_TO_VIEWPORT = 'constrain2view',
	CONTAINER = 'container',
	DD = 'dd',
	DEFAULT = 'default',
	DESTROY_ON_CLOSE = 'destroyOnClose',
	DIALOG = 'dialog',
	DOT = '.',
	DRAGGABLE = 'draggable',
	DRAG_INSTANCE = 'dragInstance',
	FOOTER_CONTENT = 'footerContent',
	HD = 'hd',
	ICON = 'icon',
	IO = 'io',
	LOADING = 'loading',
	MODAL = 'modal',
	STACK = 'stack',
	TOOLS = 'tools',

	getCN = A.ClassNameManager.getClassName,

	CSS_DIALOG_BUTTON = getCN(DIALOG, BUTTON),
	CSS_DIALOG_BUTTON_CONTAINER = getCN(DIALOG, BUTTON, CONTAINER),
	CSS_DIALOG_BUTTON_DEFAULT = getCN(DIALOG, BUTTON, DEFAULT),
	CSS_DIALOG_HD = getCN(DIALOG, HD),
	CSS_ICON_LOADING = getCN(ICON, LOADING),
	CSS_PREFIX = getCN(DD),

	NODE_BLANK_TEXT = document.createTextNode(''),

	TPL_BUTTON = '<button class="' + CSS_DIALOG_BUTTON + '"></button>',
	TPL_BUTTON_CONTAINER = '<div class="' + CSS_DIALOG_BUTTON_CONTAINER + '"></div>',
	TPL_LOADING = '<div class="' + CSS_ICON_LOADING + '"></div>';

var Dialog = function(config) {};

A.mix(
	Dialog,
	{
		NAME: DIALOG,

		ATTRS: {
			bodyContent: {
				value: NODE_BLANK_TEXT
			},

			buttons: {
				value: [],
				validator: isArray
			},

			close: {
				value: true
			},

			constrain2view: {
				value: false,
				validator: isBoolean
			},

			destroyOnClose: {
				value: false,
				validator: isBoolean
			},

			draggable: {
				lazyAdd: true,
				value: true,
				setter: function(v) {
					return this._setDraggable(v);
				}
			},

			dragInstance: {
				value: null
			},

			headerContent: {
				writeOnce: true,
				getter: function() {
					return this.titleContainter;
				}
			},

			modal: {
				setter: function(v) {
					return this._setModal(v);
				},
				lazyAdd: false,
				value: false,
				validator: isBoolean
			},

			io: {
				lazyAdd: true,
				value: null,
				setter: function(v) {
					return this._setIO(v);
				}
			},

			stack: {
				lazyAdd: true,
				value: true,
				setter: function(v) {
					return this._setStack(v);
				},
				validator: isBoolean
			}
		}
	}
);

Dialog.prototype = {
	initializer: function(config) {
		var instance = this;
		var tools = instance.get(TOOLS);
		var close = instance.get(CLOSE);
		var buttons = instance.get(BUTTONS);

		if (buttons && buttons.length && !instance.get(FOOTER_CONTENT)) {
			instance.set(FOOTER_CONTENT, NODE_BLANK_TEXT);
		}

		if (close) {
			var closeConfig = {
				icon: CLOSE,
				id: CLOSE,
				handler: {
					fn: instance.close,
					context: instance
				}
			};

			if (tools) {
				tools.push(closeConfig);
			}

			instance.set(TOOLS, tools);
		}

		instance.after('render', instance._afterRenderer);
	},

	bindUI: function() {
		var instance = this;

		instance.publish('close', { defaultFn: instance._close });
	},

	/*
	* Methods
	*/
	close: function() {
		var instance = this;

		instance.fire('close');
	},

	_afterRenderer: function() {
		var instance = this;

		instance._initButtons();

		// forcing lazyAdd:true attrs call the setter
		instance.get(STACK);
		instance.get(DRAGGABLE);
		instance.get(IO);
	},

	_close: function() {
		var instance = this;

		if (instance.get(DESTROY_ON_CLOSE)) {
			instance.destroy();
		}
		else {
			instance.hide();
		}

		if (instance.get(MODAL)) {
			A.DialogMask.hide();
		}
	},

	_initButtons: function() {
		var instance = this;

		var buttons = instance.get(BUTTONS);
		var container = A.Node.create(TPL_BUTTON_CONTAINER);
		var nodeModel = A.Node.create(TPL_BUTTON);

		A.each(
			buttons,
			function(button, i) {
				var node = nodeModel.cloneNode();

				if (button.isDefault) {
					node.addClass(CSS_DIALOG_BUTTON_DEFAULT);
				}

				if (button.handler) {
					node.on('click', button.handler, instance);
				}

				node.html(button.text || BLANK);

				container.append(node);
			}
		);

		if (buttons.length) {
			instance.set(FOOTER_CONTENT, container);
		}
	},

	_setDraggable: function(value) {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);

		var destroyDraggable = function() {
			var dragInstance = instance.get(DRAG_INSTANCE);

			if (dragInstance) {
				// TODO - YUI3 has a bug when destroy and recreates
				dragInstance.destroy();
				dragInstance.unplug(A.Plugin.DDConstrained);
			}
		};

		A.DD.DDM.CSS_PREFIX = CSS_PREFIX;

		if (value) {
			var defaults = {
				node: boundingBox,
				handles: [ DOT + CSS_DIALOG_HD ]
			};

			var dragOptions = A.merge(defaults, instance.get(DRAGGABLE) || {});

			// change the drag scope callback to execute using the dialog scope
			if (dragOptions.on) {
				A.each(
					dragOptions.on,
					function(fn, eventName) {
						dragOptions.on[eventName] = A.bind(fn, instance);
					}
				);
			}

			destroyDraggable();

			var dragInstance = new A.DD.Drag(dragOptions);

			dragInstance.plug(
				A.Plugin.DDConstrained,
				{
					constrain2view: instance.get(CONSTRAIN_TO_VIEWPORT)
				}
			);

			instance.set(DRAG_INSTANCE, dragInstance);
		}
		else {
			destroyDraggable();
		}

		return value;
	},

	_setIO: function(value) {
		var instance = this;

		if (value && !instance.get(BODY_CONTENT)) {
			instance.set(BODY_CONTENT, TPL_LOADING);
		}

		if (value) {
			instance.unplug(A.Plugin.StdModIOPlugin);

			value.uri = value.uri || value.url;
			value.cfg = value.cfg || {};

			var data = value.cfg.data;

			if (isObject(data)) {
				value.cfg.data = A.toQueryString(data);
			}

			instance.plug(A.Plugin.StdModIOPlugin, value);

			var autoRefresh = ('autoRefresh' in value) ? value.autoRefresh : true;

			if (instance.io && autoRefresh) {
				instance.io.refresh();
			}
		}
		else {
			instance.unplug(A.Plugin.StdModIOPlugin);
		}

		return value;
	},

	_setModal: function(value) {
		var instance = this;

		if (value) {
			A.DialogMask.show();
		}
		else {
			A.DialogMask.hide();
		}

		return value;
	},

	_setStack: function(value) {
		var instance = this;

		if (value) {
			A.DialogManager.register(instance);
		}
		else {
			A.DialogManager.remove(instance);
		}

		return value;
	},

	/*
	* Attribute Listeners
	*/
	_afterSetVisible: function(event) {
		var instance = this;

		if (instance.get(MODAL)) {
			if (event.newVal) {
				A.DialogMask.show();
			}
			else {
				A.DialogMask.hide();
			}
		}
	}
};

A.Dialog = A.Base.build(DIALOG, A.Panel, [Dialog, A.WidgetPosition, A.WidgetStack, A.WidgetPositionExt]);

A.DialogManager = new A.OverlayManager(
	{
		zIndexBase: 1000
	}
);

A.mix(
	A.DialogManager,
	{
		findByChild: function(child) {
			return A.Widget.getByNode(child);
		},

		closeByChild: function(child) {
			return A.DialogManager.findByChild(child).close();
		},

		refreshByChild: function(child, io) {
			var dialog = A.DialogManager.findByChild(child);

			if (dialog && dialog.io) {
				if (io) {
					dialog.set(IO, io);
				}
				else {
					dialog.io.refresh();
				}
			}
		}
	}
);

A.DialogMask = new A.OverlayMask().render();

}, '0.1a', { requires: [ 'aui-base', 'panel', 'overlay-manager', 'overlay-mask', 'dd-constrain', 'io-stdmod', 'dialog-css' ] });AUI.add('dispatcher', function(Y) {


/**
* <p>The Dispatcher Node Plugin makes it easy to transform existing
* markup into an dispatcher element with expandable and collapsable elements,
* elements are  easy to customize, and only require a small set of dependencies.</p>
*
*
* <p>To use the Dispatcher Node Plugin, simply pass a reference to the plugin to a
* Node instance's <code>plug</code> method.</p>
*
* <p>
* <code>
* &#60;script type="text/javascript"&#62; <br>
* <br>
* 		//	Call the "use" method, passing in "node-dispatcher".  This will <br>
* 		//	load the script and CSS for the Dispatcher Node Plugin and all of <br>
* 		//	the required dependencies. <br>
* <br>
* 		YUI().use("gallery-dispatcher", function(Y) { <br>
* <br>
* 			//	Use the "contentready" event to initialize the dispatcher when <br>
* 			//	the element that represente the dispatcher <br>
* 			//	(&#60;div id="dispatcher-1"&#62;) is ready to be scripted. <br>
* <br>
* 			Y.on("contentready", function () { <br>
* <br>
* 				//	The scope of the callback will be a Node instance <br>
* 				//	representing the dispatcher (&#60;div id="dispatcher-1"&#62;). <br>
* 				//	Therefore, since "this" represents a Node instance, it <br>
* 				//	is possible to just call "this.plug" passing in a <br>
*				//	reference to the Dispatcher Node Plugin. <br>
* <br>
* 				this.plug(Y.Plugin.NodeDispatcher); <br>
* <br>
* 			}, "#dispatcher-1"); <br>
* <br>
* 		}); <br>
* <br>
* 	&#60;/script&#62; <br>
* </code>
* </p>
*
* <p>The Dispatcher Node Plugin has several configuration properties that can be
* set via an object literal that is passed as a second argument to a Node
* instance's <code>plug</code> method.
* </p>
*
* <p>
* <code>
* &#60;script type="text/javascript"&#62; <br>
* <br>
* 		//	Call the "use" method, passing in "node-dispatcher".  This will <br>
* 		//	load the script and CSS for the Dispatcher Node Plugin and all of <br>
* 		//	the required dependencies. <br>
* <br>
* 		YUI().use("node-dispatcher", function(Y) { <br>
* <br>
* 			//	Use the "contentready" event to initialize the dispatcher when <br>
* 			//	the element that represente the dispatcher <br>
* 			//	(&#60;div id="dispatcher-1"&#62;) is ready to be scripted. <br>
* <br>
* 			Y.on("contentready", function () { <br>
* <br>
* 				//	The scope of the callback will be a Node instance <br>
* 				//	representing the dispatcher (&#60;div id="dispatcher-1"&#62;). <br>
* 				//	Therefore, since "this" represents a Node instance, it <br>
* 				//	is possible to just call "this.plug" passing in a <br>
*				//	reference to the Dispatcher Node Plugin. <br>
* <br>
* 				this.plug(Y.Plugin.NodeDispatcher, { anim: true, effect: Y.Easing.backIn });
* <br><br>
* 			}, "#dispatcher-1"); <br>
* <br>
* 		}); <br>
* <br>
* 	&#60;/script&#62; <br>
* </code>
* </p>
*
* @module node-dispatcher
*/


//	Util shortcuts

var UA = Y.UA,
	getClassName = Y.ClassNameManager.getClassName,

	//	Frequently used strings
	DISPATCHER = "dispatcher",
	PERIOD = ".",
	DISPATCHER_START = 'start',
    DISPATCHER_PURGE = 'purge',
    DISPATCHER_CHANGE = 'change',
    DISPATCHER_LOAD = 'load',

	//	Attribute keys
	ATTR_URI 		 = 'uri',
	ATTR_CONTENT 	 = 'content',

	//	CSS class names
	CLASS_DISPATCHER 			 = getClassName(DISPATCHER),
	CLASS_DISPATCHER_LOADING 	 = getClassName(DISPATCHER, 'loading'),

	//	CSS selectors
	SELECTOR_DISPATCHER = PERIOD + CLASS_DISPATCHER,

	// shorthands
    L = Y.Lang,
    isBoolean= L.isBoolean,
    isString = L.isString,
    isObject = L.isObject,

	/**
	* The NodeDispatcher class is a plugin for a Node instance.  The class is used via
	* the <a href="Node.html#method_plug"><code>plug</code></a> method of Node and
	* should not be instantiated directly.
	* @namespace plugin
	* @class NodeDispatcher
	*/
	Dispatcher = function () {
		Dispatcher.superclass.constructor.apply(this, arguments);
	};

//	Utility functions

function _parseContent ( content ) {
	var fragment = Y.Node.create('<div></div>'),
		o = {};

	fragment.setContent (content);
	o.css = fragment.all('style, link[type=text/css]').each(function (n) {
		fragment.removeChild (n);
	});
	o.js = fragment.all('script').each(function (n) {
		fragment.removeChild (n);
	});
	o.content = fragment.get ('innerHTML');
	return o;
}

// Dispatcher definition

Y.mix(Dispatcher, {

    /**
     * The identity of the component.
     *
     * @property Dispatcher.NAME
     * @type String
     * @static
     */
    NAME : DISPATCHER,

     /*
     * @property Dispatcher._hashtable
     * @Type Array
     * @static
     */
    _hashtable : [],

    /**
     * Static property used to define the default attribute configuration of
     * the component.
     *
     * @property Dispatcher.ATTRS
     * @Type Object
     * @static
     */
    ATTRS : {

 		/**
 		* If dispatcher should purge the DOM elements before replacing the content
 		* @attribute autopurge
 		* @default true
 		* @type boolean
 		*/
 		autopurge: {
 			value: true,
 			validator : isBoolean
 		},
 		/**
 		* URL that should be injected within the host
 		* @attribute uri
 		* @default null
 		* @type string
 		*/
 		uri: {
 			value: null,
 			setter : function (v) {
 				Y.log ('dispatching a new url','info',DISPATCHER);
 				this.stop ();
 				this._io = this._fetch(v);
				return v;
			},
 			validator : isString
 		},
 		/**
 		* default content for the dynamic area
 		* @attribute content
 		* @default null
 		* @type string
 		*/
 		content: {
 			value: '',
 			setter : function (v) {
 				Y.log ('dispatching a new content','info',DISPATCHER);
 				this.stop();
 				v = this._dispatch(v); // discarding the file name
	            return v;
			},
 			validator : isString
 		},
	    /**
		* Boolean indicating that a process is undergoing.
		*
		* @attribute loading
		* @default false
		* @type {boolean}
		*/
		loading: {
			value: false,
			validator: isBoolean,
			setter: function (v) {
				Y.log ('setting status','info',DISPATCHER);
				if (v) {
					this._node.addClass (CLASS_DISPATCHER_LOADING);
				} else {
					this._node.removeClass (CLASS_DISPATCHER_LOADING);
				}
				return v;
			}
		}
     }
});

Y.extend(Dispatcher, Y.Base, {

	//	Protected properties

   /**
    * ...
    *
    * @property _history
    * @type Array
    * @protected
    */
   _history : [],
   _node: null,
   _queue: null,
   _io: null,

	//	Public methods

    initializer: function (config) {
		Y.log ('Initializer','info',DISPATCHER);
		this._queue = new Y.AsyncQueue ();
		if (!isObject(config) || !config.node || !(this._node = Y.one(config.node))) {
			Y.log ('Dispatcher requires a NODE to be instantiated','info',DISPATCHER);
			// how can we stop the initialization?
			return;
		}

		/**
         * Signals the end of a thumb drag operation.  Payload includes
         * the DD.Drag instance's drag:end event under key ddEvent.
         *
         * @event slideEnd
         * @param event {Event.Facade} An Event Facade object with the following attribute specific properties added:
         *  <dl>
         *      <dt>ddEvent</dt>
         *          <dd><code>drag:end</code> event from the managed DD.Drag instance</dd>
         *  </dl>
         */
        this.publish(DISPATCHER_START);
        this.publish(DISPATCHER_PURGE);
        this.publish(DISPATCHER_CHANGE);
        this.publish(DISPATCHER_LOAD);
	},

	destructor: function () {
		this.stop();
		this._node = null;
		this._queue = null;
		this._io = null;
    },
    stop: function () {
    	this._queue.stop ();
    	if (this._io) {
    		this._io.abort();
    	}
    	return this;
    },
	/**
	 * Dispatching the next node of the handle
	 * @method dispatch
	 * @return null
	 */
	_dispatch: function(content) {
    	var o = _parseContent (content),
    		q = this._queue,
    		n = this._node;
    	// injecting CSS blocks first
    	o.css.each (function (cssNode) {
    		if (cssNode && cssNode.get ('href')) {
	    		q.add ({
					fn: function () {
	    				Y.log ('external link tag: '+cssNode.get ('href'),'info',DISPATCHER);
	    				//q.next();
	    				Y.Get.css(cssNode.get ('href'), {
	    					onFailure: function(o) {
	    						Y.log ('external link tag fail to load: '+cssNode.get ('href'),'warn',DISPATCHER);
							},
							onEnd: function () {
								q.run();
							}
						});
					},
					autoContinue: false
	    		});
    		} else {
	    		q.add ({
					fn: function () {
		    			// inject css;
		    			Y.log ('inline style tag: '+cssNode.get ('innerHTML'),'info',DISPATCHER);
		    			var d = cssNode.get('ownerDocument'),
							h = d.one('head') || d.get ('documentElement'),
							newStyle = Y.Node.create('<style></style>');
						h.replaceChild(cssNode, h.appendChild(newStyle));
					}
	    		});
    		}
    	});
    	// autopurging children collection
    	if (this.get ('autopurge')) {
    		q.add ({
    			fn: function () {
    				Y.log ('purging children collection','info',DISPATCHER);
	        		n.get ('children').each(function(c) {
	        			c.purge (true);
	        		});
	        	}
    		});
		}
    	// injecting new content
    	q.add ({
			fn: function () {
				Y.log ('setting new content: '+o.content,'info',DISPATCHER);
    			n.setContent (o.content);
			}
		});
    	// executing JS blocks before the injection
    	o.js.each (function (jsNode) {
    		if (jsNode && jsNode.get ('src')) {
	    		q.add ({
					fn: function () {
						Y.log ('external script tag: '+jsNode.get ('src'),'info',DISPATCHER);
						//q.next();
						Y.Get.script(jsNode.get ('src'), {
							onFailure: function(o) {
	    						Y.log ('external script tag fail to load: '+jsNode.get ('src'),'error',DISPATCHER);
							},
							onEnd: function (o) {
								o.purge(); //removes the script node immediately after executing it
								q.run();
							}
						});
					},
					autoContinue: false
	    		});
    		} else {
	    		q.add ({
					fn: function () {
		    			// inject js;
						Y.log ('inline script tag: '+jsNode.get ('innerHTML'),'info',DISPATCHER);
						var d = jsNode.get('ownerDocument'),
							h = d.one('head') || d.get ('documentElement'),
							newScript = Y.Node.create('<script></script>');
						h.replaceChild(jsNode, h.appendChild(newScript));
						if (jsNode._node.text) {
					        newScript._node.text = jsNode._node.text;
						}
						jsNode.remove(); //removes the script node immediately after executing it
					}
	    		});
    		}
    	});
    	// executing the queue
    	this._queue.run();
	},
	/**
	* * Fetching a remote file that will be processed thru this object...
	* @param {object} uri       URI to be loaded using IO
	* @return object  Reference to the connection handler
	*/
	_fetch: function ( uri, cfg ){
		cfg = cfg || {
			method: 'GET'
		};
		cfg.on = {
			start: function () {
		   		Y.log ('Start','info',DISPATCHER);
	   		},
			success: function (tid, o) {
		   		Y.log ('Success: '+o.responseText,'info',DISPATCHER);
		   		this.set(ATTR_CONTENT, o.responseText);
	   		},
	   		failure: function (tid, o) {
	   			Y.log ('Failure','warn',DISPATCHER);
		   	},
			end: function () {
		   		Y.log ('End','info',DISPATCHER);
	   		}
		};
		cfg.context = this;
		return Y.io(uri, cfg);
	},

	/**
	 * Destroy Custom Event will be fired before remove the innerHTML in the displaying process
	 * @method _destroy
	 * @param {Object} el    	DOM Element reference
	 * @param {Object} config    User configuration (useful for future implementations)
	 * @return void
	 */
    _destroy: function ( node, callback ) {
		// if the injected code tries to set up a destroyer method, this method should be
		// set in a FIFO, and if the area that contains the node will be destroyed, the
		// callback will be called.
	}
});

Y.Dispatcher = Dispatcher;

}, '0.1a' , { requires: [ 'async-queue', 'io' ] });AUI().add(
	'editable',
	function(A) {
		var Lang = A.Lang,
			isFunction = Lang.isFunction,

			getClassName = A.ClassNameManager.getClassName,

			HOVER = 'hover',
			NAME = 'editable',

			CSS_EDITING = getClassName(NAME, 'editing'),
			CSS_HOVER = getClassName(NAME, HOVER),

			CONTENT_BOX = 'contentBox';

		var Editable = function() {
			Editable.superclass.constructor.apply(this, arguments);
		};

		Editable.NAME = 'editable';

		Editable.ATTRS = {
			cancelButton: {
				valueFn: function() {
					var instance = this;

					return {
						id: 'cancel',
						icon: 'circle-close',
						handler: {
							context: instance,
							fn: instance.cancel
						}
					};
				}
			},
			contentText: {
				value: '',
				setter: function(value) {
					var instance = this;

					value = Lang.trim(value);

					instance._toText(value);

					return value;
				}
			},

			formatInput: {
				value: null,
				validator: isFunction
			},

			formatOutput: {
				value: null,
				validator: isFunction
			},

			node: {
				setter: function(value) {
					var node = A.get(value);

					if (!node) {
						A.error('AUI.Editable: Invalid Node Given: ' + value);
					}
					else {
						node = node.item(0);
					}

					return node;
				}
			},

			eventType: {
				value: 'click'
			},

			renderTo: {
				value: document.body,
				setter: function(value) {
					var instance = this;

					var node;

					if (value == 'node') {
						node = instance.get(value);
					}
					else {
						node = A.get(value);
					}

					if (!node) {
						A.error('AUI.Editable: Invalid renderTo Given: ' + value);
					}
					else {
						node = node.item(0);
					}

					return node;
				}
			},

			saveButton: {
				valueFn: function() {
					var instance = this;

					return {
						id: 'save',
						icon: 'circle-check',
						handler: {
							context: instance,
							fn: instance.save
						}
					};
				}
			},

			tools: {
				value: []
			},

			inputType: {
				value: 'text',
				setter: function(value) {
					var instance = this;

					if (value != 'text' && value != 'textarea') {
						value = A.Attribute.INVALID_VALUE;
					}

					return value;
				}
			}
		};

		A.extend(
			Editable,
			A.Component,
			{
				initializer: function() {
					var instance = this;

					instance._scopedSave = A.bind(instance.save, instance);

					var node = instance.get('node');
					var eventType = instance.get('eventType');

					node.on('mouseenter', instance._onMouseEnterEditable, instance);
					node.on('mouseleave', instance._onMouseLeaveEditable, instance);

					node.on(eventType, instance._startEditing, instance);

					instance._createEvents();
				},

				renderUI: function() {
					var instance = this;

					var contentBox = instance.get(CONTENT_BOX);
					var inputType = instance.get('inputType');

					var comboConfig = {};

					var tools = instance.get('tools');

					if (tools !== false) {
						var cancelButton = instance.get('cancelButton');
						var saveButton = instance.get('saveButton');

						if (cancelButton !== false) {
							tools.push(cancelButton);
						}

						if (saveButton !== false) {
							tools.push(saveButton);
						}

						comboConfig.tools = tools;
					}

					if (inputType != 'text') {
						A.mix(
							comboConfig,
							{
								field: {
									autoSize: true
								},
								fieldWidget: A.Textarea
							}
						);
					}

					var comboBox = new A.Combobox(comboConfig).render(contentBox);

					instance._comboBox = comboBox;

					instance.inputNode = comboBox.get('node');
				},

				bindUI: function() {
					var instance = this;

					var contentBox = instance.get(CONTENT_BOX);
					var node = instance.get('node');

					var inputNode = instance.inputNode;

					inputNode.on('keypress', instance._onKeypressEditable, instance);

					instance.after('contentTextChange', instance._syncContentText);

					contentBox.swallowEvent('click');

					A.getDoc().after('click', instance._afterFocusedChangeEditable, instance);
				},

				syncUI: function() {
					var instance = this;

					var currentText = instance.get('node').get('innerHTML');

					currentText = currentText.replace(/\n|\r/gim, '');
					currentText = Lang.trim(currentText);

					currentText = instance._toText(currentText);

					instance._setInput(currentText);

					instance.set(
						'contentText',
						currentText,
						{
							initial: true
						}
					);
				},

				cancel: function() {
					var instance = this;

					instance.fire('cancel');
				},

				save: function(event) {
					var instance = this;

					instance.fire('save');
				},

				_afterFocusedChangeEditable: function(event) {
					var instance = this;

					instance.fire('stopEditing', instance.get('visible'));
				},

				_createEvents: function() {
					var instance = this;

					instance.publish(
						'startEditing',
						{
							bubbles: true,
							defaultFn: instance._defStartEditingFn,
							emitFacade: true,
							queable: false
						}
					);

					instance.publish(
						'stopEditing',
						{
							bubbles: true,
							defaultFn: instance._defStopEditingFn,
							emitFacade: true,
							queable: false
						}
					);

					instance.publish(
						'save',
						{
							bubbles: true,
							defaultFn: instance._defSaveFn,
							emitFacade: true,
							queable: false
						}
					);

					instance.publish(
						'cancel',
						{
							bubbles: true,
							defaultFn: instance._defCancelFn,
							emitFacade: true,
							queable: false
						}
					);
				},

				_defCancelFn: function(event) {
					var instance = this;

					instance.fire('stopEditing', false);
				},

				_defStartEditingFn: function(event) {
					var instance = this;

					var boundingBox = instance.get('boundingBox');
					var node = instance.get('node');

					var inputNode = instance.inputNode;

					var nodeHeight = node.get('offsetHeight');
					var nodeWidth = node.get('offsetWidth');

					instance.show();

					node.addClass(CSS_EDITING);

					var xy = node.getXY();

					boundingBox.setStyles(
						{
							height: nodeHeight + 'px',
							left: xy[0] + 'px',
							top: xy[1] + 'px',
							width: nodeWidth + 'px'
						}
					);

					var inputField = instance._comboBox._field

					inputField.set('width', nodeWidth);
					inputField.fire('adjustSize');

					inputNode.focus();
					inputNode.select();
				},

				_defStopEditingFn: function(event, save) {
					var instance = this;

					instance.hide();

					instance.get('node').removeClass(CSS_EDITING);

					if (save) {
						instance.set('contentText', instance.inputNode.get('value'));
					}
					else {
						instance._setInput(instance.get('contentText'));
					}
				},

				_defSaveFn: function(event) {
					var instance = this;

					instance.fire('stopEditing', true);
				},

				_onKeypressEditable: function(event) {
					var instance = this;

					var keyCode = event.keyCode;

					if (keyCode == 27) {
						event.preventDefault();

						instance.cancel();
					}
					else if (keyCode == 13 && (instance.get('inputType') == 'text')) {
						instance.save();
					}
				},

				_onMouseEnterEditable: function(event) {
					var instance = this;

					instance.get('node').addClass(CSS_HOVER);
				},

				_onMouseLeaveEditable: function(event) {
					var instance = this;

					instance.get('node').removeClass(CSS_HOVER);
				},

				_setInput: function(value) {
					var instance = this;

					var inputFormatter = instance.get('formatInput');

					if (inputFormatter) {
						value = inputFormatter.call(instance, value);
					}
					else {
						value = instance._toText(value);
					}

					instance.inputNode.set('value', value);
				},

				_setOutput: function(value) {
					var instance = this;

					var outputFormatter = instance.get('formatOutput');

					if (outputFormatter) {
						value = outputFormatter.call(instance, value);
					}
					else {
						value = instance._toHTML(value);
					}

					instance.get('node').set('innerHTML', value);
				},

				_startEditing: function(event) {
					var instance = this;

					if (!instance.get('rendered')) {
						instance.render(instance.get('renderTo'));
					}

					instance.fire('startEditing');

					event.halt();
				},

				_syncContentText: function(event) {
					var instance = this;

					if (!event.initial) {
						var contentText = event.newVal;

						instance._setInput(contentText);
						instance._setOutput(contentText);
					}
				},

				_toHTML: function(text) {
					var instance = this;

					return String(text).replace(/\n/gim, '<br/>');
				},

				_toText: function(text) {
					var instance = this;

					var text = String(text);

					text = text.replace(/<br\s*\/?>/gim, '\n');

					text = text.replace(/(<\/?[^>]+>|\t)/gim, '');

					return text;
				}
			}
		);

		A.Editable = Editable;
	},
	'0.1a',
	{
		requires: ['widget', 'tool'],
		use: []
	}
);AUI().add(
	'field',
	function(A) {
		var Lang = A.Lang,

			getClassName = A.ClassNameManager.getClassName,

			NAME = 'field',

			getTypeClassName = A.cached(
				function(type, prefix) {
					var base = ['field'];

					if (prefix) {
						base.push(prefix);
					}

					base = base.join('-');

					var className = [getClassName(base, type)];

					if (type == 'password') {
						className.push(getClassName(base, 'text'));
					}

					return className.join(' ');
				}
			),

			CSS_FIELD = getClassName(NAME),
			CSS_FIELD_CONTENT = getClassName(NAME, 'content'),
			CSS_FIELD_INPUT = getClassName(NAME, 'input'),
			CSS_FIELD_HINT = getClassName(NAME, 'hint'),
			CSS_FIELD_INVALID = getClassName(NAME, 'invalid'),
			CSS_FIELD_LABEL = getClassName(NAME, 'label'),

			CSS_LABELS = getClassName(NAME, 'labels'),
			CSS_LABELS_INLINE = getClassName(NAME, 'labels', 'inline'),

			CSS_LABEL_ALIGN = {
				left: [CSS_LABELS, 'left'].join('-'),
				right: [CSS_LABELS, 'right'].join('-'),
				top: [CSS_LABELS, 'top'].join('-')
			},

			REGEX_INLINE_LABEL = /left|right/,

			TPL_BOUNDING_BOX = '<span class="' + CSS_FIELD + '"></span>',
			TPL_CONTENT_BOX = '<span class="' + CSS_FIELD_CONTENT + '"></span>',
			TPL_FIELD_HINT = '<span class="' + CSS_FIELD_HINT + '"></span>',
			TPL_INPUT = '<input autocomplete="off" class="{cssClass}" id="{id}" name="{name}" type="{type}" />',
			TPL_LABEL = '<label class="' + CSS_FIELD_LABEL + '"></label>',

			_FIELD_INSTANCES = {};

		var Field = function() {
			Field.superclass.constructor.apply(this, arguments);
		};

		var fieldPrototype = Field.prototype;

		Field.NAME = NAME;

		Field.ATTRS = {
			readOnly: {
				value: false
			},

			name: {
				value: '',
				getter: function(value) {
					var instance = this;

					return value || instance.get('id');
				}
			},

			id: {
				getter: function(value) {
					var instance = this;

					var node = this.get('node');

					if (node) {
						value = node.get('id');
					}

					if (!value) {
						value = A.guid();
					}

					return value;
				}
			},

			type: {
				value: 'text',
				writeOnce: true
			},

			labelAlign: {
				value: ''
			},

			labelNode: {
				valueFn: function() {
					var instance = this;

					return A.Node.create(TPL_LABEL);
				}
			},

			labelText: {
				valueFn: function() {
					var instance = this;

					return instance.get('labelNode').get('innerHTML');
				},

				setter: function(value) {
					var instance = this;

					instance.get('labelNode').set('innerHTML', value);

					return value;
				}
			},

			node: {
				value: null,
				setter: function(value) {
					var instance = this;

					return A.get(value) || instance._createFieldNode();
				}
			},

			fieldHint: {
				value: ''
			},

			fieldHintNode: {
				value: null,
				setter: function(value) {
					var instance = this;

					return A.get(value) || instance._createFieldHint();
				}
			},

			prevVal: {
				value: ''
			},

			valid: {
				value: true,
				getter: function(value) {
					var instance = this;

					var validator = instance.get('validator');

					var valid = instance.get('disabled') || validator(instance.get('value'));

					return valid;
				}
			},

			dirty: {
				value: false,
				getter: function(value) {
					var instance = this;

					if (instance.get('disabled')) {
						value = false;
					}
					else {
						var currentVal = String(instance.get('value'));
						var prevVal = String(instance.get('prevVal'));

						value = (currentVal !== prevVal);
					}

					return value;
				}
			},

			size: {},

			validator: {
				valueFn: function() {
					var instance = this;

					return instance.fieldValidator;
				},
				validator: Lang.isFunction
			},

			value: {
				validator: Field.prototype.fieldValidator
			}
		};

		Field.HTML_PARSER = {
			labelNode: 'label',
			node: 'input, textarea, select'
		};

		Field.getTypeClassName = getTypeClassName;

		A.extend(
			Field,
			A.Component,
			{
				BOUNDING_TEMPLATE: TPL_BOUNDING_BOX,
				CONTENT_TEMPLATE: TPL_CONTENT_BOX,
				FIELD_TEMPLATE: TPL_INPUT,
				FIELD_TYPE: 'text',

				initializer: function() {
					var instance = this;

					var id = instance.get('node').guid();

					_FIELD_INSTANCES[id] = instance;
				},

				renderUI: function() {
					var instance = this;

					instance._renderField();
					instance._renderLabel();
					instance._renderFieldHint();
				},

				bindUI: function() {
					var instance = this;

					instance.after('labelAlignChange', instance._afterLabelAlignChange);
					instance.after('fieldHintChange', instance._afterFieldHintChange);
				},

				syncUI: function() {
					var instance = this;

					instance.set('prevVal', instance.get('value'));

					instance._updateNodeAttrs();
				},

				fieldValidator: function(value) {
					var instance = this;

					return true;
				},

				isValid: function() {
					var instance = this;

					return instance.get('valid');
				},

				isDirty: function() {
					var instance = this;

					return instance.get('dirty');
				},

				resetValue: function() {
					var instance = this;

					instance.set('value', instance.get('prevVal'));

					instance.clearInvalid();
				},

				markInvalid: function(message) {
					var instance = this;

					instance.set('fieldHint', message);
					instance.get('fieldHintNode').show();

					instance.get('boundingBox').addClass(CSS_FIELD_INVALID);
				},

				clearInvalid: function() {
					var instance = this;

					instance.reset('fieldHint');

					if (!instance.get('fieldHint')) {
						instance.get('fieldHintNode').hide();
					}

					instance.get('boundingBox').removeClass(CSS_FIELD_INVALID);
				},

				validate: function() {
					var instance = this;

					var valid = instance.get('valid');

					if (valid) {
						instance.clearInvalid();
					}

					return valid;
				},

				_afterFieldHintChange: function(event) {
					var instance = this;

					instance._uiSetFieldHint(event.newVal, event.prevVal);
				},

				_afterLabelAlignChange: function(event) {
					var instance = this;

					instance._uiSetLabelAlign(event.newVal, event.prevVal);
				},

				_afterNodeAttrChange: function(event) {
					var instance = this;

					instance._attrNodeSetter(
						event.attrName,
						event.newVal,
						event.prevVal
					);
				},

				_attrNodeGetter: function(key, storedValue) {
					var instance = this;

					var node = instance.get('node');
					var value;

					if (key != 'value') {
						value = node.attr(key);
					}
					else {
						value = node.val();
					}

					if (String(storedValue) != String(value)) {
						instance._setStateVal(key, value);
					}

					return value;
				},

				_attrNodeSetter: function(key, newVal, prevVal) {
					var instance = this;

					var node = instance.get('node');

					if (key != 'value') {
						node.attr(key, newVal);
					}
					else {
						node.val(newVal);
					}

					return newVal;
				},

				_createFieldHint: function() {
					var instance = this;

					var fieldHint = A.Node.create(TPL_FIELD_HINT);

					instance.get('contentBox').append(fieldHint);

					return fieldHint;
				},

				_createFieldNode: function() {
					var instance = this;

					var fieldTemplate = instance.FIELD_TEMPLATE;

					instance.FIELD_TEMPLATE = A.substitute(
						fieldTemplate,
						{
							cssClass: CSS_FIELD_INPUT,
							id: instance.get('id'),
							name: instance.get('name'),
							type: instance.get('type')
						}
					);

					return A.Node.create(instance.FIELD_TEMPLATE);
				},

				_rawAttrGetter: function(value, key) {
					var instance = this;

					return instance._attrNodeGetter(key, value);
				},

				_renderField: function() {
					var instance = this;

					var node = instance.get('node');

					node.val(instance.get('value'));

					var boundingBox = instance.get('boundingBox');
					var contentBox = instance.get('contentBox');

					var type = instance.get('type');

					boundingBox.addClass(getTypeClassName(type));
					node.addClass(getTypeClassName(type, 'input'));

					if (!contentBox.contains(node)) {
						if (node.inDoc()) {
							node.placeBefore(boundingBox);

							contentBox.appendChild(node);
						}
						else {
							contentBox.appendChild(node);
						}
					}

					boundingBox.removeAttribute('tabIndex');
				},

				_renderFieldHint: function() {
					var instance = this;

					var fieldHint = instance.get('fieldHint');

					if (fieldHint) {
						instance._uiSetFieldHint(fieldHint);
					}
				},

				_renderLabel: function() {
					var instance = this;

					var labelText = instance.get('labelText');

					if (labelText !== false) {
						var node = instance.get('node');
						var id = node.guid();

						var labelText = instance.get('labelText');
						var labelNode = instance.get('labelNode');

						labelNode.addClass(getClassName(instance.name, 'label'));
						labelNode.setAttribute('for', id);
						labelNode.set('innerHTML', labelText);

						instance._uiSetLabelAlign(instance.get('labelAlign'));

						var contentBox = instance.get('contentBox');

						contentBox.prepend(labelNode);
					}
				},

				_uiSetLabelAlign: function(newVal, prevVal) {
					var instance = this;

					var boundingBox = instance.get('boundingBox');

					boundingBox.replaceClass(CSS_LABEL_ALIGN[prevVal], CSS_LABEL_ALIGN[newVal]);

					var action = 'removeClass';

					if (REGEX_INLINE_LABEL.test(newVal)) {
						action = 'addClass';
					}

					boundingBox[action](CSS_LABELS_INLINE);
				},

				_uiSetFieldHint: function(newVal, prevVal) {
					var instance = this;

					instance.get('fieldHintNode').set('innerHTML', newVal);
				},

				_updateNodeAttrs: function() {
					var instance = this;

					var syncedProperties = instance._syncedProperties;
					var length = syncedProperties.length;

					var modifiedAttr = {};
					var action = 'addAttr';
					var attrConfig = {
						getter: instance._rawAttrGetter
					};

					for (var i = length - 1; i >= 0; i--) {
						var property = syncedProperties[i];

						instance.after(property + 'Change', instance._afterNodeAttrChange);

						if (instance.attrAdded(property)) {
							action = 'modifyAttr';
						}

						var value = instance.get(property);

						instance._attrNodeSetter(property, value);

						instance[action](property, attrConfig);
					}
				},

				_requireAddAttr: false,

				_syncedProperties: [
					'disabled',
					'id',
					'readOnly',
					'name',
					'size',
					'tabIndex',
					'type',
					'value'
				]
			}
		);

		Field.getField = function(field) {
			var fieldWidget = null;

			if (field instanceof A.Field) {
				fieldWidget = field;
			}
			else if (field && (Lang.isString(field) || field instanceof A.Node || field.nodeName)) {
				var fieldId = A.get(field).get('id');

				fieldWidget = _FIELD_INSTANCES[fieldId];

				if (!fieldWidget) {
					var boundingBox = field.ancestor('.aui-field');
					var contentBox = field.ancestor('.aui-field-content');

					fieldWidget = new Field(
						{
							boundingBox: boundingBox,
							contentBox: contentBox,
							node: field
						}
					);
				}
			}
			else if (Lang.isObject(field)) {
				fieldWidget = new Field(field);
			}

			return fieldWidget;
		};

		A.Field = Field;
	},
	'0.1a',
	{
		requires: ['substitute'],
		use: []
	}
);AUI().add(
	'fieldset',
	function(A) {
		A.Fieldset = A.Base.build('fieldset', A.Panel, []);
	},
	'0.1a',
	{
		requires: ['panel'],
		use: []
	}
);AUI().add(
	'form',
	function(A) {
		var Lang = A.Lang,

			getClassName = A.ClassNameManager.getClassName,

			NAME = 'form',

			CSS_FORM = getClassName(NAME),
			CSS_LABELS = getClassName('field', 'labels'),
			CSS_LABELS_INLINE = getClassName('field', 'labels', 'inline')

			CSS_LABEL_ALIGN = {
				left: [CSS_LABELS, 'left'].join('-'),
				right: [CSS_LABELS, 'right'].join('-'),
				top: [CSS_LABELS, 'top'].join('-')
			};

		var Form = function() {
			Form.superclass.constructor.apply(this, arguments);
		};

		Form.NAME = NAME;

		var formPrototype = Form.prototype;

		Form.ATTRS = {
			action: {
				value: location.href,
				getter: formPrototype._attributeGetter,
				setter: formPrototype._attributeSetter
			},
			id: {},
			method: {
				value: 'POST',
				getter: formPrototype._attributeGetter,
				setter: formPrototype._attributeSetter
			},
			monitorChanges: {
				value: false
			},
			nativeSubmit: {
				value: false
			},

			values: {
				getter: function(value) {
					var instance = this;

					var values = A.io._serialize(instance.get('contentBox').getDOM());

					return A.fromQueryString(values);
				},

				setter: function(value) {
					var instance = this;

					var setFields = instance._setFieldsObject;

					var monitorChanges = instance.get('monitorChanges');

					if (Lang.isArray(value)) {
						setFields = instance._setFieldsArray;
					}

					A.each(value, A.rbind(setFields, instance, monitorChanges));

					return A.Attribute.INVALID_VALUE;
				}
			},

			fieldValues: {
				getter: function(value) {
					var instance = this;

					var obj = {};

					instance.fields.each(
						function(item, index, collection) {
							obj[item.get('name')] = item.get('value');
						}
					);

					return obj;
				}
			},

			labelAlign: {
				value: ''
			}
		};

		A.extend(
			Form,
			A.Component,
			{
				CONTENT_TEMPLATE: '<form></form>',

				initializer: function() {
					var instance = this;

					instance.fields = new A.DataSet(
						{
							getKey: instance._getNodeId
						}
					);
				},

				renderUI: function() {
					var instance = this;

					instance._renderForm();
				},

				bindUI: function() {
					var instance = this;

					var nativeSubmit = instance.get('nativeSubmit');

					if (!nativeSubmit) {
						instance.get('contentBox').on('submit', instance._onSubmit);
					}

					instance.after('disabledChange', instance._afterDisabledChange);
					instance.after('labelAlignChange', instance._afterLabelAlignChange);
					instance.after('nativeSubmitChange', instance._afterNativeSubmitChange);
				},

				syncUI: function() {
					var instance = this;

					var node = instance.get('contentBox');

					instance.set('id', node.guid());

					instance._uiSetLabelAlign(instance.get('labelAlign'));
				},

				add: function(fields, render) {
					var instance = this;

					var args = A.Array(fields);
					var length = args.length;
					var field;

					var fields = instance.fields;

					var contentBox = instance.get('contentBox');

					for (var i = 0; i < args.length; i++) {
						field = args[i];

						field = A.Field.getField(field);

						if (field && fields.indexOf(field) == -1) {
							fields.add(field);

							if (render && !field.get('rendered')) {
								var node = field.get('node');

								var location = null;

								if (!node.inDoc()) {
									location = contentBox;
								}

								field.render(location);
							}
						}
					}
				},

				clearInvalid: function() {
					var instance = this;

					instance.fields.each(
						function(item, index, collection) {
							item.clearInvalid();
						}
					);
				},

				getField: function(id) {
					var instance = this;

					var field;

					if (id) {
						var fields = instance.fields;

						field = fields.item(id);

						if (!Lang.isObject(field)) {
							fields.each(
								function(item, index, collection) {
									if (item.get('id') == id || item.get('name') == id) {
										field = item;

										return false;
									}
								}
							);
						}
					}

					return field;
				},

				invoke: function(method, args) {
					var instance = this;

					return instance.fields.invoke(method, args);
				},

				isDirty: function() {
					var instance = this;

					var dirty = false;

					instance.fields.each(
						function(item, index, collection) {
							if (item.isDirty()) {
								dirty = true;

								return false;
							}
						}
					);

					return dirty;
				},

				isValid: function() {
					var instance = this;

					var valid = true;

					instance.fields.each(
						function(item, index, collection) {
							if (!item.isValid()) {
								valid = false;

								return false;
							}
						}
					);

					return valid;
				},

				markInvalid: function(value) {
					var instance = this;

					var markFields = instance._markInvalidObject;

					if (Lang.isArray(value)) {
						markFields = instance._markInvalidArray;
					}

					A.each(value, markFields, instance);

					return instance;
				},

				remove: function(field, fromMarkup) {
					var instance = this;

					instance.fields.remove(field);

					if (fromMarkup) {
						field = instance.getField(field);

						if (field) {
							field.destroy();
						}
					}

					return instance;
				},

				resetValues: function() {
					var instance = this;

					instance.fields.each(
						function(item, index, collection) {
							item.resetValue();
						}
					);
				},

				submit: function(config) {
					var instance = this;

					var valid = instance.isValid();

					if (valid) {
						if (instance.get('nativeSubmit')) {
							instance.get('contentBox').submit();
						}
						else {
							config = config || {};

							A.mix(
								config,
								{
									id: instance.get('id')
								}
							);

							A.io(
								instance.get('action'),
								{
									form: config,
									method: instance.get('method'),
									on: {
										complete: A.bind(instance._onSubmitComplete, instance),
										end: A.bind(instance._onSubmitEnd, instance),
										failure: A.bind(instance._onSubmitFailure, instance),
										start: A.bind(instance._onSubmitStart, instance),
										success: A.bind(instance._onSubmitSuccess, instance)
									}
								}
							);
						}
					}

					return valid;
				},

				_afterDisabledChange: function(event) {
					var instance = this;

					var action = 'disable';

					if (event.newVal) {
						action = 'enable';
					}

					instance.fields.each(
						function(item, index, collection) {
							item[action];
						}
					);
				},

				_afterLabelAlignChange: function(event) {
					var instance = this;

					instance._uiSetLabelAlign(event.newVal, event.prevVal)
				},

				_afterNativeSubmitChange: function(event) {
					var instance = this;

					var contentBox = instance.get('contentBox');

					var action = 'on';

					if (event.newVal) {
						action = 'detach';
					}

					contentBox[action]('submit', instance._onSubmit);
				},

				_attributeGetter: function(value, key) {
					var instance = this;

					return instance.get('contentBox').attr(key);
				},

				_attributeSetter: function(value, key) {
					var instance = this;

					instance.get('contentBox').attr(key, value);

					return value;
				},

				_getNodeId: function(obj) {
					var node;

					if (obj instanceof A.Field) {
						node = obj.get('node');
					}
					else {
						node = A.get(obj);
					}
					var guid = node && node.guid();

					return guid;
				},

				_onSubmit: function(event) {
					event.halt();
				},

				_onSubmitComplete: function(event) {
					var instance = this;

					instance.fire(
						'complete',
						 {
						 	ioEvent: event
						 }
					);
				},

				_onSubmitEnd: function(event) {
					var instance = this;

					instance.fire(
						'end',
						 {
						 	ioEvent: event
						 }
					);
				},

				_onSubmitFailure: function(event) {
					var instance = this;

					instance.fire(
						'failure',
						 {
						 	ioEvent: event
						 }
					);
				},

				_onSubmitStart: function(event) {
					var instance = this;

					instance.fire(
						'start',
						 {
						 	ioEvent: event
						 }
					);
				},

				_onSubmitSuccess: function(event) {
					var instance = this;

					instance.fire(
						'success',
						 {
						 	ioEvent: event
						 }
					);
				},

				_renderForm: function() {
					var instance = this;

					instance.get('contentBox').removeClass(CSS_FORM);
				},

				_markInvalidArray: function(item, index, collection) {
					var instance = this;

					var field = instance.getField(item.id);

					if (field) {
						field.markInvalid(item.message);
					}
				},

				_markInvalidObject: function(item, index, collection) {
					var instance = this;

					var field = (!Lang.isFunction(item)) && instance.getField(index);

					if (field) {
						field.markInvalid(item);
					}
				},

				_setFieldsArray: function(item, index, collection, monitorChanges) {
					var instance = this;

					var field = instance.getField(item.id);

					if (field) {
						field.set('value', item.value);

						if (monitorChanges) {
							field.set('prevVal', field.get('value'));
						}
					}
				},

				_setFieldsObject: function(item, index, collection, monitorChanges) {
					var instance = this;

					var field = (!Lang.isFunction(item)) && instance.getField(index);

					if (field) {
						field.set('value', item);

						if (monitorChanges) {
							field.set('prevVal', field.get('value'));
						}
					}
				},

				_uiSetLabelAlign: function(newVal, prevVal) {
					var instance = this;

					var contentBox = instance.get('contentBox');

					contentBox.replaceClass(CSS_LABEL_ALIGN[prevVal], CSS_LABEL_ALIGN[newVal]);

					var action = 'removeClass';

					if (/right|left/.test(newVal)) {
						action = 'addClass';
					}

					contentBox[action](CSS_LABELS_INLINE);
				}
			}
		);

		A.Form = Form;
	},
	'0.1a',
	{
		requires: ['aui-base', 'data-set', 'io-form', 'field'],
		use: []
	}
);AUI.add('image-gallery', function(A) {

/*
* ImageGallery
*/
var L = A.Lang,
	isBoolean = L.isBoolean,
	isNumber = L.isNumber,
	isObject = L.isObject,
	isString = L.isString,

	AUTO_PLAY = 'autoPlay',
	BODY = 'body',
	CONTENT = 'content',
	CURRENT_INDEX = 'currentIndex',
	DELAY = 'delay',
	DOT = '.',
	ENTRY = 'entry',
	HANDLER = 'handler',
	HIDDEN = 'hidden',
	HREF = 'href',
	IMAGE_GALLERY = 'image-gallery',
	IMG = 'img',
	LEFT = 'left',
	LINKS = 'links',
	OFFSET_WIDTH = 'offsetWidth',
	OVERLAY = 'overlay',
	PAGE = 'page',
	PAGINATOR = 'paginator',
	PAGINATOR_EL = 'paginatorEl',
	PAGINATOR_INSTANCE = 'paginatorInstance',
	PAUSE = 'pause',
	PAUSED = 'paused',
	PAUSED_LABEL = 'pausedLabel',
	PLAY = 'play',
	PLAYER = 'player',
	PLAYING = 'playing',
	PLAYING_LABEL = 'playingLabel',
	PX = 'px',
	REPEAT = 'repeat',
	SHOW_PLAYER = 'showPlayer',
	SPACE = ' ',
	SRC = 'src',
	THUMB = 'thumb',
	TOOLSET = 'toolSet',
	TOOLSET_INSTANCE = 'toolSetInstance',
	TOTAL_LINKS = 'totalLinks',
	USE_ORIGINAL_IMAGE = 'useOriginalImage',
	VIEWPORT_REGION = 'viewportRegion',
	VISIBLE = 'visible',

	concat = function() {
		return Array.prototype.slice.call(arguments).join(SPACE);
	},

	getCN = A.ClassNameManager.getClassName,

	CSS_IMAGE_GALLERY_PAGINATOR = getCN(IMAGE_GALLERY, PAGINATOR),
	CSS_IMAGE_GALLERY_PAGINATOR_CONTENT = getCN(IMAGE_GALLERY, PAGINATOR, CONTENT),
	CSS_IMAGE_GALLERY_PAGINATOR_ENTRY = getCN(IMAGE_GALLERY, PAGINATOR, ENTRY),
	CSS_IMAGE_GALLERY_PAGINATOR_LINKS = getCN(IMAGE_GALLERY, PAGINATOR, LINKS),
	CSS_IMAGE_GALLERY_PAGINATOR_THUMB = getCN(IMAGE_GALLERY, PAGINATOR, THUMB),
	CSS_IMAGE_GALLERY_PLAYER = getCN(IMAGE_GALLERY, PLAYER),
	CSS_IMAGE_GALLERY_PLAYER_CONTENT = getCN(IMAGE_GALLERY, PLAYER, CONTENT),
	CSS_OVERLAY_HIDDEN = getCN(OVERLAY, HIDDEN),

	TEMPLATE_PLAYING_LABEL = '(playing)',
	TEMPLATE_PAGINATOR = '<div class="'+CSS_IMAGE_GALLERY_PAGINATOR_CONTENT+'">{PageLinks}</div>',

	TPL_LINK = '<span class="' + CSS_IMAGE_GALLERY_PAGINATOR_ENTRY + '"><span class="' + CSS_IMAGE_GALLERY_PAGINATOR_THUMB+'"></span></span>',
	TPL_LINK_CONTAINER = '<div class="' + CSS_IMAGE_GALLERY_PAGINATOR_LINKS + '"></div>',
	TPL_PAGINATOR_CONTAINER = '<div class="'+concat(CSS_OVERLAY_HIDDEN, CSS_IMAGE_GALLERY_PAGINATOR)+'"></div>',
	TPL_PLAYER_CONTAINER = '<div class="'+CSS_IMAGE_GALLERY_PLAYER+'"></div>',
	TPL_PLAYER_CONTENT = '<span class="'+CSS_IMAGE_GALLERY_PLAYER_CONTENT+'"></span>';


function ImageGallery(config) {
	ImageGallery.superclass.constructor.apply(this, arguments);
}

A.mix(ImageGallery, {
	NAME: IMAGE_GALLERY,

	ATTRS: {
		autoPlay: {
			value: false,
			validator: isBoolean
		},

		delay: {
			value: 7000,
			validator: isNumber
		},

		paginator: {
			value: {},
			setter: function(value) {
				var instance = this;
				var paginatorEl = instance.get(PAGINATOR_EL);
				var totalLinks = instance.get(TOTAL_LINKS);

				return A.merge(
					{
						containers: paginatorEl,
						pageContainerTemplate: TPL_LINK_CONTAINER,
						pageLinkContent: A.bind(instance._setThumbContent, instance),
						pageLinkTemplate: TPL_LINK,
						template: TEMPLATE_PAGINATOR,
						total: totalLinks,
						on: {
							changeRequest: function(event) {
								// fire changeRequest from ImageGallery passing the "state" object from Paginator
								instance.fire('changeRequest', { state: event.state })
							}
						}
					},
					value
				);
			},
			validator: isObject
		},

		paginatorEl: {
			readyOnly: true,
			valueFn: function() {
				return A.Node.create(TPL_PAGINATOR_CONTAINER);
			}
		},

		paginatorInstance: {
			value: null
		},

		paused: {
			value: false,
			validator: isBoolean
		},

		pausedLabel: {
			value: '',
			validator: isString
		},

		playing: {
			value: false,
			validator: isBoolean
		},

		playingLabel: {
			value: TEMPLATE_PLAYING_LABEL,
			validator: isString
		},

		repeat: {
			value: true,
			validator: isBoolean
		},

		showPlayer: {
			value: true,
			validator: isBoolean
		},

		toolSet: {
			value: {},
			setter: function(value) {
				var instance = this;

				return A.merge(
					{
						tools: [
							{
								id: PLAY,
								icon: PLAY
							},
							{
								id: PAUSE,
								icon: PAUSE
							}
						]
					},
					value
				);
			},
			validator: isObject
		},

		toolSetInstance: {
			value: null
		},

		useOriginalImage: {
			value: false,
			validator: isBoolean
		}
	}
});

A.extend(ImageGallery, A.ImageViewer, {
	_timer: null,

	/*
	* Lifecycle
	*/
	renderUI: function() {
		var instance = this;

		ImageGallery.superclass.renderUI.apply(this, arguments);

		instance._renderPaginator();

		if (instance.get(SHOW_PLAYER)) {
			instance._renderPlayer();
		}
	},

	bindUI: function() {
		var instance = this;

		ImageGallery.superclass.bindUI.apply(this, arguments);

		instance._bindToolSetUI();

		instance.on('playingChange', instance._onPlayingChange);
		instance.on('pausedChange', instance._onPausedChange);

		instance.publish('changeRequest', { defaultFn: this._changeRequest });
	},

	destroy: function() {
		var instance = this;

		ImageGallery.superclass.destroy.apply(this, arguments);

		instance.get(PAGINATOR_INSTANCE).destroy();
	},

	/*
	* Methods
	*/
	hidePaginator: function() {
		var instance = this;

		instance.get(PAGINATOR_EL).addClass(CSS_OVERLAY_HIDDEN);
	},

	pause: function() {
		var instance = this;

		instance.set(PAUSED, true);
		instance.set(PLAYING, false);

		instance._syncInfoUI();
	},

	play: function() {
		var instance = this;

		instance.set(PAUSED, false);
		instance.set(PLAYING, true);

		instance._syncInfoUI();
	},

	showPaginator: function() {
		var instance = this;

		instance.get(PAGINATOR_EL).removeClass(CSS_OVERLAY_HIDDEN);
	},

	_bindToolSetUI: function() {
		var instance = this;

		if (instance.get(SHOW_PLAYER)) {
			var toolSetInstance = instance.get(TOOLSET_INSTANCE);

			var play = toolSetInstance.item(PLAY);
			var pause = toolSetInstance.item(PAUSE);

			play.set(HANDLER, A.bind(instance.play, instance));
			pause.set(HANDLER, A.bind(instance.pause, instance));
		}
	},

	_cancelTimer: function() {
		var instance = this;

		if (instance._timer) {
			instance._timer.cancel();
		}
	},

	_renderPaginator: function() {
		var instance = this;
		var paginatorEl = instance.get(PAGINATOR_EL);

		A.one(BODY).append(
			paginatorEl.hide()
		);

		var paginatorInstance = new A.Paginator(
			instance.get(PAGINATOR)
		)
		.render();

		instance.set(PAGINATOR_INSTANCE, paginatorInstance);
	},

	_renderPlayer: function() {
		var instance = this;
		var paginatorEl = instance.get(PAGINATOR_EL);
		var playerContent = A.Node.create(TPL_PLAYER_CONTENT);

		paginatorEl.append(
			A.Node.create(TPL_PLAYER_CONTAINER).append(playerContent)
		);

		var toolSetInstance = new A.ToolSet(
			instance.get(TOOLSET)
		)
		.render(playerContent);

		instance.set(TOOLSET_INSTANCE, toolSetInstance);
	},

	_startTimer: function() {
		var instance = this;
		var delay = instance.get(DELAY);

		instance._cancelTimer();

		instance._timer = A.later(delay, instance, instance._syncSlideShow);
	},

	_syncControlsUI: function() {
		var instance = this;

		ImageGallery.superclass._syncControlsUI.apply(this, arguments);

		if (instance.get(VISIBLE)) {
			instance._syncSelectedThumbUI();

			instance.showPaginator();
		}
		else {
			instance.hidePaginator();

			instance._cancelTimer();
		}
	},

	_syncSelectedThumbUI: function() {
		var instance = this;
		var currentIndex = instance.get(CURRENT_INDEX);
		var paginatorInstance = instance.get(PAGINATOR_INSTANCE);
		var paginatorIndex = paginatorInstance.get(PAGE) - 1;

		// when currentIndex != paginatorIndex we need to load the new image
		if (currentIndex != paginatorIndex) {
			// originally the paginator changeRequest is only invoked when user interaction happens, forcing invoke changeRequest from paginator
			paginatorInstance.set(PAGE, currentIndex + 1);

			paginatorInstance.changeRequest();
		}
	},

	_syncSlideShow: function() {
		var instance = this;

		if (!instance.hasNext()) {
			if (instance.get(REPEAT)) {
				instance.set(CURRENT_INDEX, -1);
			}
			else {
				instance._cancelTimer();
			}
		}

		instance.next();
	},

	/*
	* Paginator Methods
	*/
	_changeRequest: function(event) {
		var instance = this;
		var paginatorInstance = event.state.paginator;
		var newState = event.state;
		var beforeState = newState.before;
		var page = newState.page;

		// only update the paginator UI when the Overlay is visible
		if (!instance.get(VISIBLE)) {
			return false; // NOTE: return
		}

		var currentIndex = instance.get(CURRENT_INDEX);
		var paginatorIndex = page - 1;

		// check if the beforeState page number is different from the newState page number.
		if (!beforeState || beforeState && (beforeState.page != page)) {
			// updating currentIndex
			instance.set(CURRENT_INDEX, paginatorIndex);

			// loading current index image
			instance.loadImage(
				instance.getCurrentLink().attr(HREF)
			);

			// updating the UI of the paginator
			paginatorInstance.setState(newState);

			// restart the timer if the user change the image, respecting the paused state
			var paused = instance.get(PAUSED);
			var playing = instance.get(PLAYING);

			if (playing && !paused) {
				instance._startTimer();
			}
		}
	},

	_setThumbContent: function(pageEl, pageNumber) {
		var instance = this;
		var index = pageNumber - 1;
		var link = instance.getLink(index);
		var thumbEl = pageEl.one(DOT+CSS_IMAGE_GALLERY_PAGINATOR_THUMB);
		var thumbSrc = null;

		if (instance.get(USE_ORIGINAL_IMAGE)) {
			thumbSrc = link.attr(HREF);
		}
		else {
			// try to find a inner thumbnail image to show on the paginator
			var innerImage = link.one(IMG);

			if (innerImage) {
				thumbSrc = innerImage.attr(SRC);
			}
		}

		if (thumbSrc) {
			thumbEl.setStyles({
				// use background to show the thumbnails to take advantage of the background-position: 50% 50%
				backgroundImage: 'url(' + thumbSrc + ')'
			});
		}
	},

	/*
	* Getters
	*/
	_getInfoTemplate: function(v) {
		var label;
		var instance = this;
		var paused = instance.get(PAUSED);
		var playing = instance.get(PLAYING);

		if (playing) {
			label = instance.get(PLAYING_LABEL);
		}
		else if (paused) {
			label = instance.get(PAUSED_LABEL);
		}

		return concat(
			ImageGallery.superclass._getInfoTemplate.apply(this, arguments),
			label
		);
	},

	/*
	* Listeners
	*/
	_afterVisibleChange: function(event) {
		var instance = this;

		// invoke A.ImageViewer _afterVisibleChange method
		ImageGallery.superclass._afterVisibleChange.apply(this, arguments);

		if (event.newVal) {
			// trigger autoPlay when overlay is visible
			if (instance.get(AUTO_PLAY)) {
				instance.play();
			}
		}
	},

	_onPausedChange: function(event) {
		var instance = this;

		if (event.newVal) {
			instance._cancelTimer();
		}
	},

	_onPlayingChange: function(event) {
		var instance = this;

		if (event.newVal) {
			instance._startTimer();
		}
	}
});

A.ImageGallery = ImageGallery;

}, '0.1a', { requires: [ 'image-viewer', 'paginator', 'tool-set' ] });AUI.add('image-viewer', function(A) {

/*
* ImageViewer
*/
var L = A.Lang,
	isBoolean = L.isBoolean,
	isNumber = L.isNumber,
	isObject = L.isObject,
	isString = L.isString,

	NodeFx = A.Plugin.NodeFX,

	ANIM = 'anim',
	ARROW = 'arrow',
	ARROW_LEFT_EL = 'arrowLeftEl',
	ARROW_RIGHT_EL = 'arrowRightEl',
	BD = 'bd',
	BLANK = 'blank',
	BODY = 'body',
	BOUNDING_BOX = 'boundingBox',
	CAPTION = 'caption',
	CAPTION_EL = 'captionEl',
	CAPTION_FROM_TITLE = 'captionFromTitle',
	CENTERED = 'centered',
	CLOSE = 'close',
	CLOSE_EL = 'closeEl',
	CREATE_DOCUMENT_FRAGMENT = 'createDocumentFragment',
	CURRENT_INDEX = 'currentIndex',
	EASE_BOTH_STRONG = 'easeBothStrong',
	FOOTER = 'footer',
	HELPER = 'helper',
	HIDDEN = 'hidden',
	HIDE = 'hide',
	HREF = 'href',
	ICON = 'icon',
	IMAGE = 'image',
	IMAGE_ANIM = 'imageAnim',
	IMAGE_VIEWER = 'image-viewer',
	INFO = 'info',
	INFO_EL = 'infoEl',
	INFO_TEMPLATE = 'infoTemplate',
	LEFT = 'left',
	LINK = 'link',
	LINKS = 'links',
	LOADER = 'loader',
	LOADING = 'loading',
	LOADING_EL = 'loadingEl',
	LOCK = 'lock',
	MODAL = 'modal',
	OFFSET_HEIGHT = 'offsetHeight',
	OFFSET_WIDTH = 'offsetWidth',
	OPACITY = 'opacity',
	OVERLAY = 'overlay',
	PRELOAD_ALL_IMAGES = 'preloadAllImages',
	PRELOAD_NEIGHBOR_IMAGES = 'preloadNeighborImages',
	PX = 'px',
	RIGHT = 'right',
	SCROLL = 'scroll',
	SHOW = 'show',
	SHOW_ARROWS = 'showArrows',
	SHOW_CLOSE = 'showClose',
	SPACE = ' ',
	SRC = 'src',
	TITLE = 'title',
	TOP = 'top',
	TOTAL_LINKS = 'totalLinks',
	VIEWPORT_REGION = 'viewportRegion',
	VISIBLE = 'visible',
    OWNER_DOCUMENT = 'ownerDocument',

	isNodeList = function(v) {
		return (v instanceof A.NodeList);
	},

	concat = function() {
		return Array.prototype.slice.call(arguments).join(SPACE);
	},

	KEY_ESC = 27,
	KEY_RIGHT = 39,
	KEY_LEFT = 37,

	getCN = A.ClassNameManager.getClassName,

	CSS_HELPER_SCROLL_LOCK = getCN(HELPER, SCROLL, LOCK),
	CSS_ICON_LOADING = getCN(ICON, LOADING),
	CSS_IMAGE_VIEWER_ARROW = getCN(IMAGE_VIEWER, ARROW),
	CSS_IMAGE_VIEWER_ARROW_LEFT = getCN(IMAGE_VIEWER, ARROW, LEFT),
	CSS_IMAGE_VIEWER_ARROW_RIGHT = getCN(IMAGE_VIEWER, ARROW, RIGHT),
	CSS_IMAGE_VIEWER_BD = getCN(IMAGE_VIEWER, BD),
	CSS_IMAGE_VIEWER_CAPTION = getCN(IMAGE_VIEWER, CAPTION),
	CSS_IMAGE_VIEWER_CLOSE = getCN(IMAGE_VIEWER, CLOSE),
	CSS_IMAGE_VIEWER_IMAGE = getCN(IMAGE_VIEWER, IMAGE),
	CSS_IMAGE_VIEWER_INFO = getCN(IMAGE_VIEWER, INFO),
	CSS_IMAGE_VIEWER_LINK = getCN(IMAGE_VIEWER, LINK),
	CSS_IMAGE_VIEWER_LOADING = getCN(IMAGE_VIEWER, LOADING),
	CSS_OVERLAY_HIDDEN = getCN(OVERLAY, HIDDEN),

	NODE_BLANK_TEXT = document.createTextNode(''),

	INFO_LABEL_TEMPLATE = 'Image {current} of {total}',

	TPL_ARROW_LEFT = '<a href="#" class="'+concat(CSS_IMAGE_VIEWER_ARROW, CSS_IMAGE_VIEWER_ARROW_LEFT)+'"></a>',
	TPL_ARROW_RIGHT = '<a href="#" class="'+concat(CSS_IMAGE_VIEWER_ARROW, CSS_IMAGE_VIEWER_ARROW_RIGHT)+'"></a>',
	TPL_CAPTION = '<div class="' + CSS_IMAGE_VIEWER_CAPTION + '"></div>',
	TPL_CLOSE = '<a href="#" class="'+ CSS_IMAGE_VIEWER_CLOSE +'"></a>',
	TPL_IMAGE = '<img class="' + CSS_IMAGE_VIEWER_IMAGE + '" />',
	TPL_INFO = '<div class="' + CSS_IMAGE_VIEWER_INFO + '"></div>',
	TPL_LOADER = '<div class="' + CSS_OVERLAY_HIDDEN + '"></div>',
	TPL_LOADING = '<div class="' + CSS_ICON_LOADING + '"></div>';

function ImageViewer(config) {
	ImageViewer.superclass.constructor.apply(this, arguments);
}

A.mix(ImageViewer, {
	NAME: IMAGE_VIEWER,

	ATTRS: {
		anim: {
			value: true,
			validator: isBoolean
		},

		bodyContent: {
			value: NODE_BLANK_TEXT
		},

		caption: {
			value: BLANK,
			validator: isString
		},


		captionFromTitle: {
			value: true,
			validator: isBoolean
		},

		centered: {
			value: true
		},

		currentIndex: {
			value: 0,
			validator: isNumber
		},

		image: {
			readOnly: true,
			valueFn: function() {
				return A.Node.create(TPL_IMAGE);
			}
		},

		imageAnim: {
			value: {},
			setter: function(value) {
				return A.merge(
					{
						to: {
							opacity: 1
						},
						easing: EASE_BOTH_STRONG,
						duration: .8
					},
					value
				);
			},
			validator: isObject
		},

		infoTemplate: {
			getter: function(v) {
				return this._getInfoTemplate(v);
			},
			value: INFO_LABEL_TEMPLATE,
			validator: isString
		},

		links: {
			setter: function(v) {
				var instance = this;

				if (isNodeList(v)) {
					return v;
				}
				else if (isString(v)) {
					return A.all(v);
				}

				return new A.NodeList([v]);
			}
		},

		loading: {
			value: false,
			validator: isBoolean
		},

		modal: {
			value: {
				opacity: .8,
				background: '#000'
			}
		},

		preloadAllImages: {
			value: false,
			validator: isBoolean
		},

		preloadNeighborImages: {
			value: true,
			validator: isBoolean
		},

		showClose: {
			value: true,
			validator: isBoolean
		},

		showArrows: {
			value: true,
			validator: isBoolean
		},

		totalLinks: {
			readOnly: true,
			getter: function(v) {
				return this.get(LINKS).size();
			}
		},

		visible: {
			value: false
		},

		zIndex: {
			value: 3000,
			validator: isNumber
		},

		/*
		* Static Attrs
		*/
		arrowLeftEl: {
			readOnly: true,
			valueFn: function() {
				return A.Node.create(TPL_ARROW_LEFT);
			}
		},

		arrowRightEl: {
			readOnly: true,
			valueFn: function() {
				return A.Node.create(TPL_ARROW_RIGHT);
			}
		},

		captionEl: {
			readOnly: true,
			valueFn: function() {
				return A.Node.create(TPL_CAPTION);
			}
		},

		closeEl: {
			readOnly: true,
			valueFn: function() {
				return A.Node.create(TPL_CLOSE);
			}
		},

		infoEl: {
			readOnly: true,
			valueFn: function() {
				return A.Node.create(TPL_INFO);
			}
		},

		loader: {
			readOnly: true,
			valueFn: function() {
				return A.Node.create(TPL_LOADER).appendTo(document.body);
			}
		},

		loadingEl: {
			valueFn: function() {
				return A.Node.create(TPL_LOADING);
			}
		}
	}
});

A.extend(ImageViewer, A.ComponentOverlay, {
	activeImage: 0,

	_keyHandler: null,

	/*
	* Lifecycle
	*/
	renderUI: function() {
		var instance = this;

		instance._renderControls();
		instance._renderFooter();

		instance.get(LINKS).addClass(CSS_IMAGE_VIEWER_LINK);
	},

	bindUI: function() {
		var instance = this;
		var links = instance.get(LINKS);
		var arrowLeftEl = instance.get(ARROW_LEFT_EL);
		var arrowRightEl = instance.get(ARROW_RIGHT_EL);
		var closeEl = instance.get(CLOSE_EL);

		arrowLeftEl.on('click', A.bind(instance._onClickLeftArrow, instance));
		arrowRightEl.on('click', A.bind(instance._onClickRightArrow, instance));
		closeEl.on('click', A.bind(instance._onClickCloseEl, instance));
		links.on('click', A.bind(instance._onClickLinks, instance));

		instance._keyHandler = A.bind(instance._onKeyInteraction, instance);

		// NOTE: using keydown to avoid keyCode bug on IE
		A.getDoc().on('keydown', instance._keyHandler);

		instance.after('render', instance._afterRender);
		instance.after('loadingChange', instance._afterLoadingChange);
		instance.after('visibleChange', instance._afterVisibleChange);
	},

	destroy: function() {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);
		var links = instance.get(LINKS);

		instance.close();

		links.detach('click');
		links.removeClass(CSS_IMAGE_VIEWER_LINK);

		// detach key global listener from the document
		A.getDoc().detach('keydown', instance._keyHandler);

		instance.get(ARROW_LEFT_EL).remove();
		instance.get(ARROW_RIGHT_EL).remove();
		instance.get(CLOSE_EL).remove();
		instance.get(LOADER).remove();

		boundingBox.remove();
	},

	/*
	* Methods
	*/
	close: function() {
		var instance = this;

		instance.hide();
		instance.hideMask();
	},

	getLink: function(currentIndex) {
		var instance = this;

		return instance.get(LINKS).item(currentIndex);
	},

	getCurrentLink: function() {
		var instance = this;

		return instance.getLink(
			instance.get(CURRENT_INDEX)
		);
	},

	loadImage: function(src) {
		var instance = this;
		var bodyNode = instance.bodyNode;
		var loader = instance.get(LOADER);

		instance.set(LOADING, true);

		// the user could navigate to the next/prev image before the current image onLoad trigger
		// detach load event from the activeImage before create the new image placeholder
		if (instance.activeImage) {
			instance.activeImage.detach('load');
		}

		// creating the placeholder image
		instance.activeImage = instance.get(IMAGE).cloneNode(true);

		var image = instance.activeImage;

		// append the placeholder image to the loader div
		loader.empty();
		loader.append(image);

		// bind the onLoad handler to the image, this handler should append the loaded image
		// to the overlay and take care of all animations
		image.on('load', A.bind(instance._onLoadImage, instance));

		// set the src of the image to be loaded on the placeholder image
		image.attr(SRC, src);

		instance.fire('request', { image: image });
	},

	hasLink: function(currentIndex) {
		var instance = this;

		return instance.getLink(currentIndex);
	},

	hasNext: function() {
		var instance = this;

		return instance.hasLink(
			instance.get(CURRENT_INDEX) + 1
		);
	},

	hasPrev: function() {
		var instance = this;

		return instance.hasLink(
			instance.get(CURRENT_INDEX) - 1
		);
	},

	hideControls: function() {
		var instance = this;

		instance.get(ARROW_LEFT_EL).hide();
		instance.get(ARROW_RIGHT_EL).hide();
		instance.get(CLOSE_EL).hide();
	},

	hideMask: function() {
		A.ImageViewerMask.hide();
	},

	next: function() {
		var instance = this;
		var currentIndex = instance.get(CURRENT_INDEX);

		if (instance.hasNext()) {
			instance.set(CURRENT_INDEX, currentIndex + 1);

			instance.loadImage(
				instance.getCurrentLink().attr(HREF)
			);
		}
	},

	preloadAllImages: function() {
		var instance = this;

		instance.get(LINKS).each(function(link, index) {
			instance.preloadImage(index);
		});
	},

	preloadImage: function(currentIndex) {
		var instance = this;

		var link = instance.getLink(currentIndex);

		if (link) {
			var src = link.attr(HREF);

			instance.get(IMAGE).cloneNode(true).attr(SRC, src);
		}
	},

	prev: function() {
		var instance = this;
		var currentIndex = instance.get(CURRENT_INDEX);

		if (instance.hasPrev()) {
			instance.set(CURRENT_INDEX, currentIndex - 1);

			instance.loadImage(
				instance.getCurrentLink().attr(HREF)
			);
		}
	},

	showLoading: function() {
		var instance = this;
		var bodyNode = instance.bodyNode;

		instance.setStdModContent(
			BODY,
			instance.get(LOADING_EL)
		);
	},

	showMask: function() {
		var instance = this;
		var modal = instance.get(MODAL);

		if (isObject(modal)) {
			A.each(modal, function(value, key) {
				A.ImageViewerMask.set(key, value);
			});
		}

		if (modal) {
			A.ImageViewerMask.show();
		}
	},

	show: function() {
		var instance = this;
		var currentLink = instance.getCurrentLink();

		if (currentLink) {
			instance.showMask();

			ImageViewer.superclass.show.apply(this, arguments);

			instance.loadImage(
				currentLink.attr(HREF)
			);
		}
	},

	_renderControls: function() {
		var instance = this;
		var body = A.one(BODY);

		body.append(
			instance.get(ARROW_LEFT_EL).hide()
		);

		body.append(
			instance.get(ARROW_RIGHT_EL).hide()
		);

		body.append(
			instance.get(CLOSE_EL).hide()
		);
	},

	_renderFooter: function() {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);
		var docFrag = boundingBox.get(OWNER_DOCUMENT).invoke(CREATE_DOCUMENT_FRAGMENT);

		docFrag.append(
			instance.get(CAPTION_EL)
		);
		docFrag.append(
			instance.get(INFO_EL)
		);

		instance.setStdModContent(
			FOOTER,
			docFrag
		);
	},

	_syncCaptionUI: function() {
		var instance = this;
		var caption = instance.get(CAPTION);
		var captionEl = instance.get(CAPTION_EL);
		var captionFromTitle = instance.get(CAPTION_FROM_TITLE);

		if (captionFromTitle) {
			var currentLink = instance.getCurrentLink();

			if (currentLink) {
				var title = currentLink.attr(TITLE);

				if (title) {
					caption = currentLink.attr(TITLE);
				}
			}
		}

		captionEl.html(caption);
	},

	_syncControlsUI: function() {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);
		var arrowLeftEl = instance.get(ARROW_LEFT_EL);
		var arrowRightEl = instance.get(ARROW_RIGHT_EL);
		var closeEl = instance.get(CLOSE_EL);

		if (instance.get(VISIBLE)) {
			if (instance.get(SHOW_ARROWS)) {
				// get the viewportRegion to centralize the arrows on the middle of the window viewport
				var viewportRegion = boundingBox.get(VIEWPORT_REGION);
				var heightRegion = Math.floor(viewportRegion.height/2) + viewportRegion.top;

				// show or hide arrows based on the hasPrev/hasNext information
				arrowLeftEl[ instance.hasPrev() ? SHOW : HIDE ]();
				arrowRightEl[ instance.hasNext() ? SHOW : HIDE ]();

				// set style top of the arrows in the middle of the window viewport
				arrowLeftEl.setStyle(TOP, heightRegion - arrowLeftEl.get(OFFSET_HEIGHT) + PX);
				arrowRightEl.setStyle(TOP, heightRegion - arrowRightEl.get(OFFSET_HEIGHT) + PX);
			}

			// if SHOW_CLOSE is enables, show close icon
			if (instance.get(SHOW_CLOSE)) {
				closeEl.show();
			}
		}
		else {
			// if the overlay is not visible hide all controls
			instance.hideControls();
		}
	},

	_syncImageViewerUI: function() {
		var instance = this;

		instance._syncControlsUI();
		instance._syncCaptionUI();
		instance._syncInfoUI();
	},

	_syncInfoUI: function() {
		var instance = this;
		var infoEl = instance.get(INFO_EL);

		infoEl.html(
			instance.get(INFO_TEMPLATE)
		);
	},

	/*
	* Getters
	*/
	_getInfoTemplate: function(v) {
		var instance = this;
		var total = instance.get(TOTAL_LINKS);
		var current = instance.get(CURRENT_INDEX) + 1;

		return A.substitute(v, {
			current: current,
			total: total
		});
	},

	/*
	* Listeners
	*/
	_afterRender: function() {
		var instance = this;
		var bodyNode = instance.bodyNode;

		bodyNode.addClass(CSS_IMAGE_VIEWER_BD);

		if (instance.get(PRELOAD_ALL_IMAGES)) {
			instance.preloadAllImages();
		}
	},

	_afterLoadingChange: function(event) {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);

		if (event.newVal) {
			boundingBox.addClass(CSS_IMAGE_VIEWER_LOADING);

			instance.showLoading();
		}
		else{
			boundingBox.removeClass(CSS_IMAGE_VIEWER_LOADING);
		}
	},

	_afterVisibleChange: function(event) {
		var instance = this;

		// invoke A.Overlay _afterVisibleChange method
		ImageViewer.superclass._afterVisibleChange.apply(this, arguments);

		instance._syncControlsUI();
	},

	_onClickCloseEl: function(event) {
		var instance = this;

		instance.close();

		event.halt()
	},

	_onClickLeftArrow: function(event) {
		var instance = this;

		instance.prev();

		event.halt()
	},

	_onClickRightArrow: function(event) {
		var instance = this;

		instance.next();

		event.halt()
	},

	_onClickLinks: function(event) {
		var instance = this;
		var target = event.currentTarget;

		// set the current currentIndex of the clicked image
		instance.set(
			CURRENT_INDEX,
			instance.get(LINKS).indexOf(target)
		);

		instance.show();

		event.preventDefault();
	},

	_onKeyInteraction: function(event) {
		var instance = this;
		var keyCode = event.keyCode;

		if (!instance.get(VISIBLE)) {
			return false; // NOTE: return
		}

		if (keyCode == KEY_LEFT) {
			instance.prev();
		}
		else if (keyCode == KEY_RIGHT) {
			instance.next();
		}
		else if (keyCode == KEY_ESC) {
			instance.close();
		}
	},

	_onLoadImage: function(event) {
		var instance = this;
		var bodyNode = instance.bodyNode;
		var image = event.currentTarget;

		var offsetHeight = image.get(OFFSET_HEIGHT) + PX;
		var offsetWidth = image.get(OFFSET_WIDTH) + PX;
		var imageAnim = instance.get(IMAGE_ANIM);

		if (instance.get(ANIM)) {
			image.setStyle(OPACITY, 0);

			// preparing node to the animation, pluging the NodeFX
			image.unplug(NodeFx).plug(NodeFx);

			image.fx.on('end', function(info) {
				instance.fire('anim', { anim: info, image: image });
			});

			image.fx.setAttrs(imageAnim);
			image.fx.stop().run();
		}

		instance.setStdModContent(BODY, image);

		bodyNode.setStyles({
			width: offsetWidth,
			height: offsetHeight
		});

		instance._syncImageViewerUI();

		instance.set(CENTERED, true);
		instance.set(LOADING, false);

		instance.fire('load', { image: image });

		if (instance.get(PRELOAD_NEIGHBOR_IMAGES)) {
			// preload neighbor images
			var currentIndex = instance.get(CURRENT_INDEX);

			instance.preloadImage(currentIndex + 1);
			instance.preloadImage(currentIndex - 1);
		}
	}
});

A.ImageViewer = ImageViewer;

A.ImageViewerMask = new A.OverlayMask().render();

}, '0.1a', { requires: [ 'aui-base', 'anim', 'overlay-mask', 'substitute', 'image-viewer-css' ] });AUI.add('input-handler', function(A) {

/*
* This event fires when the value of the element changes, either as a result of
* a keystroke, or from an input event.
*
* @event input
*/
var	L = A.Lang,
	isFunction = L.isFunction,

	ACTIVE_ELEMENT = 'activeElement',
	OWNER_DOCUMENT = 'ownerDocument',

	UA = A.UA;

var evt = {
	on: function(type, fn, el) {
		// priorize input event that supports copy & paste
		var etype = 'input';

		// WebKit before version 531 (3.0.182.2) did not support input events for textareas.
		// http://dev.chromium.org/developers/webkit-version-table
		// All Chrome versions supports input event
		// TODO: use UA.chrome when YUI 3 detects it
		if (!/chrome/i.test(UA.agent) && UA.webkit && UA.version.major <= 2) {
			etype = 'keypress';
		}
		else if (UA.ie) {
			// IE doesn't support input event, simulate it with propertychange
			etype = 'propertychange';
		}

		var handler = function(event) {
			var instance = this;
			var input = event.target;
			var originalEvent = event._event;

			// only trigger checkLength() on IE when propertychange happens on the value attribute
			if (event.type == 'propertychange') {
				if (originalEvent && (originalEvent.propertyName != 'value')) {
					return false; // NOTE: return
				}
			}

			var focused = (input.get(OWNER_DOCUMENT).get(ACTIVE_ELEMENT) == input);

			if (focused && isFunction(fn)) {
				fn.apply(instance, arguments);
			}
		};

		return A.Event.attach(etype, handler, el);
	}
};

A.Env.evt.plugins.input = evt;

if (A.Node) {
	A.Node.DOM_EVENTS.input = evt;
}

}, '0.1a', { requires: [] });AUI.add('io-stdmod', function(A) {

var L = A.Lang,
	isString = L.isString,

	BLANK = '',
	CFG = 'cfg',
	FORMATTER = 'formatter',
	HOST = 'host',
	ICON = 'icon',
	LOADING = 'loading',
	POST = 'POST',
	QUEUE = 'queue',
	SECTION = 'section',
	URI = 'uri',

	getCN = A.ClassNameManager.getClassName,

	CSS_ICON_LOADING = getCN(ICON, LOADING);

var StdMod = A.WidgetStdMod;

/* Standard Module IO Plugin Constructor */
function StdModIOPlugin(config) {
	StdModIOPlugin.superclass.constructor.apply(this, arguments);
}

A.mix(StdModIOPlugin, {
	NAME: 'stdModIOPlugin',

	NS: 'io',

	ATTRS: {
		uri: {
			value: null
		},

		cfg: {
			value: {}
		},

		/*
		* The default formatter to use when formatting response data. The default
		* implementation simply passes back the response data passed in.
		*/
		formatter: {
			valueFn: function() {
				return this._defFormatter;
			}
		},

		/*
		* The Standard Module section to which the io plugin instance is bound.
		* Response data will be used to populate this section, after passing through
		* the configured formatter.
		*/
		section: {
			value: StdMod.BODY,
			validator: function(val) {
				return (!val || val == StdMod.BODY || val == StdMod.HEADER || val == StdMod.FOOTER);
			}
		},

		loading: {
			value: '<div class="' + CSS_ICON_LOADING + '"></div>'
		}
	}
});

A.extend(StdModIOPlugin, A.Plugin.Base, {
	initializer: function() {
		var queue = null;
		var instance = this;
		var host = instance.get(HOST);
		var bodyNode = host.bodyNode;

		StdModIOPlugin.superclass.initializer.apply(this, arguments);

		if (bodyNode) {
			bodyNode.plug(A.Plugin.ParseContent);

			queue = bodyNode.ParseContent.get(QUEUE);
		}

		if (queue) {
			// dont close the overlay while queue is running
			host.on('close', function(event) {
				if (queue.isRunning()) {
					event.halt();
				}
			});

			// stop the queue after the dialog is closed, just in case.
			host.after('close', function(event) {
				queue.stop();
			});
		}
	},

	destructor: function() {
		if (this.isActive()) {
			A.io.abort(this._activeIO);
			this._activeIO = null;
		}
	},

	isActive: function() {
		return this._activeIO;
	},

	/*
	* IO Plugin specific method, use to initiate a new io request using the current
	* io configuration settings.
	*/
	refresh: function() {
		var instance = this;
		var section = this.get(SECTION);

		if (section && !this.isActive()) {
			var uri = this.get(URI);

			if (uri) {
				var cfg = A.mix(
					this.get(CFG),
					{
						method: POST,
						on: {}
					}
				);

				// binding correct scopes on callbacks
				cfg.on = A.merge(
					cfg.on,
					{
						start: A.bind(cfg.on.start || this._defStartHandler, this),
						complete: A.bind(cfg.on.complete || this._defCompleteHandler, this),
						success: A.bind(cfg.on.success || this._defSuccessHandler, this),
						failure: A.bind(cfg.on.failure || this._defFailureHandler, this)
					}
				);

				A.io(uri, cfg);
			}
		}
	},

	_defSuccessHandler: function(id, o) {
		var response = o.responseText || BLANK;
		var section = this.get(SECTION);
		var formatter = this.get(FORMATTER);

		this.get(HOST).setStdModContent(section, formatter(response));
	},

	_defFailureHandler: function(id, o) {
		this.get(HOST).setStdModContent(this.get(SECTION), 'Failed to retrieve content');
	},

	_defStartHandler: function(id, o) {
		this._activeIO = o;
		this.get(HOST).setStdModContent(this.get(SECTION), this.get(LOADING));
	},

	_defCompleteHandler: function(id, o) {
		this._activeIO = null;
	},

	_defFormatter: function(val) {
		return val;
	}
});

A.namespace('Plugin');
A.Plugin.StdModIOPlugin = StdModIOPlugin;

}, '0.1a', { requires: [ 'aui-base', 'component-overlay', 'parse-content', 'io', 'plugin' ] });AUI.add('live-search', function(A) {

var L = A.Lang,
	isString = L.isString,
	isObject = L.isObject,
	isFunction = L.isFunction,

	BLANK = '',
	DATA = 'data',
	DELAY = 'delay',
	HIDE = 'hide',
	INDEX = 'index',
	INPUT = 'input',
	LIVE_SEARCH = 'live-search',
	MATCH_REGEX = 'matchRegex',
	NODES = 'nodes',
	SHOW = 'show',
	STAR = '*',

	KEY_ENTER = 13,

	isNodeList = function(v) {
		return (v instanceof A.NodeList);
	};

function LiveSearch(config) {
	LiveSearch.superclass.constructor.apply(this, arguments);
}

A.mix(LiveSearch, {
	NAME: LIVE_SEARCH,

	ATTRS: {
		data: {
			value: function(node) {
				return node.html();
			},
			validator: isFunction
		},

		delay: {
			value: 250
		},

		hide: {
			value: function(node) {
				return node.hide();
			},
			validator: isFunction
		},

		index: {
			value: [],
			validator: isObject
		},

		input: {
			setter: function(v) {
				return A.get(v);
			}
		},

		matchRegex: {
			validator: function(v) {
				return (v instanceof RegExp);
			},
			value: /(\w|\s|[*])*/g
		},

		nodes: {
			setter: function(v) {
				return this._setNodes(v);
			}
		},

		show: {
			value: function(node) {
				return node.show();
			},
			validator: isFunction
		}
	}
});

A.extend(LiveSearch, A.Base, {
	normalizedQuery: BLANK,

	query: BLANK,

	timer: null,

	/*
	* Lifecycle
	*/
	initializer: function() {
		var instance = this;

		instance.refreshIndex();

		instance.bindUI();
	},

	bindUI: function() {
		var instance = this;
		var input = instance.get(INPUT);

		input.on('keyup', A.bind(instance._inputKeyUp, instance));

		instance.publish('search', { defaultFn: instance.search });
	},

	destroy: function() {
		var instance = this;
		var input = instance.get(INPUT);

		input.detach('keyup');
	},

	/*
	* Methods
	*/
	filter: function(query) {
		var instance = this;
		var results = [];
		var nodes = instance.get(NODES);
		var index = instance.get(INDEX);

		instance.query = query;
		instance.normalizedQuery = instance._normalizeQuery(query);

		var regex = new RegExp(
			instance.normalizedQuery
		);

		A.each(index, function(content, index) {
			var node = nodes.item(index);

			results.push({
				content: content,
				match: regex.test(content),
				node: node
			});
		});

		return results;
	},

	refreshIndex: function() {
		var instance = this;
		var index = [];

		instance.get(NODES).each(function(node) {
			var content = L.trim(
				instance.get(DATA).apply(instance, [node]).toLowerCase()
			);

			index.push(content);
		});

		instance.set(INDEX, index);
	},

	search: function(event) {
		var instance = this;
		var value = instance.get(INPUT).val();

		var results = instance.filter(value);

		A.each(results, function(search) {
			var node = search.node;

			if (search.match) {
				instance.get(SHOW).apply(instance, [node]);
			}
			else {
				instance.get(HIDE).apply(instance, [node]);
			}
		});

		event.liveSearch.results = results;
	},

	_normalizeQuery: function(query) {
		var instance = this;
		var matchRegex = instance.get(MATCH_REGEX);

		// trim the user query and lowercase it
		query = L.trim( query.toLowerCase() );

		// match with the matchRegex to be only alphanumeric (default regex)
		query = query.match(matchRegex).join(BLANK);

		// replace on the query '*' to '', on a regex empty match with everything like *
		query = query.replace(STAR, BLANK);

		return query;
	},

	/*
	* Listeners
	*/
	_inputKeyUp: function(event) {
		var instance = this;
		var delay = instance.get(DELAY);
		var keyCode = event.keyCode;

		if (keyCode = KEY_ENTER) {
			event.halt();
		}

		if (isObject(instance.timer)) {
			instance.timer.cancel();
		}

		instance.timer = A.later(delay, instance, function() {
			instance.fire('search', {
				liveSearch: {
					inputEvent: event
				}
			});
		});
	},

	/*
	* Setters
	*/
	_setNodes: function(v) {
		var instance = this;

		if (isNodeList(v)) {
			return v;
		}
		else if (isString(v)) {
			return A.all(v);
		}

		return new A.NodeList([v]);
	}
});

A.LiveSearch = LiveSearch;

}, '0.1a', { requires: [ 'aui-base' ] });AUI.add('nested-list', function(A) {

var L = A.Lang,
	isString = L.isString,
	isFunction = L.isFunction,

	BLOCK = 'block',
	BODY = 'body',
	DD = 'dd',
	DISPLAY = 'display',
	DOWN = 'down',
	DRAG_NODE = 'dragNode',
	DROP_CONDITION = 'dropCondition',
	DROP_ON = 'dropOn',
	FLOAT = 'float',
	HEIGHT = 'height',
	HELPER = 'helper',
	HIDDEN = 'hidden',
	LEFT = 'left',
	NESTED_LIST = 'nested-list',
	NODE = 'node',
	NODES = 'nodes',
	NONE = 'none',
	OFFSET_HEIGHT = 'offsetHeight',
	PLACEHOLDER = 'placeholder',
	PX = 'px',
	RIGHT = 'right',
	SORT_CONDITION = 'sortCondition',
	UL = 'ul',
	UP = 'up',
	VISIBILITY = 'visibility',
	VISIBLE = 'visible',

	DDM = A.DD.DDM,

	isNodeList = function(v) {
		return (v instanceof A.NodeList);
	};

function NestedList(config) {
	NestedList.superclass.constructor.apply(this, arguments);
}

A.mix(NestedList, {
	NAME: NESTED_LIST,

	ATTRS: {
		dd: {
			value: null
		},

		dropCondition: {
			value: function() {
				return true;
			},
			setter: function(v) {
				return A.bind(v, this);
			},
			validator: isFunction
		},

		dropOn: {
			value: UL,
			validator: isString
		},

		helper: {
			value: null
		},

		nodes: {
			setter: function(v) {
				return this._setNodes(v);
			}
		},

		placeholder: {
			value: null
		},

		sortCondition: {
			value: function() {
				return true;
			},
			setter: function(v) {
				return A.bind(v, this);
			},
			validator: isFunction
		}
	}
});

A.extend(NestedList, A.Base, {
	/*
	* Lifecycle
	*/
	initializer: function() {
		var instance = this;
		var nodes = instance.get(NODES);

		// drag & drop listeners
		instance.on('drag:align', instance._onDragAlign);
		instance.on('drag:exit', instance._onDragExit);
		instance.on('drag:over', instance._onDragOver);
		instance.on('drag:start', instance._onDragStart);
		instance.on('drag:end', instance._onDragEnd);

		instance._createHelper();

		if (nodes) {
			instance.addAll(nodes);
		}
	},

	/*
	* Methods
	*/
	add: function(node) {
		var instance = this;

		instance._createDrag(node);
	},

	addAll: function(nodes) {
		var instance = this;

		nodes.each(function(node) {
			instance.add(node);
		});
	},

	_createDrag: function(node) {
		var instance = this;
		var helper = instance.get(HELPER);

		if (!DDM.getDrag(node)) {
			var dragOptions = {
				node: node,
				bubbles: instance,
				target: true
			};

			var proxyOptions = {
				moveOnEnd: false,
				positionProxy: false
			};

			if (helper) {
				proxyOptions.borderStyle = null;
			}

			// creating delayed drag instance
			var dd = new A.DD.Drag(
				A.mix(dragOptions, instance.get(DD))
			)
			.plug(A.Plugin.DDProxy, proxyOptions);
		}
	},

	_createHelper: function() {
		var instance = this;
		var helper = instance.get(HELPER);

		if (helper) {
			// append helper to the body
			A.get(BODY).append( helper.hide() );

			instance.set(HELPER, helper);
		}
	},

	_updatePlaceholder: function(event, cancelAppend) {
		var instance = this;
		var drag = event.target;
		var drop = event.drop;
		var dragNode = drag.get(NODE);
		var dropNode = drop.get(NODE);
		var container = dropNode.one('>' + instance.get(DROP_ON));

		var floating = false;
		var xDirection = instance.XDirection;
		var yDirection = instance.YDirection;

		if (dropNode.getStyle(FLOAT) != NONE) {
			floating = true;
		}

		var placeholder = instance.get(PLACEHOLDER);

		if (!placeholder) {
			// if no placeholder use the dragNode instead
			placeholder = dragNode;
		}

		if (!placeholder.contains(dropNode)) {
			// check for the user dropCondition
			var dropCondition = instance.get(DROP_CONDITION);

			// if there is a container waiting for nodes to be appended it's priority
			if (container && !cancelAppend && dropCondition(event)) {
				// this checking avoid the parent bubbling drag:over
				if (!container.contains(placeholder) &&
					!placeholder.contains(container)) {
						// append placeholder on the found container
						container.append(placeholder);
				}
			}
			// otherwise, check if it's floating and the xDirection
			// or if it's not floating and the yDirection
			else {
				if (floating && (xDirection == LEFT) || !floating && (yDirection == UP)) {
					// LEFT or UP directions means to place the placeholder before
					dropNode.placeBefore(placeholder);
				}
				else {
					// RIGHT or DOWN directions means to place the placeholder after
					dropNode.placeAfter(placeholder);
				}
			}
		}
	},

	/*
	* Listeners
	*/
	_onDragAlign: function(event) {
		var instance = this;
		var lastX = instance.lastX;
		var lastY = instance.lastY;
		var xy = event.target.lastXY;

		var x = xy[0];
		var y = xy[1];

		// if the y change
		if (y != lastY) {
			// set the drag vertical direction
			instance.YDirection = (y < lastY) ? UP : DOWN;
		}

		// if the x change
		if (x != lastX) {
			// set the drag horizontal direction
			instance.XDirection = (x < lastX) ? LEFT : RIGHT;
		}

		instance.lastX = x;
		instance.lastY = y;
	},

	_onDragEnd: function(event) {
		var instance = this;
		var drag = event.target;
		var dragNode = drag.get(NODE);
		var placeholder = instance.get(PLACEHOLDER);

		if (placeholder) {
			dragNode.show();
			placeholder.hide();
			// position dragNode after the placeholder
			placeholder.placeAfter(dragNode);
		}
	},

	_onDragExit: function(event) {
		var instance = this;
		var sortCondition = instance.get(SORT_CONDITION);

		if (sortCondition(event)) {
			instance._updatePlaceholder(event, true);
		}
	},

	_onDragOver: function(event) {
		var instance = this;
		var sortCondition = instance.get(SORT_CONDITION);

		if (sortCondition(event)) {
			instance._updatePlaceholder(event);
		}
	},

	_onDragStart: function(event) {
 		var instance = this;
		var drag = event.target;
		var dragNode = drag.get(NODE);
		var helper = instance.get(HELPER);
		var placeholder = instance.get(PLACEHOLDER);

		if (placeholder) {
			// update placeholder height
			placeholder.setStyle(
				HEIGHT,
				dragNode.get(OFFSET_HEIGHT) + PX
			);

			dragNode.hide();
			placeholder.show();
			// position placeholder after the dragNode
			dragNode.placeAfter(placeholder);
		}

		if (helper) {
			// show helper, we need display block here, yui dd hide it with display none
			helper.setStyles({
				display: BLOCK,
				visibility: VISIBLE
			}).show();

			// update the DRAG_NODE with the new helper
			drag.set(DRAG_NODE, helper);
		}
 	},

	/*
	* Setters
	*/
	_setNodes: function(v) {
		var instance = this;

		if (isNodeList(v)) {
			return v;
		}
		else if (isString(v)) {
			return A.all(v);
		}

		return new A.NodeList([v]);
	}
});

A.NestedList = NestedList;

}, '0.1a', { requires: [ 'aui-base', 'dd' ] });AUI.add('overlay-manager', function(A) {

var Lang = A.Lang,
	isArray = Lang.isArray,
	isBoolean = Lang.isBoolean,
	isNumber = Lang.isNumber,
	isString = Lang.isString,

	BOUNDING_BOX = 'boundingBox',
	DEFAULT = 'default',
	HOST = 'host',
	OVERLAY_MANAGER = 'OverlayManager',
	GROUP = 'group',
	Z_INDEX = 'zIndex',
	Z_INDEX_BASE = 'zIndexBase';

	function OverlayManager(config) {
	 	OverlayManager.superclass.constructor.apply(this, arguments);
	}

	A.mix(
		OverlayManager,
		{
			NAME: OVERLAY_MANAGER.toLowerCase(),

			ATTRS: {
				zIndexBase: {
					value: 1000,
					validator: isNumber,
					setter: function(value) {
						return parseInt(value, 10);
					}
				}
			}
		}
	);

	A.extend(OverlayManager, A.Base, {
		initializer: function() {
			var instance = this;

			instance._overlays = [];
		},

		bringToTop: function(overlay) {
			var instance = this;

			var overlays = instance._overlays.sort(instance.sortByZIndexDesc);

			var highest = overlays[0];

			if (highest !== overlay) {
				var overlayZ = overlay.get(Z_INDEX);
				var highestZ = highest.get(Z_INDEX);

				overlay.set(Z_INDEX, highestZ + 1);

				overlay.set('focused', true);
			}
		},

		destroy: function() {
			var instance = this;

			instance.remove();
		},

		register: function (overlay) {
			var instance = this;

			var overlays = instance._overlays;

			if (isArray(overlay)) {
				A.Array.each(overlay, function(o) {
					instance.register(o);
				});
			}
			else {
				var zIndexBase = instance.get(Z_INDEX_BASE);
				var registered = instance._registered(overlay);

				if (
					!registered && overlay &&
					((overlay instanceof A.Overlay) ||
					(A.Component && overlay instanceof A.Component))
				) {
					var boundingBox = overlay.get(BOUNDING_BOX);

					overlays.push(overlay);

					var zIndex = overlay.get(Z_INDEX) || 0;
					var newZIndex = overlays.length + zIndex + zIndexBase;

					overlay.set(Z_INDEX, newZIndex);

					overlay.on('focusedChange', instance._onFocusedChange, instance);
					boundingBox.on('mousedown', instance._onMouseDown, instance);
				}
			}

			return overlays;
		},

		remove: function (overlay) {
			var instance = this;

			var overlays = instance._overlays;

			if (overlays.length) {
				return A.Array.removeItem(overlays, overlay);
			}

			return null;
		},

		each: function(fn) {
			var instance = this;

			var overlays = instance._overlays;

			A.Array.each(overlays, fn);
		},

		showAll: function() {
			this.each(
				function(overlay) {
					overlay.show();
				}
			);
		},

		hideAll: function() {
			this.each(
				function(overlay) {
					overlay.hide();
				}
			);
		},

		sortByZIndexDesc: function(a, b) {
			if (!a || !b || !a.hasImpl(A.WidgetStack) || !b.hasImpl(A.WidgetStack)) {
				return 0;
			}
			else {
				var aZ = a.get(Z_INDEX);
				var bZ = b.get(Z_INDEX);

				if (aZ > bZ) {
					return -1;
				} else if (aZ < bZ) {
					return 1;
				} else {
					return 0;
				}
			}
		},

		_registered: function(overlay) {
			var instance = this;

			return A.Array.indexOf(instance._overlays, overlay) != -1;
		},

		_onMouseDown: function(event) {
			var instance = this;
			var overlay = A.Widget.getByNode(event.currentTarget || event.target);
			var registered = instance._registered(overlay);

			if (overlay && registered) {
				instance.bringToTop(overlay);
			}
		},

		_onFocusedChange: function(event) {
			var instance = this;

			if (event.newVal) {
				var overlay = event.currentTarget || event.target;
				var registered = instance._registered(overlay);

				if (overlay && registered) {
					instance.bringToTop(overlay);
				}
			}
		}
	});

	A.OverlayManager = OverlayManager;

}, '0.1a', { requires: [ 'overlay', 'plugin' ] });AUI.add('overlay-mask', function(A) {

var L = A.Lang,
	isString = L.isString,
	isNumber = L.isNumber,

	UA = A.UA,

	ie6 = (UA.ie && UA.version.major <= 6),

	ABSOLUTE = 'absolute',
	ALIGN = 'align',
	BACKGROUND = 'background',
	BOUNDING_BOX = 'boundingBox',
	FIXED = 'fixed',
	HEIGHT = 'height',
	OFFSET_HEIGHT = 'offsetHeight',
	OFFSET_WIDTH = 'offsetWidth',
	OPACITY = 'opacity',
	OVERLAY_MASK = 'overlaymask',
	POSITION = 'position',
	TARGET = 'target',
	TL = 'tl',
	WIDTH = 'width';

function OverlayMask(config) {
 	OverlayMask.superclass.constructor.apply(this, arguments);
}

A.mix(OverlayMask, {
	NAME: OVERLAY_MASK,

	ATTRS: {
		align: {
            value: { node: null, points: [ TL, TL ] }
        },

		background: {
			lazyAdd: false,
			value: '#000',
			validator: isString,
			setter: function(v) {
				this.get(BOUNDING_BOX).setStyle(BACKGROUND, v);

				return v;
			}
		},

		target: {
			lazyAdd: false,
			value: document,
			setter: function(v) {
				return A.get(v);
			}
		},

		opacity: {
			lazyAdd: false,
			value: .5,
			validator: isNumber,
			setter: function(v) {
				this.get(BOUNDING_BOX).setStyle(OPACITY, v);

				return v;
			}
		},

		shim: {
			value: A.UA.ie
		},

		visible: {
			value: false
		},

		zIndex: {
			value: 1000
		}
	}
});

A.extend(OverlayMask, A.ComponentOverlay, {
	/*
	* Lifecycle
	*/
	bindUI: function() {
		var instance = this;

		OverlayMask.superclass.bindUI.apply(this, arguments);

		instance.after('targetChange', instance._afterTargetChange);

		// window:resize YUI normalized event is not working, bug?
		A.on('resize', A.bind(instance.refreshMask, instance));
	},

	syncUI: function() {
		var instance = this;

		instance.refreshMask();
	},

	/*
	* Methods
	*/
	getTargetSize: function() {
		var instance = this;
		var target = instance.get(TARGET);
		var height = target.get(OFFSET_HEIGHT);
		var width = target.get(OFFSET_WIDTH);

		var HUNDRED = '100%';
		var isDoc = target.compareTo(document);
		var isWin = target.compareTo(window);

		if (ie6) {
			// IE6 doesn't support height/width 100% on doc/win
			if (isWin) {
				width = A.DOM.winWidth();
				height = A.DOM.winHeight();
			}
			else if (isDoc) {
				width = A.DOM.docWidth();
				height = A.DOM.docHeight();
			}
		}
		// good browsers...
		else if (isDoc || isWin) {
			height = HUNDRED;
			width = HUNDRED;
		}

		return { height: height, width: width };
	},

	/*
	* Methods
	*/
	refreshMask: function() {
		var instance = this;
		var align = instance.get(ALIGN);
		var target = instance.get(TARGET);
		var boundingBox = instance.get(BOUNDING_BOX);

		var isDoc = target.compareTo(document);
		var isWin = target.compareTo(window);

		if (!ie6 && (isDoc || isWin)) {
			boundingBox.setStyle(POSITION, FIXED);
		}
		else {
			boundingBox.setStyle(POSITION, ABSOLUTE);
		}

		var size = instance.getTargetSize();

		instance.set(HEIGHT, size.height);
		instance.set(WIDTH, size.width);

		instance.align(target, align.points);
	},

	/*
	* Listeners
	*/
	_afterTargetChange: function(event) {
		var instance = this;

		instance.refreshMask();
	}
});

A.OverlayMask = OverlayMask;

}, '0.1a', { requires: [ 'overlay', 'event-resize' ] });AUI.add('paginator', function(A) {

var L = A.Lang,
	isArray = L.isArray,
	isBoolean = L.isBoolean,
	isFunction = L.isFunction,
	isNumber = L.isNumber,
	isObject = L.isObject,
	isString = L.isString,

	ALWAYS_VISIBLE = 'alwaysVisible',
	BOUNDING_BOX = 'boundingBox',
	CONTAINER = 'container',
	CONTAINERS = 'containers',
	CONTENT = 'content',
	CURRENT = 'current',
	DOT = '.',
	FIRST = 'first',
	FIRST_PAGE_LINK = 'firstPageLink',
	FIRST_PAGE_LINK_LABEL = 'firstPageLinkLabel',
	LAST = 'last',
	LAST_PAGE_LINK = 'lastPageLink',
	LAST_PAGE_LINK_LABEL = 'lastPageLinkLabel',
	LINK = 'link',
	MAX_PAGE_LINKS = 'maxPageLinks',
	NEXT = 'next',
	NEXT_PAGE_LINK = 'nextPageLink',
	NEXT_PAGE_LINK_LABEL = 'nextPageLinkLabel',
	PAGE = 'page',
	PAGE_CONTAINER_TEMPLATE = 'pageContainerTemplate',
	PAGE_LINK_CONTENT = 'pageLinkContent',
	PAGE_LINK_TEMPLATE = 'pageLinkTemplate',
	PAGE_REPORT_EL = 'pageReportEl',
	PAGE_REPORT_LABEL_TEMPLATE = 'pageReportLabelTemplate',
	PAGINATOR = 'paginator',
	PER = 'per',
	PREV = 'prev',
	PREV_PAGE_LINK = 'prevPageLink',
	PREV_PAGE_LINK_LABEL = 'prevPageLinkLabel',
	REPORT = 'report',
	ROWS = 'rows',
	ROWS_PER_PAGE = 'rowsPerPage',
	ROWS_PER_PAGE_EL = 'rowsPerPageEl',
	ROWS_PER_PAGE_OPTIONS = 'rowsPerPageOptions',
	SELECT = 'select',
	SPACE = ' ',
	STATE = 'state',
	TEMPLATE = 'template',
	TOTAL = 'total',
	TOTAL_EL = 'totalEl',
	TOTAL_LABEL = 'totalLabel',
	TOTAL_PAGES = 'totalPages',

	nodeSetter = function(v) {
		return A.get(v);
	},

	concat = function() {
		return Array.prototype.slice.call(arguments).join(SPACE);
	},

	isNodeList = function(v) {
		return (v instanceof A.NodeList);
	},

	num = function(n) {
		return parseInt(n, 10) || 0;
	},

	getCN = A.ClassNameManager.getClassName,

	CSS_PAGINATOR = getCN(PAGINATOR),
	CSS_PAGINATOR_CONTAINER = getCN(PAGINATOR, CONTAINER),
	CSS_PAGINATOR_CONTENT = getCN(PAGINATOR, CONTENT),
	CSS_PAGINATOR_CURRENT_PAGE = getCN(PAGINATOR, CURRENT, PAGE),
	CSS_PAGINATOR_FIRST_LINK = getCN(PAGINATOR, FIRST, LINK),
	CSS_PAGINATOR_LAST_LINK = getCN(PAGINATOR, LAST, LINK),
	CSS_PAGINATOR_LINK = getCN(PAGINATOR, LINK),
	CSS_PAGINATOR_NEXT_LINK = getCN(PAGINATOR, NEXT, LINK),
	CSS_PAGINATOR_PAGE_CONTAINER = getCN(PAGINATOR, PAGE, CONTAINER),
	CSS_PAGINATOR_PAGE_LINK = getCN(PAGINATOR, PAGE, LINK),
	CSS_PAGINATOR_PAGE_REPORT = getCN(PAGINATOR, CURRENT, PAGE, REPORT),
	CSS_PAGINATOR_PREV_LINK = getCN(PAGINATOR, PREV, LINK),
	CSS_PAGINATOR_ROWS_PER_PAGE = getCN(PAGINATOR, ROWS, PER, PAGE),
	CSS_PAGINATOR_TOTAL = getCN(PAGINATOR, TOTAL),

	TOTAL_LABEL_TPL = '(Total {total})',
	PAGE_REPORT_LABEL_TPL = '({page} of {totalPages})',
	DEFAULT_OUTPUT_TPL = '{FirstPageLink} {PrevPageLink} {PageLinks} {NextPageLink} {LastPageLink} {CurrentPageReport} {Total} {RowsPerPageSelect}',

	GT_TPL = '&gt;',
	LT_TPL = '&lt;',
	FIRST_LINK_TPL = '<a href="#" class="'+concat(CSS_PAGINATOR_LINK, CSS_PAGINATOR_FIRST_LINK)+'"></a>',
	LAST_LINK_TPL = '<a href="#" class="'+concat(CSS_PAGINATOR_LINK, CSS_PAGINATOR_LAST_LINK)+'"></a>',
	NEXT_LINK_TPL = '<a href="#" class="'+concat(CSS_PAGINATOR_LINK, CSS_PAGINATOR_NEXT_LINK)+'"></a>',
	PAGE_CONTAINER_TPL = '<span></span>',
	PAGE_LINK_TPL = '<a href="#"></a>',
	PAGE_REPORT_TPL = '<span class="'+concat(CSS_PAGINATOR_PAGE_REPORT)+'"></span>',
	PREV_LINK_TPL = '<a href="#" class="'+concat(CSS_PAGINATOR_LINK, CSS_PAGINATOR_PREV_LINK)+'"></a>',
	ROWS_PER_PAGE_TPL = '<select class="'+CSS_PAGINATOR_ROWS_PER_PAGE+'"></select>',
	TOTAL_TPL = '<span class="'+concat(CSS_PAGINATOR_TOTAL)+'"></span>';

function Paginator(config) {
	Paginator.superclass.constructor.apply(this, arguments);
}

A.mix(Paginator, {
	NAME: PAGINATOR,

	ATTRS: {
		alwaysVisible: {
			value: true,
			validator: isBoolean
		},

		containers: {
			writeOnce: true,
			setter: function(v) {
				var instance = this;

				if (isNodeList(v)) {
					return v;
				}
				else if (isString(v)) {
					return A.all(v);
				}

				return new A.NodeList([v]);
			}
		},

		firstPageLink: {
			setter: nodeSetter,
			valueFn: function() {
				var label = this.get(FIRST_PAGE_LINK_LABEL);

				return A.Node.create(FIRST_LINK_TPL).html(label);
			}
		},

		firstPageLinkLabel: {
			value: FIRST,
			validator: isString
		},

		lastPageLink: {
			setter: nodeSetter,
			valueFn: function() {
				var label = this.get(LAST_PAGE_LINK_LABEL);

				return A.Node.create(LAST_LINK_TPL).html(label);
			}
		},

		lastPageLinkLabel: {
			value: LAST,
			validator: isString
		},

		maxPageLinks: {
			value: 10,
			getter: function(v) {
				var totalPages = this.get(TOTAL_PAGES);

				// maxPageLinks cannot be bigger than totalPages
				return Math.min(totalPages, v);
			},
			validator: isNumber
		},

		nextPageLink: {
			setter: nodeSetter,
			valueFn: function() {
				var label = this.get(NEXT_PAGE_LINK_LABEL);

				return A.Node.create(NEXT_LINK_TPL).html(label);
			}
		},

		nextPageLinkLabel: {
			value: concat(NEXT, GT_TPL),
			validator: isString
		},

		page: {
			setter: function(v) {
				return num(v);
			},
			value: 1
		},

		pageContainerTemplate: {
			getter: function(v) {
				return A.Node.create(v).addClass(CSS_PAGINATOR_PAGE_CONTAINER);
			},
			value: PAGE_CONTAINER_TPL,
			validator: isString
		},

		pageLinkContent: {
			value: function(pageEl, pageNumber, index) {
				pageEl.html(pageNumber);
			},
			validator: isFunction
		},

		pageLinkTemplate: {
			getter: function(v) {
				var node = A.Node.create(v);

				return node.addClass(
					concat(CSS_PAGINATOR_LINK, CSS_PAGINATOR_PAGE_LINK)
				);
			},
			value: PAGE_LINK_TPL,
			validator: isString
		},

		pageReportEl: {
			setter: nodeSetter,
			valueFn: function() {
				var label = this.get(PAGE_REPORT_LABEL_TEMPLATE);

				return A.Node.create(PAGE_REPORT_TPL).html(label);
			}
		},

		pageReportLabelTemplate: {
			getter: function() {
				var instance = this;

				return A.substitute(PAGE_REPORT_LABEL_TPL, {
					page: instance.get(PAGE),
					totalPages: instance.get(TOTAL_PAGES)
				});
			},
			validator: isString
		},

		prevPageLink: {
			setter: nodeSetter,
			valueFn: function() {
				var label = this.get(PREV_PAGE_LINK_LABEL);

				return A.Node.create(PREV_LINK_TPL).html(label);
			}
		},

		prevPageLinkLabel: {
			value: concat(LT_TPL, PREV),
			validator: isString
		},

		rowsPerPageOptions: {
			value: {},
			validator: isArray
		},

		rowsPerPage: {
			setter: function(v) {
				return num(v);
			},
			value: 1
		},

		rowsPerPageEl: {
			setter: nodeSetter,
			valueFn: function() {
				return A.Node.create(ROWS_PER_PAGE_TPL);
			}
		},

		state: {
			setter: function(v) {
				return this._setState(v);
			},
			getter: function(v) {
				return this._getState(v);
			},
			value: {},
			validator: isObject
		},

		template: {
			getter: function(v) {
				return this._getTemplate(v);
			},
			writeOnce: true,
			value: DEFAULT_OUTPUT_TPL,
			validator: isString
		},

		total: {
			setter: function(v) {
				return this._setTotal(v);
			},
			value: 0,
			validator: isNumber
		},

		totalEl: {
			setter: nodeSetter,
			valueFn: function() {
				var label = this.get(TOTAL_LABEL);

				return A.Node.create(TOTAL_TPL).html(label);
			}
		},

		totalLabel: {
			getter: function() {
				var instance = this;

				return A.substitute(TOTAL_LABEL_TPL, {
					total: instance.get(TOTAL)
				});
			},
			validator: isString
		},

		totalPages: {
			readOnly: true,
			getter: function(v) {
				return Math.ceil(
					this.get(TOTAL) / this.get(ROWS_PER_PAGE)
				);
			}
		}
	}
});

A.extend(Paginator, A.Component, {
	lastState: null,
	templatesCache: null,

	/*
	* Lifecycle
	*/
	renderUI: function() {
		var instance = this;
		var containers = instance.get(CONTAINERS);

		containers.unselectable();

		instance._renderRowsPerPageOptions();

		instance._renderTemplateUI();

		containers.addClass(CSS_PAGINATOR_CONTAINER);
	},

	bindUI: function() {
		var instance = this;

		instance._delegateDOM();

		instance.publish('changeRequest');
		instance.after('stateChange', A.bind(instance._afterSetState, instance));
		instance.before('stateChange', A.bind(instance._beforeSetState, instance));

		// invoke _renderTemplateUI to recreate the template markup
		instance.after('maxPageLinksChange', A.bind(instance._renderTemplateUI, instance));
		instance.after('rowsPerPageChange', A.bind(instance._renderTemplateUI, instance));
		instance.after('totalChange', A.bind(instance._renderTemplateUI, instance));
	},

	syncUI: function() {
		var instance = this;

		// fire changeRequest to the first state
		instance.changeRequest();
	},

	destroy: function() {
		var instance = this;

		instance.get(BOUNDING_BOX).remove();
		instance.get(CONTAINERS).remove();
	},

	_syncPageLinksUI: function() {
		var instance = this;
		var containers = instance.get(CONTAINERS);
		var page = instance.get(PAGE);

		// creating range to show on the pageLinks, keep the current page on center
		var range = instance.calculateRange(page);

		// loop all containers
		containers.each(function(node) {
			var index = 0;
			var pageNumber = range.start;
			// query all anchor that represents the page links
			var pageLinks = node.all(DOT+CSS_PAGINATOR_PAGE_LINK);

			if (pageLinks) {
				pageLinks.removeClass(CSS_PAGINATOR_CURRENT_PAGE);

				// loop all pages from range.start to range.end
				while (pageNumber <= range.end) {
					// get the anchor pageEl and set the label to be the number of the current page
					var pageEl = pageLinks.item(index);

					// invoke the handler to set the page link content
					instance.get(PAGE_LINK_CONTENT).apply(instance, [pageEl, pageNumber, index]);

					// uset an attribute page on the anchor to retrieve later when _onClickPageLinkEl fires
					pageEl.setAttribute(PAGE, pageNumber);

					if (pageNumber == page) {
						// search for the current page and addClass saying it's the current
						pageEl.addClass(CSS_PAGINATOR_CURRENT_PAGE);
					}

					index++;
					pageNumber++;
				};
			}
		});
	},

	_syncPageReportUI: function(event) {
		var instance = this;
		var containers = instance.get(CONTAINERS);

		containers.each(function(node) {
			// search for the respective pageReportEl
			var pageReportEl = node.one(DOT+CSS_PAGINATOR_PAGE_REPORT);

			if (pageReportEl) {
				// update its label with the page report template, eg. (1 of 100)
				pageReportEl.html(
					instance.get(PAGE_REPORT_LABEL_TEMPLATE)
				);
			}
		});
	},

	/*
	* Methods
	*/
	calculateRange: function(page) {
		var instance = this;
		var totalPages = instance.get(TOTAL_PAGES);
		var maxPageLinks = instance.get(MAX_PAGE_LINKS);
		// calculates the center page link index
		var offset = Math.ceil(maxPageLinks/2);

		// find the start range to show on the page links
		// Math.min pick the minimum value when the page number is near totalPages value
		// this fixes when the offset is small and generates less than [maxPageLinks] page links
		var start = Math.min(
			// Math.max(x, 1) doesn't allow negative or zero values
			Math.max(page - offset, 1), (totalPages - maxPageLinks + 1)
		);

		// find the end range, the range has always maxPageLinks size
		// so, (start + maxPageLinks - 1) try to find the end range
		// Math.min with totalPages doesn't allow values bigger than totalPages
		var end = Math.min(start + maxPageLinks - 1, totalPages);

		return {
			start: start,
			end: end
		};
	},

	changeRequest: function() {
		var instance = this;
		var state = instance.get(STATE);

		// fires changeRequest, this is the most important event to the user
		// the user needs to invoke .setState(newState) to update the UI
		instance.fire('changeRequest', { state: state });
	},

	eachContainer: function(fn) {
		var instance = this;

		instance.get(CONTAINERS).each(function(node) {
			if (node) {
				fn.apply(instance, arguments);
			}
		});
	},

	hasNextPage: function() {
		var instance = this;

		return instance.hasPage(
			instance.get(PAGE) + 1
		);
	},

	hasPage: function(page) {
		var instance = this;
		var totalPages = instance.get(TOTAL_PAGES);

		return ( (page > 0) && (page <= totalPages) );
	},

	hasPrevPage: function() {
		var instance = this;

		return instance.hasPage(
			instance.get(PAGE) - 1
		);
	},

	_renderRowsPerPageOptions: function() {
		var instance = this;
		var i = 0;
		var rowsPerPageEl = instance.get(ROWS_PER_PAGE_EL);
		var rowsPerPageOptions = instance.get(ROWS_PER_PAGE_OPTIONS);

		A.each(rowsPerPageOptions, function(value) {
			rowsPerPageEl.getDOM().options[i++] = new Option(value, value);
		});
	},

	_renderTemplateUI: function() {
		var instance = this;
		var containers = instance.get(CONTAINERS);

		instance.templatesCache = null;

		// loading HTML template on the containers
		containers.html(
			instance.get(TEMPLATE)
		);

		// sync pageLinks
		instance._syncPageLinksUI();

		// sync page report, eg. (1 of 100)
		instance._syncPageReportUI();

		// bind the DOM events after _renderTemplateUI
		instance._bindDOMEvents();
	},

	/*
	* Getters & Setters
	*/
	setState: function(v) {
		var instance = this;

		instance.set(STATE, v);
	},

	_getState: function(v) {
		var instance = this;

		return {
			before: instance.lastState,
			paginator: instance,
			page: instance.get(PAGE),
			total: instance.get(TOTAL),
			totalPages: instance.get(TOTAL_PAGES),
			rowsPerPage: instance.get(ROWS_PER_PAGE)
		};
	},

	_getTemplate: function(v) {
		var instance = this;

		var outer = function(key) {
			return instance.get(key).outerHTML();
		};

		// if template is not cached...
		if (!instance.templatesCache) {
			var page = 0;
			var totalPages = instance.get(TOTAL_PAGES);
			var maxPageLinks = instance.get(MAX_PAGE_LINKS);
			var pageContainer = instance.get(PAGE_CONTAINER_TEMPLATE);

			// crate the anchor to be the page links
			while (page++ < maxPageLinks) {
				pageContainer.append(
					instance.get(PAGE_LINK_TEMPLATE)
				)
			};

			// substitute the {keys} on the templates with the real outerHTML templates
			instance.templatesCache = A.substitute(v,
				{
					CurrentPageReport: outer(PAGE_REPORT_EL),
					FirstPageLink: outer(FIRST_PAGE_LINK),
					LastPageLink: outer(LAST_PAGE_LINK),
					NextPageLink: outer(NEXT_PAGE_LINK),
					PageLinks: pageContainer.outerHTML(),
					PrevPageLink: outer(PREV_PAGE_LINK),
					RowsPerPageSelect: outer(ROWS_PER_PAGE_EL),
					Total: outer(TOTAL_EL)
				}
			);
		}

		return instance.templatesCache;
	},

	_setState: function(v) {
		var instance = this;

		A.each(v, function(value, key) {
			instance.set(key, value);
		});

		return v;
	},

	_setTotal: function(v) {
		var instance = this;
		var alwaysVisible = instance.get(ALWAYS_VISIBLE);
		var containers = instance.get(CONTAINERS);

		// if !alwaysVisible and there is nothing to show, hide it
		if (!alwaysVisible && (v == 0)) {
			containers.hide();
		}
		else {
			containers.show();
		}

		return v;
	},

	/*
	* Listeners
	*/
	_afterSetState: function(event) {
		var instance = this;

		instance._syncPageLinksUI();
		instance._syncPageReportUI();
	},

	_beforeSetState: function(event) {
		var instance = this;

		instance.lastState = event.prevVal;
	},

	_onClickFirstLinkEl: function(event) {
		var instance = this;

		instance.set(PAGE, 1);

		instance.changeRequest();

		event.halt();
	},

	_onClickPrevLinkEl: function(event) {
		var instance = this;

		if (instance.hasPrevPage()) {
			var page = instance.get(PAGE);

			instance.set(PAGE, page - 1);

			instance.changeRequest();
		}

		event.halt();
	},

	_onClickPageLinkEl: function(event) {
		var instance = this;
		var pageNumber = event.currentTarget.attr(PAGE);

		instance.set(PAGE, pageNumber);

		instance.changeRequest();

		event.halt();
	},

	_onClickNextLinkEl: function(event) {
		var instance = this;

		if (instance.hasNextPage()) {
			var page = instance.get(PAGE);

			instance.set(PAGE, page + 1);

			instance.changeRequest();
		}

		event.halt();
	},

	_onClickLastLinkEl: function(event) {
		var instance = this;
		var totalPages = instance.get(TOTAL_PAGES);

		instance.set(PAGE, totalPages);

		instance.changeRequest();

		event.halt();
	},

	_bindDOMEvents: function() {
		var instance = this;

		// loop all containers...
		instance.eachContainer(function(node) {
			// search for selects rows per page elements
			var rowsPerPageEl = node.one(DOT+CSS_PAGINATOR_ROWS_PER_PAGE);

			if (rowsPerPageEl) {
				// update the value with the current rowsPerPage
				rowsPerPageEl.val(
					instance.get(ROWS_PER_PAGE)
				);

				// detach change event
				rowsPerPageEl.detach('change');

				// bind change event to update the rowsPerPage
				rowsPerPageEl.on('change', function(event) {
					var rowsPerPage = instance.get(ROWS_PER_PAGE);

					try {
						// prevent IE error when first access .val() on A.Node when wraps a SELECT
						rowsPerPage = event.target.val();
					}
					catch(e) {}

					// reset the page before render the pageLinks again
					instance.set(PAGE, 1);

					// set rowsPerPage, this will render the UI again
					instance.set(ROWS_PER_PAGE, rowsPerPage);

					instance.changeRequest();
				});
			}
		});
	},

	_delegateDOM: function() {
		var instance = this;

		instance.eachContainer(function(node, i) {
			node.delegate('click', A.bind(instance._onClickFirstLinkEl, instance), DOT+CSS_PAGINATOR_FIRST_LINK);
			node.delegate('click', A.bind(instance._onClickPrevLinkEl, instance), DOT+CSS_PAGINATOR_PREV_LINK);
			node.delegate('click', A.bind(instance._onClickPageLinkEl, instance), DOT+CSS_PAGINATOR_PAGE_LINK);
			node.delegate('click', A.bind(instance._onClickNextLinkEl, instance), DOT+CSS_PAGINATOR_NEXT_LINK);
			node.delegate('click', A.bind(instance._onClickLastLinkEl, instance), DOT+CSS_PAGINATOR_LAST_LINK);
		});
	}
});

A.Paginator = Paginator;

}, '0.1a', { requires: [ 'aui-base', 'substitute' ] });AUI().add(
	'panel',
	function(A) {
		var Lang = A.Lang,
			isArray = Lang.isArray,
			isBoolean = Lang.isBoolean,

			BOUNDING_BOX = 'boundingBox',
			COLLAPSE = 'collapse',
			COLLAPSED = 'collapsed',
			COLLAPSIBLE = 'collapsible',
			ICON = 'icon',
			MINUS = 'minus',
			PANEL = 'panel',
			PLUS = 'plus',
			TITLE = 'title',
			TOOLS = 'tools',
			VISIBLE = 'visible',

			getClassName = A.ClassNameManager.getClassName,

			CSS_CLEARFIX = getClassName('helper', 'clearfix'),
			CSS_COLLAPSED = getClassName(PANEL, COLLAPSED),
			CSS_PANEL = getClassName(PANEL),
			CSS_PANEL_HD_TEXT = getClassName(PANEL, 'hd', 'text'),
			CSS_PANEL_TOOLSET = getClassName(PANEL, 'toolset'),

			CSS_PANELS = {
				body: 'bd',
				footer: 'ft',
				header: 'hd'
			},

			NODE_BLANK_TEXT = document.createTextNode(''),

			TPL_HEADER_TEXT = '<span class="' + CSS_PANEL_HD_TEXT + '"></span>';

		var Panel = function() {};

		Panel.ATTRS = {
			collapsed: {
				value: false,
				validator: isBoolean
			},

			collapsible: {
				value: false,
				validator: isBoolean
			},

			fillHeight: {
				value: ''
			},

			title: {
				value: '',
				validator: function(v) {
					return Lang.isString(v) || isBoolean(v);
				}
			},

			tools: {
				value: [],
				validator: isArray
			}
		};

		Panel.prototype = {
			/*
			* Lifecycle
			*/
			initializer: function(config) {
				var instance = this;

				if (!config.bodyContent) {
					instance.set('bodyContent', NODE_BLANK_TEXT);
				}

				if (!config.headerContent) {
					instance.set('headerContent', NODE_BLANK_TEXT);
				}

				instance.after('collapsedChange', instance._afterCollapsedChange);
				instance.after('render', instance._afterPanelRender);
				instance.after('titleChange', instance._afterTitleChange);
			},

			/*
			* Methods
			*/
			collapse: function() {
				var instance = this;

				instance.set(COLLAPSED, true);
			},

			expand: function() {
				var instance = this;

				instance.set(COLLAPSED, false);
			},

			toggle: function() {
				var instance = this;

				instance.set(
					VISIBLE,
					!instance.get(VISIBLE)
				);
			},

			toggleCollapse: function() {
				var instance = this;

				if (instance.get(COLLAPSED)) {
					instance.expand();
				}
				else {
					instance.collapse();
				}
			},

			_addPanelClass: function(section) {
				var instance = this;

				var sectionNode = instance[section + 'Node'];

				if (sectionNode) {
					var rootCssClass = CSS_PANELS[section];
					var cssClassMod = getClassName(PANEL, rootCssClass);

					// using instance.name to add the correct component name
					// when Panel is used to build another component using A.build
					var instanceName = instance.name;
					var cssClass = getClassName(instanceName, rootCssClass);

					sectionNode.addClass(cssClassMod);
					sectionNode.addClass(cssClass);
				}
			},

			_renderToolItems: function() {
				var instance = this;
				var tools = instance.get(TOOLS);

				if (instance.get(COLLAPSIBLE)) {
					var icon = instance.get(COLLAPSED) ? PLUS : MINUS;

					tools.unshift(
						{
							icon: icon,
							id: COLLAPSE,
							handler: {
								fn: instance.toggleCollapse,
								context: instance
							}
						}
					);
				}

				instance.toolset = new A.ToolSet(
					{
						tools: tools
					}
				)
				.render(instance.headerNode);

				instance.toolset.get(BOUNDING_BOX).addClass(CSS_PANEL_TOOLSET);
			},

			_renderHeaderText: function() {
				var instance = this;
				var headerNode = instance.headerNode;
				var headerTextNode = A.Node.create(TPL_HEADER_TEXT);
				var html = headerNode.html();

				headerNode.empty();

				headerTextNode.addClass(CSS_PANEL_HD_TEXT);

				headerNode.prepend(headerTextNode);

				instance.headerTextNode = headerTextNode;

				if (!instance.get(TITLE)) {
					instance.set(TITLE, html);
				}

				instance._syncTitleUI();
			},

			_syncCollapsedUI: function() {
				var instance = this;

				if (instance.get(COLLAPSIBLE)) {
					var bodyNode = instance.bodyNode;
					var boundingBox = instance.get(BOUNDING_BOX);
					var collapsed = instance.get(COLLAPSED);

					if (instance.toolset) {
						var toolset = instance.toolset;
						var collapseItem = toolset.tools.item(COLLAPSE);

						if (collapseItem) {
							collapseItem.set(
								ICON,
								collapsed ? PLUS : MINUS
							);
						}
					}

					if (collapsed) {
						bodyNode.hide();
						boundingBox.addClass(CSS_COLLAPSED);
					}
					else {
						bodyNode.show();
						boundingBox.removeClass(CSS_COLLAPSED);
					}
				}
			},

			_syncTitleUI: function() {
				var instance = this;
				var title = instance.get(TITLE);

				instance.headerTextNode.html(title);
			},

			/*
			* Listeners
			*/
			_afterCollapsedChange: function(event) {
				var instance = this;

				instance._syncCollapsedUI();
			},

			_afterPanelRender: function() {
				var instance = this;

				instance.headerNode.addClass(CSS_CLEARFIX);

				instance._addPanelClass('body');
				instance._addPanelClass('footer');
				instance._addPanelClass('header');

				instance._renderHeaderText();
				instance._renderToolItems();

				instance._syncCollapsedUI();
			},

			_afterTitleChange: function(event) {
				var instance = this;

				instance._syncTitleUI();
			}
		}

		A.Panel = A.Base.build(PANEL, A.Component, [Panel, A.WidgetStdMod]);
	},
	'0.1a',
	{
		requires: ['widget', 'widget-stdmod', 'tool-set'],
		use: []
	}
);/*
* Alloy UI ParseContent Plugin (YUI3)
*
* Copyright (c) 2009 Eduardo Lundgren (eduardo.lundgren@liferay.com)
* and Nate Cavanaugh (nate.cavanaugh@liferay.com)
*
*	 Example: node.plug(A.Plugin.ParseContent);
*
*  - After plug ParseContent on a A.Node instance the javascript chunks will be executed (remote and inline scripts).
*  - All the javascripts within a content will be executed according to the order of apparition.
*
* NOTE: The inspiration of ParseContent cames from the "Caridy Patino" Node Dispatcher Plugin
* 		http://github.com/caridy/yui3-gallery/blob/master/src/gallery-dispatcher/
*/
AUI.add('parse-content', function(A) {

var L = A.Lang,
	isString = L.isString,

	APPEND = 'append',
	DOCUMENT_ELEMENT = 'documentElement',
	FIRST_CHILD = 'firstChild',
	HEAD = 'head',
	HOST = 'host',
	INNER_HTML = 'innerHTML',
	PARSE_CONTENT = 'ParseContent',
	QUEUE = 'queue',
	SCRIPT = 'script',
	SRC = 'src';

function ParseContent(config) {
	ParseContent.superclass.constructor.apply(this, arguments);
}

A.mix(ParseContent, {
	NAME: PARSE_CONTENT,

	NS: PARSE_CONTENT,

	ATTRS: {
		queue: {
			value: null
		}
	}
});

A.extend(ParseContent, A.Plugin.Base, {
	initializer: function() {
		var instance = this;

		ParseContent.superclass.initializer.apply(this, arguments);

		instance.set(
			QUEUE,
			new A.AsyncQueue()
		);

		instance._bindAOP();
	},

	globalEval: function(data) {
		var doc = A.getDoc();
		var head = doc.one(HEAD) || doc.get(DOCUMENT_ELEMENT);

		// NOTE: A.Node.create('<script></script>') doesn't work correctly on Opera
		var newScript = document.createElement(SCRIPT);

		newScript.type = 'text/javascript';

		if (data) {
			// NOTE: newScript.set(TEXT, data) breaks on IE, YUI BUG.
			newScript.text = L.trim(data);
		}

		head.appendChild(newScript).remove(); //removes the script node immediately after executing it
	},

	parseContent: function(content) {
		var instance = this;
		var output = instance._clean(content);

		instance._dispatch(output);

		return output;
	},

	_bindAOP: function() {
		var instance = this;

		// overloading node.insert() arguments, affects append/prepend methods
		this.doBefore('insert', function(content) {
			var args = Array.prototype.slice.call(arguments);
			var output = instance.parseContent(content);

			// replace the first argument with the clean fragment
			args.splice(0, 1, output.fragment);

			return new A.Do.AlterArgs(null, args);
		});

		// overloading node.setContent() arguments
		this.doBefore('setContent', function(content) {
			var output = instance.parseContent(content);

			return new A.Do.AlterArgs(null, [
				output.fragment.get(INNER_HTML)
			]);
		});
	},

	_clean: function(content) {
		var output = {};
		var fragment = A.Node.create('<div></div>');

		// instead of fix all tags to "XHTML"-style, make the firstChild be a valid non-empty tag
		fragment.append('<div>_</div>');

		if (isString(content)) {
			// create fragment from {String}
			if (A.UA.ie) {
				// TODO: use A.DOM.addHTML for all browsers after YUI fix the ticket http://yuilibrary.com/projects/yui3/ticket/2528452
				fragment.getDOM().innerHTML += content;
			}
			else {
				A.DOM.addHTML(fragment, content, APPEND);
			}
		}
		else {
			// create fragment from {Y.Node | HTMLElement}
			fragment.append(content);
		}

		output.js = fragment.all(SCRIPT).each(
			function(node, i) {
				node.remove();
			}
		);

		// remove padding node
		fragment.get(FIRST_CHILD).remove();

		output.fragment = fragment;

		return output;
	},

	_dispatch: function(output) {
		var instance = this;
		var queue = instance.get(QUEUE);

		output.js.each(function(node, i) {
			var src = node.get(SRC);

			if (src) {
				queue.add({
					autoContinue: false,
					fn: function () {
						A.Get.script(src, {
							onEnd: function (o) {
								o.purge(); //removes the script node immediately after executing it
								queue.run();
							}
						});
					},
					timeout: 0
				});
			}
			else {
				queue.add({
					fn: function () {
						var dom = node._node;

						instance.globalEval(
							dom.text || dom.textContent || dom.innerHTML || ''
						);
					},
					timeout: 0
				});
			}
		});

		queue.run();
	}
});

A.namespace('Plugin');
A.Plugin.ParseContent = ParseContent;


}, '0.1a' , { requires: [ 'async-queue', 'io', 'plugin' ] });AUI.add('rating', function(A) {

var L = A.Lang,
	isBoolean = L.isBoolean,
	isNumber = L.isNumber,
	isString = L.isString,

	isNodeList = function(v) {
		return (v instanceof A.NodeList);
	},

	isNode = function(v) {
		return (v instanceof A.Node);
	},

	ANCHOR = 'a',
	BLANK = '',
	BOUNDING_BOX = 'boundingBox',
	CAN_RESET = 'canReset',
	CLEARFIX = 'clearfix',
	CONTENT_BOX = 'contentBox',
	DEFAULT_SELECTED = 'defaultSelected',
	DESTROY = 'destroy',
	DISABLED = 'disabled',
	ELEMENT = 'element',
	ELEMENTS = 'elements',
	HELPER = 'helper',
	HOVER = 'hover',
	INNER_HTML = 'innerHTML',
	INPUT = 'input',
	INPUT_NAME = 'inputName',
	LABEL = 'label',
	LABEL_ELEMENT = 'labelElement',
	NAME = 'name',
	OFF = 'off',
	ON = 'on',
	RATING = 'rating',
	SELECTED_INDEX = 'selectedIndex',
	SHOW_TITLE = 'showTitle',
	SIZE = 'size',
	TITLE = 'title',
	VALUE = 'value',

	getCN = A.ClassNameManager.getClassName,

	CSS_CLEAR_FIX = getCN(HELPER, CLEARFIX),
	CSS_RATING_LABEL_EL = getCN(RATING, LABEL, ELEMENT),
	CSS_RATING_EL = getCN(RATING, ELEMENT),
	CSS_RATING_EL_HOVER  = getCN(RATING, ELEMENT, HOVER),
	CSS_RATING_EL_OFF = getCN(RATING, ELEMENT, OFF),
	CSS_RATING_EL_ON = getCN(RATING, ELEMENT, ON);

function Rating() {
	Rating.superclass.constructor.apply(this, arguments);
}

A.mix(Rating, {
	NAME: 'Rating',

	ATTRS: {
		canReset: {
			value: true,
			validator: isBoolean
		},

		defaultSelected: {
			value: 0,
			writeOnce: true,
			validator: isNumber
		},

		elements: {
			writeOnce: true,
			readOnly: true,
			validator: isNodeList
		},

		hiddenInput: {
			validator: isNode
		},

		labelElement: {
			validator: isNode
		},

		inputName: {
			value: BLANK,
			validator: isString
		},

		label: {
			value: BLANK,
			validator: isString
		},

		render: {
			value: true
		},

		selectedIndex: {
			value: -1,
			validator: isNumber
		},

		showTitle: {
			value: true,
			validator: isBoolean
		},

		size: {
			value: 5,
			validator: function(v) {
				return isNumber(v) && (v > 0);
			}
		},

		title: null,

		value: null
	}
});

A.extend(Rating, A.Component, {
	/*
	* Lifecycle
	*/
	initializer: function(){
		var instance = this;

		instance.inputElementsData = {};

		instance.after('labelChange', this._afterSetLabel);
	},

	renderUI: function () {
		var instance = this;

		instance._parseInputElements();
		instance._renderElements();
	},

	bindUI: function () {
		var instance = this;

		instance._delegateElements();
	},

	syncUI: function(){
		var instance = this;

		instance._syncElements();
	},

	destructor: function(){
		var instance = this;
		var	boundingBox = instance.get(BOUNDING_BOX);

		boundingBox.detachAll();
		boundingBox.remove();
	},

	/*
	* Methods
	*/
	clearSelection: function() {
		var instance = this;

		instance.get(ELEMENTS).each(function(node) {
			node.removeClass(CSS_RATING_EL_ON);
			node.removeClass(CSS_RATING_EL_HOVER);
		});
	},

	select: function(index) {
		var instance = this;
		var oldIndex = instance.get(SELECTED_INDEX);
		var canReset = instance.get(CAN_RESET);

		// clear selection when the selected element is clicked
		if (canReset && (oldIndex == index)) {
			index = -1;
		}

		instance.set(SELECTED_INDEX, index);

		var selectedIndex = instance.get(SELECTED_INDEX);
		var	data = instance._getInputData(selectedIndex);

		var title = (TITLE in data) ? data.title : BLANK;
		var value = (VALUE in data) ? data.value : selectedIndex;

		instance.fillTo(selectedIndex);

		instance.set(TITLE, title);
		instance.set(VALUE, value);

		var hiddenInput = instance.get('hiddenInput');

		hiddenInput.setAttribute(TITLE, title);
		hiddenInput.setAttribute(VALUE, value);

		instance.fire('select');
	},

	fillTo: function(index, className) {
		var instance = this;

		instance.clearSelection();

		if (index >= 0) {
			instance.get(ELEMENTS).some(function(node, i) {
				node.addClass(className || CSS_RATING_EL_ON);

				return (index == i);
			});
		}
	},

	_parseInputElements: function() {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);
		var inputs = boundingBox.queryAll(INPUT);
		var size = inputs.size();
		var inputName = instance.get(INPUT_NAME);
		var hiddenInput = A.Node.create('<input type="hidden" />');

		if (size > 0) {
			inputName = inputName || inputs.item(0).getAttribute(NAME);

			instance.set(SIZE, size);

			inputs.each(function(node, index) {
				instance.inputElementsData[index] = {
					value: node.getAttribute(VALUE) || index,
					title: node.getAttribute(TITLE)
				};
			});

			inputs.remove();
		}

		hiddenInput.setAttribute(NAME, inputName);

		boundingBox.appendChild(hiddenInput);

		instance.set('hiddenInput', hiddenInput);
	},

	_renderElements: function() {
		var instance = this;
		var contentBox = instance.get(CONTENT_BOX);
		var ratingElement = A.Node.create('<a href="javascript:void(0);"></a>');
		var labelElement = A.Node.create('<div></div>');

		contentBox.addClass(CSS_CLEAR_FIX);
		ratingElement.addClass(CSS_RATING_EL);
		ratingElement.addClass(CSS_RATING_EL_OFF);
		labelElement.addClass(CSS_RATING_LABEL_EL);

		contentBox.append(labelElement);

		// creating rating elements
		for (var i = 0, size = this.get(SIZE); i < size; i++) {
			var	data = instance._getInputData(i);
			var title = data.title;
			var element = ratingElement.cloneNode();

			if (!title) {
				title = instance.get(TITLE);
			}

			if (instance.get(SHOW_TITLE) && title) {
				element.setAttribute(TITLE, title);
			}

			contentBox.appendChild(element);
		}

		instance.set(LABEL_ELEMENT, labelElement);
		instance.set(ELEMENTS, contentBox.queryAll(ANCHOR));
	},

	_syncElements: function(){
		var instance = this;
		var labelText = instance.get(LABEL);
		var selectedIndex = instance.get(DEFAULT_SELECTED) - 1;

		instance.set(SELECTED_INDEX, selectedIndex);

		instance.get(LABEL_ELEMENT).html(labelText);

		instance.select();
	},

	_delegateElements: function() {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);

		boundingBox.delegate('click', A.bind(instance._delegateMethod, this), ANCHOR);
		boundingBox.delegate('mouseover', A.bind(instance._delegateMethod, this), ANCHOR);
		boundingBox.delegate('mouseout', A.bind(instance._delegateMethod, this), ANCHOR);
	},

	_getInputData: function(index) {
		var instance = this;

		return instance.inputElementsData[index] || {};
	},

	/*
	* Delegated events
	*/
	_delegateMethod: function(event){
		var instance = this;
		var type = event.type;
		var disabled = instance.get(DISABLED);
		var	elements = instance.get(ELEMENTS);
		var selectedIndex = instance.get(SELECTED_INDEX);
		var index = elements.indexOf(event.target);

		var on = {
			click: function() {
				instance.select(index);
			},
			mouseover: function() {
				instance.fillTo(index, CSS_RATING_EL_HOVER);
			},
			mouseout: function() {
				instance.fillTo(selectedIndex);
			}
		};

		if (type) {
			if (!disabled) {
				on[type]();
			}
			// trigger user callback even when disabled
			instance.fire(type);
		}
	},

	/*
	* Attribute Listeners
	*/
	_afterSetLabel: function(event) {
		this.syncUI();
	}
});


/*
* ThumbRating
*/
var DOWN = 'down',
	THUMB = 'thumb',
	THUMB_RATING = 'ThumbRating',
	UP = 'up',

	CSS_RATING_THUMB_DOWN = getCN(RATING, THUMB, DOWN),
	CSS_RATING_THUMB_UP = getCN(RATING, THUMB, UP);

function ThumbRating(config) {
	ThumbRating.superclass.constructor.apply(this, arguments);
}

A.mix(ThumbRating, {
	NAME: THUMB_RATING,

	ATTRS: {
		size: {
			value: 2,
			readOnly: true
		}
	}
});

A.extend(ThumbRating, Rating, {
	renderUI: function() {
		ThumbRating.superclass.renderUI.apply(this, arguments);

		var elements = this.get(ELEMENTS);
		elements.item(0).addClass(CSS_RATING_THUMB_UP);
		elements.item(1).addClass(CSS_RATING_THUMB_DOWN);
	},

	fillTo: function(index, className) {
		this.clearSelection();

		if (index >= 0) {
			this.get(ELEMENTS).item(index).addClass(className || CSS_RATING_EL_ON);
		}
	},

	_syncElements: function(){
		var instance = this;
		var labelText = instance.get(LABEL);

		instance.get(LABEL_ELEMENT).html(labelText);
	}
});

A.Rating = Rating;
A.StarRating = Rating;
A.ThumbRating = ThumbRating;

}, '0.1a' , { requires: [ 'widget' ] });
AUI().add(
	'resize',
	function(A) {
		var Lang = A.Lang,
			isBoolean = Lang.isBoolean,
			isNumber = Lang.isNumber,
			isString = Lang.isString,
			isArray = Lang.isArray,

			UA = A.UA,
			IS_IE = UA.ie,

			getClassName = A.ClassNameManager.getClassName,

			NAME = 'resize',

			STR_BLANK = ' ',
			STR_HANDLE = 'handle',
			STR_ACTIVE = 'active',
			STR_INNER = 'inner',
			STR_T = 't',
			STR_R = 'r',
			STR_B = 'b',
			STR_L = 'l',
			STR_TR = 'tr',
			STR_TL = 'tl',
			STR_BR = 'br',
			STR_BL = 'bl',

			CSS_RESIZE = getClassName(NAME),
			CSS_TEXTAREA = getClassName(NAME, 'textarea'),
			CSS_DRAG = getClassName('dd'),
			CSS_HOVER = getClassName(NAME, 'hover'),
			CSS_PROXY = getClassName(NAME, 'proxy'),
			CSS_WRAP = getClassName(NAME, 'wrap'),
			CSS_KNOB = getClassName(NAME, 'knob'),
			CSS_HIDDEN = getClassName(NAME, 'hidden'),
			CSS_STATUS = getClassName(NAME, 'status'),
			CSS_GHOST = getClassName(NAME, 'ghost'),
			CSS_RESIZING = getClassName(NAME, 'resizing'),

			CSS_ICON = getClassName('icon'),
			CSS_GRIP_HORIZONTAL = getClassName('icon-grip-solid-horizontal'),
			CSS_GRIP_VERTICAL = getClassName('icon-grip-solid-vertical'),
			CSS_GRIP_DIAGONAL_TR = getClassName('icon-grip-diagonal-tr'),
			CSS_GRIP_DIAGONAL_TL = getClassName('icon-grip-diagonal-tl'),
			CSS_GRIP_DIAGONAL_BR = getClassName('icon-grip-diagonal-br'),
			CSS_GRIP_DIAGONAL_BL = getClassName('icon-grip-diagonal-bl'),

			CSS_HANDLE = getClassName(NAME, STR_HANDLE),
			CSS_HANDLE_ACTIVE = getClassName(NAME, STR_HANDLE, STR_ACTIVE),

			CSS_HANDLES_MAP = {
				t: getClassName(NAME, STR_HANDLE, STR_T),
				r: getClassName(NAME, STR_HANDLE, STR_R),
				b: getClassName(NAME, STR_HANDLE, STR_B),
				l: getClassName(NAME, STR_HANDLE, STR_L),
				tr: getClassName(NAME, STR_HANDLE, STR_TR),
				tl: getClassName(NAME, STR_HANDLE, STR_TL),
				br: getClassName(NAME, STR_HANDLE, STR_BR),
				bl: getClassName(NAME, STR_HANDLE, STR_BL)
			},

			CSS_HANDLES_INNER_MAP = {
				t: [getClassName(NAME, STR_INNER, STR_T), CSS_ICON, CSS_GRIP_HORIZONTAL].join(STR_BLANK),
				r: [getClassName(NAME, STR_INNER, STR_R), CSS_ICON, CSS_GRIP_VERTICAL].join(STR_BLANK),
				b: [getClassName(NAME, STR_INNER, STR_B), CSS_ICON, CSS_GRIP_HORIZONTAL].join(STR_BLANK),
				l: [getClassName(NAME, STR_INNER, STR_L), CSS_ICON, CSS_GRIP_VERTICAL].join(STR_BLANK),
				tr: [getClassName(NAME, STR_INNER, STR_TR), CSS_ICON, CSS_GRIP_DIAGONAL_TR].join(STR_BLANK),
				tl: [getClassName(NAME, STR_INNER, STR_TL), CSS_ICON, CSS_GRIP_DIAGONAL_TL].join(STR_BLANK),
				br: [getClassName(NAME, STR_INNER, STR_BR), CSS_ICON, CSS_GRIP_DIAGONAL_BR].join(STR_BLANK),
				bl: [getClassName(NAME, STR_INNER, STR_BL), CSS_ICON, CSS_GRIP_DIAGONAL_BL].join(STR_BLANK)
			},

			CSS_HANDLES_ACTIVE_MAP = {
				t: getClassName(NAME, STR_HANDLE, STR_T, STR_ACTIVE),
				r: getClassName(NAME, STR_HANDLE, STR_R, STR_ACTIVE),
				b: getClassName(NAME, STR_HANDLE, STR_B, STR_ACTIVE),
				l: getClassName(NAME, STR_HANDLE, STR_L, STR_ACTIVE),
				tr: getClassName(NAME, STR_HANDLE, STR_TR, STR_ACTIVE),
				tl: getClassName(NAME, STR_HANDLE, STR_TL, STR_ACTIVE),
				br: getClassName(NAME, STR_HANDLE, STR_BR, STR_ACTIVE),
				bl: getClassName(NAME, STR_HANDLE, STR_BL, STR_ACTIVE)
			};

		var Resize = function() {
			Resize.superclass.constructor.apply(this, arguments);
		};

		Resize.NAME = NAME;

		Resize.ATTRS = {
			active: {
				value: false
			},

			dd: {
				value: null
			},

			node: {
				setter: function(value) {
					var instance = this;

					var node = A.get(value);

					if (!node) {
						A.error('Resize: Invalid Node Given: ' + value);
					}
					else {
						node = node.item(0);
					}

					return node;
				}
			},

			lock: {
				value: false,
				setter: function(value) {
					var instance = this;

					var dd = instance.get('dd');

					if (dd) {
						dd.set('lock', value);
					}

					return value;
				},
				validator: isBoolean
			},

			positioned: {
				value: false
			},

			wrap: {
				value: null
			},
			useShim: {
				value: false
			},

			size: {
				value: true
			},

			setSize: {
				value: true,
				validator: isBoolean
			},

			handles: {
				value: ['r', 'b', 'br'],
				validator: function(value) {
					var instance = this;

					if (isString(value) && value.toLowerCase() == 'all') {
						value = ['t', 'b', 'r', 'l', 'bl', 'br', 'tl', 'tr'];
					}

					if (!isArray(value)) {
						value = value.replace(/, /g, ',');
						value = value.split(',');
					}

					return value;
				}
			},

			width: {
				value: 0,
				setter: function(value) {
					var instance = this;

					if (isNumber(value)) {
						if (value > 0) {
							var node = instance.get('node');

							if (instance.get('setSize')) {
								node.setStyle('width', value + 'px');
							}

							node.set('width', value);

							instance._cache.width = value;
						}
					}
					else {
						value = A.Attribute.INVALID_VALUE;
					}

					return value;
				}
			},

			height: {
				value: 0,
				setter: function(value) {
					var instance = this;

					if (isNumber(value)) {
						if (value > 0) {
							var node = instance.get('node');

							if (instance.get('setSize')) {
								node.setStyle('height', value + 'px');
							}

							node.set('height', value);
							instance._cache.height = value;
						}
					}
					else {
						value = A.Attribute.INVALID_VALUE;
					}

					return value;
				}
			},

			minHeight: {
				value: 15,
				validator: isNumber
			},

			minWidth: {
				value: 15,
				validator: isNumber
			},

			maxHeight: {
				value: 10000,
				validator: isNumber
			},

			maxWidth: {
				value: 10000,
				validator: isNumber
			},

			minY: {
				value: false
			},

			minX: {
				value: false
			},

			maxX: {
				value: false
			},

			maxY: {
				value: false
			},

			proxy: {
				value: false,
				validator: isBoolean
			},

			ratio: {
				value: false,
				validator: isBoolean
			},

			ghost: {
				value: false,
				validator: isBoolean
			},

			draggable: {
				value: false,
				validator: isBoolean,
				valueFn: function(dd) {
					var instance = this;

					if (dd && instance.get('wrap')) {
						instance._setupDragDrop();
					}
					else if (instance.get('dd')) {
						instance.get('wrap').removeClass(CSS_DRAG);

						instance.get('dd').unreg();
					}
				}
			},

			hover: {
				value: false,
				validator: isBoolean
			},

			hiddenHandles: {
				value: false,
				validator: isBoolean
			},

			knobHandles: {
				value: false,
				validator: isBoolean
			},

			xTicks: {
				value: false
			},

			yTicks: {
				value: false
			},

			status: {
				value: true,
				validator: isBoolean
			},

			autoRatio: {
				value: false,
				validator: isBoolean
			}
		};

		Resize._instances = {};

		Resize.getResizeById = function(id) {
			return Resize._instances[id] || false;
		};

		A.extend(
			Resize,
			A.Base,
			{
				initializer: function() {
					var instance = this;

					instance._createCache();
					instance._createWrap();
					instance._createProxy();
					instance._createHandles();
				},

				destructor: function() {
					var instance = this;

					var handles = instance._handles;

					for (var i in handles) {
						var handle = handles[i];

						A.Event.purgeElement(handle);
						handle.remove();
					}

					if (instance._proxy) {
						instance._proxy.remove();
					}

					if (instance._status) {
						instance._status.remove();
					}

					if (instance.dd) {
						instance.dd.destroy();

						instance._wrap.removeClass(CSS_DRAG);
					}

					var node = instance.get('node');

					if (!instance._wrap.compareTo(node)) {
						node.setStyles(
							{
								position: '',
								top: '',
								left: ''
							}
						);

						instance._wrap.get('parentNode').replaceChild(node, instance._wrap);
					}

					node.removeClass(CSS_RESIZE);

					delete Resize._instances[instance.get('id')];

					for (var i in instance) {
						instance[i] = null;

						delete instance[i];
					}
				},

				toString: function() {
					var instance = this;

					if (instance.get) {
						return 'Resize (#' + instance.get('id') + ')';
					}

					return 'Resize utility';
				},

				_createCache: function() {
					var instance = this;

					this._cache = {
						xy: [],
						height: 0,
						width: 0,
						top: 0,
						left: 0,
						offsetHeight: 0,
						offsetWidth: 0,
						start: {
							height: 0,
							width: 0,
							top: 0,
							left: 0
						}
					};
				},

				_createProxy: function() {
					var instance = this;

					if (instance.get('proxy')) {
						var proxy = A.Node.create('<div></div>');

						proxy.set('className', CSS_PROXY);

						var node = instance.get('node');
						var elHeight = node.get('clientHeight');
						var elWidth = node.get('clientWidth');

						proxy.setStyle('height', elHeight + 'px');
						proxy.setStyle('width', elWidth + 'px');

						instance._wrap.get('parentNode').appendChild(proxy);

						instance._proxy = proxy;
					}
				},

				_createWrap: function() {
					var instance = this;

					var node = instance.get('node');
					var tagName = node.get('tagName').toLowerCase();
					var wrap = node;

					if (instance.get('wrap') == false) {
						if (/img|textarea|input|iframe|select/.test(tagName)) {
							instance.set('wrap', true);
						}
					}

					if (instance.get('wrap') == true) {
						wrap = A.Node.create('<div></div>');

						wrap.set('id', node.get('id') + '_wrap');
						wrap.set('className', CSS_WRAP);

						if (tagName == 'textarea') {
							wrap.addClass(CSS_TEXTAREA);
						}

						wrap.setStyle('width', instance.get('width') + 'px');
						wrap.setStyle('height', instance.get('height') + 'px');
						wrap.setStyle('zIndex', node.getStyle('zIndex'));

						node.setStyle('zIndex', 0);

						var position = node.getStyle('position');
						var top = node.getStyle('top');
						var left = node.getStyle('left');

						wrap.setStyle('position', (position == 'static' ? 'relative' : position));
						wrap.setStyle('top', top);
						wrap.setStyle('left', left);

						if (position == 'absolute') {
							node.setStyle('position', 'relative');
							node.setStyle('top', 0);
							node.setStyle('left', 0);
						}

						var parentNode = node.get('parentNode');

						parentNode.replaceChild(wrap, node);

						wrap.appendChild(node);
					}
					else if (wrap.getStyle('position') == 'absolute') {
						instance.set('positioned', true);
					}

					if (instance.get('draggable')) {
						instance._setupDragDrop();
					}

					if (instance.get('hover')) {
						wrap.addClass(CSS_HOVER);
					}

					if (instance.get('knobHandles')) {
						wrap.addClass(CSS_KNOB);
					}

					if (instance.get('hiddenHandles')) {
						wrap.addClass(CSS_HIDDEN);
					}

					wrap.addClass(CSS_RESIZE);

					instance._wrap = wrap;
				},

				_setupDragDrop: function() {
					var instance = this;

					instance._wrap.addClass(CSS_DRAG);

					var dd = new A.DD.Drag(
						{
							node: instance._wrap
						}
					);

					dd.addTarget(instance);

					instance.set('dd', dd);
				},

				_createHandles: function() {
					var instance = this;

					var handlesCache = {};
					var ddsCache = {};

					var handles = instance.get('handles');
					var length = handles.length;

					var useShim = instance.get('useShim');

					for (var i = 0; i < length; i++) {
						var handle = handles[i];

						var handleNode = A.Node.create('<div></div>');

						var handleClassName = CSS_HANDLE + ' ' + CSS_HANDLES_MAP[handle];

						handleNode.set('id', A.guid());
						handleNode.addClass(handleClassName);

						var knobNode = A.Node.create('<div></div>');

						knobNode.addClass(CSS_HANDLES_INNER_MAP[handle]);

						handleNode.appendChild(knobNode);

						handleNode.on('mouseover', instance._handleMouseOver, instance);
						handleNode.on('mouseout', instance._handleMouseOut, instance);

						var dd = new A.DD.Drag(
							{
								node: handleNode,
								useShim: useShim,
								move: false
							}
						);

						dd.plug(
							A.Plugin.DDConstrained,
							{
								stickX: (handle == 'r' || handle == 'l'),
								stickY: (handle == 't' || handle == 'b')
							}
						);

						dd.on('drag:start', A.rbind(instance._handleStartDrag, instance, dd));
						dd.on('drag:mouseDown', A.rbind(instance._handleMouseDown, instance, dd));
						dd.on('drag:drag', A.rbind(instance['_handle_for_' + handle], instance, dd), instance);
						dd.on('drag:end', instance._handleMouseUp, instance);

						handlesCache[handle] = handleNode;
						ddsCache[handle] = dd;

						instance._wrap.appendChild(handleNode);
					}

					instance._status = A.Node.create('<span class="' + CSS_STATUS + '"></span>');

					A.get('body').appendChild(instance._status);

					instance._handles = handlesCache;
					instance._dds = ddsCache;
				},

				_ieSelectFix: function() {
					return false;
				},

				_setAutoRatio: function(dd) {
					var instance = this;

					if (instance.get('autoRatio')) {
						var event = dd && dd._ev_md;

						instance.set('ratio', (event && event.shiftKey));
					}
				},

				_handleMouseDown: function(event, dd) {
					var instance = this;

					if (instance.get('lock')) {
						return false;
					}

					if (instance._wrap.getStyle('position') == 'absolute') {
						instance.set('positioned', true);
					}

					instance._setAutoRatio(dd);

					if (IS_IE) {
						instance._ieSelectBack = document.body.onselectstart;
						document.body.onselectstart = instance._ieSelectFix;
					}
				},

				_handleMouseOver: function(event) {
					var instance = this;

					if (instance.get('lock')) {
						return false;
					}

					instance._wrap.removeClass(CSS_RESIZE);

					if (instance.get('hover')) {
						instance._wrap.removeClass(CSS_HOVER);
					}

					var target = event.target;

					if (!target.hasClass(CSS_HANDLE)) {
						target = target.get('parentNode');
					}

					if (target.hasClass(CSS_HANDLE) && !instance.get(STR_ACTIVE)) {
						target.addClass(CSS_HANDLE_ACTIVE);

						for (var i in instance._handles) {
							if (instance._handles[i].compareTo(target)) {
								target.addClass(CSS_HANDLES_ACTIVE_MAP[i]);

								break;
							}
						}
					}

					instance._wrap.addClass(CSS_RESIZE);
				},

				_handleMouseOut: function(event) {
					var instance = this;

					instance._wrap.removeClass(CSS_RESIZE);

					if (instance.get('hover') && !instance.get(STR_ACTIVE)) {
						instance._wrap.addClass(CSS_HOVER);
					}

					var target = event.target;

					if (!target.hasClass(CSS_HANDLE)) {
						target = target.get('parentNode');
					}

					if (target.hasClass(CSS_HANDLE) && !instance.get(STR_ACTIVE)) {
						target.removeClass(CSS_HANDLE_ACTIVE);

						for (var i in instance._handles) {
							if (instance._handles[i].compareTo(target)) {
								target.removeClass(CSS_HANDLES_ACTIVE_MAP[i]);

								break;
							}
						}
					}

					instance._wrap.addClass(CSS_RESIZE);
				},

				_handleStartDrag: function(event, dd) {
					var instance = this;

					var target = dd.get('dragNode');

					if (target.hasClass(CSS_HANDLE)) {
						if (instance._wrap.getStyle('position') == 'absolute') {
							instance.set('positioned', true);
						}

						var node = instance.get('node');

						instance.set(STR_ACTIVE, true);
						instance._currentDD = dd;

						if (instance._proxy) {
							instance._proxy.setStyles(
								{
									visibility: 'visible',
									zIndex: 1000,
									width: node.get('offsetWidth') + 'px',
									height: node.get('offsetHeight') + 'px'
								}
							);
						}

						for (var i in instance._handles) {
							if (instance._handles[i].compareTo(target)) {
								instance._currentHandle = i;

								var handle = '_handle_for_' + i;

								target.addClass(CSS_HANDLES_ACTIVE_MAP[i]);

								break;
							}
						}

						target.addClass(CSS_HANDLE_ACTIVE);

						if (instance.get('proxy')) {
							var xy = node.getXY();

							instance._proxy.setXY(xy);

							if (instance.get('ghost')) {
								node.addClass(CSS_GHOST);
							}
						}

						instance._wrap.addClass(CSS_RESIZING);

						instance._setCache();

						var cache = instance._cache;

						instance._updateStatus(cache.height, cache.width, cache.top, cache.left);

						instance.fire('startResize');
					}
				},

				_setCache: function() {
					var instance = this;

					var cache = instance._cache;
					var wrap = instance._wrap;
					var node = instance.get('node');

					cache.xy = wrap.getXY();

					wrap.setXY(cache.xy);

					cache.height = node.get('offsetHeight');
					cache.width = node.get('offsetWidth');

					cache.start.height = cache.height;
					cache.start.width = cache.width;
					cache.start.top = cache.xy[1];
					cache.start.left = cache.xy[0];

					instance.set('height', cache.height);
					instance.set('width', cache.width);
				},

				_handleMouseUp: function(event) {
					var instance = this;

					event.stopImmediatePropagation();

					instance.set(STR_ACTIVE, false);

					var handle = '_handle_for_' + instance._currentHandle;
					var cache = instance._cache;

					if (instance._proxy) {
						var proxy = instance._proxy;

						proxy.setStyles(
							{
								visibility: 'hidden',
								zIndex: '-1'
							}
						);

						if (instance.get('setSize')) {
							instance.resize(event, cache.height, cache.width, cache.top, cache.left, true);
						}
						else {
							instance.fire(
								'resize',
								{
									height: cache.height,
									width: cache.width,
									top: cache.top,
									left: cache.left
								}
							);
						}

						if (instance.get('ghost')) {
							instance.get('node').removeClass(CSS_GHOST);
						}
					}

					if (instance.get('hover')) {
						instance._wrap.addClass(CSS_HOVER);
					}

					if (instance._status) {
						instance._status.addClass('aui-helper-hidden');
					}

					if (IS_IE) {
						document.body.onselectstart = instance._ieSelectBack;

						instance._wrap.removeClass(CSS_RESIZE);
					}

					for (var i in instance._handles) {
						instance._handles[i].removeClass(CSS_HANDLES_ACTIVE_MAP[i]);
					}

					if (instance.get('hover') && !instance.get(STR_ACTIVE)) {
						instance._wrap.addClass(CSS_HOVER);
					}

					instance._wrap.removeClass(CSS_RESIZING);

					var currentHandle = instance._handles[instance._currentHandle];

					currentHandle.removeClass(CSS_HANDLE_ACTIVE);

					if (IS_IE) {
						instance._wrap.addClass(CSS_RESIZE);
					}

					instance._resizeEvent = null;
					instance._currentHandle = null;

					instance.fire(
						'endResize',
						{
							height: cache.height,
							width: cache.width,
							top: cache.top,
							left: cache.left
						}
					);
				},

				_setRatio: function(height, width, top, left) {
					var instance = this;

					var originalHeight = height;
					var originalWidth = width;

					if (instance.get('ratio')) {
						var newHeight = instance.get('height');
						var newWidth = instance.get('width');

						var maxHeight = instance.get('maxHeight');
						var maxWidth = instance.get('maxWidth');
						var minHeight = instance.get('minHeight');
						var minWidth = instance.get('minWidth');

						switch(instance._currentHandle) {
							case 'l':
								height = newHeight * (width / newWidth);
								height = Math.min(Math.max(minHeight, height), maxHeight);

								width = newWidth * (height / newHeight);

								top = (instance._cache.start.top - (-((newHeight - height) / 2)));
								left = (instance._cache.start.left - (-((newWidth - width))));

							break;

							case 'r':
								height = newHeight * (width / newWidth);
								height = Math.min(Math.max(minHeight, height), maxHeight);

								width = newWidth * (height / newHeight);

								top = (instance._cache.start.top - (-((newHeight - height) / 2)));
							break;

							case 't':
								height = newHeight * (width / newWidth);
								width = newWidth * (height / newHeight);

								top = (instance._cache.start.top - (-((newHeight - height))));
								left = (instance._cache.start.left - (-((newWidth - width) / 2)));
							break;

							case 'b':
								height = newHeight * (width / newWidth);
								width = newWidth * (height / newHeight);

								left = (instance._cache.start.left - (-((newWidth - width) / 2)));
							break;

							case 'bl':
								height = newHeight * (width / newWidth);
								width = newWidth * (height / newHeight);

								left = (instance._cache.start.left - (-((newWidth - width))));
							break;

							case 'br':
								height = newHeight * (width / newWidth);
								width = newWidth * (height / newHeight);
							break;

							case 'tl':
								height = newHeight * (width / newWidth);
								width = newWidth * (height / newHeight);

								top = (instance._cache.start.top - (-((newHeight - height))));
								left = (instance._cache.start.left - (-((newWidth - width))));
							break;

							case 'tr':
								height = newHeight * (width / newWidth);
								width = newWidth * (height / newHeight);

								top = (instance._cache.start.top - (-((newHeight - height))));
								left = (instance._cache.start.left);
							break;
						}

						var originalHeight = instance._checkHeight(height);
						var originalWidth = instance._checkWidth(width);

						if ((originalHeight != height) || (originalWidth != width)) {
							top = 0;
							left = 0;

							if (originalHeight != height) {
								originalWidth = instance._cache.width;
							}

							if (originalWidth != width) {
								originalHeight = instance._cache.height;
							}
						}
					}

					return [originalHeight, originalWidth, top, left];
				},

				_updateStatus: function(height, width, top, left) {
					var instance = this;

					if (instance._resizeEvent && !Lang.isString(instance._resizeEvent)) {
						height = (height === 0) ? instance._cache.start.height : height;
						width = (width === 0) ? instance._cache.start.width : width;

						var height1 = instance.get('height');
						var width1 = instance.get('width');

						if (isNaN(height1)) {
							height1 = height;
						}

						if (isNaN(width1)) {
							width1 = width;
						}

						var diffHeight = (height - height1);
						var diffWidth = (width - width1);

						instance._cache.offsetHeight = diffHeight;
						instance._cache.offsetWidth = diffWidth;

						if (instance.get('status')) {
							instance._status.removeClass('aui-helper-hidden');

							var statusSize = '<strong>' + parseInt(height, 10) + ' x ' + parseInt(width, 10) + '</strong>';
							var statusDelta = '<em>' + (diffHeight > 0 ? '+' : '') + diffHeight + ' x ' + (diffWidth > 0 ? '+' : '') + diffWidth + '</em>';

							instance._status.html(statusSize + statusDelta);

							instance._status.setXY(instance._resizeEvent.pageX + 12, instance._resizeEvent.pageY + 12);
						}
					}
				},

				reset: function() {
					var instance = this;

					var cacheStart = instance._cache.start;

					instance.resize(null, cacheStart.height, cacheStart.width, cacheStart.top, cacheStart.left, true);

					return instance;
				},

				resize: function(event, height, width, top, left, force, silent) {
					var instance = this;

					if (instance.get('lock')) {
						return false;
					}

					instance._resizeEvent = event;

					var el = instance._wrap;
					var set = true;

					var positioned = instance.get('positioned');

					if (instance._proxy && !force) {
						el = instance._proxy;
					}

					instance._setAutoRatio(instance._currentDD);

					if (positioned == true) {
						if (instance._proxy) {
							top = instance._cache.top - top;
							left = instance._cache.left - left;
						}
					}

					var ratio = instance._setRatio(height, width, top, left);

					height = parseInt(ratio[0], 10);
					width = parseInt(ratio[1], 10);
					top = parseInt(ratio[2], 10);
					left = parseInt(ratio[3], 10);

					if (top == 0) {
						top = el.getY();
					}

					if (left == 0) {
						left = el.getX();
					}

					if (positioned) {
						if (instance._proxy && force) {
							el.setStyles(
								{
									left: instance._proxy.getStyle('left'),
									top: instance._proxy.getStyle('top')
								}
							);
						}
						else {
							if (!instance.get('ratio') && !instance._proxy) {
								top = instance._cache.top + -(top);
								left = instance._cache.left + -(left);
							}

							if (top) {
								var minY = instance.get('minY');
								var maxY = instance.get('maxY');

								if (minY) {
									if (top < minY) {
										top = minY;
									}
								}

								if (maxY) {
									if (top > maxY) {
										top = maxY;
									}
								}
							}

							if (left) {
								var minX = instance.get('minX');
								var maxX = instance.get('maxX');

								if (minX) {
									if (left < minX) {
										left = minX;
									}
								}

								if (maxX) {
									if ((left + width) > maxX) {
										left = maxX - width;
									}
								}
							}
						}
					}

					instance._updateStatus(height, width, top, left);

					if (positioned) {
						if (!(instance._proxy && force)) {
							if (top) {
								el.setY(top);
								instance._cache.top = top;
							}

							if (left) {
								el.setX(left);
								instance._cache.left = left;
							}
						}
					}

					if (height) {
						set = true;

						if (instance._proxy && force) {
							if (!instance.get('setSize')) {
								set = false;
							}
						}

						if (set) {
							el.setStyle('height', height + 'px');
						}

						if ((instance._proxy && force) || !instance._proxy) {
							var node = instance.get('node');

							if (!instance._wrap.compareTo(node)) {
								node.setStyle('height', height + 'px');
							}
						}

						instance._cache.height = height;
					}

					if (width) {
						instance._cache.width = width;

						set = true;

						if (instance._proxy && force) {
							if (!instance.get('setSize')) {
								set = false;
							}
						}

						if (set) {
							el.setStyle('width', width + 'px');
						}

						if ((instance._proxy && force) || !instance._proxy) {
							var node = instance.get('node');

							if (!instance._wrap.compareTo(node)) {
								node.setStyle('width', width + 'px');
							}
						}
					}

					var eventData = {
						height: height,
						width: width,
						top: top,
						left: left
					};

					if (instance._proxy && !force) {
						instance.fire('proxyResize', eventData);
					}
					else {
						instance.fire('resize', eventData);
					}

					return instance;
				},

				_handle_for_br: function(event, dd) {
					var instance = this;

					var newHeight = instance._setHeight(event);
					var newWidth = instance._setWidth(event);

					instance.resize(event, newHeight, newWidth, 0, 0);
				},

				_handle_for_bl: function(event) {
					var instance = this;

					var newHeight = instance._setHeight(event);
					var newWidth = instance._setWidth(event, true);

					var left = (newWidth - instance._cache.width);

					instance.resize(event, newHeight, newWidth, 0, left);
				},

				_handle_for_tl: function(event) {
					var instance = this;

					var newHeight = instance._setHeight(event, true);
					var newWidth = instance._setWidth(event, true);

					var top = (newHeight - instance._cache.height);
					var left = (newWidth - instance._cache.width);

					instance.resize(event, newHeight, newWidth, top, left);
				},

				_handle_for_tr: function(event) {
					var instance = this;

					var newHeight = instance._setHeight(event, true);
					var newWidth = instance._setWidth(event);

					var top = (newHeight - instance._cache.height);

					instance.resize(event, newHeight, newWidth, top, 0);
				},

				_handle_for_r: function(event) {
					var instance = this;

					var newWidth = instance._setWidth(event);

					instance.resize(event, 0, newWidth, 0, 0);
				},

				_handle_for_l: function(event) {
					var instance = this;

					var newWidth = instance._setWidth(event, true);

					var left = (newWidth - instance._cache.width);

					instance.resize(event, 0, newWidth, 0, left);
				},

				_handle_for_b: function(event) {
					var instance = this;

					var newHeight = instance._setHeight(event);

					instance.resize(event, newHeight, 0, 0, 0);
				},

				_handle_for_t: function(event) {
					var instance = this;

					var newHeight = instance._setHeight(event, true);

					var top = (newHeight - instance._cache.height);

					instance.resize(event, newHeight, 0, top, 0);
				},

				_setWidth: function(event, flip) {
					var instance = this;

					var xy = instance._cache.xy[0];
					var width = instance._cache.width;
					var x = event.pageX;
					var newWidth = (x - xy);

					if (flip) {
						newWidth = (xy - x) + instance.get('width');
					}

					newWidth = instance._snapTick(newWidth, instance.get('xTicks'));
					newWidth = instance._checkWidth(newWidth);

					return newWidth;
				},

				_checkWidth: function(width) {
					var instance = this;

					var minWidth = instance.get('minWidth');
					var maxWidth = instance.get('maxWidth');

					if (minWidth) {
						if (width < minWidth) {
							width = minWidth;
						}
					}

					if (maxWidth) {
						if (width > maxWidth) {
							width = maxWidth;
						}
					}

					return width;
				},

				_checkHeight: function(height) {
					var instance = this;

					var minHeight = instance.get('minHeight');
					var maxHeight = instance.get('maxHeight');

					if (minHeight) {
						if (height < minHeight) {
							height = minHeight;
						}
					}

					if (maxHeight) {
						if (height > maxHeight) {
							height = maxHeight;
						}
					}

					return height;
				},

				_setHeight: function(event, flip) {
					var instance = this;

					var xy = instance._cache.xy[1];
					var height = instance._cache.height;
					var y = event.pageY;
					var newHeight = (y - xy);

					if (flip) {
						newHeight = (xy - y) + instance.get('height');
					}

					newHeight = instance._snapTick(newHeight, instance.get('yTicks'));
					newHeight = instance._checkWidth(newHeight);

					return newHeight;
				},

				_snapTick: function(size, pix) {
					var instance = this;

					if (!size || !pix) {
						return size;
					}

					var newSize = size;
					var newX = size % pix;

					if (newX > 0) {
						if (newX > (pix / 2)) {
							newSize = size + (pix - newX);
						}
						else {
							newSize = size - newX;
						}
					}

					return newSize;
				},

				_cache: {},
				_currentDD: null,
				_dds: null,
				_handles: null,
				_ieSelectBack: null,
				_proxy: null
			}
		);

		A.Resize = Resize;
	},
	'0.1a',
	{
		requires: ['dd'],
		skinnable: false
	}
);

AUI().add(
	'resize-plugin',
	function(A) {
		var ResizePlugin = function(config) {
			config.node = config.host;

			ResizePlugin.superclass.constructor.apply(this, arguments);
		};

		ResizePlugin.NAME = 'resizePlugin';
		ResizePlugin.NS = 'resize';

		A.extend(ResizePlugin, A.Resize);

		A.namespace('Plugin');

		A.Plugin.ResizePlugin = ResizePlugin;
	},
	'0.1a',
	{
		requires: ['resize'],
		skinnable: false
	}
);AUI().add(
	'sortable',
	function(A) {
		var Lang = A.Lang,

			getClassName = A.ClassNameManager.getClassName,

			NAME = 'sortable',

			DDM = A.DD.DDM,

			CSS_DRAGGING = getClassName(NAME, 'dragging'),
			CSS_HANDLE = getClassName(NAME, 'handle'),
			CSS_ITEM = getClassName(NAME, 'item'),
			CSS_NO_HANDLES = getClassName(NAME, 'no-handles'),
			CSS_PLACEHOLDER = getClassName(NAME, 'placeholder'),
			CSS_PROXY = getClassName(NAME, 'proxy'),
			CSS_SORTABLE = getClassName(NAME);

		var Sortable = function() {
			Sortable.superclass.constructor.apply(this, arguments);
		};

		Sortable.NAME = NAME;

		Sortable.ATTRS = {
			dd: {
				value: {}
			},

			constrain: {},

			container: {
				value: null
			},

			groups: {
				valueFn: function() {
					var instance = this;

					return [A.guid()];
				}
			},

			nodes: {
				value: null,
				setter: function(value) {
					var instance = this;

					var container = instance.get('container');

					if (!(value instanceof A.NodeList)) {
						if(Lang.isString(value)) {
							if (container) {
								value = container.queryAll(value);
							}
							else {
								value = A.all(value);
							}
						}
					}

					if (value instanceof A.NodeList && value.size()) {
						instance.set('container', value.item(0).get('parentNode'));
					}
					else {
						value = A.Attribute.INVALID_VALUE;
					}

					return value;
				}
			},

			placeholder: {},

			proxy: {}
		};

		A.extend(
			Sortable,
			A.Base,
			{
				initializer: function() {
					var instance = this;

					var nodes = instance.get('nodes');

					var constrain = instance.get('constrain');

					instance._useConstrain = !!constrain;

					if (Lang.isObject(constrain)) {
						instance._constrainConfig = constrain;
					}

					var proxy = instance.get('proxy');

					instance._useProxy = !!proxy;

					if (Lang.isObject(proxy)) {
						instance._proxyConfig = proxy;
					}

					var ddConfig = instance.get('dd');

					instance._ddConfig = ddConfig;

					instance._ddConfig = A.mix(
						instance._ddConfig,
						{
							bubbles: instance,
							groups: instance.get('groups'),
							placeholder: instance.get('placeholder'),
							constrain: instance.get('constrain'),
							proxy: instance.get('proxy')
						}
					);

					if (nodes) {
						nodes.each(instance.add, instance);
					}

					instance.after('drag:drag', instance._onDrag);
					instance.after('drag:end', instance._onDragEnd);
					instance.after('drag:over', instance._onDragOver);
					instance.after('drag:start', instance._onDragStart);
				},

				add: function(item) {
					var instance = this;

					if (item) {
						var ddConfig = instance._ddConfig;

						if ((item instanceof A.Node) || Lang.isString(item) || item.nodeName) {
							item = A.get(item);

							ddConfig.node = item;
						}
						else if (Lang.isObject(item)) {
							A.mix(item, ddConfig);

							ddConfig = item;
						}

						var sortableItem = instance.getSortableItem();

						var dd = new sortableItem(ddConfig);
					}
				},

				getSortableItem: function() {
					var instance = this;

					return SortableItem;
				},

				_onDrag: function(event) {
					var instance = this;

					var drag = event.target;

					var lastXY = drag.lastXY;
					var x = lastXY[0];
					var y = lastXY[1];

					var lastX = instance._lastX;
					var lastY = instance._lastY;

					var xToleranceMet = Math.abs(x - lastX);
					var yToleranceMet = Math.abs(y - lastY);

					instance._goingUp = ((x < lastX) && xToleranceMet) || ((y < lastY) && yToleranceMet);

					instance._lastX = x;
					instance._lastY = y;

					A.later(50, DDM, DDM.syncActiveShims);
				},

				_onDragEnd: function(event) {
					var instance = this;

					var drag = event.target;
					var node = drag.get('node');

					node.removeClass(CSS_DRAGGING);
				},

				_onDragOver: function(event) {
					var instance = this;

					var sortDirection = 0;
					var midpoint = 0;
					var lastX = instance._lastX;
					var lastY = instance._lastY;

					var DDM = A.DD.DDM;
					var drag = event.drag;
					var drop = event.drop;

					var dropNode = drop.get('node');

					var action = 'placeBefore';

					if (!instance._goingUp) {
						action = 'placeAfter';
					}

					dropNode[action](drag.get('placeholder'));

					drop.sizeShim();
				},

				_onDragStart: function(event) {
					var instance = this;

					var drag = event.target;

					var node = drag.get('node');

					if (instance._useProxy) {
						drag.get('dragNode').addClass(CSS_PROXY);
					}

					node.addClass(CSS_DRAGGING);
				},

				_lastX: 0,
				_lastY: 0
			}
		);

		var SortableItem = function(config) {
			SortableItem.superclass.constructor.call(this, config.dd || config);
		};

		SortableItem.NAME = 'sortableitem';

		SortableItem.ATTRS = {
			constrain: {
				value: null
			},

			placeholder: {
				getter: function() {
					var instance = this;

					return instance.get('node');
				}
			},

			proxy: {
				value: {
					borderStyle: 0,
					moveOnEnd: false
				}
			},

			target: {
				value: true
			},

			syncPlaceholderSize: {
				value: true
			}
		};

		A.extend(
			SortableItem,
			A.DD.Drag,
			{
				initializer: function() {
					var instance = this;

					var node = instance.get('node');

					node.dd = instance;

					node.addClass(CSS_ITEM);

					instance._initHandles();
					instance._initConstrain();
					instance._initProxy();
				},

				_initHandles: function() {
					var instance = this;

					var handles = instance.get('handles');
					var node = instance.get('node');

					if (handles) {
						for (var i = handles.length - 1; i >= 0; i--) {
							var handle = handles[i];

							node.queryAll(handle).addClass(CSS_HANDLE);
						}
					}
					else {
						node.addClass(CSS_NO_HANDLES);
					}

					instance.removeInvalid('a');
				},

				_initConstrain: function() {
					var instance = this;

					var constrain = instance.get('constrain');

					if (!!constrain) {
						if (!Lang.isObject(constrain)) {
							constrain = null;
						}

						instance.plug(A.Plugin.DDConstrained, constrain);
					}
				},

				_initProxy: function() {
					var instance = this;

					var proxy = instance.get('proxy');

					if (!!proxy) {
						if (!Lang.isObject(proxy)) {
							proxy = null;
						}

						instance.plug(A.Plugin.DDProxy, proxy);

						instance.get('dragNode').addClass(CSS_PROXY);
					}
				}
			}
		);

		A.Sortable = Sortable;
		A.SortableItem = SortableItem;
	},
	'0.1a',
	{
		requires: ['base', 'dd'],
		use: []
	}
);AUI().add(
	'state-interaction',
	function(A) {
		var Lang = A.Lang,
			isBoolean = Lang.isBoolean,
			isString = Lang.isString,

			getClassName = A.ClassNameManager.getClassName,

			STATE = 'state',

			CSS_STATE_DEFAULT = getClassName(STATE, 'default'),
			CSS_STATE_HOVER = getClassName(STATE, 'hover'),
			CSS_STATE_ACTIVE = getClassName(STATE, 'active');

		var StateInteractionPlugin = function(config) {
			var host = config.host;
			var node = host;

			if (A.Widget && host instanceof A.Widget) {
				node = host.get('contentBox');
			}

			config.node = node;

			StateInteractionPlugin.superclass.constructor.apply(this, arguments);
		};

		StateInteractionPlugin.NAME = 'stateinteraction';
		StateInteractionPlugin.NS = 'StateInteraction';

		StateInteractionPlugin.ATTRS = {
			active: {
				value: false
			},

			activeState: {
				value: true,
				validator: isBoolean
			},

			bubbleTarget: {
				value: null
			},

			classNames: {
				value: {}
			},

			'default': {
				value: false
			},

			defaultState: {
				value: true,
				validator: isBoolean
			},

			hover: {
				value: false
			},

			hoverState: {
				value: true,
				validator: isBoolean
			},

			node: {
				value: null
			}
		};

		A.extend(
			StateInteractionPlugin,
			A.Plugin.Base,
			{
				initializer: function() {
					var instance = this;

					var activeClass = instance.get('classNames.active');
					var defaultClass = instance.get('classNames.default');
					var hoverClass = instance.get('classNames.hover');

					instance._CSS_STATES = {
						active: isString(activeClass) ? activeClass : CSS_STATE_ACTIVE,
						'default': isString(defaultClass) ? defaultClass : CSS_STATE_DEFAULT,
						hover: isString(hoverClass) ? hoverClass : CSS_STATE_HOVER
					};

					if (instance.get('defaultState')) {
						instance.get('node').addClass(instance._CSS_STATES['default']);
					}

					instance._createEvents();

					instance._attachInteractionEvents();
				},

				_attachInteractionEvents: function() {
					var instance = this;

					var node = instance.get('node');

					node.on('click', instance._fireEvents, instance);

					node.on('mouseenter', A.rbind(instance._fireEvents, instance, 'mouseover'));
					node.on('mouseleave', A.rbind(instance._fireEvents, instance, 'mouseout'));

					instance.after('activeChange', instance._uiSetState);
					instance.after('hoverChange', instance._uiSetState);
					instance.after('defaultChange', instance._uiSetState);
				},

				_fireEvents: function(event, officialType) {
					var instance = this;

					var bubbleTarget = instance.get('bubbleTarget');

					officialType = officialType || event.type;

					if (bubbleTarget) {
						bubbleTarget.fire(officialType);
					}

					return instance.fire(officialType);
				},

				_createEvents: function() {
					var instance = this;

					var bubbleTarget = instance.get('bubbleTarget');

					if (bubbleTarget) {
						instance.addTarget(bubbleTarget);
					}

					instance.publish(
						'click',
						{
							defaultFn: instance._defClickFn,
							emitFacade: true
						}
					);

					instance.publish(
						'mouseout',
						{
							defaultFn: instance._defMouseOutFn,
							emitFacade: true
						}
					);

					instance.publish(
						'mouseover',
						{
							defaultFn: instance._defMouseOverFn,
							emitFacade: true
						}
					);
				},

				_defClickFn: function(event) {
					var instance = this;

					instance.set('active', !instance.get('active'));
				},

				_defMouseOutFn: function() {
					var instance = this;

					instance.set('hover', false);
				},

				_defMouseOverFn: function() {
					var instance = this;

					instance.set('hover', true);
				},

				_uiSetState: function(event) {
					var instance = this;

					var attrName = event.attrName;

					if (instance.get(attrName + 'State')) {
						var action = 'addClass';

						if (!event.newVal) {
							action = 'removeClass';
						}

						instance.get('node')[action](instance._CSS_STATES[attrName]);
					}
				}
			}
		);

		A.StateInteractionPlugin = StateInteractionPlugin;
	},
	'0.1a',
	{
		requires: ['aui-base', 'plugin']
	}
);AUI().add(
	'tabs',
	function(A) {
		var Lang = A.Lang,

			getClassName = A.ClassNameManager.getClassName,

			TAB = 'tab',
			TABVIEW = 'tabview',

			BOUNDING_BOX = 'boundingBox',
			CONTENT_BOX = 'contentBox',
			CONTENT_NODE = 'contentNode',

			CSS_TAB = getClassName(TAB),
			CSS_TAB_LABEL = getClassName(TAB, 'label'),
			CSS_TAB_DISABLED = getClassName(TAB, 'disabled'),
			CSS_TAB_ACTIVE = getClassName(TAB, 'active'),

			CSS_TABVIEW_LIST = [getClassName(TABVIEW, 'list'), getClassName('widget', 'hd')].join(' '),
			CSS_TABVIEW_CONTENT = [getClassName(TABVIEW, 'content'), getClassName('widget', 'bd')].join(' '),

			CSS_HIDDEN = getClassName('helper-hidden'),

			TPL_DIV = '<div></div>',
			TPL_SPAN = '<span></span>',
			TPL_UL = '<ul></ul>',

			TPL_LABEL = TPL_SPAN,
			TPL_TAB_CONTAINER = TPL_UL,
			TPL_CONTENT_ITEM = TPL_DIV,
			TPL_CONTENT_CONTAINER = TPL_DIV;

		var Tab = function() {
			Tab.superclass.constructor.apply(this, arguments);
		};

		Tab.NAME = TAB;

		Tab.ATTRS = {
			label: {
				lazyAdd: false,
				valueFn: function() {
					var instance = this;

					var boundingBox = instance.get(BOUNDING_BOX);

					var label = boundingBox.one('.' + CSS_TAB_LABEL);

					var value;

					if (label) {
						value = label.html();

						instance.set('labelNode', label);
					}
					else {
						value = boundingBox.html();
						boundingBox.html('');
					}

					return value;
				},

				setter: function(value) {
					var instance = this;

					var labelNode = instance.get('labelNode');

					labelNode.html(value);

					return value;
				}
			},

			labelNode: {
				valueFn: function() {
					var instance = this;

					var labelNode = instance.get(BOUNDING_BOX).one('.' + CSS_TAB_LABEL);

					if (!labelNode) {
						labelNode = instance._createDefaultLabel();
					}

					instance.get(CONTENT_BOX).appendChild(labelNode);

					return labelNode;
				},
				setter: function(value) {
					var instance = this;

					var node = A.Node.get(value);

					if (!node) {
						node = instance._createDefaultLabel();

						instance.get(CONTENT_BOX).appendChild(node);
					}

					node.addClass(CSS_TAB_LABEL);

					return node;
				}
			},

			contentNode: {
				value: null,
				setter: function(value) {
					var instance = this;

					var node = A.Node.get(value);

					if (!node) {
						node = instance._createDefaultContentEl();

						instance.get(CONTENT_BOX).prepend(node);
					}

					node.addClass(CSS_TABVIEW_CONTENT);

					var current = instance.get(CONTENT_NODE);

					if (current) {
						if (!instance.get('active')) {
							node.addClass(CSS_HIDDEN);
						}

						var currentHTML = node.html();

						instance.set('content', currentHTML);
					}

					return node;
				}
			},

			content: {
				lazyAdd: false,
				valueFn: function() {
					var instance = this;

					var value = '';
					var contentNode = instance.get(CONTENT_NODE);

					if (contentNode) {
						value = contentNode.html();
					}

					return value;
				},
				setter: function(value) {
					var instance = this;

					var node = instance.get(CONTENT_NODE);

					var currentHTML = node.html();

					if (currentHTML != value) {
						node.html(value);
					}

					return value;
				}
			},

			active: {
				valueFn: function() {
					var instance = this;

					return instance.get(BOUNDING_BOX).hasClass(CSS_TAB_ACTIVE);
				},
				validator: function(value) {
					var instance = this;

					return Lang.isBoolean(value) && !instance.get('disabled');
				},
				setter: function(value) {
					var instance = this;

					var action = 'addClass';
					var boundingBox = instance.get(BOUNDING_BOX);

					if (value === false) {
						action = 'removeClass';
					}

					instance.StateInteraction.set('active', value);

					boundingBox[action](CSS_TAB_ACTIVE);

					instance.set('contentVisible', value);

					return value;
				}
			},

			disabled: {
				valueFn: function() {
					var instance = this;

					return instance.get(BOUNDING_BOX).hasClass(CSS_TAB_DISABLED);
				},
				setter: function(value) {
					var instance = this;

					var action = 'addClass';
					var boundingBox = instance.get(BOUNDING_BOX);

					if (value === false) {
						action = 'removeClass';
					}

					boundingBox[action](CSS_TAB_DISABLED);

					return value;
				}
			},

			contentVisible: {
				value: false,
				setter: function(value) {
					var instance = this;

					var action = 'addClass';
					var contentNode = instance.get(CONTENT_NODE);

					if (value === true) {
						action = 'removeClass';
					}

					contentNode[action](CSS_HIDDEN);

					return value;
				}
			},

			tabView: {
				value: null
			}
		};

		A.extend(
			Tab,
			A.Component,
			{
				BOUNDING_TEMPLATE: '<li></li>',
				CONTENT_TEMPLATE: '<span></span>',
				bindUI: function() {
					var instance = this;

					var boundingBox = instance.get(BOUNDING_BOX);

					boundingBox.plug(
						A.StateInteractionPlugin,
						{
							bubbleTarget: instance
						}
					);

					boundingBox.StateInteraction.on('click', instance._onActivateTab, instance);

					instance.StateInteraction = boundingBox.StateInteraction;

					instance.get('labelNode').on('click', instance._onLabelClick, instance);
				},

				destructor: function() {
					var instance = this;

					var boundingBox = instance.get(BOUNDING_BOX);
					var contentNode = instance.get(CONTENT_NODE);

					A.Event.purgeElement(boundingBox, true);
					A.Event.purgeElement(contentNode, true);

					boundingBox.remove();
					contentNode.remove();
				},

				_createDefaultLabel: function() {
					var instance = this;

					return A.Node.create(TPL_LABEL);
				},

				_createDefaultContentEl: function() {
					var instance = this;

					return A.Node.create(TPL_CONTENT_ITEM);
				},

				_onActivateTab: function(event) {
					var instance = this;

					event.halt();

					var tabView = instance.get('tabView');

					tabView.set('activeTab', instance);
				},

				_onLabelClick: function(event) {
					event.preventDefault();
				}
			}
		);

		A.Tab = Tab;

		var TabView = function() {
			TabView.superclass.constructor.apply(this, arguments);
		};

		TabView.NAME = TABVIEW;

		TabView.ATTRS = {
			listNode: {
				value: null,
				setter: function(value) {
					var instance = this;

					var node = A.Node.get(value);

					if (!node) {
						node = instance._createDefaultList();
					}

					instance.get(CONTENT_BOX).prepend(node);

					node.addClass(CSS_TABVIEW_LIST);

					return node;
				}
			},

			contentNode: {
				value: null,
				setter: function(value) {
					var instance = this;

					var node = A.Node.get(value);

					if (!node) {
						node = instance._createDefaultContentContainer();
					}

					instance.get(CONTENT_BOX).appendChild(node);

					node.addClass(CSS_TABVIEW_CONTENT);

					return node;
				}
			},

			items: {
				value: []
			},

			activeTab: {
				value: null,
				setter: function(value) {
					var instance = this;

					var activeTab = instance.get('activeTab');

					if (activeTab && activeTab != value) {
						activeTab.set('active', false);
					}

					return value;
				},
				validator: function(value) {
					return Lang.isNull(value) || (value && !value.get('disabled'));
				}
			}
		};

		A.extend(
			TabView,
			A.Component,
			{
				renderUI: function() {
					var instance = this;

					instance.after('activeTabChange', instance._onActiveTabChange);

					instance._renderContentSections();
					instance._renderTabs();
				},

				addTab: function(tab, index) {
					var instance = this;

					var before = instance.getTab(index);

					var items = instance.get('items');

					if (Lang.isUndefined(index)) {
						index = A.Array.indexOf(items, tab);
					}

					var inArray = index > -1;

					if (!inArray) {
						index = items.length;

						items.splice(index, 0, tab);
					}

					if (!instance.get('rendered') && !inArray) {
						return;
					}

					if (!(tab instanceof Tab)) {
						tab = new Tab(tab);

						items.splice(index, 1, tab);
					}

					var listNode = instance.get('listNode');

					tab.render(listNode);

					if (before) {
						listNode.insert(tab.get(BOUNDING_BOX), before.get(BOUNDING_BOX));
					}
					else {
						listNode.appendChild(tab.get(BOUNDING_BOX));
					}

					var tabContentNode = tab.get(CONTENT_NODE);

					var tabViewContentNode = instance.get(CONTENT_NODE);

					if (!tabViewContentNode.contains(tabContentNode)) {
						tabViewContentNode.appendChild(tabContentNode);
					}

					if (tab.get('active')) {
						instance.set('activeTab', tab);
					}

					tab.set('tabView', instance);
				},

				deselectTab: function(index){
					var instance = this;

					if (instance.getTab(index) === instance.get('activeTab')) {
						instance.set('activeTab', null);
					}
				},

				disableTab: function(index){
					var instance = this;

					var tab;

					if (Lang.isNumber(index)) {
						tab = instance.getTab(index);
					}
					else {
						tab = index;
					}

					if (tab) {
						tab.set('disabled', true);
					}
				},

				enableTab: function(index){
					var instance = this;

					var tab;

					if (Lang.isNumber(index)) {
						tab = instance.getTab(index);
					}
					else {
						tab = index;
					}

					if (tab) {
						tab.set('disabled', false);
					}
				},

				getTab: function(index){
					var instance = this;

					return instance.get('items')[index];
				},

				getTabIndex: function(tab){
					var instance = this;

					var items = instance.get('items');

					return A.Array.indexOf(items, tab);
				},

				removeTab: function(index){
					var instance = this;

					var tab;

					if (Lang.isNumber(index)) {
						tab = instance.getTab(index);
					}
					else {
						tab = index;
					}

					if (tab) {
						var items = instance.get('items');

						var tabCount = items.length;

						if (tab === instance.get('activeTab')) {
							if (tabCount > 1) {
								if (index + 1 === tabCount) {
									instance.selectTab(index - 1);
								}
								else {
									instance.selectTab(index + 1);
								}
							}
							else {
								instance.set('activeTab', null);
							}
						}

						tab.destroy();

						items.splice(index, 1);
					}
				},

				selectTab: function(index){
					var instance = this;

					var selectedTab = instance.getTab(index);

					instance.set('activeTab', selectedTab);
				},

				_createDefaultList: function() {
					var instance = this;

					return A.Node.create(TPL_TAB_CONTAINER);
				},

				_createDefaultContentContainer: function() {
					var instance = this;

					return A.Node.create(TPL_CONTENT_CONTAINER);
				},

				_onActiveTabChange: function(event) {
					var instance = this;

					var oldTab = event.prevVal;
					var newTab = event.newVal;

					if (newTab) {
						newTab.set('active', true);
					}

					if (oldTab) {
						oldTab.set('active', false);
					}
				},

				_renderContentSections: function() {
					var instance = this;

					instance._renderSection('list');
					instance._renderSection('content');
				},

				_renderSection: function(section) {
					var instance = this;

					instance.get(section + 'Node');
				},

				_renderTabs: function() {
					var instance = this;

					var contentNode = instance.get(CONTENT_NODE);
					var listNode = instance.get('listNode');

					var tabs = listNode.get('children');
					var tabContent = contentNode.get('children');

					var items = instance.get('items');

					tabs.each(
						function(node, i, nodeList) {
							var config = {
								boundingBox: node,
								contentNode: tabContent.item(i)
							};

							items.splice(i, 0, config);
						}
					);

					var length = items.length;

					for (var i = 0; i < items.length; i++) {
						instance.addTab(items[i]);
					}

					if (!instance.get('activeTab')) {
						instance.selectTab(0);
					}
				}
			}
		);

		A.TabView = TabView;
	},
	'0.1a',
	{
		requires: ['widget', 'state-interaction'],
		use: []
	}
);AUI().add(
	'textarea',
	function(A) {
		var Lang = A.Lang,

			getClassName = A.ClassNameManager.getClassName,

			NAME = 'textarea',

			CSS_TEXTAREA = getClassName(NAME),
			CSS_HEIGHT_MONITOR = [
				getClassName(NAME, 'height', 'monitor'),
				getClassName('field', 'text', 'input'),
				getClassName('helper', 'hidden', 'accessible')
			].join(' '),

			DEFAULT_EMPTY_CONTENT = '&nbsp;&nbsp;',
			DEFAULT_APPEND_CONTENT = '&nbsp;\n&nbsp;',

			TPL_HEIGHT_MONITOR_OPEN = '<pre class="' + CSS_HEIGHT_MONITOR + '">',
			TPL_HEIGHT_MONITOR_CLOSE = '</pre>',
			TPL_INPUT = '<textarea autocomplete="off" class="{cssClass}" name="{name}"></textarea>';

		var Textarea = function() {
			Textarea.superclass.constructor.apply(this, arguments);
		};

		Textarea.NAME = NAME;

		var textareaPrototype = Textarea.prototype;

		Textarea.ATTRS = {
			autoSize: {
				value: true
			},

			height: {
				value: 'auto'
			},

			maxHeight: {
				value: 1000,
				setter: textareaPrototype._setAutoDimension
			},

			minHeight: {
				value: 45,
				setter: textareaPrototype._setAutoDimension
			},

			width: {
				value: 'auto',
				setter: textareaPrototype._setAutoDimension
			}
		};

		Textarea.HTML_PARSER = {
			node: 'textarea'
		};

		A.extend(
			Textarea,
			A.Textfield,
			{
				FIELD_TEMPLATE: TPL_INPUT,
				renderUI: function() {
					var instance = this;

					Textarea.superclass.renderUI.call(instance);

					if (instance.get('autoSize')) {
						instance._renderHeightMonitor();
					}
				},

				bindUI: function() {
					var instance = this;

					Textarea.superclass.bindUI.call(instance);

					if (instance.get('autoSize')) {
						instance.get('node').on('keyup', instance._onKeyup, instance);
					}

					instance.after('adjustSize', instance._uiAutoSize);

					instance.after('heightChange', instance._afterHeightChange);
					instance.after('widthChange', instance._afterWidthChange);
				},

				syncUI: function() {
					var instance = this;

					Textarea.superclass.syncUI.call(instance);

					instance._setAutoDimension(instance.get('minHeight'), 'minHeight');
					instance._setAutoDimension(instance.get('maxHeight'), 'maxHeight');

					var width = instance.get('width');
					var height = instance.get('minHeight');

					instance._setAutoDimension(width, 'width');

					instance._uiSetDim('height', height);
					instance._uiSetDim('width', width);
				},

				_afterHeightChange: function(event) {
					var instance = this;

					instance._uiSetDim('height', event.newVal, event.prevVal);
				},

				_afterWidthChange: function(event) {
					var instance = this;

					instance._uiSetDim('width', event.newVal, event.prevVal);
				},

				_onKeyup: function(event) {
					var instance = this;

					instance.fire('adjustSize');
				},

				_renderHeightMonitor: function() {
					var instance = this;

					var heightMonitor = A.Node.create(TPL_HEIGHT_MONITOR_OPEN + TPL_HEIGHT_MONITOR_CLOSE);
					var node = instance.get('node');

					A.getBody().append(heightMonitor);

					instance._heightMonitor = heightMonitor;

					var fontFamily = node.getComputedStyle('fontFamily');
					var fontSize = node.getComputedStyle('fontSize');
					var fontWeight = node.getComputedStyle('fontWeight');
					var lineHeight = node.getComputedStyle('fontSize');

					node.setStyle('height', instance.get('minHeight') + 'px');

					heightMonitor.setStyles(
						{
							fontFamily: fontFamily,
							fontSize: fontSize,
							fontWeight: fontWeight
						}
					);

					if ('outerHTML' in heightMonitor.getDOM()) {
						instance._updateContent = instance._updateOuterContent;
					}
					else {
						instance._updateContent = instance._updateInnerContent;
					}
				},

				_setAutoDimension: function(value, key) {
					var instance = this;

					instance['_' + key] = value;
				},

				_uiAutoSize: function() {
					var instance = this;

					var node = instance.get('node');
					var heightMonitor = instance._heightMonitor;

					var minHeight = instance._minHeight;
					var maxHeight = instance._maxHeight;

					var content = node.val();
					var textNode = document.createTextNode(content);

					heightMonitor.set('innerHTML', '');

					heightMonitor.appendChild(textNode);

					heightMonitor.setStyle('width', node.getComputedStyle('width'));

					content = heightMonitor.get('innerHTML');

					if (!content.length) {
						content = DEFAULT_EMPTY_CONTENT;
					}
					else {
						content += DEFAULT_APPEND_CONTENT;
					}

					instance._updateContent(content);

					var height = Math.max(heightMonitor.get('offsetHeight'), minHeight);

					height = Math.min(height, maxHeight);

					if (height != instance._lastHeight) {
						instance._lastHeight = height;

						instance._uiSetDim('height', height);
					}
				},

				_uiSetDim: function(key, newVal) {
					var instance = this;

					var node = instance.get('node');

					if (Lang.isNumber(newVal)) {
						newVal += 'px';
					}

					node.setStyle(key, newVal);
				},

				_updateInnerContent: function(content) {
					var instance = this;

					return instance._heightMonitor.set('innerHTML', content);
				},

				_updateOuterContent: function(content) {
					var instance = this;

					content = content.replace(/\n/g, '<br />');

					return instance._updateInnerContent(content);
				}
			}
		);

		A.Textarea = Textarea;
	},
	'0.1a',
	{
		requires: ['textfield'],
		use: []
	}
);
AUI().add(
	'textboxlist',
	function(A) {
		var Lang = A.Lang,

			getClassName = A.ClassNameManager.getClassName,

			ENTRY_NAME = 'textboxlistentry',
			NAME = 'textboxlist',

			BOUNDING_BOX = 'boundingBox',
			CONTENT_BOX = 'contentBox',

			CONFIG_ANIM = {
				from: {
					opacity: 1
				},
				to: {
					opacity: 0.3
				},
				duration: 0.1,
				on: {
					end: function(event) {
						var instance = this;

						var reverse = instance.get('reverse');

						if (!reverse) {
							instance.run();
						}

						instance.set('reverse', !reverse);
					}
				}
			},

			CSS_CLEARFIX = getClassName('helper', 'clearfix'),

			CSS_ICON = getClassName('icon'),
			CSS_ICON_CLOSE = getClassName('icon', 'close'),
			CSS_ICON_CLOSE_HOVER = getClassName(ENTRY_NAME, 'close', 'hover'),
			CSS_ENTRY_CLOSE = getClassName(ENTRY_NAME, 'close'),
			CSS_ENTRY_HOLDER = getClassName(ENTRY_NAME, 'holder'),
			CSS_ENTRY_TEXT = getClassName(ENTRY_NAME, 'text'),
			CSS_ENTRY_ITEM = getClassName(ENTRY_NAME, 'item'),

			CSS_INPUT_CONTAINER = getClassName(NAME, 'input','container'),

			KEY_BACKSPACE = 8,
			KEY_ENTER = 13,
			KEY_LEFT = 37,
			KEY_RIGHT = 39,

			TPL_ENTRY_CLOSE = '<span class="' + [CSS_ICON, CSS_ICON_CLOSE, CSS_ENTRY_CLOSE].join(' ') + '"></span>',
			TPL_ENTRY_TEXT = '<span class="' + CSS_ENTRY_TEXT + '"></span>',
			TPL_ENTRY_HOLDER = '<ul class="' + [CSS_CLEARFIX, CSS_ENTRY_HOLDER].join(' ') + '"></ul>',

			TPL_INPUT_CONTAINER = '<li tabindex="0" class="' + CSS_INPUT_CONTAINER + '"></li>';

		var TextboxList = function() {
			TextboxList.superclass.constructor.apply(this, arguments);
		};

		TextboxList.NAME = NAME;

		TextboxList.ATTRS = {
			allowAnyEntry: {
				value: false
			},
			delimChar: {
				value: ''
			}
		};

		A.extend(
			TextboxList,
			A.AutoComplete,
			{
				initializer: function(config) {
					var instance = this;

					var matchKey = instance.get('matchKey');

					instance.entries = new A.DataSet(
						{
							getKey: function(obj) {
								var instance = this;

								return obj[matchKey];
							}
						}
					);

					instance._lastSelectedEntry = -1;
				},

				renderUI: function() {
					var instance = this;

					instance._renderEntryHolder();

					TextboxList.superclass.renderUI.apply(instance, arguments);
				},

				bindUI: function() {
					var instance = this;

					TextboxList.superclass.bindUI.apply(instance, arguments);

					instance.after('itemSelect', instance._afterItemSelect);
					instance.after('focusedChange', instance._afterTBLFocusedChange);
					instance.after('textboxlistentry:focusedChange', instance._afterTBLFocusedChange);

					var entries = instance.entries;
					var entryHolder = instance.entryHolder;
					var closeSelector = '.' + CSS_ICON_CLOSE;

					entries.on('add', instance._updateEntryHolder, instance);
					entries.on('replace', instance._updateEntryHolder, instance);
					entries.on('remove', instance._updateEntryHolder, instance);

					entryHolder.delegate('click', A.bind(instance._removeItem, instance), closeSelector);
					entryHolder.delegate('mouseenter', A.bind(instance._onCloseIconMouseOver, instance), closeSelector);
					entryHolder.delegate('mouseleave', A.bind(instance._onCloseIconMouseOut, instance), closeSelector);

					A.on(
						'key',
						instance._onTBLKeypress,
						instance.get(BOUNDING_BOX),
						'down:39,40,37,38,8,13',
						instance
					);

					instance.inputNode.on('focus', instance._onInputNodeFocus, instance);
				},

				add: function(label) {
					var instance = this;

					var entry = instance._prepareEntry(label);

					instance.entries.add(entry);
				},

				insert: function(index, label) {
					var instance = this;

					var entry = instance._prepareEntry(label);

					return instance.entries.insert(index, entry);
				},

				remove: function(label) {
					var instance = this;

					return instance.entries.removeKey(label);
				},

				_afterItemSelect: function(elListItem) {
					var instance = this;

					instance.entries.add(elListItem._resultData);

				},

				_afterTBLFocusedChange: function(event) {
					var instance = this;

					if (event.type.indexOf('textboxlistentry') > -1) {
						if (event.newVal) {
							var entryBoundingBox = event.target.get(BOUNDING_BOX);

							instance._lastSelectedEntry = instance.entryHolder.all('li').indexOf(entryBoundingBox);
						}
					}
					else if (event.newVal && instance._lastSelectedEntry == -1) {
						instance.inputNode.focus();
					}
				},

				_onCloseIconMouseOut: function(event) {
					var instance = this;

					event.currentTarget.removeClass(CSS_ICON_CLOSE_HOVER);
				},

				_onCloseIconMouseOver: function(event) {
					var instance = this;

					event.currentTarget.addClass(CSS_ICON_CLOSE_HOVER);
				},

				_onInputNodeFocus: function(event) {
					var instance = this;

					instance._lastSelectedEntry = -1;
				},

				_onTBLKeypress: function(event) {
					var instance = this;

					var keyCode = event.keyCode;
					var inputNode = instance.inputNode;

					if (!inputNode.val()) {
						var lastSelectedEntry = instance._lastSelectedEntry;
						var currentSelectedEntry = -1;

						var unselected = (lastSelectedEntry == -1);

						var deleteEntry = (keyCode == KEY_BACKSPACE);
						var deleteBack = (deleteEntry && unselected);
						var moveBack = keyCode == KEY_LEFT || deleteBack;
						var moveForward = (keyCode == KEY_RIGHT);

						var entries = instance.entries;

						var entriesSize = entries.size();
						var lastEntryIndex = entriesSize - 1;

						if (moveBack) {
							if (unselected) {
								currentSelectedEntry = lastEntryIndex;
							}
							else if (lastSelectedEntry == 0) {
								currentSelectedEntry = lastSelectedEntry;
							}
							else {
								currentSelectedEntry = lastSelectedEntry - 1;
							}
						}
						else if (moveForward) {
							if (unselected || (lastSelectedEntry == lastEntryIndex)) {
								currentSelectedEntry = -1;
							}
							else {
								currentSelectedEntry = lastSelectedEntry + 1;
							}
						}
						else if (deleteEntry) {
							entries.removeAt(lastSelectedEntry);

							entriesSize = entries.size();

							if (lastSelectedEntry == entriesSize) {
								currentSelectedEntry = -1;
							}
							else {
								currentSelectedEntry = lastSelectedEntry;
							}
						}

						if (deleteBack || deleteEntry) {
							event.halt();
						}

						if (currentSelectedEntry != -1) {
							entries.item(currentSelectedEntry).entry.focus();
						}
						else {
							inputNode.focus();
						}

						instance._lastSelectedEntry = currentSelectedEntry;
					}
					else {
						if (keyCode == KEY_ENTER && instance.get('allowAnyEntry')) {
							instance.entries.add(inputNode.val(), {});
						}
					}
				},

				_onTextboxKeyPress: function(event) {
					var instance = this;

					TextboxList.superclass._onTextboxKeyPress.apply(instance, arguments);

					if (event.keyCode == KEY_ENTER) {
						event.halt();
					}
				},

				_prepareEntry: function(label) {
					var instance = this;

					var entry = {};
					var matchKey = instance.get('matchKey');

					entry[matchKey] = label;

					return entry;
				},

				_removeItem: function(event) {
					var instance = this;

					var entry = A.Widget.getByNode(event.currentTarget);

					entry = entry.get(BOUNDING_BOX);

					var currentIndex = instance.entryHolder.all('li').indexOf(entry);

					instance.entries.removeAt(currentIndex);
				},

				_renderEntryHolder: function() {
					var instance = this;

					var contentBox = instance.get(CONTENT_BOX);
					var entryHolder = A.Node.create(TPL_ENTRY_HOLDER);

					contentBox.prepend(entryHolder);

					instance.entryHolder = entryHolder;
				},

				_renderInput: function() {
					var instance = this;

					var contentBox = instance.get(CONTENT_BOX);
					var input = instance.get('input');

					var fieldConfig = {
						labelText: false
					};

					var inputParent = null;

					if (input) {
						input = A.get(input);

						fieldConfig.node = input;

						inputParent = input.get('parentNode');
					}

					var inputContainer = A.Node.create(TPL_INPUT_CONTAINER);

					instance.entryHolder.append(inputContainer);

					var inputField = new A.Textfield(fieldConfig).render(inputContainer);
					var inputBoundingBox = inputField.get(BOUNDING_BOX);

					if (inputBoundingBox.get('parentNode') != inputContainer) {
						inputContainer.appendChild(inputBoundingBox);
					}

					instance.inputContainer = inputContainer;
					instance.inputField = inputField;
					instance.inputNode = inputField.get('node');
					instance.button = new A.ToolItem();

					instance.set('uniqueName', A.stamp(instance.inputNode));
				},

				_updateEntryHolder: function(event) {
					var instance = this;

					var eventType = event.type;
					var inputNode = instance.inputNode;
					var entryHolder = instance.entryHolder;
					var item = event.item;
					var index = event.index;

					var matchKey = instance.get('matchKey');

					var key = item[matchKey] || event.attrName;

					if (key) {
						if (eventType == 'dataset:add') {
							var entry = new TextboxListEntry(
								{
									labelText: key
								}
							);

							entry.addTarget(instance);

							var entryNode = entry.get(BOUNDING_BOX);

							entry.render(entryHolder);

							entryHolder.all('li').item(index).placeBefore(entryNode);

							entryNode.plug(A.Plugin.NodeFX, CONFIG_ANIM);

							item.entry = entry;

							inputNode.val('');
						}
						else if (eventType == 'dataset:replace') {
							inputNode.val('');

							var entry = event.prevVal.entry;

							item.entry = entry;

							entry.get(BOUNDING_BOX).fx.run();
						}
						else if (eventType == 'dataset:remove') {
							var entryNodes = entryHolder.all('li');

							if (entryNodes) {
								entryNodes.item(index).remove();
							}
						}
					}
					else {
						instance.entries.removeAt(index);
					}
				}
			}
		);

		var TextboxListEntry = function() {
			TextboxListEntry.superclass.constructor.apply(this, arguments);
		};

		TextboxListEntry.NAME = ENTRY_NAME;

		TextboxListEntry.ATTRS = {
			labelText: {
				value: ''
			}
		};

		A.extend(
			TextboxListEntry,
			A.Widget,
			{
				BOUNDING_TEMPLATE: '<li></li>',
				CONTENT_TEMPLATE: '<span></span>',
				renderUI: function() {
					var instance = this;

					var contentBox = instance.get(CONTENT_BOX);

					var text = A.Node.create(TPL_ENTRY_TEXT);
					var close = A.Node.create(TPL_ENTRY_CLOSE);

					var labelText = instance.get('labelText');

					text.set('innerHTML', labelText);

					contentBox.appendChild(text);
					contentBox.appendChild(close);
				}
			}
		);

		A.TextboxList = TextboxList;
		A.TextboxListEntry = TextboxListEntry;
	},
	'0.1a',
	{
		requires: ['aui-base', 'autocomplete', 'anim-node-plugin', 'node-focusmanager'],
		use: []
	}
);AUI().add(
	'textfield',
	function(A) {
		var Lang = A.Lang,

			getClassName = A.ClassNameManager.getClassName,

			NAME = 'textfield',

			CSS_TEXTFIELD = getClassName(NAME);

		var Textfield = function() {
			Textfield.superclass.constructor.apply(this, arguments);
		};

		Textfield.NAME = NAME;

		Textfield.ATTRS = {
			selectOnFocus: {
				value: false
			},

			allowOnly: {
				value: null,
				validator: function(value) {
					var instance = this;

					return value instanceof RegExp;
				}
			},

			defaultValue: {
				value: ''
			},

			validator: {
				value: null
			}
		};

		A.extend(
			Textfield,
			A.Field,
			{
				bindUI: function() {
					var instance = this;

					Textfield.superclass.bindUI.call(instance);

					var node = instance.get('node');

					if (instance.get('allowOnly')) {
						node.on('keypress', instance._filterInputText, instance);
					}

					if (instance.get('selectOnFocus')) {
						node.on('focus', instance._selectInputText, instance);
					}

					var defaultValue = instance.get('defaultValue');

					if (defaultValue) {
						node.on('blur', instance._checkDefaultValue, instance);
						node.on('focus', instance._checkDefaultValue, instance);
					}
				},

				syncUI: function() {
					var instance = this;

					var currentValue = instance.get('value');

					if (!currentValue) {
						var defaultValue = instance.get('defaultValue');

						instance.set('value', instance.get('defaultValue'));
					}

					Textfield.superclass.syncUI.apply(instance, arguments);
				},

				_filterInputText: function(event) {
					var instance = this;

					var allowOnly = instance.get('allowOnly');

					var inputChar = String.fromCharCode(event.charCode);

					if (!allowOnly.test(inputChar)) {
						event.halt();
					}
				},

				_checkDefaultValue: function(event) {
					var instance = this;

					var defaultValue = instance.get('defaultValue');
					var node = instance.get('node');
					var currentValue = Lang.trim(instance.get('value'));
					var eventType = event.type;

					var focus = (eventType == 'focus' || eventType == 'focusin');

					if (defaultValue) {
						var value = currentValue;

						if (focus && (currentValue == defaultValue)) {
							value = '';
						}
						else if (!focus && !currentValue) {
							value = defaultValue;
						}

						instance.set('value', value);
					}
				},

				_selectInputText: function(event) {
					var instance = this;

					event.currentTarget.select();
				}
			}
		);

		A.Textfield = Textfield;
	},
	'0.1a',
	{
		requires: ['field'],
		use: []
	}
);AUI().add(
	'tool-item',
	function(A) {
		var Lang = A.Lang,
			isString = Lang.isString,
			isFunction = Lang.isFunction,
			isObject = Lang.isObject,

			getClassName = A.ClassNameManager.getClassName,

			TOOL = 'tool',
			ICON = 'icon',
			STATE = 'state',

			CSS_TOOL = getClassName(TOOL),
			CSS_ICON = getClassName(ICON),

			TPL_GENERIC = '<span></span>',
			TPL_ICON = TPL_GENERIC,
			TPL_TOOL = TPL_GENERIC;

		var ToolItem = function(config) {
			if (isString(config)) {
				config = {
					icon: config
				};
			}

			ToolItem.superclass.constructor.apply(this, arguments);
		};

		ToolItem.NAME = 'tool-item';

		ToolItem.ATTRS = {
			classNames: {},

			activeState: {
				value: false
			},

			defaultState: {},

			handler: {
				lazyAdd: false,
				value: null,
				setter: function(value) {
					var instance = this;

					var fn = value;
					var context = instance;
					var args = instance;
					var type = 'click';

					if (isObject(fn)) {
						var handlerConfig = fn;

						fn = handlerConfig.fn || fn;
						context = handlerConfig.context || context;
						type = handlerConfig.type || type;
					}

					if (isFunction(fn)) {
						instance.on(type, A.rbind(fn, context, args, handlerConfig.args));
					}

					return value;
				}
			},

			hoverState: {},

			iconNode: {
				valueFn: function() {
					var instance = this;

					return A.Node.create(TPL_ICON);
				}
			},

			icon: {
				lazyAdd: false,
				setter: function(value) {
					var instance = this;

					instance._uiSetIcon(value);

					return value;
				}
			},

			id: {
				valueFn: function() {
					return A.guid();
				}
			},

			renderTo: {
				value: null
			}
		};

		A.extend(
			ToolItem,
			A.Component,
			{
				BOUNDING_TEMPLATE: TPL_GENERIC,
				CONTENT_TEMPLATE: TPL_GENERIC,

				initializer: function() {
					var instance = this;

					var renderTo = instance.get('renderTo');

					if (renderTo) {
						instance.render(renderTo);
					}
				},

				renderUI: function() {
					var instance = this;

					var contentBox = instance.get('contentBox');
					var iconNode = instance.get('iconNode');

					contentBox.addClass(CSS_TOOL);

					iconNode.addClass(CSS_ICON);

					instance.plug(
						A.StateInteractionPlugin,
						{
							activeState: instance.get('activeState'),
							classNames: instance.get('classNames'),
							defaultState: instance.get('defaultState'),
							hoverState: instance.get('hoverState'),
							bubbleTarget: instance
						}
					);

					contentBox.appendChild(iconNode);
				},

				bindUI: function() {
					var instance = this;

					instance.after('iconChange', instance._afterIconChange);
				},

				destroy: function() {
					var instance = this;
					var boundingBox = instance.get('boundingBox');

					boundingBox.remove();
				},

				_afterIconChange: function(event) {
					var instance = this;

					instance._uiSetIcon(event.newVal, event.prevVal);
				},

				_uiSetIcon: function(newVal, prevVal) {
					var instance = this;

					var contentBox = instance.get('iconNode');

					newVal = getClassName(ICON, newVal);

					if (prevVal) {
						prevVal = getClassName(ICON, prevVal);
					}

					contentBox.replaceClass(prevVal, newVal);
				}
			}
		);

		A.ToolItem = ToolItem;
	},
	'0.1a',
	{
		requires: ['aui-base', 'state-interaction'],
		use: []
	}
);
AUI().add(
	'tool-set',
	function(A) {
		var Lang = A.Lang,
			isArray = Lang.isArray,
			isNumber = Lang.isNumber,
			isString = Lang.isString,

			isToolItem = function(item) {
				return (item instanceof A.ToolItem);
			},

			getClassName = A.ClassNameManager.getClassName,

			NAME = 'toolset',

			CSS_FIRST = getClassName(NAME, 'first'),
			CSS_ITEM = getClassName(NAME, 'item'),
			CSS_ITEM_CONTENT = getClassName(NAME, 'item', 'content'),
			CSS_LAST = getClassName(NAME, 'last'),
			CSS_TOOLSET = getClassName(NAME),

			TPL_GENERIC = '<span></span>';

		var ToolSet = function() {
			ToolSet.superclass.constructor.apply(this, arguments);
		};

		ToolSet.NAME = NAME;

		ToolSet.ATTRS = {
			activeState: {},
			defaultState: {},
			hoverState: {},

			tools: {
				value: [],
				validator: isArray
			}
		};

		A.extend(
			ToolSet,
			A.Component,
			{
				BOUNDING_TEMPLATE: TPL_GENERIC,
				CONTENT_TEMPLATE: TPL_GENERIC,

				/*
				* Lifecycle
				*/
				initializer: function() {
					var instance = this;

					instance.tools = new A.DataSet();

					instance.tools.on('add', instance._afterAddToolItem, instance);
					instance.tools.on('remove', instance._afterRemoveToolItem, instance);
				},

				renderUI: function() {
					var instance = this;
					var toolItems = instance.get('tools');

					A.each(toolItems, function(item, i) {
						instance.add(item);
					});
				},

				syncUI: function() {
					var instance = this;
					var toolItems = instance.get('tools');
					var toolSet = instance.tools;
					var length = toolSet.size() - 1;

					// loop all items applying the CSS_FIRST and
					// CSS_LAST class names on the correct elements
					toolSet.each(function(item, index) {
						var itemBoundingBox = item.get('boundingBox');

						itemBoundingBox.removeClass(CSS_FIRST);
						itemBoundingBox.removeClass(CSS_LAST);

						if (index == 0) {
							itemBoundingBox.addClass(CSS_FIRST);
						}

						if (index == length) {
							itemBoundingBox.addClass(CSS_LAST);
						}
					});
				},

				/*
				* Methods
				*/
				add: function(toolItem) {
					var instance = this;
					var toolSet = instance.tools;

					// fix the toolItem argument the user passed, supports plain object, ToolItem and String
					// NOTE: if ToolItem passed as argument it will return the same instance
					toolItem = instance._createToolItem(toolItem);

					if (!toolSet.contains(toolItem)) {
						toolSet.add(toolItem);
					}
				},

				item: function(key) {
					var instance = this;

					return instance.tools.item(key);
				},

				remove: function(item) {
					var instance = this;
					var toolSet = instance.tools;

					if (isNumber(item)) {
						toolSet.removeAt(item);
					}
					if (isString(item)) {
						toolSet.removeKey(item);
					}
					else {
						toolSet.remove(item);
					}
				},

				_createToolItem: function(item) {
					var instance = this;
					var toolItem = null;

					// check if is needed to instantiate a new ToolItem
					if (isToolItem(item)) {
						toolItem = item;
					}
					else {
						var defaultToolConfig = {
							activeState: instance.get('activeState'),
							defaultState: instance.get('defaultState'),
							hoverState: instance.get('hoverState')
						};

						if (isString(item)) {
							item = {
								icon: item
							};
						}

						A.mix(item, defaultToolConfig);

						toolItem = new A.ToolItem(item);
					}

					var itemBoundingBox = toolItem.get('boundingBox');
					var itemContentBox = toolItem.get('contentBox');

					itemBoundingBox.addClass(CSS_ITEM);
					itemContentBox.addClass(CSS_ITEM_CONTENT);

					return toolItem;
				},

				/*
				* Listeners
				*/
				_afterAddToolItem: function(event) {
					var instance = this;
					var toolItem = event.item;
					var contentBox = instance.get('contentBox');

					if (isToolItem(toolItem)) {
						toolItem.render(contentBox);
					}

					instance.syncUI();
				},

				_afterRemoveToolItem: function(event) {
					var instance = this;
					var toolItem = event.item;
					var contentBox = instance.get('contentBox');

					if (isToolItem(toolItem)) {
						toolItem.destroy();
					}

					instance.syncUI();
				}
			}
		);

		A.ToolSet = ToolSet;
	},
	'0.1a',
	{
		requires: ['data-set', 'tool-item'],
		use: []
	}
);AUI.add('tooltip', function(A) {

var L = A.Lang,
	isString = L.isString,
	isUndefined = L.isUndefined,
	isBoolean = L.isBoolean,

	BL = 'bl',
	TR = 'tr',
	BLANK = '',
	ATTR = 'attr',
	TITLE = 'title',
	CURRENT_NODE = 'currentNode',
	SECTION = 'section',
	TRIGGER = 'trigger',
	BODY_CONTENT = 'bodyContent',
	TOOLTIP = 'tooltip';

function Tooltip(config) {
	Tooltip.superclass.constructor.apply(this, arguments);
}

A.mix(Tooltip, {
	NAME: TOOLTIP,

	ATTRS: {
		anim: {
			value: {
				show: false
			}
		},

		align: {
			value: { node: null, points: [ BL, TR ] }
		},

		showOn: {
			value: 'mouseover'
		},

		hideOn: {
			value: 'mouseout'
		},

		hideDelay: {
			value: 500
		},

		title: {
			value: false,
			validador: isBoolean
		}
	}
});

A.extend(Tooltip, A.ContextPanel, {
	/*
	* Lifecycle
	*/
	bindUI: function() {
		var instance = this;

		Tooltip.superclass.bindUI.apply(instance, arguments);
	},

	/*
	* Methods
	*/
	show: function() {
		var instance = this;
		var bodyContent = instance.get(BODY_CONTENT);

		Tooltip.superclass.show.apply(instance, arguments);

		if (instance.get(TITLE)) {
			instance._loadBodyContentFromTitle( instance.get(CURRENT_NODE) );
		}
	},

	_loadBodyContentFromTitle: function(currentNode) {
		var instance = this;
		var trigger = instance.get(TRIGGER);

		if (!instance._titles) {
			instance._titles = trigger.attr(TITLE);

			// prevent default browser tooltip for title
			trigger.attr(TITLE, BLANK);
		}

		if (currentNode) {
			var index = trigger.indexOf(currentNode);
			var title = instance._titles[index];

			instance.set(BODY_CONTENT, title);
		}
	},

	/*
	* Listeners
	*/
	_afterBodyChange: function(e) {
		var instance = this;

		Tooltip.superclass._afterBodyChange.apply(this, arguments);

		// need to refreshAlign() after body change
		instance.refreshAlign();
	}
});

A.Tooltip = Tooltip;

}, '0.1a', { requires: [ 'context-panel' ] });AUI.add('tree-data', function(A) {

var L = A.Lang,
	isArray = L.isArray,
	isObject = L.isObject,
	isString = L.isString,
	isUndefined = L.isUndefined,

	AFTER = 'after',
	APPEND = 'append',
	BEFORE = 'before',
	BOUNDING_BOX = 'boundingBox',
	CHILDREN = 'children',
	CONTAINER = 'container',
	DOT = '.',
	ID = 'id',
	INDEX = 'index',
	NEXT_SIBLING = 'nextSibling',
	NODE = 'node',
	OWNER_TREE = 'ownerTree',
	PARENT_NODE = 'parentNode',
	PREV_SIBLING = 'prevSibling',
	PREVIOUS_SIBLING = 'previousSibling',
	TREE = 'tree',
	TREE_DATA = 'tree-data',

	nodeSetter = function(v) {
		return A.get(v);
	},

	isTreeNode = function(v) {
		return ( v instanceof A.TreeNode );
	},

	getCN = A.ClassNameManager.getClassName,

	CSS_TREE_NODE = getCN(TREE, NODE);

/*
* AUI TreeData
*
* Contains the logic to handle the data of the tree.
* Basic DOM methods (append/remove/insert) and
* indexing management for the children.
*/
function TreeData(config) {
	TreeData.superclass.constructor.apply(this, arguments);
}

A.mix(TreeData, {
	NAME: TREE_DATA,

	ATTRS: {
		container: {
			setter: nodeSetter
		},

		// childNodes
		children: {
			value: [],
			validador: isArray,
			setter: function(v) {
				return this._setChildren(v);
			}
		},

		index: {
			value: {}
		}
	}
});

A.extend(TreeData, A.Widget, {
	/*
	* Lifecycle
	*/
	initializer: function() {
		var instance = this;

		// binding on initializer, needed before .render() phase
		instance.publish('move');
		instance.publish('collapseAll', { defaultFn: instance._collapseAll });
		instance.publish('expandAll', { defaultFn: instance._expandAll });
		instance.publish('append', { defaultFn: instance._appendChild });
		instance.publish('remove', { defaultFn: instance._removeChild });

		TreeData.superclass.initializer.apply(this, arguments);
	},

	/*
	* Index methods
	*/
	getNodeById: function(uid) {
		var instance = this;

		return instance.get(INDEX)[uid];
	},

	isRegistered: function(node) {
		var instance = this;

		return !!(instance.get(INDEX)[ node.get(ID) ]);
	},

	updateReferences: function(node, parentNode, ownerTree) {
		var instance = this;
		var oldParent = node.get(PARENT_NODE);
		var oldOwnerTree = node.get(OWNER_TREE);
		var moved = oldParent && (oldParent != parentNode);

		if (oldParent) {

			if (moved) {
				// when moved update the oldParent children
				var children = oldParent.get(CHILDREN);

				A.Array.removeItem(children, instance);

				oldParent.set(CHILDREN, children);
			}

			oldParent.unregisterNode(node);
		}

		if (oldOwnerTree) {
			oldOwnerTree.unregisterNode(node);
		}

		// update parent reference when registered
		node.set(PARENT_NODE, parentNode);

		// update the ownerTree of the node
		node.set(OWNER_TREE, ownerTree);

		if (parentNode) {
			// register the new node on the parentNode index
			parentNode.registerNode(node);
		}

		if (ownerTree) {
			// register the new node to the ownerTree index
			ownerTree.registerNode(node);
		}

		if (oldOwnerTree != ownerTree) {
			// when change the OWNER_TREE update the children references also
			node.eachChildren(function(child) {
				instance.updateReferences(child, child.get(PARENT_NODE), ownerTree);
			});
		}

		// trigger move event
		if (moved) {
			var output = instance.getEventOutputMap(node);

			output.tree.oldParent = oldParent;
			output.tree.oldOwnerTree = oldOwnerTree;

			instance.bubbleEvent('move', output);
		}
	},

	refreshIndex: function() {
		var instance = this;

		// reset index
		instance.updateIndex({});

		// get all descendent children - deep
		instance.eachChildren(function(node) {
			instance.registerNode(node);
		}, true);
	},

	registerNode: function(node) {
		var instance = this;
		var uid = node.get(ID);
		var index = instance.get(INDEX);

		if (uid) {
			index[uid] = node;
		}

		instance.updateIndex(index);
	},

	updateIndex: function(index) {
		var instance = this;

		if (index) {
			instance.set(INDEX, index);
		}
	},

	unregisterNode: function(node) {
		var instance = this;
		var index = instance.get(INDEX);

		delete index[ node.get(ID) ];

		instance.updateIndex(index);
	},

	/*
	* Methods
	*/
	collapseAll: function() {
		var instance = this;
		var output = instance.getEventOutputMap(instance);

		instance.fire('collapseAll', output);
	},

	_collapseAll: function(event) {
		var instance = this;

		instance.eachChildren(function(node) {
			node.collapse();
		}, true);
	},

	expandAll: function() {
		var instance = this;
		var output = instance.getEventOutputMap(instance);

		instance.fire('expandAll', output);
	},

	_expandAll: function(event) {
		var instance = this;

		instance.eachChildren(function(node) {
			node.expand();
		}, true);
	},

	selectAll: function() {
		var instance = this;

		instance.eachChildren(function(child) {
			child.select();
		}, true);
	},

	unselectAll: function() {
		var instance = this;

		instance.eachChildren(function(child) {
			child.unselect();
		}, true);
	},

	eachChildren: function(fn, deep) {
		var instance = this;
		var children = instance.getChildren(deep);

		A.Array.each(children, function(node) {
			if (node) {
				fn.apply(instance, arguments);
			}
		});
	},

	eachParent: function(fn) {
		var instance = this;
		var parentNode = instance.get(PARENT_NODE);

		while (parentNode) {
			if (parentNode) {
				fn.apply(instance, [parentNode]);
			}
			parentNode = parentNode.get(PARENT_NODE);
		}
	},

	bubbleEvent: function(eventType, args, cancelBubbling, stopActionPropagation) {
		var instance = this;

		// event.stopActionPropagation == undefined, invoke the event native action
		instance.fire(eventType, args);

		if (!cancelBubbling) {
			var parentNode = instance.get(PARENT_NODE);

			// Avoid execution of the native action (private methods) while propagate
			// for example: private _appendChild() is invoked only on the first level of the bubbling
			// the intention is only invoke the user callback on parent nodes.
			args = args || {};

			if (isUndefined(stopActionPropagation)) {
				stopActionPropagation = true;
			}

			args.stopActionPropagation = stopActionPropagation;

			while(parentNode) {
				parentNode.fire(eventType, args);
				parentNode = parentNode.get(PARENT_NODE)
			}
		}
	},

	createNode: function(options) {
		var instance = this;
		var classType = options.type;

		if (isString(classType) && A.TreeNode.nodeTypes) {
			classType = A.TreeNode.nodeTypes[classType];
		}

		if (!classType) {
			classType = A.TreeNode;
		}

		return new classType(options);
	},

	appendChild: function(node, cancelBubbling) {
		var instance = this;
		var output = instance.getEventOutputMap(node);

		instance.bubbleEvent('append', output, cancelBubbling);
	},

	_appendChild: function(event) {
		// stopActionPropagation while bubbling
		if (event.stopActionPropagation) {
			return false;
		}

		var instance = this;
		var node = event.tree.node;
		var ownerTree = instance.get(OWNER_TREE);
		var children = instance.get(CHILDREN);

		// updateReferences first
		instance.updateReferences(node, instance, ownerTree);
		// and then set the children, to have the appendChild propagation
		// the PARENT_NODE references should be updated
		var length = children.push(node);
		instance.set(CHILDREN, children);

		// updating prev/nextSibling attributes
		var prevIndex = length - 2;
		var prevSibling = instance.item(prevIndex);

		node.set(NEXT_SIBLING, null);
		node.set(PREV_SIBLING, prevSibling);

		instance.get(CONTAINER).append(
			node.get(BOUNDING_BOX)
		);

		// render node after it's appended
		node.render();
	},

	item: function(index) {
		var instance = this;

		return instance.get(CHILDREN)[index];
	},

	indexOf: function(node) {
		var instance = this;

		return A.Array.indexOf( instance.get(CHILDREN), node );
	},

	hasChildNodes: function() {
		return ( this.get(CHILDREN).length > 0 );
	},

	getChildren: function(deep) {
		var instance = this;
		var cNodes = [];
		var children = instance.get(CHILDREN);

		cNodes = cNodes.concat(children);

		if (deep) {
			instance.eachChildren(function(child) {
				cNodes = cNodes.concat( child.getChildren(deep) );
			});
		}

		return cNodes;
	},

	getEventOutputMap: function(node) {
		var instance = this;

		return {
			tree: {
				instance: instance,
				node: node || instance
			}
		};
	},

	removeChild: function(node) {
		var instance = this;
		var output = instance.getEventOutputMap(node);

		instance.bubbleEvent('remove', output);
	},

	_removeChild: function(event) {
		// stopActionPropagation while bubbling
		if (event.stopActionPropagation) {
			return false;
		}

		var instance = this;
		var node = event.tree.node;
		var ownerTree = instance.get(OWNER_TREE);

		if (instance.isRegistered(node)) {
			// update parent reference when removed
			node.set(PARENT_NODE, null);

			// unregister the node
			instance.unregisterNode(node);

			// no parent, no ownerTree
			node.set(OWNER_TREE, null);

			if (ownerTree) {
				// unregister the removed node from the tree index
				ownerTree.unregisterNode(node);
			}

			// remove child from the container
			node.get(BOUNDING_BOX).remove();

			var children = instance.get(CHILDREN);

			A.Array.removeItem(children, node);
			instance.set(CHILDREN, children);
		}
	},

	empty: function() {
		var instance = this;

		instance.eachChildren(function(node) {
			var parentNode = node.get(PARENT_NODE);

			if (parentNode) {
				parentNode.removeChild(node);
			}
		});
	},

	insert: function(treeNode, refTreeNode, where) {
		var instance = this;
		refTreeNode = refTreeNode || this;

		if (refTreeNode == treeNode) {
			return false; // NOTE: return
		}
		var refParentTreeNode = refTreeNode.get(PARENT_NODE);

		if (treeNode && refParentTreeNode) {
			var nodeBoundinBox = treeNode.get(BOUNDING_BOX);
			var refBoundinBox = refTreeNode.get(BOUNDING_BOX);
			var ownerTree = refTreeNode.get(OWNER_TREE);

			if (where == 'before') {
				refBoundinBox.placeBefore(nodeBoundinBox);
			}
			else if (where == 'after') {
				refBoundinBox.placeAfter(nodeBoundinBox);
			}

			var refSiblings = [];
			// using the YUI selector to regenerate the index based on the real dom
			// this avoid misscalculations on the nodes index number
			var DOMChildren = refParentTreeNode.get(BOUNDING_BOX).all('> ul > li');

			DOMChildren.each(function(child) {
				refSiblings.push( A.Widget.getByNode(child) );
			});

			// updating prev/nextSibling attributes
			treeNode.set(
				NEXT_SIBLING,
				A.Widget.getByNode( nodeBoundinBox.get(NEXT_SIBLING) )
			);
			treeNode.set(
				PREV_SIBLING,
				A.Widget.getByNode( nodeBoundinBox.get(PREVIOUS_SIBLING) )
			);

			// update all references
			refTreeNode.updateReferences(treeNode, refParentTreeNode, ownerTree);

			// updating refParentTreeNode childTreeNodes
			refParentTreeNode.set(CHILDREN, refSiblings);
		}

		// render treeNode after it's inserted
		treeNode.render();

		// invoking insert event
		var output = refTreeNode.getEventOutputMap(treeNode);

		output.tree.refTreeNode = refTreeNode;

		refTreeNode.bubbleEvent('insert', output);
	},

	insertAfter: function(treeNode, refTreeNode) {
		refTreeNode.insert(treeNode, refTreeNode, 'after');
	},

	insertBefore: function(treeNode, refTreeNode) {
		refTreeNode.insert(treeNode, refTreeNode, 'before');
	},

	getNodeByChild: function(child) {
		var instance = this;
		var treeNodeEl = child.ancestor(DOT+CSS_TREE_NODE);

		if (treeNodeEl) {
			return instance.getNodeById( treeNodeEl.attr(ID) );
		}

		return null;
	},

	/*
	* Setters
	*/
	_setChildren: function(v) {
		var instance = this;
		var childNodes = [];

		A.Array.each(v, function(node) {
			if (node) {
				if (!isTreeNode(node) && isObject(node)) {
					// creating node from json
					node = instance.createNode(node);
				}

				// before render the node, make sure the PARENT_NODE references are updated
				// this is required on the render phase of the TreeNode (_createNodeContainer)
				// to propagate the appendChild callback
				node.render();

				// avoid duplicated children on the childNodes list
				if (A.Array.indexOf(childNodes, node) == -1) {
					childNodes.push(node);
				}
			}
		});

		return childNodes;
	}
});

A.TreeData = TreeData;

}, '0.1a', { requires: [ 'aui-base' ] });AUI.add('tree-node', function(A) {

var L = A.Lang,
	isString = L.isString,
	isBoolean = L.isBoolean,

	ALWAYS_SHOW_HITAREA = 'alwaysShowHitArea',
	BLANK = '',
	BOUNDING_BOX = 'boundingBox',
	CHILDREN = 'children',
	CLEARFIX = 'clearfix',
	COLLAPSED = 'collapsed',
	CONTAINER = 'container',
	CONTENT = 'content',
	CONTENT_BOX = 'contentBox',
	EL = 'el',
	EXPANDED = 'expanded',
	HELPER = 'helper',
	HIDDEN = 'hidden',
	HITAREA = 'hitarea',
	HIT_AREA_EL = 'hitAreaEl',
	ICON = 'icon',
	ICON_EL = 'iconEl',
	ID = 'id',
	LABEL = 'label',
	LABEL_EL = 'labelEl',
	LAST_SELECTED = 'lastSelected',
	LEAF = 'leaf',
	NODE = 'node',
	OVER = 'over',
	OWNER_TREE = 'ownerTree',
	PARENT_NODE = 'parentNode',
	SELECTED = 'selected',
	SPACE = ' ',
	TREE = 'tree',
	TREE_NODE = 'tree-node',

	nodeSetter = function(v) {
		return A.get(v);
	},

	concat = function() {
		return Array.prototype.slice.call(arguments).join(SPACE);
	},

	isTreeNode = function(v) {
		return ( v instanceof A.TreeNode );
	},

	getCN = A.ClassNameManager.getClassName,

	CSS_HELPER_CLEARFIX = getCN(HELPER, CLEARFIX),
	CSS_TREE_COLLAPSED = getCN(TREE, COLLAPSED),
	CSS_TREE_CONTAINER = getCN(TREE, CONTAINER),
	CSS_TREE_EXPANDED = getCN(TREE, EXPANDED),
	CSS_TREE_HIDDEN = getCN(TREE, HIDDEN),
	CSS_TREE_HITAREA = getCN(TREE, HITAREA),
	CSS_TREE_ICON = getCN(TREE, ICON),
	CSS_TREE_LABEL = getCN(TREE, LABEL),
	CSS_TREE_NODE_CONTENT = getCN(TREE, NODE, CONTENT),
	CSS_TREE_NODE_HIDDEN_HITAREA = getCN(TREE, NODE, HIDDEN, HITAREA),
	CSS_TREE_NODE_LEAF = getCN(TREE, NODE, LEAF),
	CSS_TREE_NODE_OVER = getCN(TREE, NODE, OVER),
	CSS_TREE_NODE_SELECTED = getCN(TREE, NODE, SELECTED),

	HIT_AREA_TPL = '<div class="'+CSS_TREE_HITAREA+'"></div>',
	ICON_TPL = '<div class="'+CSS_TREE_ICON+'"></div>',
	LABEL_TPL = '<div class="'+CSS_TREE_LABEL+'"></div>',
	NODE_CONTAINER_TPL = '<ul></ul>',

	NODE_BOUNDING_TEMPLATE = '<li></li>',
	NODE_CONTENT_TEMPLATE = '<div class="'+concat(CSS_HELPER_CLEARFIX, CSS_TREE_NODE_CONTENT)+'"></div>';

/*
* TreeNode
*/
function TreeNode(config) {
	TreeNode.superclass.constructor.apply(this, arguments);
}

A.mix(TreeNode, {
	NAME: TREE_NODE,

	ATTRS: {
		draggable: {
			value: true,
			validador: isBoolean
		},

		ownerTree: {
			value: null
		},

		label: {
			value: BLANK,
			validador: isString
		},

		expanded: {
			value: false,
			validador: isBoolean
		},

		id: {
			validador: isString
		},

		leaf: {
			value: true,
			setter: function(v) {
				// if has children it's not a leaf
				if (v && this.get(CHILDREN).length) {
					return false;
				}

				return v;
			},
			validador: isBoolean
		},

		nextSibling: {
			value: null,
			validador: isTreeNode
		},

		prevSibling: {
			value: null,
			validador: isTreeNode
		},

		parentNode: {
			value: null,
			validador: isTreeNode
		},

		labelEl: {
			setter: nodeSetter,
			valueFn: function() {
				var label = this.get(LABEL);

				return A.Node.create(LABEL_TPL).html(label).unselectable();
			}
		},

		hitAreaEl: {
			setter: nodeSetter,
			valueFn: function() {
				return A.Node.create(HIT_AREA_TPL);
			}
		},

		alwaysShowHitArea: {
			value: true,
			validador: isBoolean
		},

		iconEl: {
			setter: nodeSetter,
			valueFn: function() {
				return A.Node.create(ICON_TPL);
			}
		},

		tabIndex: {
			value: null
		}
	}
});


A.extend(TreeNode, A.TreeData, {
	BOUNDING_TEMPLATE: NODE_BOUNDING_TEMPLATE,
	CONTENT_TEMPLATE: NODE_CONTENT_TEMPLATE,

	/*
	* Lifecycle
	*/
	initializer: function() {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);

		if (!instance.get(ID)) {
			// add a default unique id for the index
			instance.set( ID, A.guid(TREE_NODE) );
		}

		// invoking TreeData initializer
		TreeNode.superclass.initializer.apply(this, arguments);
	},

	bindUI: function() {
		var instance = this;

		// binding collapse/expand
		instance.publish('collapse', { defaultFn: instance._collapse });
		instance.publish('expand', { defaultFn: instance._expand });

		instance.after('childrenChange', A.bind(instance._afterSetChildren, instance));
		instance.after('idChange', instance._afterSetId, instance);
	},

	// overloading private _renderUI, don't call this._renderBox method
	// avoid render node on the body
    _renderUI: function(parentNode) {
        this._renderBoxClassNames();
		// this._renderBox(parentNode);
    },

	renderUI: function() {
		var instance = this;

		instance._renderBoundingBox();
		instance._renderContentBox();
	},

	syncUI: function() {
		var instance = this;

		instance._syncHitArea( instance.get( CHILDREN ) );
	},

	_renderContentBox: function(v) {
		var instance = this;
		var contentBox = instance.get(CONTENT_BOX);

		if (instance.isLeaf()) {
			// add leaf css classes
			contentBox.addClass(CSS_TREE_NODE_LEAF);
		}
		else {
			// add folder css classes state
			contentBox.addClass(
				instance.get(EXPANDED) ? CSS_TREE_EXPANDED : CSS_TREE_COLLAPSED
			);
		}

		return contentBox;
	},

	_renderBoundingBox: function() {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);
		var contentBox = instance.get(CONTENT_BOX);

		if (!instance.isLeaf()) {
			// append hitarea element
			contentBox.append( instance.get(HIT_AREA_EL) );

			// if has children append them to this model
			var nodeContainer = instance._createNodeContainer();
		}

		contentBox.append( instance.get(ICON_EL) );
		contentBox.append( instance.get(LABEL_EL) );

		boundingBox.append(contentBox);

		if (nodeContainer) {
			if (!instance.get(EXPANDED)) {
				nodeContainer.addClass(CSS_TREE_HIDDEN);
			}

			boundingBox.append(nodeContainer);
		}

		return boundingBox;
	},

	_createNodeContainer: function() {
		var instance = this;

		// creating <ul class="aui-tree-container">
		var nodeContainer = instance.get(CONTAINER) || A.Node.create(NODE_CONTAINER_TPL);

		nodeContainer.addClass(CSS_TREE_CONTAINER);

		// when it's not a leaf it has a <ul> container
		instance.set(CONTAINER, nodeContainer);

		instance.eachChildren(function(node) {
			instance.appendChild(node);
		});

		return nodeContainer;
	},

	_syncHitArea: function(children) {
		var instance = this;

		if (instance.get(ALWAYS_SHOW_HITAREA) || children.length) {
			instance.showHitArea();
		}
		else {
			instance.hideHitArea();

			instance.collapse();
		}
	},

	/*
	* Methods
	*/
	appendChild: function() {
		var instance = this;

		if (!instance.isLeaf()) {
			TreeNode.superclass.appendChild.apply(instance, arguments);
		}
	},

	collapse: function() {
		var instance = this;

		if (instance.get(EXPANDED)) {
			var output = instance.getEventOutputMap(instance);

			instance.bubbleEvent('collapse', output);
		}
	},

	_collapse: function(event) {
		// stopActionPropagation while bubbling
		if (event.stopActionPropagation) {
			return false;
		}

		var instance = this;

		if (!instance.isLeaf()) {
			var container = instance.get(CONTAINER);
			var contentBox = instance.get(CONTENT_BOX);

			contentBox.replaceClass(CSS_TREE_EXPANDED, CSS_TREE_COLLAPSED);

			if (container) {
				container.addClass(CSS_TREE_HIDDEN);
			}

			instance.set(EXPANDED, false);
		}
	},

	collapseAll: function() {
		var instance = this;

		TreeNode.superclass.collapseAll.apply(instance, arguments);

		// instance is also a node, so collapse itself
		instance.collapse();
	},

	contains: function(node) {
        return node.isAncestor(this);
	},

	expand: function() {
		var instance = this;

		if (!instance.get(EXPANDED)) {
			var output = instance.getEventOutputMap(instance);

			instance.bubbleEvent('expand', output);
		}
	},

	_expand: function(event) {
		// stopActionPropagation while bubbling
		if (event.stopActionPropagation) {
			return false;
		}

		var instance = this;

		if (!instance.isLeaf()) {
			var container = instance.get(CONTAINER);
			var contentBox = instance.get(CONTENT_BOX);

			contentBox.replaceClass(CSS_TREE_COLLAPSED, CSS_TREE_EXPANDED);

			if (container) {
				container.removeClass(CSS_TREE_HIDDEN);
			}

			instance.set(EXPANDED, true);
		}
	},

	expandAll: function() {
		var instance = this;

		TreeNode.superclass.expandAll.apply(instance, arguments);

		// instance is also a node, so expand itself
		instance.expand();
	},

	getDepth: function() {
		var depth = 0;
		var instance = this;
		var parentNode = instance.get(PARENT_NODE);

		while (parentNode) {
			++depth;
			parentNode = parentNode.get(PARENT_NODE);
		}

		return depth;
	},

	hasChildNodes: function() {
		var instance = this;

		return (!instance.isLeaf() &&
				TreeNode.superclass.hasChildNodes.apply(this, arguments));
	},

	isSelected: function() {
		return this.get(CONTENT_BOX).hasClass(CSS_TREE_NODE_SELECTED);
	},

	isLeaf: function() {
		var instance = this;

		return instance.get(LEAF);
	},

	isAncestor: function(node) {
		var instance = this;
		var parentNode = instance.get(PARENT_NODE);

		while (parentNode) {
			if (parentNode == node) {
				return true;
			}
			parentNode = parentNode.get(PARENT_NODE);
		}

		return false;
	},

	insertAfter: function(node, refNode) {
		var instance = this;

		TreeNode.superclass.insertAfter.apply(this, [node, instance]);
	},

	insertBefore: function(node) {
		var instance = this;

		TreeNode.superclass.insertBefore.apply(this, [node, instance]);
	},

	removeChild: function(node) {
		var instance = this;

		if (!instance.isLeaf()) {
			TreeNode.superclass.removeChild.apply(instance, arguments);
		}
	},

	toggle: function() {
		var instance = this;

		if (instance.get(EXPANDED)) {
			instance.collapse();
		}
		else {
			instance.expand();
		}
	},

	select: function() {
		var instance = this;
		var ownerTree = instance.get(OWNER_TREE);

		if (ownerTree) {
			ownerTree.set(LAST_SELECTED, instance);
		}

		instance.get(CONTENT_BOX).addClass(CSS_TREE_NODE_SELECTED);

		instance.fire('select');
	},

	unselect: function() {
		var instance = this;

		instance.get(CONTENT_BOX).removeClass(CSS_TREE_NODE_SELECTED);

		instance.fire('unselect');
	},

	over: function() {
		this.get(CONTENT_BOX).addClass(CSS_TREE_NODE_OVER);
	},

	out: function() {
		this.get(CONTENT_BOX).removeClass(CSS_TREE_NODE_OVER);
	},

	showHitArea: function() {
		var instance = this;
		var hitAreaEl = instance.get(HIT_AREA_EL);

		hitAreaEl.removeClass(CSS_TREE_NODE_HIDDEN_HITAREA);
	},

	hideHitArea: function() {
		var instance = this;
		var hitAreaEl = instance.get(HIT_AREA_EL);

		hitAreaEl.addClass(CSS_TREE_NODE_HIDDEN_HITAREA);
	},

	/*
	* Listeners
	*/
	_afterSetChildren: function(event) {
		var instance = this;

		instance._syncHitArea(event.newVal);
	},

	_afterSetId: function(event) {
		var instance = this;

		instance.get(BOUNDING_BOX).attr(ID, event.newVal);
	}
});

A.TreeNode = TreeNode;


/*
* TreeNodeIO
*/
var isFunction = L.isFunction,

	CACHE = 'cache',
	FORMATTER = 'formatter',
	IO = 'io',
	LOADED = 'loaded',
	LOADING = 'loading',
	TREE_NODE_IO = 'tree-node-io',

	CSS_TREE_NODE_IO_LOADING = getCN(TREE, NODE, IO, LOADING);

function TreeNodeIO(config) {
	TreeNodeIO.superclass.constructor.apply(this, arguments);
}

A.mix(TreeNodeIO, {
	NAME: TREE_NODE_IO,

	ATTRS: {
		io: {
			lazyAdd: false,
			value: null,
			setter: function(v) {
				return this._setIO(v);
			}
		},

		loading: {
			value: false,
			validador: isBoolean
		},

		loaded: {
			value: false,
			validador: isBoolean
		},

		cache: {
			value: true,
			validador: isBoolean
		},

		leaf: {
			value: false,
			validador: isBoolean
		}
	}
});

A.extend(TreeNodeIO, A.TreeNode, {
	/*
	* Methods
	*/
	createNode: function(nodes) {
		var instance = this;

		A.each(nodes, function(node) {
			var newNode = TreeNodeIO.superclass.createNode.apply(instance, [node]);

			instance.appendChild(newNode);
		});
	},

	expand: function() {
		var instance = this;
		var cache = instance.get(CACHE);
		var io = instance.get(IO);
		var loaded = instance.get(LOADED);
		var loading = instance.get(LOADING);
		var ownerTree = instance.get(OWNER_TREE);

		// inheriting the IO configuration from the OWNER_TREE
		if (!io && ownerTree) {
			instance.set( IO, A.clone(ownerTree.get(IO)) );

			io = instance.get(IO);
		}

		if (!cache) {
			// if cache is false on expand, always set LOADED to false
			instance.set(LOADED, false);
		}

		if (!io || loaded) {
			TreeNodeIO.superclass.expand.apply(this, arguments);
		}
		else {
			if (!loading) {
				if (!cache) {
					// remove all children to reload
					instance.empty();
				}

				if (isFunction(io.cfg.data)) {
					io.cfg.data = io.cfg.data.apply(instance, [instance]);
				}

				if (isFunction(io.loader)) {
					var loader = A.bind(io.loader, instance);

					// apply loader in the TreeNodeIO scope
					loader(io.url, io.cfg, instance);
				}
				else {
					A.io(io.url, io.cfg);
				}
			}
		}
	},

	ioStartHandler: function() {
		var instance = this;
		var contentBox = instance.get(CONTENT_BOX);

		instance.set(LOADING, true);

		contentBox.addClass(CSS_TREE_NODE_IO_LOADING);
	},

	ioCompleteHandler: function() {
		var instance = this;
		var contentBox = instance.get(CONTENT_BOX);

		instance.set(LOADING, false);
		instance.set(LOADED, true);

		contentBox.removeClass(CSS_TREE_NODE_IO_LOADING);
	},

	ioSuccessHandler: function() {
		var instance = this;
		var io = instance.get(IO);
		var args = Array.prototype.slice.call(arguments);
		var length = args.length;

		// if using the first argument as the JSON object
		var nodes = args[0];

		// if using (id, o) yui callback syntax
		if (length >= 2) {
			var id = args[0], o = args[1];
			// try to convert responseText to JSON
			try {
				nodes = A.JSON.parse(o.responseText);
			}
			catch(e) {}
		}

		var formatter = io.formatter;

		if (formatter) {
			nodes = formatter(nodes);
		}

		instance.createNode(nodes);

		instance.expand();
	},

	ioFailureHandler: function() {
		var instance = this;

		instance.set(LOADING, false);
		instance.set(LOADED, false);
	},

	/*
	* Setters
	*/
	_setIO: function(v) {
		var instance = this;

		if (!v) {
			return null;
		}
		else if (isString(v)) {
			v = { url: v };
		}

		v = v || {};
		v.cfg = v.cfg || {};
		v.cfg.on = v.cfg.on || {};

		var defCallbacks = {
			start: A.bind(instance.ioStartHandler, instance),
			complete: A.bind(instance.ioCompleteHandler, instance),
			success: A.bind(instance.ioSuccessHandler, instance),
			failure: A.bind(instance.ioFailureHandler, instance)
		};

		A.each(defCallbacks, function(fn, name) {
			var userFn = v.cfg.on[name];

			if (isFunction(userFn)) {
				// wrapping user callback and default callback, invoking both handlers
				var wrappedFn = function() {
					fn.apply(instance, arguments);
					userFn.apply(instance, arguments);
				};

				v.cfg.on[name] = A.bind(wrappedFn, instance);
			}
			else {
				// get from defCallbacks map
				v.cfg.on[name] = fn;
			}

		});

		return v;
	}
});

A.TreeNodeIO = TreeNodeIO;


/*
* TreeNodeCheck
*/
var	CHECKBOX = 'checkbox',
	CHECKED = 'checked',
	CHECK_CONTAINER_EL = 'checkContainerEl',
	CHECK_EL = 'checkEl',
	CHECK_NAME = 'checkName',
	DOT = '.',
	NAME = 'name',
	TREE_NODE_CHECK = 'tree-node-check',

	CSS_TREE_NODE_CHECKBOX = getCN(TREE, NODE, CHECKBOX),
	CSS_TREE_NODE_CHECKBOX_CONTAINER = getCN(TREE, NODE, CHECKBOX, CONTAINER),
	CSS_TREE_NODE_CHECKED = getCN(TREE, NODE, CHECKED),

	CHECKBOX_CONTAINER_TPL = '<div class="'+CSS_TREE_NODE_CHECKBOX_CONTAINER+'"></div>',
	CHECKBOX_TPL = '<input class="'+CSS_TREE_NODE_CHECKBOX+'" type="checkbox" />';

function TreeNodeCheck(config) {
	TreeNodeCheck.superclass.constructor.apply(this, arguments);
}

A.mix(TreeNodeCheck, {
	NAME: TREE_NODE_CHECK,

	ATTRS: {
		checked: {
			value: false,
			validador: isBoolean
		},

		checkName: {
			value: TREE_NODE_CHECK,
			validador: isString
		},

		checkContainerEl: {
			setter: nodeSetter,
			valueFn: function() {
				return A.Node.create(CHECKBOX_CONTAINER_TPL);
			}
		},

		checkEl: {
			setter: nodeSetter,
			valueFn: function() {
				var checkName = this.get(CHECK_NAME);

				return A.Node.create(CHECKBOX_TPL).attr(NAME, checkName);
			}
		}
	}
});

A.extend(TreeNodeCheck, A.TreeNodeIO, {
	/*
	* Lifecycle
	*/
	renderUI: function() {
		var instance = this;

		TreeNodeCheck.superclass.renderUI.apply(instance, arguments);

		var labelEl = instance.get(LABEL_EL);
		var checkEl = instance.get(CHECK_EL);
		var checkContainerEl = instance.get(CHECK_CONTAINER_EL);

		checkEl.hide();

		checkContainerEl.append(checkEl);

		labelEl.placeBefore(checkContainerEl);

		if (instance.isChecked()) {
			instance.check();
		}
	},

	bindUI: function() {
		var instance = this;
		var contentBox = instance.get(CONTENT_BOX);
		var labelEl = instance.get(LABEL_EL);

		TreeNodeCheck.superclass.bindUI.apply(instance, arguments);

		instance.publish('check');
		instance.publish('uncheck');
		contentBox.delegate('click', A.bind(instance.toggleCheck, instance), DOT+CSS_TREE_NODE_CHECKBOX_CONTAINER);
		contentBox.delegate('click', A.bind(instance.toggleCheck, instance), DOT+CSS_TREE_LABEL);

		// cancel dblclick because of the check
		labelEl.swallowEvent('dblclick');
	},

	/*
	* Methods
	*/
	check: function() {
		var instance = this;
		var contentBox = instance.get(CONTENT_BOX);
		var checkEl = instance.get(CHECK_EL);

		contentBox.addClass(CSS_TREE_NODE_CHECKED);

		instance.set(CHECKED, true);

		checkEl.attr(CHECKED, CHECKED);

		instance.fire('check');
	},

	uncheck: function() {
		var instance = this;
		var contentBox = instance.get(CONTENT_BOX);
		var checkEl = instance.get(CHECK_EL);

		contentBox.removeClass(CSS_TREE_NODE_CHECKED);

		instance.set(CHECKED, false);

		checkEl.attr(CHECKED, BLANK);

		instance.fire('uncheck');
	},

	toggleCheck: function() {
		var instance = this;
		var checkEl = instance.get(CHECK_EL);
		var checked = checkEl.attr(CHECKED);

		if (!checked) {
			instance.check();
		}
		else {
			instance.uncheck();
		}
	},

	isChecked: function() {
		var instance = this;

		return instance.get(CHECKED);
	}
});

A.TreeNodeCheck = TreeNodeCheck;


/*
* TreeNodeTask
*/
var	CHILD = 'child',
	TREE_NODE_TASK = 'tree-node-task',
	UNCHECKED = 'unchecked',

	isTreeNodeTask = function(node) {
		return node instanceof A.TreeNodeCheck;
	},

	CSS_TREE_NODE_CHILD_UNCHECKED = getCN(TREE, NODE, CHILD, UNCHECKED);

function TreeNodeTask(config) {
	TreeNodeTask.superclass.constructor.apply(this, arguments);
}

A.mix(TreeNodeTask, {
	NAME: TREE_NODE_TASK
});

A.extend(TreeNodeTask, A.TreeNodeCheck, {
	/*
	* Methods
	*/
	check: function(stopPropagation) {
		var instance = this;
		var parentNode = instance.get(PARENT_NODE);
		var contentBox = instance.get(CONTENT_BOX);

		// invoke default check logic
		TreeNodeTask.superclass.check.apply(this, arguments);

		if (!stopPropagation) {
			// always remove the CSS_TREE_NODE_CHILD_UNCHECKED of the checked node
			contentBox.removeClass(CSS_TREE_NODE_CHILD_UNCHECKED);

			// loop all parentNodes
			instance.eachParent(
				function(parentNode) {
					// if isTreeNodeTask and isChecked
					if (isTreeNodeTask(parentNode)) {
						var hasUnchecked = false;

						// after check a child always check the parentNode temporary
						// and add the CSS_TREE_NODE_CHILD_UNCHECKED state until the !hasUnchecked check
						parentNode.check(true);
						parentNode.get(CONTENT_BOX).addClass(CSS_TREE_NODE_CHILD_UNCHECKED);

						// check if has at least one child uncheked
						parentNode.eachChildren(function(child) {
							if (isTreeNodeTask(child) && !child.isChecked()) {
								hasUnchecked = true;
							}
						}, true);

						// if doesn't have unchecked children remove the CSS_TREE_NODE_CHILD_UNCHECKED class
						if (!hasUnchecked) {
							parentNode.get(CONTENT_BOX).removeClass(CSS_TREE_NODE_CHILD_UNCHECKED);
						}
					}
				}
			);

			if (!instance.isLeaf()) {
				// check all TreeNodeTask children
				instance.eachChildren(function(child) {
					if (isTreeNodeTask(child)) {
						child.check();
					}
				});
			}
		}
	},

	uncheck: function() {
		var instance = this;
		var contentBox = instance.get(CONTENT_BOX);

		// invoke default uncheck logic
		TreeNodeTask.superclass.uncheck.apply(this, arguments);

		// always remove the CSS_TREE_NODE_CHILD_UNCHECKED of the clicked node
		contentBox.removeClass(CSS_TREE_NODE_CHILD_UNCHECKED);

		instance.eachParent(
			function(parentNode) {
				// if isTreeNodeTask and isChecked
				if (isTreeNodeTask(parentNode) && parentNode.isChecked()) {
					// add CSS_TREE_NODE_CHILD_UNCHECKED class
					parentNode.get(CONTENT_BOX).addClass(CSS_TREE_NODE_CHILD_UNCHECKED);
				}
			}
		);

		if (!instance.isLeaf()) {
			// uncheck all TreeNodeTask children
			instance.eachChildren(function(child) {
				if (child instanceof A.TreeNodeCheck) {
					child.uncheck();
				}
			});
		}
	}
});

A.TreeNodeTask = TreeNodeTask;

/*
* A.TreeNode.nodeTypes
*/
A.TreeNode.nodeTypes = {
	task: A.TreeNodeTask,
	check: A.TreeNodeCheck,
	node: A.TreeNode,
	io: A.TreeNodeIO
};

}, '0.1a', { requires: [ 'tree-data', 'io', 'json' ] });AUI.add('tree-view', function(A) {

var L = A.Lang,
	isString = L.isString,

	BLANK = '',
	BOUNDING_BOX = 'boundingBox',
	CHILDREN = 'children',
	CONTAINER = 'container',
	CONTENT = 'content',
	CONTENT_BOX = 'contentBox',
	DOT = '.',
	EL = 'el',
	FILE = 'file',
	HITAREA = 'hitarea',
	ICON = 'icon',
	LABEL = 'label',
	LAST_SELECTED = 'lastSelected',
	LEAF = 'leaf',
	NODE = 'node',
	OWNER_TREE = 'ownerTree',
	ROOT = 'root',
	SELECTED = 'selected',
	SPACE = ' ',
	TREE = 'tree',
	TREE_VIEW = 'tree-view',
	TYPE = 'type',
	VIEW = 'view',

	concat = function() {
		return Array.prototype.slice.call(arguments).join(SPACE);
	},

	isTreeNode = function(v) {
		return ( v instanceof A.TreeNode );
	},

	getCN = A.ClassNameManager.getClassName,

	CSS_TREE_HITAREA = getCN(TREE, HITAREA),
	CSS_TREE_ICON = getCN(TREE, ICON),
	CSS_TREE_LABEL = getCN(TREE, LABEL),
	CSS_TREE_NODE_CONTENT = getCN(TREE, NODE, CONTENT),
	CSS_TREE_NODE_SELECTED = getCN(TREE, NODE, SELECTED),
	CSS_TREE_ROOT_CONTAINER = getCN(TREE, ROOT, CONTAINER),
	CSS_TREE_VIEW_CONTENT = getCN(TREE, VIEW, CONTENT);

/*
* TreeView
*/

function TreeView(config) {
	TreeView.superclass.constructor.apply(this, arguments);
}

A.mix(TreeView, {
	NAME: TREE_VIEW,

	ATTRS: {
		type: {
			value: FILE,
			validator: isString
		},

		lastSelected: {
			value: null,
			validator: isTreeNode
		},

		io: {
			value: null
		}
	}
});

A.extend(TreeView, A.TreeData, {
	CONTENT_TEMPLATE: '<ul></ul>',

	/*
	* Lifecycle
	*/
	bindUI: function() {
		var instance = this;

		instance._delegateDOM();
	},

	renderUI: function() {
		var instance = this;

		instance._renderElements();
	},

	syncUI: function() {
		var instance = this;

		instance.refreshIndex();
	},

	/*
	* Methods
	*/
	registerNode: function(node) {
		var instance = this;

		// when the node is appended to the TreeView set the OWNER_TREE
		node.set(OWNER_TREE, instance);

		TreeView.superclass.registerNode.apply(this, arguments);
	},

	_createFromHTMLMarkup: function(container) {
		var instance = this;

		container.all('> li').each(function(node) {
			// use firstChild as label
			var labelEl = node.one('> *').remove();
			var label = labelEl.outerHTML();

			// avoid memory leak
			docFrag = null;

			var treeNode = new A.TreeNode({
				boundingBox: node,
				label: label
			});

			var deepContainer = node.one('> ul');

			if (deepContainer) {
				// if has deepContainer it's not a leaf
				treeNode.set(LEAF, false);
				treeNode.set(CONTAINER, deepContainer);

				// render node before invoke the recursion
				treeNode.render();

				// propagating markup recursion
				instance._createFromHTMLMarkup(deepContainer);
			}
			else {
				treeNode.render();
			}

			// find the parent TreeNode...
			var parentNode = node.get(PARENT_NODE).get(PARENT_NODE);
			var parentTreeNode = A.Widget.getByNode(parentNode);

			// and simulate the appendChild.
			parentTreeNode.appendChild(treeNode);
		});
	},

	_renderElements: function() {
		var instance = this;
		var contentBox = instance.get(CONTENT_BOX);
		var children = instance.get(CHILDREN);
		var type = instance.get(TYPE);
		var CSS_TREE_TYPE = getCN(TREE, type);

		contentBox.addClass(CSS_TREE_VIEW_CONTENT);

		instance.set(CONTAINER, contentBox);

		contentBox.addClass(
			concat(CSS_TREE_TYPE, CSS_TREE_ROOT_CONTAINER)
		);

		if (children.length) {
			// if has children appendChild them
			instance.eachChildren(function(node) {
				instance.appendChild(node, true);
			});
		}
		else {
			// if children not specified try to create from markup
			instance._createFromHTMLMarkup(contentBox);
		}
	},

	/*
	* Listeners
	*/
	_delegateDOM: function() {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);

		// expand/collapse delegations
		boundingBox.delegate('click', A.bind(instance._onClickHitArea, instance), DOT+CSS_TREE_HITAREA);
		boundingBox.delegate('dblclick', A.bind(instance._onClickHitArea, instance), DOT+CSS_TREE_ICON);
		boundingBox.delegate('dblclick', A.bind(instance._onClickHitArea, instance), DOT+CSS_TREE_LABEL);
		// other delegations
		boundingBox.delegate('mouseenter', A.bind(instance._onMouseEnterNodeEl, instance), DOT+CSS_TREE_NODE_CONTENT);
		boundingBox.delegate('mouseleave', A.bind(instance._onMouseLeaveNodeEl, instance), DOT+CSS_TREE_NODE_CONTENT);
		boundingBox.delegate('click', A.bind(instance._onClickNodeEl, instance), DOT+CSS_TREE_NODE_CONTENT);
	},

	_onClickNodeEl: function(event) {
		var instance = this;
		var treeNode = instance.getNodeByChild( event.currentTarget );

		if (treeNode && !treeNode.isSelected()) {
			var lastSelected = instance.get(LAST_SELECTED);

			// select drag node
			if (lastSelected) {
				lastSelected.unselect();
			}

			treeNode.select();
		}
	},

	_onMouseEnterNodeEl: function(event) {
		var instance = this;
		var treeNode = instance.getNodeByChild( event.currentTarget );

		if (treeNode) {
			treeNode.over();
		}
	},

	_onMouseLeaveNodeEl: function(event) {
		var instance = this;
		var treeNode = instance.getNodeByChild( event.currentTarget );

		if (treeNode) {
			treeNode.out();
		}
	},

	_onClickHitArea: function(event) {
		var instance = this;
		var treeNode = instance.getNodeByChild( event.currentTarget );

		if (treeNode) {
			treeNode.toggle();
		}
	}
});

A.TreeView = TreeView;


/*
* TreeViewDD - Drag & Drop
*/
var isNumber = L.isNumber,

	ABOVE = 'above',
	APPEND = 'append',
	BELOW = 'below',
	BLOCK = 'block',
	BODY = 'body',
	CLEARFIX = 'clearfix',
	DEFAULT = 'default',
	DISPLAY = 'display',
	DOWN = 'down',
	DRAG = 'drag',
	DRAGGABLE = 'draggable',
	DRAG_CURSOR = 'dragCursor',
	DRAG_NODE = 'dragNode',
	EXPANDED = 'expanded',
	HELPER = 'helper',
	ID = 'id',
	INSERT = 'insert',
	OFFSET_HEIGHT = 'offsetHeight',
	OFFSET_TOP = 'offsetTop',
	PARENT_NODE = 'parentNode',
	SCROLL_DELAY = 'scrollDelay',
	STATE = 'state',
	TREE_DRAG_DROP = 'tree-drag-drop',
	UP = 'up',

	DDM = A.DD.DDM,

	CSS_HELPER_CLEARFIX = getCN(HELPER, CLEARFIX),
	CSS_ICON = getCN(ICON),
	CSS_TREE_DRAG_HELPER = getCN(TREE, DRAG, HELPER),
	CSS_TREE_DRAG_HELPER_CONTENT = getCN(TREE, DRAG, HELPER, CONTENT),
	CSS_TREE_DRAG_HELPER_LABEL = getCN(TREE, DRAG, HELPER, LABEL),
	CSS_TREE_DRAG_INSERT_ABOVE = getCN(TREE, DRAG, INSERT, ABOVE),
	CSS_TREE_DRAG_INSERT_APPEND = getCN(TREE, DRAG, INSERT, APPEND),
	CSS_TREE_DRAG_INSERT_BELOW = getCN(TREE, DRAG, INSERT, BELOW),
	CSS_TREE_DRAG_STATE_APPEND = getCN(TREE, DRAG, STATE, APPEND),
	CSS_TREE_DRAG_STATE_INSERT_ABOVE = getCN(TREE, DRAG, STATE, INSERT, ABOVE),
	CSS_TREE_DRAG_STATE_INSERT_BELOW = getCN(TREE, DRAG, STATE, INSERT, BELOW),

	HELPER_TPL = '<div class="'+CSS_TREE_DRAG_HELPER+'">'+
					'<div class="'+[CSS_TREE_DRAG_HELPER_CONTENT, CSS_HELPER_CLEARFIX].join(SPACE)+'">'+
						'<span class="'+CSS_ICON+'"></span>'+
						'<span class="'+CSS_TREE_DRAG_HELPER_LABEL+'"></span>'+
					'</div>'+
				 '</div>';


function TreeViewDD(config) {
	TreeViewDD.superclass.constructor.apply(this, arguments);
}

A.mix(TreeViewDD, {
	NAME: TREE_DRAG_DROP,

	ATTRS: {
		helper: {
			value: null
		},

		scrollDelay: {
			value: 100,
			validator: isNumber
		}
	}
});

A.extend(TreeViewDD, A.TreeView, {
	direction: BELOW,

	dropAction: null,

	lastY: 0,

	node: null,

	nodeContent: null,

	/*
	* Lifecycle
	*/
	bindUI: function() {
		var instance = this;

		TreeViewDD.superclass.bindUI.apply(this, arguments);

		instance._bindDragDrop();
	},

	renderUI: function() {
		var instance = this;

		TreeViewDD.superclass.renderUI.apply(this, arguments);

		// creating drag helper and hiding it
		var helper = A.Node.create(HELPER_TPL).hide();

		// append helper to the body
		A.get(BODY).append(helper);

		instance.set(HELPER, helper);

		// set DRAG_CURSOR to the default arrow
		DDM.set(DRAG_CURSOR, DEFAULT);
	},

	/*
	* Methods
	*/
	_createDrag: function(node) {
		var instance = this;

		if (!instance.dragTimers) {
			instance.dragTimers = [];
		}

		if (!DDM.getDrag(node)) {
			var dragTimers = instance.dragTimers;
			// dragDelay is a incremental delay for create the drag instances
			var dragDelay = 50 * dragTimers.length;

			// wrapping the _createDrag on a setTimeout for performance reasons
			var timer = setTimeout(
				function() {
					if (!DDM.getDrag(node)) {
						// creating delayed drag instance
						new A.DD.Drag({
							node: node,
							bubbles: instance,
							target: true
						})
						.plug(A.Plugin.DDProxy, {
							moveOnEnd: false,
							positionProxy: false,
							borderStyle: null
						})
						.plug(A.Plugin.DDNodeScroll, {
							scrollDelay: instance.get(SCROLL_DELAY),
							node: instance.get(BOUNDING_BOX)
						});
					}

					A.Array.removeItem(dragTimers, timer);
				},
				dragDelay
			);

			dragTimers.push(timer);
		}
	},

	_bindDragDrop: function() {
		var instance = this;
		var boundingBox = instance.get(BOUNDING_BOX);

		instance._createDragInitHandler = A.bind(
			function() {
				// set init elements as draggable
				instance.eachChildren(function(child) {
					if (child.get(DRAGGABLE)) {
						instance._createDrag( child.get(CONTENT_BOX) );
					}
				}, true);

				boundingBox.detach('mouseover', instance._createDragInitHandler);
			},
			instance
		);

		// only create the drag on the init elements if the user mouseover the boundingBox for init performance reasons
		boundingBox.on('mouseover', instance._createDragInitHandler);

		// when append new nodes, make them draggable
		instance.after('insert', A.bind(instance._afterAppend, instance));
		instance.after('append', A.bind(instance._afterAppend, instance));

		// drag & drop listeners
		instance.on('drag:align', instance._onDragAlign);
		instance.on('drag:start', instance._onDragStart);
		instance.on('drop:exit', instance._onDropExit);
		instance.on('drop:hit', instance._onDropHit);
		instance.on('drop:over', instance._onDropOver);
	},

	_appendState: function(nodeContent) {
		var instance = this;

		instance.dropAction = APPEND;

		instance.get(HELPER).addClass(CSS_TREE_DRAG_STATE_APPEND);

		nodeContent.addClass(CSS_TREE_DRAG_INSERT_APPEND);
	},

	_goingDownState: function(nodeContent) {
		var instance = this;

		instance.dropAction = BELOW;

		instance.get(HELPER).addClass(CSS_TREE_DRAG_STATE_INSERT_BELOW);

		nodeContent.addClass(CSS_TREE_DRAG_INSERT_BELOW);
	},

	_goingUpState: function(nodeContent) {
		var instance = this;

		instance.dropAction = ABOVE;

		instance.get(HELPER).addClass(CSS_TREE_DRAG_STATE_INSERT_ABOVE);

		nodeContent.addClass(CSS_TREE_DRAG_INSERT_ABOVE);
	},

	_resetState: function(nodeContent) {
		var instance = this;
		var helper = instance.get(HELPER);

		helper.removeClass(CSS_TREE_DRAG_STATE_APPEND);
		helper.removeClass(CSS_TREE_DRAG_STATE_INSERT_ABOVE);
		helper.removeClass(CSS_TREE_DRAG_STATE_INSERT_BELOW);

		if (nodeContent) {
			nodeContent.removeClass(CSS_TREE_DRAG_INSERT_ABOVE);
			nodeContent.removeClass(CSS_TREE_DRAG_INSERT_APPEND);
			nodeContent.removeClass(CSS_TREE_DRAG_INSERT_BELOW);
		}
	},

	_updateNodeState: function(event) {
		var instance = this;
		var drag = event.drag;
		var drop = event.drop;
		var nodeContent = drop.get(NODE);
		var dropNode = nodeContent.get(PARENT_NODE);
		var dragNode = drag.get(NODE).get(PARENT_NODE);
		var dropTreeNode = A.Widget.getByNode(dropNode);

		// reset the classNames from the last nodeContent
		instance._resetState(instance.nodeContent);

		// cannot drop the dragged element into any of its children
		// using DOM contains method for performance reason
		if ( !dragNode.contains(dropNode) ) {
			// nArea splits the height in 3 areas top/center/bottom
			// these areas are responsible for defining the state when the mouse is over any of them
			var nArea = nodeContent.get(OFFSET_HEIGHT) / 3;
			var yTop = nodeContent.getY();
			var yCenter = yTop + nArea*1;
			var yBottom = yTop + nArea*2;
			var mouseY = drag.mouseXY[1];

			// UP: mouse on the top area of the node
			if ((mouseY > yTop) && (mouseY < yCenter)) {
				instance._goingUpState(nodeContent);
			}
			// DOWN: mouse on the bottom area of the node
			else if (mouseY > yBottom) {
				instance._goingDownState(nodeContent);
			}
			// APPEND: mouse on the center area of the node
			else if ((mouseY > yCenter) && (mouseY < yBottom)) {
				// if it's a folder set the state to append
				if (dropTreeNode && !dropTreeNode.isLeaf()) {
					instance._appendState(nodeContent);
				}
				// if it's a leaf we need to set the ABOVE or BELOW state instead of append
				else {
					if (instance.direction == UP) {
						instance._goingUpState(nodeContent);
					}
					else {
						instance._goingDownState(nodeContent);
					}
				}
			}
		}

		instance.nodeContent = nodeContent;
	},

	/*
	* Listeners
	*/
	_afterAppend: function(event) {
		var instance = this;
		var treeNode = event.tree.node;

		if (treeNode.get(DRAGGABLE)) {
			instance._createDrag( treeNode.get(CONTENT_BOX) );
		}
	},

	_onDragAlign: function(event) {
		var instance = this;
		var lastY = instance.lastY;
		var y = event.target.lastXY[1];

		// if the y change
		if (y != lastY) {
			// set the drag direction
			instance.direction = (y < lastY) ? UP : DOWN;
		}

		instance.lastY = y;
	},

 	_onDragStart: function(event) {
 		var instance = this;
		var drag = event.target;
		var dragNode = drag.get(NODE).get(PARENT_NODE);
		var dragTreeNode = A.Widget.getByNode(dragNode);
		var lastSelected = instance.get(LAST_SELECTED);

		// select drag node
		if (lastSelected) {
			lastSelected.unselect();
		}

 		dragTreeNode.select();

		// initialize drag helper
		var helper = instance.get(HELPER);
		var helperLabel = helper.query(DOT+CSS_TREE_DRAG_HELPER_LABEL);

		// show helper, we need display block here, yui dd hide it with display none
		helper.setStyle(DISPLAY, BLOCK).show();

		// set the CSS_TREE_DRAG_HELPER_LABEL html with the label of the dragged node
		helperLabel.html( dragTreeNode.get(LABEL) );

		// update the DRAG_NODE with the new helper
		drag.set(DRAG_NODE, helper);
 	},

	_onDropOver: function(event) {
		var instance = this;

		instance._updateNodeState(event);
	},

	_onDropHit: function(event) {
		var instance = this;
		var dropAction = instance.dropAction;
		var dragNode = event.drag.get(NODE).get(PARENT_NODE);
		var dropNode = event.drop.get(NODE).get(PARENT_NODE);

		var dropTreeNode = A.Widget.getByNode(dropNode);
		var dragTreeNode = A.Widget.getByNode(dragNode);

		var output = instance.getEventOutputMap(instance);

		output.tree.dropNode = dropTreeNode;
		output.tree.dragNode = dragTreeNode;

		if (dropAction == ABOVE) {
			dropTreeNode.insertBefore(dragTreeNode);

			instance.bubbleEvent('dropInsert', output);
		}
		else if (dropAction == BELOW) {
			dropTreeNode.insertAfter(dragTreeNode);

			instance.bubbleEvent('dropInsert', output);
		}
		else if (dropAction == APPEND) {
			if (dropTreeNode && !dropTreeNode.isLeaf()) {
				dropTreeNode.appendChild(dragTreeNode);

				if (!dropTreeNode.get(EXPANDED)) {
					// expand node when drop a child on it
					dropTreeNode.expand();
				}

				instance.bubbleEvent('dropAppend', output);
			}
		}

		instance._resetState(instance.nodeContent);

		// bubbling drop event
		instance.bubbleEvent('drop', output);
	},

	_onDropExit: function() {
		var instance = this;

		instance.dropAction = null;

		instance._resetState(instance.nodeContent);
	}
});

A.TreeViewDD = TreeViewDD;

}, '0.1a', { requires: [ 'tree-node', 'dd' ] });