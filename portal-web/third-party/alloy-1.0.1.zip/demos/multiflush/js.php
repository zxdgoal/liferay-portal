<?php
sleep(1);

header("Content-Type: text/javascript");

$n = $_REQUEST["n"];
$m = $_REQUEST["m"];
?>

var p = document.getElementById('portlet<?= $n ?>log');

if (p) {
	p.innerHTML += "<b>(<?= $m ?> <?= $n ?>)</b><br/>";
}