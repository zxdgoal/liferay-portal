﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'fa', {
	btnIgnore: 'چشمپوشی',
	btnIgnoreAll: 'چشمپوشی همه',
	btnReplace: 'جایگزینی',
	btnReplaceAll: 'جایگزینی همه',
	btnUndo: 'واچینش',
	changeTo: 'تغییر به',
	errorLoading: 'خطا در بارگیری برنامه خدمات میزبان: %s.',
	ieSpellDownload: 'بررسی کنندهٴ املا نصب نشده است. آیا میخواهید آن را هماکنون دریافت کنید؟',
	manyChanges: 'بررسی املا انجام شد. %1 واژه تغییر یافت',
	noChanges: 'بررسی املا انجام شد. هیچ واژهای تغییر نیافت',
	noMispell: 'بررسی املا انجام شد. هیچ غلط املائی یافت نشد',
	noSuggestions: '- پیشنهادی نیست -',
	notAvailable: 'با عرض پوزش خدمات الان در دسترس نیستند.',
	notInDic: 'در واژه~نامه یافت نشد',
	oneChange: 'بررسی املا انجام شد. یک واژه تغییر یافت',
	progress: 'بررسی املا در حال انجام...',
	title: 'بررسی املا',
	toolbar: 'بررسی املا'
});
