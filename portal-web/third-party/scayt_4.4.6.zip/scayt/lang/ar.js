﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'ar', {
	btn_about: 'عن SCAYT',
	btn_dictionaries: 'قواميس',
	btn_disable: 'تعطيل SCAYT',
	btn_enable: 'تفعيل SCAYT',
	btn_langs:'لغات',
	btn_options: 'خيارات',
	text_title:  'تدقيق إملائي أثناء الكتابة'
});