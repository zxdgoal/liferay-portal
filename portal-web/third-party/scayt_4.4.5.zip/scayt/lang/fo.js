﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'fo', {
	btn_about: 'Um SCAYT',
	btn_dictionaries: 'Orðabøkur',
	btn_disable: 'Nokta SCAYT',
	btn_enable: 'Loyv SCAYT',
	btn_langs:'Tungumál',
	btn_options: 'Uppseting',
	text_title: ''
});
