AUI.add('calendar', function(A) {

var L = A.Lang,
	isBoolean = L.isBoolean,
	isNumber = L.isNumber,
	isString = L.isString,

	isNodeList = function(v) {
		return (v instanceof A.NodeList);
	},

	isNode = function(v) {
		return (v instanceof A.Node);
	},

	ALLOY = 'alloy',
	ANCHOR = 'a',
	AUTO_RENDER = 'autoRender',
	ARROW = 'arrow',
	BLANK = '',
	BOUNDING_BOX = 'boundingBox',
	CAN_RESET = 'canReset',
	CLASS_NAME = 'className',
	CONTENT_BOX = 'contentBox',
	DAY = 'day',
	DAY_NAMES = 'dayNames',
	DAY_NAMES_SHORT = 'dayNamesShort',
	DATE = 'date',
	DATE_FORMAT = 'dateFormat',
	DEFAULT_SELECTED = 'defaultSelected',
	DESTROY = 'destroy',
	DISABLED = 'disabled',
	ELEMENT = 'element',
	ELEMENTS = 'elements',
	HOVER = 'hover',
	INNER_HTML = 'innerHTML',
	INPUT = 'input',
	INPUT_NAME = 'inputName',
	LABEL = 'label',
	LABEL_ELEMENT = 'labelElement',
	NAME = 'name',
	OFF = 'off',
	ON = 'on',
	CALENDAR = 'calendar',
	MONTH_NAMES = 'monthNames',
	MONTH_NAMES_SHORT = 'monthNamesShort',
	NAVIGATION = 'navigation'
	WRAPPER = 'wrapper',
	SELECTED_INDEX = 'selectedIndex',
	SHOW_TITLE = 'showTitle',
	SIZE = 'size',
	TITLE = 'title',
	VALUE = 'value',

	getCN = A.ClassNameManager.getClassName,

	CSS_CLEAR_FIX = 'aui-helper-clearfix',
	CSS_WIDGET_HEADER = 'aui-widget-hd',
	CSS_WIDGET_TITLEBAR = 'aui-widget-titlebar',
	CSS_STATE_ACTIVE = ' aui-state-active',
	CSS_STATE_DEFAULT = ' aui-state-default',
	CSS_ICON = 'aui-icon',
	CSS_ICON_LEFT = 'aui-icon-triangle-1-w',
	CSS_ICON_RIGHT = 'aui-icon-triangle-1-e',

	CSS_CALENDAR_LABEL_EL = getCN(CALENDAR, LABEL, ELEMENT),
	CSS_CALENDAR_DAY = getCN(CALENDAR, DAY),
	CSS_CALENDAR_DAY_LABEL = getCN(CALENDAR, DAY, LABEL),
	CSS_CALENDAR_DAY_BLANK = getCN(CALENDAR, DAY, 'blank'),
	CSS_CALENDAR_EL = getCN(CALENDAR, ELEMENT),
	CSS_CALENDAR_EL_HOVER  = getCN(CALENDAR, ELEMENT, HOVER),
	CSS_NAVIGATION_WRAPPER = getCN(CALENDAR, NAVIGATION, WRAPPER);

function Calendar() {
	Calendar.superclass.constructor.apply(this, arguments);
}

A.mix(Calendar, {
	NAME: 'Calendar',

	ATTRS: {
		autoRender: {
			value: true,
			validator: isBoolean
		},

		canReset: {
			value: true,
			validator: isBoolean
		},

		dayNamesShort: {
			value: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
		},

		dayNames: {
			value: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
		},

		date: {
			value: (new Date())
		},

		dateFormat: {
			value: 'mm/dd/yy'
		},

		monthNames: {
			value: ['January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December']
        },

        monthNamesShort: {
        	value: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    	},

		title: null,

		value: null
	}
});

A.extend(Calendar, A.Widget, {
	/*
	* Lifecycle
	*/
	initializer: function() {
		var instance = this;

		instance.date = instance.get(DATE);

		if (instance.get(AUTO_RENDER)) {
			instance.render();
		}
	},

	renderUI: function() {
		var instance = this;

		instance._renderElements();
		instance._renderDayValues();
		instance._renderDayNames();
	},

	bindUI: function() {
		var instance = this;

		A.each(instance.dayValues, function(dayValue, i) {
			dayValue.on({
				click: function() {
					instance.setDate(i + 1);

					instance.syncUI();
				}
			});
		});

		instance.leftArrowWrapper.on({
			click: function() {
				instance.setMonth(instance.date.getMonth() - 1);

				instance.syncUI();
			}
		});

		instance.rightArrowWrapper.on({
			click: function() {
				instance.setMonth(instance.date.getMonth() + 1);

				instance.syncUI();
			}
		});

		instance.get(CONTENT_BOX).on({
			focus: function() {
				instance.calendarWrapper.setStyle("display", 'block');
			},
			blur: function() {
				//instance.calendarWrapper.setStyle("display", 'none');
			}
		});

	},

	syncUI: function() {
		var instance = this;

		instance._syncDate();
		instance._syncDateLabel();
		instance._syncMonthValues();
	},

	destructor: function() {
		var instance = this;
		var	boundingBox = instance.get(BOUNDING_BOX);

		boundingBox.detachAll();
		boundingBox.remove();
	},

	/*
	* Methods
	*/
	_renderElements: function() {
		var instance = this;
		var	boundingBox = instance.get(BOUNDING_BOX);
		var contentBox = instance.get(CONTENT_BOX);

		instance.calendarWrapper = A.Node.create('<div></div>');
		instance.calendarWrapper.set(CLASS_NAME, getCN(CALENDAR, WRAPPER));

		instance.navigationWrapper = A.Node.create('<div></div>');
		instance.navigationWrapper.set(CLASS_NAME, [
			CSS_NAVIGATION_WRAPPER,
			CSS_STATE_DEFAULT,
			CSS_WIDGET_HEADER,
			CSS_CLEAR_FIX
		].join(' '));

		var getArrowWraper = function(arrowClass) {
			var wrapper = A.Node.create('<a href="javascript:void(0);"></a>');
			wrapper.set(CLASS_NAME, getCN(CALENDAR, ARROW));

			var arrow = A.Node.create('<div></div>');
			arrow.set(CLASS_NAME, arrowClass);

			wrapper.appendChild(arrow);

			return wrapper;
		};

		instance.dateLabel = A.Node.create('<label>March 2009</label>');
		instance.dateLabel.set(CLASS_NAME, getCN(CALENDAR, LABEL));

		instance.leftArrowWrapper = getArrowWraper([CSS_ICON, CSS_ICON_LEFT].join(' '));
		instance.rightArrowWrapper = getArrowWraper([CSS_ICON, CSS_ICON_RIGHT].join(' '));

		instance.dayNamesWrapper = A.Node.create('<div></div>');
		instance.dayNamesWrapper.set(CLASS_NAME, CSS_CLEAR_FIX);

		instance.dayValuesWrapper = A.Node.create('<div></div>');
		instance.dayValuesWrapper.set(CLASS_NAME, CSS_CLEAR_FIX);

		instance.navigationWrapper.appendChild(instance.leftArrowWrapper);
		instance.navigationWrapper.appendChild(instance.dateLabel);
		instance.navigationWrapper.appendChild(instance.rightArrowWrapper);

		instance.calendarWrapper.appendChild(instance.navigationWrapper);
		instance.calendarWrapper.appendChild(instance.dayNamesWrapper);
		instance.calendarWrapper.appendChild(instance.dayValuesWrapper);

		boundingBox.appendChild(instance.calendarWrapper);
	},

	_renderDayNames: function() {
		var instance = this;
		var names = instance.get(DAY_NAMES_SHORT);

		instance.dayNamesWrapper.set(INNER_HTML, BLANK);

		A.each(names, function(name, i) {
			var dayName = A.Node.create('<label></label>');
			dayName.set(CLASS_NAME, CSS_CALENDAR_DAY_LABEL);
			dayName.set(INNER_HTML, name);

			instance.dayNamesWrapper.appendChild(dayName);
		});

	},

	_renderDayValues: function() {
		var instance = this;

		instance.dayValues = [];
		instance.blankDays = [];
		instance.biggerDays = [];

		for (var i = 1; i < (instance._getDaysInMonth() + 7); i++) {
			(function(i) {
				var dayValue = A.Node.create('<a href="javascript:void(0);"></a>');
				var value = i - 6;

				dayValue.set(CLASS_NAME, CSS_CALENDAR_DAY);

				if (value < 1) {
					value = '&nbsp;';

					dayValue.addClass(CSS_CALENDAR_DAY_BLANK);

					instance.blankDays.push(dayValue);
				}
				else if (value > 28) {
					instance.biggerDays.push(dayValue);
				}

				if (value > 0) {
					instance.dayValues.push(dayValue);
				}

				dayValue.setAttribute('value', value);
				dayValue.set(INNER_HTML, value);

				instance.dayValuesWrapper.appendChild(dayValue);
			})(i);
		};

	},

	setDate: function(date) {
		var instance = this;

		instance.date.setDate(date);

		instance.get(CONTENT_BOX).setAttribute('value', instance._formatDate(instance.get(DATE_FORMAT), instance.date));

		instance.calendarWrapper.setStyle("display", 'none');
	},

	setMonth: function(month) {
		var instance = this;

		instance.date = instance._getValidDate(instance.date.getFullYear(), month);
	},

	_getDaysInMonth: function(year, month) {
		var instance = this;

		month = month || instance.date.getMonth();
        year = year || instance.date.getFullYear();

        return 32 - new Date(year, month, 32).getDate();
    },

    _getMonthValues: function() {
        var instance = this,
	        monthNames = instance.get(MONTH_NAMES);
	        months = [];

        for (var i = 0; i < 12; i++) {
            months.push({
                value: i,
                caption: monthNames[i]
            });
        }

        return months;
    },

    _getValidDate: function(year, month, day) {
        var instance = this,
        	daysInMonth = instance._getDaysInMonth(year, month);

        if (daysInMonth < instance.date.getDate()) {
            return (new Date(year, month, (day || daysInMonth)));
        }

        return (new Date(year, month, (day || instance.date.getDate())));
    },

    _syncDate: function() {
    	var instance = this,
    		now = instance.date.getDate();

    	A.each(instance.dayValues, function(dv, i) {
			dv.removeClass(CSS_STATE_ACTIVE);

			if ((i + 1) == now) {
				dv.addClass(CSS_STATE_ACTIVE);
			}
    	});

    },

    _syncMonthValues: function() {
    	var instance = this,
    		daysInMonth = instance._getDaysInMonth(),
			firstDay = (new Date(
        		instance.date.getFullYear(),
        		instance.date.getMonth(),
        	1)).getDay();

    	A.each(instance.blankDays, function(dayValue, i) {
    		var display;

    		if (firstDay <= i) {
    			display = 'none';
    		} else {
    			display = 'block';
    		}

    		dayValue.setStyle("display", display);
    	});

    	A.each(instance.biggerDays, function(dayValue, i) {
    		var display;

    		if (dayValue.getAttribute('value') > daysInMonth) {
    			display = 'none';
    		} else {
    			display = 'block';
    		}

    		dayValue.setStyle("display", display);
    	});

    },

    _syncDateLabel: function() {
    	var instance = this,
    		dateFormat = instance.get(DATE_FORMAT);

    	instance.dateLabel.set(INNER_HTML, instance._formatDate('MM yy', instance.date));
    },

    /*
     * jQuery Datepicker method
    */

    _formatDate: function(format, date) {
        var instance = this;

        if (!format) {
            return '';
        }

        if (!date) {
            return '';
        }

        var dayNamesShort = instance.get(DAY_NAMES_SHORT);
        var dayNames = instance.get(DAY_NAMES);
        var monthNamesShort = instance.get(MONTH_NAMES_SHORT);
        var monthNames = instance.get(MONTH_NAMES);

        // Check whether a format character is doubled
        var lookAhead = function(match) {
            var matches = (iFormat + 1 < format.length && format.charAt(iFormat + 1) == match);
            if (matches) {
                iFormat++;
            }
            return matches;
        };

        // Format a number, with leading zero if necessary
        var formatNumber = function(match, value, len) {
            var num = '' + value;
            if (lookAhead(match)) {
                while (num.length < len) {
                    num = '0' + num;
                }
            }
            return num;
        };
        // Format a name, short or long as requested
        var formatName = function(match, value, shortNames, longNames) {
            return (lookAhead(match) ? longNames[value] : shortNames[value]);
        };
        var output = '';
        var literal = false;
        if (date) {
            for (var iFormat = 0; iFormat < format.length; iFormat++) {
                if (literal) {
                    if (format.charAt(iFormat) == "'" && !lookAhead("'")) {
                        literal = false;
                    } else {
                        output += format.charAt(iFormat);
                    }
                } else {
                    switch (format.charAt(iFormat)) {
                    case 'd':
                        output += formatNumber('d', date.getDate(), 2);
                        break;
                    case 'D':
                        output += formatName('D', date.getDay(), dayNamesShort, dayNames);
                        break;
                    case 'o':
                        var doy = date.getDate();
                        for (var m = date.getMonth() - 1; m >= 0; m--)
                        doy += this._getDaysInMonth(date.getFullYear(), m);
                        output += formatNumber('o', doy, 3);
                        break;
                    case 'm':
                        output += formatNumber('m', date.getMonth() + 1, 2);
                        break;
                    case 'M':
                        output += formatName('M', date.getMonth(), monthNamesShort, monthNames);
                        break;
                    case 'y':
                        output += (lookAhead('y') ? date.getFullYear() :
                        (date.getYear() % 100 < 10 ? '0': '') + date.getYear() % 100);
                        break;
                    case '@':
                        output += date.getTime();
                        break;
                    case "'":
                        if (lookAhead("'"))
                        output += "'";
                        else
                        literal = true;
                        break;
                    default:
                        output += format.charAt(iFormat);
                    }
                }
            }
        }

        return output;
    },

	/*
	* Delegated events
	*/
	_delegateMethod: function(event) {
		var instance = this;
		var type = event.type;
		var disabled = instance.get(DISABLED);
		var	elements = instance.get(ELEMENTS);
		var selectedIndex = instance.get(SELECTED_INDEX);
		var index = elements.indexOf(event.target);

		var on = {
			click: function() {
				instance.select(index);
			},
			mouseover: function() {
				instance.fillTo(index, CSS_RATING_EL_HOVER);
			},
			mouseout: function() {
				instance.fillTo(selectedIndex);
			}
		};

		if (type) {
			if (!disabled) {
				on[type]();
			}
			// trigger user callback even when disabled
			instance.fire(type);
		}
	},

	/*
	* Attribute Listeners
	*/
	_afterSetLabel: function(event) {
		this.syncUI();
	}

});

A.Calendar = Calendar;

}, '0.1a' , { requires: [ 'overlay' ] });